# P30 node10 voice-only current preparation

Observed D is a1ae3cb49bd6f295d9f5504d6c825d423886221f, clean. This immutable candidate proposes only 10450054 /scenario_list/9/voice: empty to vo_adv_rom,advg_rom_hikitomeru. UID1045005400010, index9, stable s10450054-p30-at0064, all13 current expected fields, full52-row ordered-array hashes, native/review ownership and manifest summary token are freshly bound. Rom model and executable9→10→11 branches remain exact.

The author supplement and independent31ff303/aff7d33 peer support short-cue identity within the recorded64–70.5s card. Selected active .937076/whole .928996 and pieces .962948/.850598/.913238 remain unchanged; all40 Rom cues and the named Felt control strengthen discrimination, not the scores. The middle-piece weakness and unknown residual cause remain. Waveform zero64.13075 is not an authored trigger offset. Original CSV/voice literal/IDs/phase/gain/loop, full spoken dialogue, listening, actor/motion and saved gameplay are not accepted.

The existing WAV97012B/5fc28f… matches package and peer. Default Opus5149B/419e89… is bound by fresh opaque bytes/SHA and current metadata only; no Opus decoding, listening, quality or source-phase comparison was performed. No export, encoding or asset registration is proposed. Native-chain and source-provenance limits remain in preflight.rootfalse.json and its exact original evidence references.

No stage/audit/apply/helper/matcher/decoder/API/browser or formal D/C/Git write occurred. Only selected WAV/Opus opaque hashing and metadata/read-only Git were used. The current write hold for UI review remains in force; all candidate approval/execution/install flags are false and final bindings are null.

After Root releases its write hold, Root must independently recheck final HEAD/status, full13 fields/pair/array/ownership/resources/code/directory and full current global/protected22 coverage. Clone into a new explicitly approved packet; retain the old sealed evidence. The existing real CLI shapes, not executed here, are:

```sh
nice -n19 taskset -c0,1 /usr/bin/python -B -m story_studio.recovery.native_repair --root ROOT --target D --directory EXACT_NATIVE_DIRECTORY --node-fields NEW_ROOT_APPROVED_PACKET --output NEW_ABSENT_STAGE
nice -n19 taskset -c0,1 /usr/bin/python -B -m story_studio.recovery.native_install --root ROOT --target D --staging SAME_STAGE
```

Only a later root-authorized apply adds --apply to the same native_install command, after real stage/audit delta review. No fixed changed-file count is assumed. Native change must be exactly the one voice leaf; target evidence/unknown-field/derived warning and normal summary/ownership/batch bookkeeping are reviewed as actual output. Other139 pairs, first-three22, prior voice/character work and all structural/acting fields remain guarded.
