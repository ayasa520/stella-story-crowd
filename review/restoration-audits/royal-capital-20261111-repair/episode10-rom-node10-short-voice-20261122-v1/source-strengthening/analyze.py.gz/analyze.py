"""Bounded numerical controls for one existing scene54/node10 cue candidate.

The fixed source interval, original FIR preparation and original NCC evaluator
are preserved. A complete shipped Rom bank adds negative controls; time masks
only restrict scored cue-zero coordinates and never crop or modify a waveform.
No decoder, playback, source-video access, installation or actor inference runs.
"""
from pathlib import Path
import ast
import contextlib
import hashlib
import io
import json
import os
import resource
import sys
import traceback
import wave

P = Path('/home/rikka/Projects/stella')
A = P / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
R = P / 'data/native_recovery/royal-capital-20261110/repair-20261111'
B = R / 'p30-scene54-three-voices-preflight-20261113-v1'
HERE = Path(__file__).resolve().parent
SOURCE = R / 'p30-bgm-identification-20261113-v1/p30-original-source.wav'
VERIFIER = B / 'verify10.py'
OLD = B / 'measurements10-window-v2.json'
MODULE = P / 'story_studio/recovery/audio_correlation.py'
INDEX = R / 'audio/waveform-graphs/p30-d7d29c63dc09/audible-review/index.json'
RATE = 4000
WINDOW = (61, 73)
CARD = (64, 70.5)
EVENT = (64.03075, 64.23075)
BANK, CUE = 'vo_adv_rom', 'advg_rom_hikitomeru'
CAP = 1024 * 1024


def digest(data):
    return hashlib.sha256(data).hexdigest()


def guard(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def save(name, value, *, append=False):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False,
                                                         allow_nan=False, separators=(',', ':')) + '\n'
    data = text.encode()
    used = sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())
    if used + len(data) >= CAP:
        raise RuntimeError('Bounded metadata output cap reached')
    with (HERE / name).open('ab' if append else 'xb') as f:
        f.write(data)


def fail(kind, value, tb):
    if not (HERE / 'first-error.txt').exists():
        save('first-error.txt', ''.join(traceback.format_exception(kind, value, tb)))
    if globals().get('inputs') and not (HERE / 'inputs-on-error.json').exists():
        save('inputs-on-error.json', [guard(p) for p in inputs])
    if globals().get('log') and not (HERE / 'numerical.stdout.log').exists():
        save('numerical.stdout.partial.log', log.getvalue())
    sys.__excepthook__(kind, value, tb)


sys.excepthook = fail
resource.setrlimit(resource.RLIMIT_NICE, (1, 1))
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
assert sorted(os.sched_getaffinity(0)) == [0, 1]
for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    assert os.environ[key] == '1'
sys.path.insert(0, str(P))
import numpy as np
from story_studio.recovery.audio_correlation import WaveformCorrelation

assert len(list(Path('/proc/self/task').iterdir())) == 1
assert guard(VERIFIER)['sha256'] == '816f31444e165ce2dd65dabfc8144f8e9eb0821b510781a8e496d5789d51b9d9'
assert guard(OLD)['sha256'] == 'a6e1e891557e7c47e0f086796c601bf05bddda895f44f953d17cab745beda52c'
assert guard(MODULE)['sha256'] == '55d38019873e50244ada14cbaa4172467ed11e90a0ad86e1e1dc972827d49444'
assert guard(SOURCE)['sha256'] == 'ce16138f1b12168383cdb88c7bdb7e390b7b0c0fb67b2fad9c6d7eac53e01831'
catalog = json.loads((D / 'assets/catalog.json').read_text())
package = json.loads((D / 'assets/package.json').read_text())
native = json.loads((D / 'native/scenes/10450054.json').read_text())
review = json.loads((D / 'review/scenes/10450054.json').read_text())
row = next(x for x in native['scenario_list'] if x['scenario_id'] == 10)
assert row['voice'] == '' and row['uniq_id'] == 1045005400010
assert review['scenarios']['10']['stableKey'] == 's10450054-p30-at0064'
draft = json.loads((B / 'node-fields-draft.json').read_text())
change = next(c for c in draft['changes'] if c['scenarioId'] == 10)
assert all(row[key] == value for key, value in change['expected'].items())
assert review['scenarios']['10']['sourceText'] == change['sourceText']
old = json.loads(OLD.read_text())
assert old['sourceWindowPcmSeconds'] == [61, 73]
assert old['bank'] == BANK and old['cue'] == CUE
entries = sorted(catalog['voices'][BANK]['cues'], key=lambda c: c['cue'])
assert len(entries) == 40
population = [(BANK, c['cue'], D / 'assets' / c['url']) for c in entries]
felt = next(c for c in catalog['voices']['vo_adv_felt']['cues'] if c['cue'] == 'advk_felt_tenkan')
population.append(('vo_adv_felt', felt['cue'], D / 'assets' / felt['url']))
assert len(population) == 41
historical = next(c for c in json.loads(INDEX.read_text())['candidates']
                  if c['member'] == 'LIMEOS/audio/vo_adv_rom/advg_rom_hikitomeru.wav')
clip = INDEX.parent / historical['sourceClip']['path']
assert guard(clip)['sha256'] == historical['sourceClip']['sha256']
inputs = [SOURCE, VERIFIER, OLD, B / 'extend_competitor_windows.py',
          B / 'node-fields-draft.json', MODULE, INDEX, clip,
          D / 'assets/catalog.json', D / 'assets/package.json',
          D / 'native/scenes/10450054.json', D / 'review/scenes/10450054.json']
inputs += [p for _, _, p in population]
before = [guard(p) for p in inputs]
save('inputs-before.json', before)
settings = dict(backend='cpu', query_fft_cache_bytes=8388608,
                memory_limit_bytes=67108864, fft_plan_cache_bytes=0)
save('parameters.json', dict(sourceWindow=WINDOW, sourceCard=CARD,
                            fixedPriorEventInterval=EVENT, population=[dict(bank=b, cue=c, path=str(p))
                                                                       for b, c, p in population],
                            bankCueCount=40, extraNamedControlCount=1,
                            activeThresholdFraction=.02, activeMarginSeconds=.025,
                            peakCount=5, peakSeparationSeconds=.4,
                            resampling='Unchanged original129-tap Hamming sinc1800Hz to4k',
                            settings=settings, originalCueZeroIsAuthoredTime=False,
                            original8kSourceClip=historical['sourceClip'],
                            existing8kMatch=historical['match'],
                            existing8kClipNumericallyReprocessed=False,
                            subprocessesAllowed=0, outputCap=CAP))
state = dict(pid=os.getpid(), pgid=os.getpgrp(), nice=19, affinity=[0, 1],
             threadsObserved=1, numpy=np.__version__, subprocesses=0)
save('process-start.json', state)
print('NUMERIC_STARTED ' + json.dumps(state), flush=True)

# Extract only these already-reviewed pure numerical definitions. The original
# helper's @UTF parsing, installers, historical paths and file-writing main do
# not execute. This also preserves the original signed-NCC arithmetic exactly.
text = VERIFIER.read_text()
tree = ast.parse(text)
names = ['read_pcm', 'to_4k', 'measure']
nodes = [next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)
         for name in names]
scope = dict(np=np, wave=wave, RATE=RATE, WINDOW=WINDOW)
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(VERIFIER), 'exec'), scope)
read_pcm, to_4k, measure = [scope[name] for name in names]
source, layout = read_pcm(SOURCE, *WINDOW)
assert layout == dict(channels=1, sampleBytes=2, rate=4000, frames=4026711)
assert len(source) == 48000
source -= source.mean()
comparisons = []
scope.update(source=source, comparisons=comparisons)
log = io.StringIO()
rows = []
selected = None


def restricted(template, cue_offset, interval):
    """Restrict existing score coordinates, retaining all five signed peaks."""
    template = template.copy()
    template -= template.mean()
    query = compute.query(template, float(np.dot(template, template)))
    scores = compute.scores(signal, query)
    zero_coordinates = WINDOW[0] + np.arange(len(scores)) / RATE - cue_offset
    allowed = (zero_coordinates >= interval[0]) & (zero_coordinates <= interval[1])
    masked = np.where(allowed, scores, -np.inf)
    values = []
    for at, score in compute.peaks(masked.copy(), 5, 0, round(.4 * RATE)):
        # Original suppression emits zero placeholders when a narrow mask has
        # no further separated positive peak. Preserve the unmodified global
        # evaluator, but do not mislabel these as peaks inside this time mask.
        if score <= 0 or not allowed[at]:
            continue
        block = source[at:at + len(template)]
        centered = block - block.mean()
        signed = float(np.dot(centered, template) /
                       np.sqrt(np.dot(centered, centered) * query.energy))
        values.append(dict(cueZeroPcmSeconds=WINDOW[0] + at / RATE - cue_offset,
                           templateStartPcmSeconds=WINDOW[0] + at / RATE,
                           absoluteNcc=score, signedNcc=signed,
                           lagSamplesInSourceWindow=at))
    return dict(cueZeroInterval=interval, availableLagPositions=int(allowed.sum()),
                requestedSeparatedPeaks=5, zeroSuppressionPlaceholdersExcluded=True,
                peaks=values)


with contextlib.redirect_stdout(log):
    with WaveformCorrelation(settings) as compute:
        signal = compute.signal(source, 1 << (len(source) + 8000 - 2).bit_length())
        assert signal.fft_size == 65536
        scope.update(compute=compute, signal=signal)
        for bank, cue, path in population:
            wavguard = next(x for x in before if x['path'] == str(path))
            rel = str(path.relative_to(D / 'assets'))
            assert package['files'][rel]['sha256'] == wavguard['sha256']
            pcm, geometry = read_pcm(path)
            converted = to_4k(pcm, geometry['rate'])
            active = np.flatnonzero(np.abs(converted) >= np.max(np.abs(converted)) * .02)
            left = max(0, int(active[0]) - round(RATE * .025))
            right = min(len(converted), int(active[-1]) + round(RATE * .025) + 1)
            query = converted[left:right]
            assert len(source) + len(query) - 1 <= signal.fft_size
            global_result = measure(bank + '/' + cue + '-active', query, left / RATE)
            item = dict(bank=bank, cue=cue, input=wavguard, layout=geometry,
                        resampledSamples=len(converted), activeSamples=len(query),
                        activeOffsetSamplesAt4k=left, globalResult=global_result,
                        withinRecordedCard=restricted(query, left / RATE, CARD),
                        withinPriorEvent=restricted(query, left / RATE, EVENT))
            rows.append(item)
            save('all-candidates.raw.jsonl', item, append=True)
            if bank == BANK and cue == CUE:
                selected = converted, query, left
        assert selected is not None
        converted, active, left = selected
        measure(BANK + '/' + CUE + '-whole-existing-cue', converted)
        borders = [0, len(active) // 3, len(active) * 2 // 3, len(active)]
        for i in range(3):
            a, b = borders[i:i + 2]
            measure(CUE + f'-piece{i + 1}', active[a:b], (left + a) / RATE)
save('numerical.stdout.log', log.getvalue())
by_label = {c['label']: c for c in comparisons}
for baseline in old['comparisons']:
    fresh = by_label[baseline['label']]
    assert fresh['templateDuration'] == baseline['templateDuration']
    assert fresh['templateStartInCueSeconds'] == baseline['templateStartInCueSeconds']
    for a, b in zip(fresh['peaks'], baseline['peaks']):
        for key in ['cueZeroPcmSeconds', 'templateStartPcmSeconds', 'absoluteNcc', 'signedNcc']:
            assert abs(a[key] - b[key]) < 1e-12, (baseline['label'], key, a[key], b[key])
save('selected-whole-and-pieces.json', [x for x in comparisons if x['label'] in
     [BANK + '/' + CUE + '-active', BANK + '/' + CUE + '-whole-existing-cue']
     or x['label'].startswith(CUE + '-piece')])
selected_row = next(x for x in rows if x['bank'] == BANK and x['cue'] == CUE)
controls = [x for x in rows if x is not selected_row]
rankings = {}
for field in ['globalResult', 'withinRecordedCard', 'withinPriorEvent']:
    rankings[field] = sorted([dict(bank=x['bank'], cue=x['cue'], peak=x[field]['peaks'][0])
                              for x in controls if x[field]['peaks']],
                             key=lambda x: x['peak']['absoluteNcc'], reverse=True)
after = [guard(p) for p in inputs]
save('inputs-after.json', after)
assert before == after
summary = dict(schema='stella.p30.scene54.node10.bounded-voice-controls.v1',
               rootConfirmed=False, installationAuthorized=False,
               target=dict(sceneId=10450054, scenarioId=10, UID=1045005400010,
                           stableKey='s10450054-p30-at0064', expected=dict(voice=''),
                           fields=dict(voice='vo_adv_rom,advg_rom_hikitomeru')),
               originalFourReferenceWholeAndPieceResultsReproduced=True,
               sourceLayout=layout, sourceWindow=WINDOW, samplesInWindow=len(source),
               candidates=41, RomBankCues=40, namedFeltControl=1,
               allCandidatesRaw=guard(HERE / 'all-candidates.raw.jsonl'),
               selected=selected_row, controlRankings=rankings,
               priorNativeBinding=old['nativeBinding'],
               sourceCardBoundaryEvidence=review['scenarios']['10']['recordings'],
               oldVoiceAndCharacterSpeakerChineseStillExact=True,
               newPCMFilesExported=False, decoderOrSubprocessRun=False,
               listened=False, originalCSVPhaseOffsetGainRecovered=False,
               fullDialogueSpeechOrWholeSceneAccepted=False,
               rootIdentityOrFieldAcceptanceGranted=False)
save('measurements.rootfalse.json', summary)
state.update(exitCode=0, allInputsBeforeAfterExact=True, records=41,
             threadsObservedAtEnd=len(list(Path('/proc/self/task').iterdir())))
assert state['threadsObservedAtEnd'] == 1
save('process-completion.json', state)
files = {p.name: guard(p) for p in sorted(HERE.iterdir()) if p.is_file()}
save('receipt.rootfalse.json', dict(schema='stella.p30.node10.bounded-controls.receipt.v1',
                                  rootConfirmed=False, installationAuthorized=False,
                                  payloads=files, outputCap=CAP, subprocesses=0,
                                  sourceOrExistingDataWritten=False,
                                  automaticRetry=False, finalPublishedHEAD=None))
print('RESULT ' + json.dumps(dict(process=state,
      selectedGlobal=selected_row['globalResult']['peaks'][0],
      highestControlAtPriorEvent=rankings['withinPriorEvent'][0],
      highestControlWithinCard=rankings['withinRecordedCard'][0],
      totalOutputBytes=sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())),
      ensure_ascii=False), flush=True)
