# Scene10450054/node10: bounded voice identity supplement

The pure PCM run completed once, exit0, chunk0c8f36, PID/PGID1128; OS now shows that PID/group absent. Nice19, CPUs0/1, one thread, no child process/decoder/browser. All53 input paths were freshly hashed before/after and remained exact. No PCM file or media copy was created.

The original129-tap1800Hz Hamming/sinc preparation and NCC evaluator reproduced every original four-reference/whole/piece peak within1e-12. Selected active signed NCC remains0.9370760033541601, whole0.9289961294024528. Its three disjoint1106-sample pieces remain positive .962948/.850598/.913238 at the same cue-zero64.13075s. Scores were not improved, retimed or fitted.

New fixed controls cover all40 shipped Rom cues plus the previously named Felt cue, in exactly the existing61–73s source PCM window. All41 candidate results retain original five separated global peaks and signed scores, plus card64–70.5s and prior event64.13075±.1s masks. Time masks restrict score coordinates and do not edit samples.

| Comparison | Strongest other cue | Signed NCC | Cue zero |
|---|---|---|---|
|Prior event|advg_rom_kanasii|0.235377348|64.130500s|
|Recorded card|advg_rom_damage|0.255340092|68.242500s|
|Full12s window|advk_felt_tenkan|0.884391408|71.348500s|

The strongest full-window control is Felt at71.3485s, outside this card. Full-bank controls strengthen discrimination of the existing cue identity. They do not make the lower original correlation values equal to26/27, nor remove the .850598 middle-piece limitation. NCC is a similarity statistic, not a correctness rate. No cause is invented for residual differences.

Existing original metadata binds CueId9→Sequence9→Track/Event9→Synth/Waveform9→AWB Stream9; mono48000Hz/48484samples, entry117888–130272. It remains referenced by the unchanged old measurement SHA; no native parser was rerun. The historical8k match .923366 and exact existing8k source-clip SHA are recorded, not numerically reprocessed.

This supports preparing a separately reviewed voice-only candidate: UID1045005400010, stable s10450054-p30-at0064, empty voice→vo_adv_rom,advg_rom_hikitomeru. Root and independent peer decide acceptance and fresh normal-import binding; no automatic install or shared acceptance with26/27 follows. Original CSV/voice literal, original scenario IDs, trigger phase/offset/gain, subjective listening, full dialogue speech, actor/motion and normal whole-scene transport remain unaccepted.
