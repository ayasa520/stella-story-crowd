# Mimi105 B1F1 lossless coverage follow-up — source only

This kit has no freeze, Worker, API, browser, recorder, decode or image-review
execution authority. Root must finish the Mimi100 and UI evidence publications,
bind the final exact HEAD/ACK and fresh complete inventory, review the source
peer, then issue separate preparation and one-attempt runtime releases. All
templates remain false. The full restoration goal and every candidate's
body/face/performance acceptance remain open.

The original packet retains all four candidates and freeze validates all four.
This follow-up explicitly selects only `mimi105-B1F1`: original `act_banzai_w`
with explicit `face_egao`; selection is not body/face/performance acceptance.
Only input v3 `50c5f227…` is admitted. Native/check changes use the actual
dot/bracket `scenario_list[104].motion`, scenarioId105 schema; the independent
native semantic delta keeps RFC6901 `/scenario_list/104/motion`. Prepared
`extra_motions` is inspected through an audit projection called `extras`, never
renamed or written into the complete received program.

These are contracts for the current canonical normal parser, not a proof of
all original native CSV semantics. Original GetLayerName classifies act_/face_
content; the GetTriggerName bare/_w predicate and newline-to-layer caller are
not globally resolved here. The four bounded body-first/face-second cases use
actual Mimi controller resources. No parser, original command phase or global
suffix rule is changed or accepted by this diagnostic.

`freeze.py` writes complete private10040043 native documents under this new A
directory and changes exactly one motion leaf. Original array/key order,
IDs/UIDs, all text/commands/branches/other fields and the complete review stay
unchanged. Full semantic comparison plus independent undo equality are required.
Fresh node104/105/106 IDs, JP/ZH anchors and branches are checked. Controller and
motion-index Mimi definitions must match the original evidence; original model,
MOC, texture and41 motion hashes must match the fresh D inventory. These checks
do not accept a rendered performance. Private aliases are not Git commits.

The normal compiled Worker remains unchanged. The preloaded transport replaces
only complete `native/scenes/10040043.json` bytes for its bound alias; formal
HEAD/main and every other file remain exact baseline bytes. Native/check always
uses the formal baseline revision and checks the selected full candidate document
before candidate preparation. Raw status/headers/bytes/issues are retained
before assertions; a validation delta or ordinary422 aborts. There is no seed,
incoming-choice guess, retry, root-entry fallback, or program override. In
particular, prepare's override acts only on body.id: preparing104 cannot use it
to modify105, so every prepare request has no override.

One complete formal baseline and one complete ordinary prepare104 response
are compared without deleting or normalizing fields. Only target105 body/face
and existing alias headSha/revision/semantics.effect_manifest leaves may differ.
Complete `before`, all other nodes and fields, edges, directory, commands,
unknown rows and metadata stay exact. The actual private browser request must
repeat the same request and return the same raw and complete-program hashes.
That original object enters the normal `stella-player-load` protocol unchanged.

The driver uses one owned Firefox and one fresh B1F1 document. Its
continuous500x1000/30fps/no-audio capture begins with a real first-X-frame ACK
before program load, follows104 Felt →105 Mimi →106 Felt, and never advances106
or enters107. Both flank nodes finish their real entry/panel and one actual
Actor second at ready. Mimi includes loading/fade/entry/natural typing/panel;
the original post-compose tap then confirms actual resting tokens, original
state.loop and absent active blend. At least four actual Actor seconds after
that observed settlement are recorded before ordinary Advance. A two-Normal-
second scheduling delay only chooses when to read; it is not native timing or
the settlement proof. No token, face weight, loop, clock, authored Wait or pose
is written after load. Empty face must show no explicit face layer. Full source
and actual video review follows independent OS closure; B1F0 is a discriminating
negative face control, not an expected accepted performance.

The read tap and owner-events remain existing immutable external sources.
Renderer/panel/GL/trusted-input/native-edge gates and the first-frame recorder
handshake reuse the P30 full-program lane. Original owner captures are retained
before rejecting byte bounds, and raw crossing BiDi/HTTP rows are retained.
Post-result tails are kept through session retirement; a late original fatal
fact rejects the single-case terminal decision. The decoded-curve audit compares
actual archived objects with the guarded original pure decoder, never a live
actor. Generation qualifications remain artifact-local and do not invent native
StoryPlayer/animator generations or painted-pixel acceptance.

The supervisor retains the P30 independent owned-role stop mechanics and
exclusive0600 X authority, adds the exact reviewed UI31 deferred-signal block,
and registers every Popen before a cooperative stop boundary. Every role gets
cleanup despite another failure. New direct-PID and announced BiDi/Worker port
proofs precede temporary profile/authority deletion. Root still independently
checks escaped processes, ports, display/profile and complete inputs after the
original terminal. No foreign process is signalled.

All heavy descendants remain nice19/CPU0,1. Original per-case caps are not
widened:120s/case,1000s total,3600 frames/18MB video,12000 tap rows,512 owner rows,
6000 console rows/4MB,160MB raw/32MB gzip tap,8 checkpoints,4000 HTTP rows,
20000 provider rows/12MB. Root additionally supplies Node heap, summed owned
process RSS, aggregate output, available-memory and disk-reserve bounds; no
guessed current machine capacity is accepted. Shared pages count per process in
the conservative RSS sum. Decoder/filter/encoder threads remain one. Sources,
tools, C/dist and all tracked D bytes use one fresh inventory reference, expanded
only in RAM; deleted historical screenshot inventories are never rebuilt.

Future preparation uses the released Node binary and explicit heap bound with
`--import ./transport.mjs ./prepare.mjs`; missing transport fails before API use.
Future runtime uses the released Python with `-B run.py --release …
--release-sha256 … --attempt attempt-1`. A failed original attempt is not retried.
Source syntax checks alone do not prove normal prepare104 is unambiguous, real
clip delivery, runtime budgets, complete capture, or source matching.

This source-only follow-up requests libx264rgb/CRF0/rgb24, ultrafast and one
FFmpeg encoder/filter thread. Legacy maxrate/bufsize requests are removed;
encoded bitrate may rise. The 18MB -fs, 256MiB total, frame/wall caps stay hard.
Software renderer LP_NUM_THREADS is two, with CPU0,1/nice19 and other thread
limits unchanged. Capability help proves availability only; actual logs and
pixels must establish the resulting capture. No quality fallback or retry is
allowed after a bound/failure. The original B4 warnings and coverage gaps remain.
The existing capture.log will also retain format=rgb24,showinfo before the
encoder, including per-frame PTS/checksums and the original input start_time.
This adds no raw frame dump or second runtime log; filter overhead is unknown.
Future RGB decode checks must match that record. These timestamps are not
claimed to be first GL paint, and no new fps/clock/PTS transform is introduced.
