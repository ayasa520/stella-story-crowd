// One private B1F1 candidate through the untouched complete
// 104->105->106 StoryPlayer program in one owned Firefox document.
// All inputs remain candidates; full source/actual review follows OS closure.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,appendFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {createInterface} from 'node:readline';
import {setTimeout as delay} from 'node:timers/promises';
import {connect} from '../../stella-p30-firefox-20261120/bidi.mjs';
import {installRenderProbe} from '../../stella-p30-firefox-20261120/render-probe.mjs';
import {auditCurves} from './curve-audit.mjs';
import {runtimeGate,readHeldJson,parseHeldJson} from './context.mjs';
const here=new URL('./',import.meta.url),origin='http://127.0.0.1:5198';
const {release:runtimeRelease,bindingBytes,binding,releaseSha256}=await runtimeGate(here,import.meta.url),budgets=binding.budgets;
const preparations=await readHeldJson(new URL('prepared/index.json',here),{
  output:process.env.STELLA_PRIVATE_OUTPUT,sha256:runtimeRelease.normalPreparationIndexSha256});
const output=process.env.STELLA_PRIVATE_OUTPUT;assert.ok(output);
const sha=b=>createHash('sha256').update(b).digest('hex');
// Match the owner classifier independently against retained original facts.
// Hitches, cancellation and observation overhead are deliberately separate.
const fatalProductNames=new Set(['STORY_PLAYER_ERROR','STORY_NORMAL_CLOCK_LISTENER_ERROR','STORY_NORMAL_CLOCK_REPORT_ERROR',
    'STORY_FX_ERROR','STORY_BACKGROUND_ERROR','STORY_PICTURE_ERROR','STORY_BGM_LOAD_FAILED']);
function rejectOriginalProductErrors(){
  assert.deepEqual(active.productFatalErrors,[],'Original product fatal diagnostics reject this case');
  assert.equal(active.productFatalDropped,0,'Original product fatal collection overflow');
}
const save=async(folder,name,value)=>writeFile(resolve(folder,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const driver=await connect(process.argv[2]);
let target,active=null,stage='session',capabilities,ipcSequence=0,firstFailure=null,sessionRetired=false;
const pending=new Map(),reader=createInterface({input:process.stdin});
const caseStates=[],completedCases=[];
reader.on('line',line=>{parseHeldJson(line,{path:'original supervisor IPC reply',output}).then(value=>{
  const job=pending.get(value.replyTo);if(job){pending.delete(value.replyTo);clearTimeout(job.timer);
    value.ok?job.resolve(value):job.reject(Error(value.error||'Supervisor IPC failure'));}
}).catch(error=>{if(active)active.errors.push(String(error));});});
function supervisor(type,caseId){return new Promise((resolve,reject)=>{
  const id=++ipcSequence,timer=setTimeout(()=>{pending.delete(id);reject(Error('Supervisor '+type+' timeout'));},20000);
  pending.set(id,{resolve,reject,timer});process.stdout.write('OWNER_IPC '+JSON.stringify({id,type,caseId})+'\n');
});}
async function evaluate(fn,arg){
  const reply=await driver.call('script.evaluate',{target,awaitPromise:true,
    expression:`(async()=>JSON.stringify(await (${fn})(${JSON.stringify(arg)})))()`});
  if(reply.type!=='success')throw Error(reply.exceptionDetails?.text||'Firefox evaluation failed');
  return reply.result.type==='undefined'?null:parseHeldJson(reply.result.value,{path:'original Firefox evaluation result',output});
}
async function state(){return evaluate(()=>window.reviewPrivateOwner?.state()||null);}
async function waitFor(fn,arg,timeout=45000){
  const end=Math.min(Date.now()+timeout,active.deadline);
  while(Date.now()<end){
    if(active.errors.length)throw Error(active.errors.at(-1));
    rejectOriginalProductErrors();
    const owner=await state();
    if(owner?.errors.length||owner?.traceDropped||owner?.mediaDropped||owner?.errorDropped)throw Error('Owner diagnostic error/drop; preserve original evidence');
    if(owner?.productFatalSeen||owner?.productFatalDropped||owner?.productFatalErrors.length)
      throw Error('Original product fatal diagnostic observed; preserve raw evidence and abort later cases');
    if(owner?.entered.some(id=>!active.plan.steps.some(s=>s.id===id)))throw Error('Natural route crossed declared boundary; retained without pause/cancel');
    const found=await evaluate(fn,arg);if(found)return found;
    for(const selector of ['#voiceContinue','#movieContinue']){
      const permission=await evaluate(selector=>{const e=document.querySelector(selector);return e&&!e.hidden&&!e.disabled&&e.checkVisibility();},selector);
      if(permission)await click(selector,null,null);
    }
    await delay(70);
  }
  throw Error('Bounded ordinary condition timed out: '+stage);
}
async function click(selector,node,phase){
  const point=await evaluate(({selector,node,phase})=>{
    if(node&&(document.body.dataset.node!==node||document.body.dataset.phase!==phase))throw Error('Normal control no longer belongs to expected ready node');
    const e=document.querySelector(selector);if(!e||e.disabled||!e.checkVisibility())return null;
    const r=e.getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)};
  },{selector,node,phase});assert.ok(point,selector);
  active.actions.push({selector,node,phase,before:await state()});
  await driver.call('input.performActions',{context:target.context,actions:[{type:'pointer',id:'mouse',parameters:{pointerType:'mouse'},
    actions:[{type:'pointerMove',origin:'viewport',...point,duration:0},{type:'pointerDown',button:0},{type:'pointerUp',button:0}]}]});
}
async function mark(name){const value=await evaluate(name=>window.reviewPrivateOwner.mark(name),name);active.marks.push(value);return value;}
async function checkpoint(label,step){
  const item=await evaluate(label=>window.reviewPrivateOwner.checkpoint(label),label);
  assert.ok(item.row,'Actual primary actor post-compose row required');assert.equal(item.row.node,step.id);assert.equal(item.row.model,step.expectedModel);
  assert.equal(item.row.primaryStoryActor.actualBacklinkVerified,true);assert.equal(item.row.normal.previewRate,1);
  assert.equal(item.row.actualProductFields.storyPlayerCurrentGeneration.value,null);
  assert.equal(item.row.actualProductFields.animatorGeneration.value,null);
  assert.equal(item.tapDropped,0);assert.equal(item.tapOwnerDropped,0);assert.deepEqual(item.tapErrors,[]);
  active.checkpoints.push(item);return item;
}
async function surface(){
  return evaluate(()=>{
    const actor=document.getElementById('actor'),card=document.getElementById('cardMotion'),panel=document.getElementById('subtitles');
    return {node:document.body.dataset.node,phase:document.body.dataset.phase,wallMilliseconds:performance.now(),
      card:{opacity:Number(getComputedStyle(card).opacity),visible:card.checkVisibility({opacityProperty:true,visibilityProperty:true})},
      panel:{opacity:Number(getComputedStyle(panel).opacity),translate:getComputedStyle(panel).translate,
        visible:panel.checkVisibility({opacityProperty:true,visibilityProperty:true})},
      actorVisible:actor.checkVisibility({opacityProperty:true,visibilityProperty:true}),
      pictureHidden:document.getElementById('picture').hidden,text:document.getElementById('accessibleText').textContent,
      render:window.reviewRenderProbe.snapshot()};
  });
}
function verifySurface(value,step){
  assert.equal(value.node,step.id);assert.equal(value.pictureHidden,true);
  assert.equal(value.render.losses.filter(e=>e.canvas==='actor'||e.attached).length,0,
    'Actor/attached-context loss history survives restoration');
  if(step.expectedModel)assert.equal(value.actorVisible,true);
}
async function visibleTarget(step){
  const observed=await waitFor(({id,model})=>{
    const s=window.reviewPrivateOwner.state(),actor=document.getElementById('actor'),card=document.getElementById('cardMotion');
    const gl=window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor');
    return s.node===id&&s.latest.commits[id]?.detail.model===model&&
      s.latest.displays[id]?.kind==='actor'&&s.latest.displays[id]?.model===model&&
      Number(getComputedStyle(card).opacity)>0&&card.checkVisibility({opacityProperty:true,visibilityProperty:true})&&
      actor.checkVisibility({opacityProperty:true,visibilityProperty:true})&&gl?.attached&&!gl.lost&&gl.draws>0&&
      {draws:gl.draws,phase:s.phase,normal:s.normal,wallMilliseconds:performance.now()};
  },{id:step.id,model:step.expectedModel});
  const visual=await surface();verifySurface(visual,step);
  const point=await checkpoint('105-first-observed-visible',step);
  // This sampled marker is not the exact first paint or native phase zero.
  // The X recording predates program load and retains the earlier fade. Never
  // reset animator time/layers to make this observational anchor look native.
  return {observed,visual,point};
}
async function readySurface(step,configuration){
  await waitFor(id=>document.body.dataset.node===id&&document.body.dataset.phase==='ready',step.id);
  const group=step.native.msg_character?configuration.player.panels.dialogue:configuration.player.panels.narration;
  const profile=configuration.transitions.panel_entries?.[group];
  const owned=await waitFor(({id,model,group,profile,command})=>{
    const s=window.reviewPrivateOwner.state(),card=document.getElementById('cardMotion'),panel=document.getElementById('subtitles');
    const start=s.latest.panelStart[id]?.detail,complete=s.latest.panelComplete[id]?.detail;
    const panelOwned=!profile||(start&&complete&&start.node===id&&complete.node===id&&
      start.group===group&&complete.group===group&&start.token===complete.token&&!s.latest.panelCancelled[group+':'+start.token]);
    const display=s.latest.displays[id],commit=s.latest.commits[id]?.detail;
    const gl=window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor');
    const foreground=model?display?.kind==='actor'&&display.model===model&&commit?.model===model&&commit.command===command&&
      gl?.attached&&!gl.lost&&document.getElementById('actor').checkVisibility({opacityProperty:true,visibilityProperty:true}):
      display?.kind==='empty';
    return s.node===id&&s.phase==='ready'&&foreground&&panelOwned&&Number(getComputedStyle(card).opacity)>=.99&&
      Number(getComputedStyle(panel).opacity)>=.99&&getComputedStyle(panel).translate==='none'&&
      panel.checkVisibility({opacityProperty:true,visibilityProperty:true})&&
      {start:start||null,complete:complete||null,group,profile:profile||null,draws:model?gl.draws:null,display,commit:commit||null};
  },{id:step.id,model:step.expectedModel,group,profile:profile||null,
    command:[step.parsedMotion.body,step.parsedMotion.face,...step.parsedMotion.extras].filter(Boolean).join(',')});
  if(step.expectedModel)await waitFor(draws=>{
    const gl=window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor');return gl?.attached&&!gl.lost&&gl.draws>draws+3;
  },owned.draws);
  const visual=await surface();verifySurface(visual,step);assert.equal(visual.phase,'ready');
  assert.ok(visual.text.includes(step.native.msg_text));
  const value={scenario:step.scenario,owned,visual};active.surfaces.push(value);return value;
}
async function flankObservation(step,configuration){
  const ready=await readySurface(step,configuration),began=await checkpoint(step.scenario+'-own-natural-ready',step);
  const required=began.row.actorSeconds+active.plan.observation.flankReadyActorSeconds;
  const reached=await waitFor(({node,target})=>{const state=window.reviewPrivateOwner.state();
    return state.node===node&&state.phase==='ready'&&state.normal.gameSeconds>=target&&state.normal;
  },{node:step.id,target:began.row.normal.gameSeconds+active.plan.observation.flankReadyActorSeconds});
  await waitFor(({node,frame})=>{const state=window.reviewPrivateOwner.state();
    return state.node===node&&state.phase==='ready'&&state.normal.frame>frame;
  },{node:step.id,frame:reached.frame});
  const ended=await checkpoint(step.scenario+'-flank-actor-time',step);
  assert.equal(ended.row.observerIdentity.animator,began.row.observerIdentity.animator);
  assert.ok(ended.row.actorSeconds>=required,'Actual flank Actor second not observed');
  return {scenario:step.scenario,ready,began,ended,sourcePerformanceAccepted:false};
}
function settledLayers(point,step){
  const body=point.row.layers.find(layer=>layer.name==='motion');
  const face=point.row.layers.find(layer=>layer.name==='face');
  const expected=active.plan.expectedSettledTokens;
  assert.ok(body&&body.loadedClip.loaded);assert.equal(body.token,expected.motion);
  assert.equal(body.state.loop,true);assert.equal(body.blend,null);
  assert.ok(!body.fade||(point.row.actorSeconds-body.fade.start)>=body.fade.duration);
  if(expected.face===null)assert.equal(face,undefined,'Empty native face must leave no explicit override layer');
  else{
    assert.ok(face&&face.loadedClip.loaded);assert.equal(face.token,expected.face);
    assert.equal(face.state.loop,true);assert.equal(face.blend,null);
    assert.ok(!face.fade||(point.row.actorSeconds-face.fade.start)>=face.fade.duration);
  }
  assert.equal(point.row.node,step.id);assert.equal(point.row.model,'mimi01');
}
async function targetObservation(step,configuration){
  assert.equal(step.scenario,105);assert.equal(step.native.motion,'');
  assert.equal(step.candidateMotion,[step.parsedMotion.body,step.parsedMotion.face].filter(Boolean).join(','));
  const visible=await visibleTarget(step),ready=await readySurface(step,configuration);
  const readyPoint=await checkpoint('105-first-natural-ready',step);
  // Normal time schedules a bounded read only. The following original Actor
  // row, its actual resting states and absent blends establish settlement.
  // No layer/token/weight/clock is written and no source Wait is introduced.
  await waitFor(({node,target})=>{const state=window.reviewPrivateOwner.state();
    return state.node===node&&state.phase==='ready'&&state.normal.gameSeconds>=target;
  },{node:step.id,target:readyPoint.row.normal.gameSeconds+active.plan.observation.settleProbeNormalSeconds});
  const settled=await checkpoint('105-observed-settled-resting-layers',step);
  assert.equal(settled.row.observerIdentity.animator,visible.point.row.observerIdentity.animator);
  settledLayers(settled,step);
  const required=settled.row.actorSeconds+active.plan.observation.settledActorSeconds;
  let current=settled;const observations=[];
  for(let index=0;index<active.plan.observation.maximumActorHoldChecks;index++){
    const remaining=Math.max(0,required-current.row.actorSeconds);
    const reached=await waitFor(({node,target})=>{const state=window.reviewPrivateOwner.state();
      return state.node===node&&state.phase==='ready'&&state.normal.gameSeconds>=target&&state.normal;
    },{node:step.id,target:current.row.normal.gameSeconds+remaining});
    await waitFor(({node,frame})=>{const state=window.reviewPrivateOwner.state();
      return state.node===node&&state.phase==='ready'&&state.normal.frame>frame;
    },{node:step.id,frame:reached.frame});
    current=await checkpoint('105-post-settled-actor-hold-'+(index+1),step);observations.push(current);
    assert.equal(current.row.observerIdentity.animator,settled.row.observerIdentity.animator);
    settledLayers(current,step);
    if(current.row.actorSeconds>=required){
      const visual=await surface();verifySurface(visual,step);assert.equal(visual.phase,'ready');
      return {scenario:105,visible,ready,readyPoint,settled,ended:current,observations,visual,
        measuredActorSecondsAfterObservedSettlement:current.row.actorSeconds-settled.row.actorSeconds,
        minimumActorSecondsAfterObservedSettlement:4,QAObservationOnly:true,
        tokensWeightsLoopsAndClocksMutated:false,sourcePhaseAccepted:false};
    }
  }
  throw Error('Four real Actor seconds after observed settlement were not proven; no repair/retry');
}
async function verifyOwner(report,plan){
  assert.deepEqual(report.productFatalErrors,[]);assert.equal(report.productFatalSeen,0);assert.equal(report.productFatalDropped,0);
  assert.ok(!report.trace.some(r=>r.method==='error'||fatalProductNames.has(r.name)),
    'Original error/fatal events cannot pass zero-error verification');
  assert.deepEqual(report.errors,[]);assert.equal(report.traceDropped,0);assert.equal(report.mediaDropped,0);assert.equal(report.errorDropped,0);
  assert.deepEqual(report.tap.errors,[]);assert.equal(report.tap.dropped,0);assert.equal(report.tap.ownerDropped,0);
  assert.equal(report.restoration.renderRestored,true);assert.equal(report.restoration.consoleRestored,true);
  const raw=new Map(report.trace.map(r=>[r.sequence,r])),forwarded=new Map(report.tap.ownerEvents.map(e=>[e.sourceEventSequence,e]));
  for(const event of report.tap.ownerEvents){
    const original=raw.get(event.sourceEventSequence);assert.ok(original?.forwarded);
    assert.equal(original.caseId,plan.id);assert.equal(original.runLabel,report.runLabel);assert.equal(original.name,event.name);
    assert.equal(original.originalCallEntryMilliseconds,event.observedWallMilliseconds);
    assert.deepEqual(await parseHeldJson(original.rawArguments[1],{
      path:'retained original owner console JSON argument',output:active.folder}),event.actualEventDetail);
  }
  function layers(values){for(const layer of values){
    assert.ok(!layer.depthLimit,'Actual layer observation cannot be silently truncated');
    if(layer.blend)layers([layer.blend.source]);
  }}
  for(const row of report.tap.rows){
    assert.equal(row.caseName,plan.id);assert.equal(row.ownerRunLabel,report.runLabel);
    assert.equal(row.observerIdentity.namespace,'artifact-local-object-identity-not-native-generation');
    assert.equal(row.actualProductFields.storyPlayerCurrentGeneration.value,null);assert.equal(row.actualProductFields.animatorGeneration.value,null);
    assert.equal(row.normal.previewRate,1);assert.equal(row.primaryStoryActor.actualBacklinkVerified,true);layers(row.layers);
    if(row.externalOwnerProductEvent){assert.ok(raw.has(row.externalOwnerProductEvent.sourceEventSequence));
      assert.deepEqual(row.externalOwnerProductEvent,forwarded.get(row.externalOwnerProductEvent.sourceEventSequence));}
  }
  // Loading can still belong to the previous actor. Preserve it as observed;
  // only the explicit owned-model checkpoints are assigned to Mimi/Felt.
  assert.ok(report.trustedInputs.every(i=>i.isTrusted));
  const enters=report.trace.filter(r=>r.name==='STORY_PLAYER_ENTER').map(r=>r.rawArguments[1]);
  assert.deepEqual(enters,plan.steps.map(s=>s.id));
  const transitions=await Promise.all(report.trace.filter(r=>r.name==='STORY_PLAYER_TRANSITION')
    .map(row=>parseHeldJson(row.rawArguments[1],{path:'retained original transition JSON',output:active.folder})));
  assert.deepEqual(transitions.map(e=>e.edge),plan.links.map(e=>e.id));
  for(const [index,event]of transitions.entries()){
    assert.equal(event.target,plan.links[index].target);assert.deepEqual(event.native,plan.links[index].native_transition);
  }
  const advances=report.trustedInputs.filter(i=>i.button==='advance');
  assert.deepEqual(advances.map(i=>i.node),plan.steps.slice(0,-1).map(s=>s.id));assert.ok(advances.every(i=>i.phase==='ready'));
  assert.ok(!advances.some(i=>i.node===plan.stop.node));assert.ok(!transitions.some(e=>e.edge===plan.stop.forbiddenEdge));
}
async function exportOwner(folder){
  assert.ok(!active.ownerExportAttempted,'Owner export is not retried');active.ownerExportAttempted=true;
  const started=Date.now(),report=await evaluate(()=>window.reviewPrivateOwner.finish());
  const raw=JSON.stringify(report),bytes=Buffer.byteLength(raw),compressed=gzipSync(raw);
  await writeFile(resolve(folder,'owner-original-trace.json.gz'),compressed,{flag:'wx'});
  // Retain the COMPLETE crossing packet before rejecting its existing budget.
  // A shortened prefix cannot stand in for the original actor/console facts.
  assert.ok(bytes<=budgets.tapRawBytesPerCase&&compressed.length<=budgets.tapGzipBytesPerCase,
    'Complete owner archive crossed its original budget; full gzip retained');
  await save(folder,'owner-archive.json',{rawBytes:bytes,rawSha256:sha(raw),gzipBytes:compressed.length,gzipSha256:sha(compressed),
    exportRoundTripWallMilliseconds:Date.now()-started,parameterPhase:report.tap.rows[0]?.observedAt,
    traceDropped:report.traceDropped,tapDropped:report.tap.dropped,ownerDropped:report.tap.ownerDropped,
    consoleOverhead:report.consoleOverhead,exportCopy:report.exportCopy,checkpointCopies:report.checkpoints.map(c=>({label:c.label,milliseconds:c.copyDurationMilliseconds}))});
  return report;
}
function retainFirstFailure(error){
  if(!firstFailure)firstFailure={stage,error:String(error),stack:error?.stack||'',caseId:active?.plan.id||null};
}
async function failureState(){
  try{return {owner:await state(),surface:await surface()};}
  catch(error){return {observationFailure:String(error),stack:error.stack};}
}
try{
  ({capabilities}=await driver.call('session.new',{capabilities:{}}));
  const {contexts}=await driver.call('browsingContext.getTree');assert.equal(contexts.length,1,'One owned browser context required');
  target={context:contexts[0].context};
  driver.events((event,value)=>{
    if(!active)return;
    if(event==='log.entryAdded'){
      const line=value.text||'',name=line.split(/\s+/,1)[0];
      // Retain original severity/handled fatal names independently of archive
      // limits. A console.info Normal listener failure is still an original
      // fatal fact; hitches/cancellations are not promoted by their prefix.
      if(value.level==='error'||value.type==='javascript'||fatalProductNames.has(name)){
        if(active.productFatalErrors.length<32)active.productFatalErrors.push({name,level:value.level,
          originalTimestamp:value.timestamp,source:value.source,rawEntry:value});
        else active.productFatalDropped++;
      }
      const entry={event,source:value.source,timestamp:value.timestamp,line,rawEntry:value,caseActiveAtReceipt:active.plan.id};
      const bytes=Buffer.byteLength(JSON.stringify(entry));
      if(value.type==='javascript')active.errors.push(line);
      active.bidiBytes+=bytes;active.bidi.push(entry);
      if(active.bidi.length>budgets.consoleRowsPerCase||active.bidiBytes>budgets.consoleBytesPerCase)
        active.errors.push('Original complete BiDi row cap crossed; crossing rows retained');
    }
    if(event==='network.responseCompleted'){
      const response=value.response,url=new URL(response.url);active.http.push({url:url.href,status:response.status,mimeType:response.mimeType,originalEvent:value});
      if(active.http.length>budgets.httpRowsPerCase)active.errors.push('Original complete HTTP trace cap crossed; crossing rows retained');
      if(url.origin===origin&&response.status>=400&&url.pathname!=='/favicon.ico')active.errors.push('HTTP '+response.status+' '+url.href);
    }
  });
  await driver.call('session.subscribe',{events:['log.entryAdded','network.responseCompleted'],contexts:[target.context]});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:installRenderProbe.toString()});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:(()=>{
    window.reviewReady=false;window.addEventListener('message',event=>{
      if(event.source===window&&event.origin===location.origin&&event.data?.type==='stella-player-ready')window.reviewReady=true;});
  }).toString()});
  await driver.call('browsingContext.setViewport',{context:target.context,viewport:{width:500,height:1000},devicePixelRatio:1});
  assert.equal(binding.plans.length,1);
  assert.equal(binding.plans[0].id,'mimi105-B1F1');
  for(const plan of binding.plans){
    const folder=resolve(output,plan.id);await mkdir(folder);
    if(active){assert.deepEqual(active.errors,[]);rejectOriginalProductErrors();}
    active={plan,folder,deadline:Date.now()+budgets.caseWallSeconds*1000,errors:[],bidi:[],bidiBytes:0,bidiDropped:0,
      http:[],actions:[],marks:[],checkpoints:[],holds:[],surfaces:[],productFatalErrors:[],productFatalDropped:0};
    caseStates.push(active);
    let recording=false,exported=false,captureEndRequested=false;
    try{
      stage=plan.id+':fresh-document';
      await driver.call('browsingContext.navigate',{context:target.context,url:origin+'/player/player.html?assetRevision='+plan.alias,wait:'interactive'});
      await waitFor(()=>window.reviewReady===true);
      assert.equal(await evaluate(()=>document.getElementById('auto').getAttribute('aria-pressed')),'false');
      assert.equal(await evaluate(()=>document.getElementById('language').value),'zh');
      const viewport=await evaluate(()=>({innerWidth,innerHeight,outerWidth,outerHeight,screenX,screenY,timeOrigin:performance.timeOrigin}));
      assert.equal(viewport.innerWidth,500);assert.equal(viewport.innerHeight,1000);await save(folder,'viewport.json',viewport);
      const runLabel=process.env.STELLA_PRIVATE_ATTEMPT+':'+plan.id+':'+viewport.timeOrigin;
      const installed=await evaluate(async args=>(await import('/__private/owner-events.mjs')).installOwner(args),{
        rootRelease:{rootConfirmed:runtimeRelease.rootConfirmed,bindingSha256:sha(bindingBytes),observerSha256:binding.tap.sha256,releaseSha256},
        caseId:plan.id,runLabel,nodeIds:plan.steps.map(s=>s.id),modelIds:['mimi01','felt01'],budgets});
      assert.equal(installed.exactlyOneTap,true);
      const configurationReplies=await evaluate(async()=>{
        const result={};
        for(const [name,url]of [['player','/player/player_config.json'],['transitions','/player-assets/transitions.json']]){
          const reply=await fetch(url),bytes=new Uint8Array(await reply.arrayBuffer());
          let binary='';for(let index=0;index<bytes.length;index+=16384)
            binary+=String.fromCharCode(...bytes.subarray(index,index+16384));
          const hash=await crypto.subtle.digest('SHA-256',bytes);
          const row={url,status:reply.status,headers:Object.fromEntries(reply.headers),rawBytes:bytes.length,
            rawSha256:[...new Uint8Array(hash)].map(value=>value.toString(16).padStart(2,'0')).join(''),rawBase64:btoa(binary)};
          let doc;
          try{doc=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);row.value=JSON.parse(doc);}
          catch(error){row.parseError=String(error);row.exceptionDoc=doc??null;row.stack=error.stack;}
          result[name]=row;
        }
        return result;
      });
      await writeFile(resolve(folder,'configuration-first-reads.json.gz'),
        gzipSync(JSON.stringify(configurationReplies)+'\n',{level:1}),{flag:'wx'});
      const configuration={};
      for(const [name,row]of Object.entries(configurationReplies)){
        assert.equal(row.status,200);assert.ok(!Object.hasOwn(row,'parseError'));
        const raw=Buffer.from(row.rawBase64,'base64');assert.equal(raw.length,row.rawBytes);assert.equal(sha(raw),row.rawSha256);
        configuration[name]=row.value;
      }
      const expected=preparations.receipts.find(r=>r.caseId===plan.id);assert.ok(expected);
      assert.deepEqual(expected.request,{id:plan.start,baseSha:plan.alias,choices:{}});
      stage=plan.id+':normal-prepare';
      const response=await evaluate(async({request,expectedSha,expectedRawSha})=>{
        const reply=await fetch('/api/player/prepare',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request)});
        const bytes=new Uint8Array(await reply.arrayBuffer()),http={status:reply.status,headers:Object.fromEntries(reply.headers)};
        const hex=buffer=>[...new Uint8Array(buffer)].map(value=>value.toString(16).padStart(2,'0')).join('');
        const rawSha256=hex(await crypto.subtle.digest('SHA-256',bytes));
        let binary='';for(let index=0;index<bytes.length;index+=16384)binary+=String.fromCharCode(...bytes.subarray(index,index+16384));
        const retained={...http,rawBase64:btoa(binary),rawBytes:bytes.length,rawSha256,stored:false};
        let doc,program;
        try{doc=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);program=JSON.parse(doc);}
        catch(error){return {...retained,parseError:String(error),exceptionDoc:doc??null,stack:error.stack};}
        const programSha256=hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(program))));
        if(reply.status===200&&rawSha256===expectedRawSha&&programSha256===expectedSha)
          window.reviewPrivatePreparedProgram=program;
        return {...retained,programSha256,stored:reply.status===200&&rawSha256===expectedRawSha&&programSha256===expectedSha};
      },{request:expected.request,expectedSha:expected.programSha256,expectedRawSha:expected.rawSha256});
      const originalProgramRaw=Buffer.from(response.rawBase64,'base64');
      await writeFile(resolve(folder,'normal-http-program.json.gz'),gzipSync(originalProgramRaw,{level:1}),{flag:'wx'});
      await save(folder,'normal-http-receipt.json',{...response,rawBase64:undefined});
      assert.equal(originalProgramRaw.length,response.rawBytes);assert.equal(sha(originalProgramRaw),response.rawSha256);
      assert.equal(response.status,200);assert.equal(response.stored,true);assert.equal(response.programSha256,expected.programSha256);
      const program=await parseHeldJson(originalProgramRaw,{path:'original complete private prepare response',output:folder,
        sha256:expected.rawSha256});
      assert.equal(program.headSha,plan.alias);assert.equal(program.start,plan.start);
      assert.equal(program.nodes.length,binding.allLibraryNodes);assert.equal(program.edges.length,binding.allLibraryEdges);
      assert.deepEqual(program.before,expected.before);
      assert.equal(program.nodes.filter(node=>node.scene_id==='scene:10040043').length,binding.sceneRows);
      assert.deepEqual((await state()).entered,[],'No product entry before continuous recording begins');
      await supervisor('capture-start',plan.id);recording=true;
      await mark('before-complete-ordinary-program-load');
      await evaluate(()=>{const program=window.reviewPrivatePreparedProgram;if(!program)throw Error('No untouched full ordinary program');
        window.postMessage({type:'stella-player-load',program},location.origin);delete window.reviewPrivatePreparedProgram;return true;});
      for(const [index,step]of plan.steps.entries()){
        stage=plan.id+':node-'+step.scenario;
        await waitFor(id=>window.reviewPrivateOwner.state().entered.includes(id),step.id);
        if(step.target)active.holds.push(await targetObservation(step,configuration));
        else active.holds.push(await flankObservation(step,configuration));
        if(index===plan.steps.length-1)break;
        await mark('normal-advance-from-'+step.scenario);await click('#advance',step.id,'ready');
      }
      const finalState=await state();assert.equal(finalState.node,plan.stop.node);assert.equal(finalState.phase,'ready');
      const finalSurface=await surface();verifySurface(finalSurface,plan.steps.at(-1));
      await mark('ordinary-observation-complete-no1061');
      const report=await exportOwner(folder);exported=true;await verifyOwner(report,plan);
      // Keep the held observation separate from the outer BiDi context target.
      // A block-scoped `target` here would shadow earlier target.context reads
      // throughout this try block, including navigation before initialization.
      const targetHold=active.holds.find(h=>h.scenario===105);
      await save(folder,'actual-body-face-candidate-preview.json',{candidateOnly:true,aliasIsGitCommit:false,
        formalNativeMotion:plan.steps[1].native.motion,stagedNativeMotion:plan.steps[1].candidateMotion,
        derivedMotion:plan.steps[1].parsedMotion,visible:targetHold.visible,ready:targetHold.readyPoint,
        settled:targetHold.settled,ended:targetHold.ended,observations:targetHold.observations,
        postLoadTokenOverridesByHelper:false,layersOrWeightsMutatedByHelper:false,
        bodyWinner:null,faceWinner:null,motionAccepted:false,sourcePhaseAccepted:false});
      await save(folder,'actual-decoded-curve-proof.json',await auditCurves(binding,report,plan));
      assert.deepEqual(active.errors,[]);rejectOriginalProductErrors();
      await save(folder,'result.json',{status:'controlled-mimi-body-face-observation-pending-source-review',candidateOnly:true,aliasIsGitCommit:false,
        motionAccepted:false,sourcePhaseAccepted:false,requiresTerminalAcceptanceReceipt:true,
        plan,prepared:expected,finalState,finalSurface,holds:active.holds,surfaces:active.surfaces,marks:active.marks,actions:active.actions,
        bidi:active.bidi,http:active.http,browser:capabilities,runLabel,rawGenerationLinksVerified:true,currentStoryPlayerGeneration:null,
        ownerRows:report.trace.length,tapRows:report.tap.rows.length,tapClips:report.tap.clips.length,
        bidiBytes:active.bidiBytes,bidiDropped:active.bidiDropped,
        productFatalErrors:active.productFatalErrors,productFatalDropped:active.productFatalDropped,
        normalHitches:report.trace.filter(r=>r.name==='STORY_NORMAL_FRAME_HITCH').length});
      active.savedBidiRows=active.bidi.length;active.savedHttpRows=active.http.length;
      captureEndRequested=true;await supervisor('capture-end',plan.id);recording=false;
      // A handled original failure received during recorder/guard shutdown
      // still prevents this case from falling through into the next document.
      assert.deepEqual(active.errors,[]);rejectOriginalProductErrors();
      completedCases.push(plan.id);
      console.error('CASE_COMPLETE '+plan.id);
    }catch(error){
      retainFirstFailure(error);
      if(!exported&&!active.ownerExportAttempted){try{await exportOwner(folder);}catch(exportError){active.errors.push('Owner export: '+String(exportError));}}
      await save(folder,'failure.json',{firstFailure,stage,error:String(error),stack:error.stack,plan,state:await failureState(),holds:active.holds,surfaces:active.surfaces,marks:active.marks,
        checkpoints:active.checkpoints,actions:active.actions,bidi:active.bidi,bidiBytes:active.bidiBytes,bidiDropped:active.bidiDropped,
        http:active.http,errors:active.errors,productFatalErrors:active.productFatalErrors,
        productFatalDropped:active.productFatalDropped,noAutomaticRetry:true});
      if(recording&&!captureEndRequested){captureEndRequested=true;await supervisor('capture-end',plan.id).catch(e=>console.error(String(e)));}
      throw error; // A failed case never falls through into another case.
    }
  }
}catch(error){
  retainFirstFailure(error);console.error(JSON.stringify({firstFailure,noRetry:true}));process.exitCode=1;
}finally{
  reader.close();process.stdin.pause();
  try{await driver.call('session.end');sessionRetired=true;}
  catch(error){retainFirstFailure(error);process.exitCode=1;}
  finally{try{driver.close();}catch(error){retainFirstFailure(error);process.exitCode=1;}}
}
// Capture-end/guard IPC and session end have completed. Recheck all retained
// late original fatal facts after the final await. A BiDi session end is not
// browser OS exit proof; independent supervisor/root closure remains required.
try{
  for(const previous of caseStates){
    const late={caseId:previous.plan.id,bidiRowsBeforeTail:previous.savedBidiRows??0,
      httpRowsBeforeTail:previous.savedHttpRows??0,
      bidiTail:previous.bidi.slice(previous.savedBidiRows??0),httpTail:previous.http.slice(previous.savedHttpRows??0),
      errors:previous.errors,productFatalErrors:previous.productFatalErrors,
      productFatalDropped:previous.productFatalDropped};
    await writeFile(resolve(previous.folder,'post-result-original-diagnostics.json.gz'),
      gzipSync(JSON.stringify(late)+'\n',{level:1}),{flag:'wx'});
    assert.deepEqual(previous.errors,[]);assert.deepEqual(previous.productFatalErrors,[]);
    assert.equal(previous.productFatalDropped,0);
  }
  if(active){assert.deepEqual(active.errors,[]);rejectOriginalProductErrors();}
  if(firstFailure)throw Error('An earlier original failure is retained');
  assert.equal(sessionRetired,true);
  assert.deepEqual(completedCases,binding.plans.map(plan=>plan.id));
  await save(output,'terminal-acceptance.json',{accepted:true,sessionRetired,
    originalFatalFactsEmpty:true,requiresRootIndependentOsPortsGuards:true,completedCases});
  if(active){assert.deepEqual(active.errors,[]);rejectOriginalProductErrors();}
  console.log('MIMI105_FOUR_CANDIDATES_COMPLETE_PENDING_INDEPENDENT_SOURCE_REVIEW');
}catch(error){
  retainFirstFailure(error);process.exitCode=1;
  await save(output,'terminal-failure.json',{firstFailure,sessionRetired,errors:active?.errors||[],
    productFatalErrors:active?.productFatalErrors||[],productFatalDropped:active?.productFatalDropped||0,
    bidi:active?.bidi||[],noRetry:true}).catch(writeError=>console.error('TERMINAL_RECORD_FAILURE '+String(writeError)));
  console.error(JSON.stringify({firstFailure,sessionRetired,noRetry:true}));
}

