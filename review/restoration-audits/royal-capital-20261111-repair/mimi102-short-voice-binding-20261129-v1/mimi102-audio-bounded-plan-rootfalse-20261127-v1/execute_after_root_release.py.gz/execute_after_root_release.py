"""Prepared node-102 audio acquisition using audited components.

Do not invoke during metadata-only preparation. A separate explicit root release
and exclusion of overlapping actual RGB heavy work are required before execution.

Only the four-second source window is newly decoded. The 39 preserved reference
PCMs retain their original decoder proofs and are not copied or decoded again.
The old module is loaded under pinned source hashes, then its in-memory output
context is rebound to this new directory. Its old run() is never entered.
"""

import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import signal as signals
import sys
import traceback

sys.dont_write_bytecode=True
import numpy as np

OUT=Path(__file__).resolve().parent
INPUT=json.loads((OUT/'inputs.rootfalse.json').read_bytes())
assert hashlib.sha256((OUT/'inputs.rootfalse.json').read_bytes()).hexdigest()=='760e5db4a0f1ccec927d53c6cd2cb655276f3f8732d790e3a1bfcba7146a64f9'
RATE=INPUT['sampleRate']
for binding in INPUT['oldProofs'].values():
    assert hashlib.sha256(Path(binding['path']).read_bytes()).hexdigest()==binding['sha256']
OLD=Path(INPUT['oldProofs']['caller']['path']).parent
sys.path.insert(0,str(OLD))
helper=importlib.import_module('execute_audio_evidence')
helper.OUT=OUT
helper.INPUT=INPUT
helper.RATE=RATE
helper.LIMIT=INPUT['maximumOutputAllocatedBytes']
helper.OWNED=[]
helper.DECODE_FACTS=[]
decode,digest,save=helper.decode,helper.digest,helper.save


def capture_source():
    start, end = INPUT['sourceWindowSeconds']
    assert [start, end] == [790.5, 794.5] and RATE == 16000
    target = OUT/'source-mono-16000.f32le'
    assert not target.exists()
    command = ['/usr/bin/ffmpeg', '-v', 'info', '-hide_banner', '-nostdin',
        '-threads', '1', '-ss', str(start), '-copyts', '-i', INPUT['video']['path'],
        '-map', '0:a:0', '-vn', '-sn', '-dn', '-to', str(end),
        '-filter_threads', '1', '-filter_complex_threads', '1', '-af',
        f'atrim=start={start}:end={end},aformat=channel_layouts=mono,aresample={RATE},ashowinfo',
        '-ac', '1', '-ar', str(RATE), '-threads', '1', '-c:a', 'pcm_f32le',
        '-f', 'f32le', str(target)]
    _, fact = decode(command, 'source-once')
    raw = target.read_bytes()
    assert 0 < len(raw) <= (end-start)*RATE*4+8 and len(raw)%4 == 0
    events = []
    for line in (OUT/fact['stderrPath']).read_text().splitlines():
        if 'Parsed_ashowinfo_' in line and 'pts_time:' in line:
            match = re.search(r'n:(\d+) pts:(-?\d+) pts_time:([\d.-]+).*?rate:(\d+) nb_samples:(\d+) checksum:([0-9A-F]+)', line)
            assert match, line
            n, pts, printed, rate, count, checksum = match.groups()
            assert int(rate) == RATE
            events.append(dict(n=int(n), pts=int(pts), samples=int(count),
                rate=int(rate), printedPTS=printed, checksum=checksum))
    assert events and [row['n'] for row in events] == list(range(len(events)))
    assert all(b['pts'] == a['pts']+a['samples'] for a, b in zip(events, events[1:]))
    assert sum(row['samples'] for row in events)*4 == len(raw)
    first = events[0]['pts']/RATE
    finish = (events[-1]['pts']+events[-1]['samples'])/RATE
    assert start-1/RATE <= first <= start+1/RATE
    assert end-1/RATE <= finish <= end+1/RATE
    assert end-start-1/RATE <= finish-first <= end-start+1/RATE
    assert abs(len(raw)//4-round((end-start)*RATE)) <= 1
    clock = dict(actualFirstPTS=events[0]['pts'], actualOutputTimeBase=[1,RATE],
        actualFirstSourceSeconds=first, requestedStartSeconds=start,
        measuredResamplerFirstOffsetSeconds=first-start,
        actualEndExclusiveSourceSeconds=finish,
        samples=len(raw)//4, rawPCMBytes=len(raw), rawPCMSHA256=digest(raw),
        everyBlockPTSContiguous=True, fullRequestedWindowWithinOneSample=True, events=events,
        inputAudioTimeBaseFromPreviouslyVerifiedOriginal=[1,44100],
        noVideoFramesDecodedOrTemporalAlignmentAssumed=True)
    save('source-audio-actual-clock.rootfalse.json', clock)
    return np.frombuffer(raw, dtype='<f4').astype(np.float64), clock


def verify_references():
    for binding in INPUT['oldProofs'].values():
        assert digest(Path(binding['path']).read_bytes())==binding['sha256']
    events=[json.loads(line) for line in Path(INPUT['oldProofs']['decodes']['path']).read_text().splitlines()]
    original=json.loads(Path(INPUT['oldProofs']['inputs']['path']).read_bytes())
    assert len(events)==40 and len(original['references'])==39 and len(INPUT['references'])==39
    templates=[]
    for i,(binding,before) in enumerate(zip(INPUT['references'],original['references'])):
        for key in ['cue','bank','sourceMember','path','bytes','sha256']:
            assert binding[key]==before[key]
        event=events[i+1]
        assert event['label']==f'reference-{i:02d}' and event['originalExitCode']==0 and event['retries']==0
        assert digest((OLD/event['stderrPath']).read_bytes())==event['stderrSHA256']
        path=Path(binding['pcmPath'])
        assert path==OLD/'templates-mono-16000'/(binding['bank']+'--'+binding['cue']+'.f32le')
        raw=path.read_bytes()
        assert len(raw)==binding['pcmBytes']==event['stdoutBytes'] and len(raw)%4==0
        assert digest(raw)==binding['pcmSHA256']==event['stdoutSHA256']
        templates.append((binding,np.frombuffer(raw,dtype='<f4').astype(np.float64)))
    assert len([b for b,_ in templates if b['bank']=='vo_adv_mimi'])==38
    return templates


def run():
    assert sorted(os.sched_getaffinity(0))==[0,1] and os.getpriority(os.PRIO_PROCESS,0)==19
    assert all(os.environ.get(k)=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
    assert INPUT['sourceWindowSeconds']==[790.5,794.5] and helper.LIMIT==2*1024*1024
    assert helper.OUT==OUT and helper.INPUT is INPUT and not helper.OWNED
    assert sys.dont_write_bytecode and not (OLD/'__pycache__').exists()
    templates=verify_references()
    helper.fresh(INPUT['video'])
    source,clock=capture_source()
    window=helper.CorrelationWindow(source,RATE,clock['actualFirstSourceSeconds'],max(len(t) for _,t in templates))
    results=[]
    for binding,template in templates:
        item=helper.process_reference(window,binding,template)
        # The audited function's legacy actor-bound argument is the entire
        # acquired audio window here. Remove those actor labels explicitly:
        # no image or native-entry boundary is inferred from the audio.
        item['maxima'].pop('actorLocalFullCue')
        item['maxima'].pop('actorLocalEffectiveQuery')
        item['completeCueFitsAcquisitionWindow']=item.pop('completeCueFitsActorInterval')
        item['longCueNotShortenedToFitAcquisitionWindow']=item.pop('longCueNotShortenedToFitActor')
        item['reversedEffectiveQueryAcquisitionMaximum']=item.pop('reversedActiveQueryActorMaximum')
        if 'fixedAlignmentControlBasis' in item:
            item['fixedAlignmentControlBasis']='complete acquired audio window effective maximum; no actor-entry inference'
        results.append(item)
    verify_references()
    helper.fresh(INPUT['video'])
    target=next(item for item in results if item['binding']['cue']=='advg_mimi_aiduchi')
    mimi=[item for item in results if item['binding']['bank']=='vo_adv_mimi']
    eligible=[item for item in mimi if item['maxima']['globalEffectiveQuery']]
    ranked=sorted(eligible,key=lambda item:item['maxima']['globalEffectiveQuery']['signedFFT'],reverse=True)
    save('audio-evidence.rootfalse.json',dict(schema='stella.mimi102.fresh-four-second-audio-evidence.v1',
        rootConfirmed=False,installationAuthorized=False,formalAcceptance=False,target=INPUT['target'],
        sourceActualClock=clock,results=results,targetCueResult=target,
        all38MimiCuesAttempted=True,
        completeCueEligibleMimiCount=sum(item['samples']<=len(source) for item in mimi),
        ineligibleLongMimiCount=sum(item['samples']>len(source) for item in mimi),
        mimiNonzeroEnergyPeakCount=len(eligible),
        completeCueFitsButNoEffectivePeakCount=sum(item['samples']<=len(source)
            and item['maxima']['globalEffectiveQuery'] is None for item in mimi),
        mimiRanking=[dict(cue=item['binding']['cue'],peak=item['maxima']['globalEffectiveQuery']) for item in ranked],
        sourceVideoAnd39ReferencePCMsFreshHashExactBeforeAfter=True,
        standardOriginalFFmpegResamplerUsed=True,referencePCMsDecodedAgainOrCopied=False,
        sourceDecodeInvocations=1,newReferenceDecodeInvocations=0,
        foreignFeltComparatorIsNotPositiveControlForThisWindow=True,
        comparisonBoundsAreAcquisitionWindowNotObservedActorOrNativeNodeBounds=True,
        sourceDialogueAtCueZeroAccepted=False,voiceInstallationAccepted=False,
        originalRmsPresetModeOrMouthCausalityAccepted=False,subjectiveListeningPerformed=False,
        noVideoFramesImagesBrowserApiDOrC=True,prior100And105FilesUnchanged=True,
        originalDecoderCommands=helper.DECODE_FACTS,numpyVersion=np.__version__))
    assert len(helper.DECODE_FACTS)==1 and all(p.poll() is not None for p in helper.OWNED)
    save('terminal.rootfalse.json',dict(rootConfirmed=False,formalAcceptance=False,originalExitCode=0,
        sourceDecodeInvocations=1,newReferenceDecodeInvocations=0,allOwnedDecoderProcessesTerminal=True,
        inputVideoAnd39ReferencePCMsFreshExactBeforeAfter=True,
        totalAllocatedBytesBeforeReceipt=helper.allocated(),maximumAllocatedBytes=helper.LIMIT))
    print(json.dumps(dict(output=str(OUT),exit=0,actualFirst=clock['actualFirstSourceSeconds'],
        actualEnd=clock['actualEndExclusiveSourceSeconds'],samples=len(source),
        targetPeak=target['maxima']['globalEffectiveQuery'],allocatedBytes=helper.allocated())))


if __name__=='__main__':
    try:
        run()
    except BaseException as error:
        for process in helper.OWNED:
            if process.poll() is None:
                os.killpg(process.pid,signals.SIGTERM)
                process.wait(timeout=5)
        save('first-failure.rootfalse.json',dict(rootConfirmed=False,errorType=type(error).__name__,
            error=str(error),traceback=traceback.format_exc(),automaticRetry=False,
            ownedDecoderProcessesAllTerminal=all(p.poll() is not None for p in helper.OWNED)))
        raise
