"""One authorized source window, preserving native presentation timestamps.

FFmpeg emits q2 JPEGs to a pipe. Only this supervisor writes files, and every
write is checked against the aggregate output budget before it happens. A JPEG
marker parser skips length-delimited header segments and escaped entropy bytes;
it does not mistake arbitrary header bytes for a frame boundary. This preserves
all selected source frames without assigning timestamps through the JPEG muxer.
"""
from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import resource
import selectors
import subprocess
import time
import traceback
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent
SOURCE = Path('/home/rikka/Videos/re0/真夜黑兔_Official_王都一日游篇/31 9本篇「结束与开始」Ver蜜蜜.mp4')
A = OUT.parent
SOURCE_SHA = '7f5bf8a6e10ad2afd02e53a039c60dfcdc378eec3b3062e1f75446437db7497f'
CAP = 64 * 1024 * 1024
FRAME_PAYLOAD_CAP = 56 * 1024 * 1024
FRAME_MAX = 200
JPEG_MAX = 2 * 1024 * 1024
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
assert os.nice(0) >= 19 and set(os.sched_getaffinity(0)) <= {0, 1}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def usage():
    return sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())


def put(name, data):
    if usage() + len(data) > CAP:
        raise RuntimeError('Aggregate64MiB pre-write cap would be exceeded')
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as stream:
        stream.write(data)
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data)}


def document(name, value):
    return put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def first_json(path, tag):
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    try:
        return json.loads(text), {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    except BaseException as error:
        put(tag + '.first-raw.gz', gzip.compress(raw, compresslevel=1))
        put(tag + '.first-string.gz', gzip.compress(text.encode(), compresslevel=1))
        if isinstance(getattr(error, 'doc', None), str):
            put(tag + '.exception-doc.gz', gzip.compress(error.doc.encode(), compresslevel=1))
        document(tag + '.first-error.json', {'error': repr(error), 'position': getattr(error, 'pos', None), 'traceback': traceback.format_exc()})
        raise


def jpeg_end(buf):
    """Return one complete JPEG length, or None when more bytes are needed."""
    if len(buf) < 2:
        return None
    if buf[:2] != b'\xff\xd8':
        raise ValueError('Unexpected bytes before JPEG SOI')
    pos = 2
    entropy = False
    while True:
        if entropy:
            marker = buf.find(b'\xff', pos)
            if marker < 0 or marker + 1 >= len(buf):
                return None
            pos = marker + 1
            while pos < len(buf) and buf[pos] == 0xff:
                pos += 1
            if pos >= len(buf):
                return None
            code = buf[pos]
            if code == 0 or 0xd0 <= code <= 0xd7:
                pos += 1
                continue
            if code == 0xd9:
                return pos + 1
            pos = marker
            entropy = False
        if pos + 1 >= len(buf):
            return None
        if buf[pos] != 0xff:
            raise ValueError('Unexpected JPEG header byte')
        pos += 1
        while pos < len(buf) and buf[pos] == 0xff:
            pos += 1
        if pos >= len(buf):
            return None
        code = buf[pos]
        pos += 1
        if code == 0xd9:
            return pos
        if pos + 2 > len(buf):
            return None
        length = int.from_bytes(buf[pos:pos + 2], 'big')
        if length < 2:
            raise ValueError('Invalid JPEG segment length')
        if pos + length > len(buf):
            return None
        pos += length
        entropy = code == 0xda


proc = None
started = time.monotonic()
frame_refs = []
stderr = bytearray()
pending = bytearray()
try:
    h = hashlib.sha256()
    with SOURCE.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    source_ref = {'path': str(SOURCE), 'bytes': SOURCE.stat().st_size, 'sha256': h.hexdigest()}
    document('source.json', source_ref)
    assert source_ref['sha256'] == SOURCE_SHA
    anchors = {}
    for kind in ['native', 'review']:
        path = A / 'data-checkout' / kind / 'scenes/10040043.json'
        j, ref = first_json(path, kind)
        if kind == 'native':
            rows = [{k: row[k] for k in ['scenario_id', 'uniq_id', 'character', 'msg_character', 'msg_text', 'voice']}
                    for row in j['scenario_list'][100:103]]
        else:
            rows = [{k: j['scenarios'][str(n)][k] for k in ['stableKey', 'sourceText', 'translation', 'sourceSpeaker']} for n in [101, 102, 103]]
        anchors[kind] = {'heldFile': ref, 'nodes101to103': rows}
    document('native-anchors.rootfalse.json', anchors)

    # The same source bytes already have a completed native stream probe.
    # Reuse its exact held JSON instead of starting a second media probe.
    probe_path = A / 'mimi100-source780p5-784p5-material-recovery-rootfalse-20261127-v1/probe.stdout.json'
    probe_raw = probe_path.read_bytes()
    assert sha(probe_raw) == 'a771efa762609a54cbeb4dfa0ea0b05c435500aac0215eef49c1e8d51a83d3d9'
    info = json.loads(probe_raw)['streams'][0]
    document('reused-probe.rootfalse.json', {'path': str(probe_path), 'bytes': len(probe_raw),
             'sha256': sha(probe_raw), 'sameSourceSHA256': SOURCE_SHA, 'newProbeCalls': 0})
    width, height = info['width'], info['height']
    # Input seek is accurate; copyts retains original video integer PTS. The
    # input duration bounds the authorized four-second window. No fps filter,
    # setpts, frame selection, scaling, frame duplication or resampling is used.
    argv = ['/usr/bin/ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'info',
            '-filter_threads', '1', '-filter_complex_threads', '1', '-threads', '1',
            '-copyts', '-ss', '790.5', '-t', '4', '-i', str(SOURCE), '-map', '0:v:0',
            '-an', '-sn', '-dn', '-vf', 'showinfo', '-fps_mode', 'passthrough',
            '-enc_time_base', '1/16000', '-c:v', 'mjpeg', '-threads', '1', '-q:v', '2',
            '-frames:v', str(FRAME_MAX), '-f', 'image2pipe', 'pipe:1']
    document('decode.command.json', {'argv': argv, 'nice': os.nice(0), 'affinity': sorted(os.sched_getaffinity(0)),
             'aggregateOutputHardCapBytes': CAP, 'framePayloadPreWriteCapBytes': FRAME_PAYLOAD_CAP,
             'OSPerFileHardCapBytes': CAP, 'JPEGBufferMaximumBytes': JPEG_MAX, 'retries': 0})
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    document('decode.pid.json', {'pid': proc.pid, 'supervisorPid': os.getpid()})
    sel = selectors.DefaultSelector()
    sel.register(proc.stdout, selectors.EVENT_READ, 'stdout')
    sel.register(proc.stderr, selectors.EVENT_READ, 'stderr')
    payload = 0
    while sel.get_map():
        if time.monotonic() - started > 180:
            raise TimeoutError('180-second extraction boundary exceeded')
        for key, _ in sel.select(timeout=1):
            data = os.read(key.fileobj.fileno(), 65536)
            if not data:
                sel.unregister(key.fileobj)
                continue
            if key.data == 'stderr':
                if len(stderr) + len(data) > JPEG_MAX:
                    raise RuntimeError('Original stderr exceeds2MiB bound')
                stderr.extend(data)
                continue
            pending.extend(data)
            if len(pending) > JPEG_MAX:
                raise RuntimeError('Pending JPEG exceeds2MiB bound')
            while (end := jpeg_end(pending)) is not None:
                frame = bytes(pending[:end])
                del pending[:end]
                if len(frame_refs) >= FRAME_MAX or payload + len(frame) > FRAME_PAYLOAD_CAP:
                    raise RuntimeError('Frame count/payload pre-write boundary exceeded')
                ref = put(f'frames/{len(frame_refs):04d}.jpg', frame)
                frame_refs.append(ref)
                payload += len(frame)
    code = proc.wait(timeout=10)
    log_ref = put('decode.stderr.log', bytes(stderr))
    document('decode.exit.json', {'pid': proc.pid, 'exitCode': code, 'stdoutEOF': True, 'stderrEOF': True,
             'framesWritten': len(frame_refs), 'pendingBytes': len(pending), 'stderr': log_ref})
    assert code == 0 and not pending and len(frame_refs) < FRAME_MAX
    log = stderr.decode('utf-8', errors='strict')
    configs = re.findall(r'config in time_base:\s*(\d+/\d+)', log)
    assert len(set(configs)) == 1
    tb = configs[0]
    numerator, denominator = map(int, tb.split('/'))
    observations = re.findall(r'\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:([^\s]+).*?\bs:(\d+)x(\d+).*?checksum:([A-F0-9]+)', log)
    assert len(observations) == len(frame_refs) and frame_refs
    frames = []
    for n, pts, printed_time, sw, sh, checksum in observations:
        ordinal, tick = int(n), int(pts)
        assert ordinal == len(frames) and (int(sw), int(sh)) == (width, height)
        exact_seconds = tick * numerator / denominator
        assert 790.5 <= exact_seconds < 794.5
        with Image.open(frame_refs[ordinal]['path']) as image:
            assert image.size == (width, height)
        frames.append({**frame_refs[ordinal], 'frameOrdinalZeroBased': ordinal, 'originalPTS': tick,
                       'timeBase': tb, 'sourcePTSSeconds': exact_seconds, 'showinfoPTSTime': printed_time,
                       'showinfoNativePixelChecksum': checksum})
    assert all(b['originalPTS'] > a['originalPTS'] for a, b in zip(frames, frames[1:]))
    # Review sheets are spatial aids, assembled after the decoder's terminal
    # exit. Every frame is included, and labels preserve local ordinal and PTS.
    sheets = []
    thumb_w = 160
    thumb_h = round(height * thumb_w / width)
    for start in range(0, len(frames), 25):
        batch = frames[start:start + 25]
        canvas = Image.new('RGB', (5 * thumb_w, 5 * (thumb_h + 20)), '#111111')
        draw = ImageDraw.Draw(canvas)
        for i, item in enumerate(batch):
            x, y = (i % 5) * thumb_w, (i // 5) * (thumb_h + 20)
            with Image.open(item['path']) as image:
                canvas.paste(image.resize((thumb_w, thumb_h)), (x, y + 20))
            draw.text((x + 2, y + 2), f"{item['frameOrdinalZeroBased']} {item['sourcePTSSeconds']:.6f}", fill='white')
        import io
        buf = io.BytesIO()
        canvas.save(buf, 'JPEG', quality=92)
        sheets.append({**put(f'sheets/{start:04d}.jpg', buf.getvalue()), 'firstOrdinal': start,
                       'lastOrdinal': start + len(batch) - 1, 'cells': len(batch)})
    document('index.rootfalse.json', {'schema': 'stella-mimi102-source-window-frame-index-v1',
             'rootConfirmed': False, 'source': source_ref, 'authorizedWindowSeconds': [790.5, 794.5],
             'windowEndExclusive': True, 'streamMetadata': info, 'nativeDimensions': [width, height],
             'frameCount': len(frames), 'timeBase': tb, 'showinfoRawLog': log_ref,
             'allFramesInOriginalOrder': True, 'frameDropDuplicateRetimingResampling': False,
             'JPEGQ': 2, 'JPEGIsLossy': True, 'originalPTSDoNotComeFromOCR': True,
             'frames': frames, 'contactSheets': sheets})
    document('material.ready.json', {'status': 'decode-complete-awaiting-CLI-closure-and-visual-review',
             'decoderExitCode': code, 'decoderPid': proc.pid, 'decoderWaitReturned': True,
             'frameCount': len(frames), 'contactSheets': len(sheets), 'totalOutputBytes': usage(),
             'outputBytesCap': CAP, 'rootConfirmed': False, 'audioDecoded': False, 'retry': False})
    print(json.dumps({'status': 'complete', 'frameCount': len(frames), 'firstPTS': frames[0]['originalPTS'],
          'lastPTS': frames[-1]['originalPTS'], 'timeBase': tb, 'bytes': usage(), 'decoderExitCode': code}))
except BaseException as error:
    if proc is not None and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=10)
    if stderr and not (OUT / 'decode.stderr.log').exists():
        put('decode.stderr.first-failure.log', bytes(stderr))
    if pending:
        put('decode.pending.first-failure.bin', bytes(pending))
    document('failure.first.json', {'error': repr(error), 'traceback': traceback.format_exc(),
             'decoderPid': proc.pid if proc else None, 'decoderExitCode': proc.returncode if proc else None,
             'framesWritten': len(frame_refs), 'pendingBytes': len(pending), 'automaticRetry': False})
    raise
