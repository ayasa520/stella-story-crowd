"""Independently reproduce closed node-102 saved-PCM evidence.

No acquisition caller, producer correlation helper, media decoder, browser or
business module is imported.  A separate closure notification and explicit
input hashes are required before this program reads the newly acquired PCM.
The retained float32 bytes are analyzed in float64 without filtering, replacing,
truncating or copying any source/reference PCM payload.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import re
import sys
import traceback
import zlib

import numpy as np

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
K = A / 'mimi102-audio-bounded-plan-rootfalse-20261127-v1'
OUT = Path(__file__).resolve().parent
RATE = 16000
TARGET = 'advg_mimi_aiduchi'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def held(path, expected=None):
    path = Path(path)
    raw = path.read_bytes()
    fact = dict(path=str(path), bytes=len(raw), sha256=digest(raw))
    if expected is not None:
        assert fact['sha256'] == expected, str(path)
    return raw, fact


def read_json(path, expected=None):
    raw, fact = held(path, expected)
    try:
        return json.loads(raw), fact
    except (json.JSONDecodeError, UnicodeDecodeError):
        # Keep the actual first failing read, rather than substituting bytes
        # from a later reread or silently repairing a malformed diagnostic.
        with (OUT / 'first-read-failure.raw.gz').open('xb') as stream:
            stream.write(gzip.compress(raw, mtime=0))
        raise


def metrics(source, reference):
    assert len(source) == len(reference) and len(source) > 1
    x, y = source - source.mean(), reference - reference.mean()
    xx, yy, xy = float(x @ x), float(y @ y), float(x @ y)
    assert xx > 0 and yy > 0
    gain = xy / yy
    active = np.abs(reference) >= np.abs(reference).max() * .02
    return dict(samples=len(x), signedPearson=xy / np.sqrt(xx * yy),
        fittedGain=gain,
        residualRMSFraction=float(np.linalg.norm(x - gain * y) / np.linalg.norm(x)),
        referenceNonzeroSamples=int(np.count_nonzero(reference)),
        sourceNonzeroSamples=int(np.count_nonzero(source)),
        aboveThresholdReferenceSamples=int(np.count_nonzero(active)),
        aboveThresholdReferenceWithNonzeroSource=int(np.count_nonzero(source[active])))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--closed-input-seal', required=True)
    args = parser.parse_args()
    assert sorted(os.sched_getaffinity(0)) == [0, 1]
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19 and sys.dont_write_bytecode
    assert all(os.environ.get(k) == '1' for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'])
    seal, seal_ref = read_json(args.closed_input_seal)
    assert digest(Path(__file__).read_bytes()) == seal['independentCodeSHA256']
    assert seal['ownerNotifiedOriginalExecutionTerminal'] is True
    assert seal['originalExecution']['exitCode'] == 0
    pins = seal['inputSHA256']
    assert set(pins) == {'inputs.rootfalse.json', 'source-mono-16000.f32le',
        'source-once.stderr.log', 'source-audio-actual-clock.rootfalse.json',
        'audio-evidence.rootfalse.json', 'terminal.rootfalse.json'}
    input_raw, input_ref = held(K / 'inputs.rootfalse.json', pins['inputs.rootfalse.json'])
    assert pins['inputs.rootfalse.json'] == '760e5db4a0f1ccec927d53c6cd2cb655276f3f8732d790e3a1bfcba7146a64f9'
    inputs = json.loads(input_raw)
    assert inputs['sourceWindowSeconds'] == [790.5, 794.5] and inputs['sampleRate'] == RATE
    terminal, terminal_ref = read_json(K / 'terminal.rootfalse.json', pins['terminal.rootfalse.json'])
    assert terminal['originalExitCode'] == 0 and terminal['allOwnedDecoderProcessesTerminal']
    assert terminal['sourceDecodeInvocations'] == 1 and terminal['newReferenceDecodeInvocations'] == 0
    raw, source_ref = held(K / 'source-mono-16000.f32le', pins['source-mono-16000.f32le'])
    source = np.frombuffer(raw, dtype='<f4').astype(np.float64)
    assert abs(len(source) - 64000) <= 1 and np.isfinite(source).all()

    # Parse each real AShowinfo block independently and bind it to raw PCM by
    # its original Adler-32.  Integer output PTS defines the origin; the seek
    # request only checks the acquired window and never supplies sample zero.
    log_raw, log_ref = held(K / 'source-once.stderr.log', pins['source-once.stderr.log'])
    pattern = re.compile(r'n:(\d+) pts:(-?\d+) pts_time:(\S+) fmt:flt channels:1 chlayout:mono rate:(\d+) nb_samples:(\d+) checksum:([A-F0-9]+)')
    blocks, cursor, origin = [], 0, None
    for line in log_raw.decode().splitlines():
        if 'ashowinfo' not in line or 'nb_samples:' not in line:
            continue
        match = pattern.search(line)
        assert match, line
        n, pts, printed, rate, count, checksum = match.groups()
        n, pts, rate, count = map(int, [n, pts, rate, count])
        if origin is None:
            origin = pts
        assert n == len(blocks) and rate == RATE and pts == origin + cursor
        block = raw[cursor * 4:(cursor + count) * 4]
        assert len(block) == count * 4 and f'{zlib.adler32(block, 0):08X}' == checksum
        blocks.append(dict(n=n, pts=pts, samples=count, printedPTS=printed, checksum=checksum))
        cursor += count
    assert blocks and cursor == len(source)
    first_seconds, end_seconds = origin / RATE, (origin + cursor) / RATE
    assert abs(first_seconds - 790.5) <= 1 / RATE and abs(end_seconds - 794.5) <= 1 / RATE
    clock, clock_ref = read_json(K / 'source-audio-actual-clock.rootfalse.json', pins['source-audio-actual-clock.rootfalse.json'])
    assert [(b['n'], b['pts'], b['samples'], b['checksum']) for b in blocks] == [
        (b['n'], b['pts'], b['samples'], b['checksum']) for b in clock['events']]
    assert clock['actualFirstPTS'] == origin and clock['rawPCMSHA256'] == source_ref['sha256']

    video = inputs['video']
    video_path = Path(video['path'])
    stat_before = video_path.stat()
    assert stat_before.st_size == video['bytes'] and stat_before.st_ino == video['ino']
    with video_path.open('rb') as stream:
        actual_video_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert actual_video_sha == video['sha256']
    events_raw, old_events_ref = held(inputs['oldProofs']['decodes']['path'], inputs['oldProofs']['decodes']['sha256'])
    old_events = [json.loads(line) for line in events_raw.splitlines() if line]
    assert len(old_events) == 40
    arrays, references = {}, []
    for binding in inputs['references']:
        ref_raw, fact = held(binding['pcmPath'], binding['pcmSHA256'])
        assert len(ref_raw) == binding['pcmBytes'] and len(ref_raw) % 4 == 0
        array = np.frombuffer(ref_raw, dtype='<f4').astype(np.float64)
        assert len(array) and np.isfinite(array).all()
        event = old_events[binding['originalDecodeEventNumber']]
        assert event['originalExitCode'] == 0 and event['retries'] == 0
        assert event['stdoutSHA256'] == fact['sha256'] and event['stdoutBytes'] == len(ref_raw)
        _, wave_fact = held(binding['path'], binding['sha256'])
        references.append(dict(cue=binding['cue'], bank=binding['bank'], samples=len(array),
            pcm=fact, originalWave=wave_fact, originalDecodeEvent=binding['originalDecodeEventNumber']))
        arrays[binding['cue']] = array
    assert len(references) == 39 and sum(r['bank'] == 'vo_adv_mimi' for r in references) == 38

    prefix = np.concatenate(([0.], np.cumsum(source)))
    squares = np.concatenate(([0.], np.cumsum(source * source)))
    transforms = {}

    def peak(query, full_length, query_offset=0, minimum=False):
        if full_length > len(source):
            return None
        count = len(query)
        y = query - query.mean()
        yy = float(y @ y)
        assert yy > 0
        size = 1 << (len(source) + count - 2).bit_length()
        if size not in transforms:
            transforms[size] = np.fft.rfft(source, size)
        # This independent FFT uses conjugate cross-correlation, rather than
        # the producer's reversed-template convolution. Every selected peak is
        # independently checked again by a direct, mean-centered dot product.
        dots = np.fft.irfft(transforms[size] * np.conjugate(np.fft.rfft(y, size)), size)[:len(source)-count+1]
        sums = prefix[count:] - prefix[:-count]
        variance = squares[count:] - squares[:-count] - sums * sums / count
        valid = variance > 0
        scores = np.full(len(dots), np.inf if minimum else -np.inf)
        scores[valid] = dots[valid] / np.sqrt(yy * variance[valid])
        low, high = query_offset, len(source) - full_length + query_offset + 1
        choose = np.argmin if minimum else np.argmax
        point = low + int(choose(scores[low:high]))
        direct = metrics(source[point:point+count], query)
        assert abs(direct['signedPearson'] - float(scores[point])) < 1e-9
        return dict(cueZeroSample=point-query_offset, querySample=point,
            eligibleAlignments=high-low, **direct)

    bank_results = []
    for binding in references:
        reference = arrays[binding['cue']]
        active = np.flatnonzero(np.abs(reference) >= np.abs(reference).max() * .02)
        first, end = int(active[0]), int(active[-1])+1
        left, right = max(0, first-400), min(len(reference), end+400)
        bank_results.append(dict(cue=binding['cue'], bank=binding['bank'], samples=len(reference),
            effectiveBounds=[first, end], paddedQueryBounds=[left, right],
            completeCueEligible=len(reference) <= len(source), neverShortened=True,
            full=peak(reference, len(reference)),
            effectiveQuery=peak(reference[left:right], len(reference), left)))
    target = next(row for row in bank_results if row['cue'] == TARGET)
    reference = arrays[TARGET]
    zero = target['effectiveQuery']['cueZeroSample']
    first, end = target['effectiveBounds']
    left, right = target['paddedQueryBounds']
    fixed_full = metrics(source[zero:zero+len(reference)], reference)
    fixed_effective = metrics(source[zero+first:zero+end], reference[first:end])
    cuts = [first+(end-first)*i//4 for i in range(5)]
    quarters = [dict(referenceBounds=[a,b], **metrics(source[zero+a:zero+b], reference[a:b]))
        for a,b in zip(cuts,cuts[1:])]
    controls = []
    for delta in [-800,-160,-16,0,16,160,800]:
        shifted = zero+delta
        entry = dict(offsetSamples=delta, offsetSeconds=delta/RATE,
            complete=0 <= shifted and shifted+len(reference) <= len(source))
        if entry['complete']:
            entry.update(metrics(source[shifted:shifted+len(reference)], reference))
        controls.append(entry)
    reverse_full = peak(reference[::-1],len(reference))
    reverse_effective = peak(reference[::-1][len(reference)-right:len(reference)-left],
        len(reference),len(reference)-right)
    negative_full = peak(reference,len(reference),minimum=True)
    others = sorted([r for r in bank_results if r['bank']=='vo_adv_mimi' and r['cue']!=TARGET and r['effectiveQuery']],
        key=lambda r:r['effectiveQuery']['signedPearson'],reverse=True)

    # Only after direct computation is complete, compare the independent
    # results with the producer's values. This establishes reproducibility,
    # while image evidence and root review still own native-node attribution.
    producer, producer_ref = read_json(K/'audio-evidence.rootfalse.json',pins['audio-evidence.rootfalse.json'])
    saved = producer['targetCueResult']
    errors = []
    for item in bank_results:
        before = next(r for r in producer['results'] if r['binding']['cue']==item['cue'])
        for ours, key in [(item['full'],'globalFullCue'),(item['effectiveQuery'],'globalEffectiveQuery')]:
            theirs = before['maxima'][key]
            if ours is None:
                assert theirs is None
                continue
            assert ours['cueZeroSample']==theirs['completeCueZeroSample']
            errors.append(abs(ours['signedPearson']-theirs['signedFFT']))
    assert max(errors) < 1e-9
    assert abs(fixed_full['signedPearson']-saved['maxima']['globalEffectiveQuery']['completeCue']['signedPearson']) < 1e-10
    assert abs(fixed_full['fittedGain']-saved['maxima']['globalEffectiveQuery']['completeCue']['fittedGain']) < 1e-10
    assert abs(fixed_effective['signedPearson']-saved['maxima']['globalEffectiveQuery']['effectiveSpan']['signedPearson']) < 1e-10
    assert all(abs(q['signedPearson']-p['signedPearson'])<1e-10 for q,p in zip(quarters,saved['activeSubwindows']))
    assert abs(reverse_full['signedPearson']-saved['reversedFullReferenceGlobalMaximum']['signedFFT']) < 1e-9
    assert abs(reverse_effective['signedPearson']-saved['reversedEffectiveQueryAcquisitionMaximum']['signedFFT']) < 1e-9
    for path, expected in pins.items():
        held(K/path,expected)
    for binding in inputs['references']:
        held(binding['pcmPath'],binding['pcmSHA256'])
    stat_after = video_path.stat()
    assert (stat_before.st_ino,stat_before.st_size,stat_before.st_mtime_ns)==(stat_after.st_ino,stat_after.st_size,stat_after.st_mtime_ns)
    report = dict(schema='stella.mimi102.independent-saved-pcm-dsp-peer.rootfalse.v1',
        status='PASS_INDEPENDENT_NUMERICAL_REPRODUCTION',rootConfirmed=False,
        formalAcceptance=False,installationAuthorized=False,sourceNodeAttributionAccepted=False,
        mouthCausalityAccepted=False,subjectiveListeningPerformed=False,
        independentSource=seal_ref,inputs=input_ref,terminal=terminal_ref,
        sourcePCM=source_ref,sourceEvidence=producer_ref,
        originalExecution=seal['originalExecution'],
        sourceVideo={**video,'actualSHA256':actual_video_sha,'decodeInvoked':False},
        sourceClock=dict(firstPTS=origin,timeBase=[1,RATE],firstSourceSeconds=first_seconds,
            endExclusiveSeconds=end_seconds,samples=len(source),blocks=len(blocks),
            everyBlockPTSAndPCMAdler32Exact=True,originalLog=log_ref,clockMetadata=clock_ref),
        referencePCMProofs=references,originalReferenceDecodeProof=old_events_ref,
        target=dict(cue=TARGET,bank='vo_adv_mimi',samples=len(reference),
            fullPeak=target['full'],effectivePeak=target['effectiveQuery'],
            cueZeroSample=zero,absoluteCueZeroSeconds=first_seconds+zero/RATE,
            fullIntervalSeconds=[first_seconds+zero/RATE,first_seconds+(zero+len(reference))/RATE],
            effectiveBounds=[first,end],paddedQueryBounds=[left,right],
            full=fixed_full,effective=fixed_effective,quarters=quarters,
            localControls=controls,reversedFullWindowMaximum=reverse_full,
            reversedEffectiveWindowMaximum=reverse_effective,mostNegativeFullWindow=negative_full),
        otherMimiStrongest=others[0],completeWindowBankResults=bank_results,
        ineligibleLongCues=[r for r in bank_results if not r['completeCueEligible']],
        maximumProducerCoefficientError=max(errors),
        # NumPy comparisons produce np.bool_ scalars. Convert only the JSON
        # representation; the numeric calculations and acceptance boundaries
        # are unchanged from the retained first, serialization-failed attempt.
        observations=dict(fullAndEffectivePeakSameSample=bool(target['full']['cueZeroSample']==zero),
            effectiveSignedPearsonAtLeastHistoricalPoint8=bool(fixed_effective['signedPearson']>=.8),
            fittedGainPositive=bool(fixed_full['fittedGain']>0),
            targetStrongerThanOtherMimi=bool(target['effectiveQuery']['signedPearson']>others[0]['effectiveQuery']['signedPearson'])),
        priorReviewFailure=seal.get('priorReviewFailure'),
        operations=dict(numpy=np.__version__,scipyImported=False,externalCommandsExecuted=False,
            producerCoreOrBusinessModulesImported=False,audioOrVideoDecoded=False,
            PCMRegeneratedOrCopied=False,browser=False,images=False,listening=False,
            dataOrCanonicalSourceWrite=False,nice=19,cpuAffinity=[0,1],blasOMPThreads=1),
        boundaries=[
            'Numerical reproducibility and waveform fingerprints are separate from native node102/speaker attribution, which requires the original visible dialogue interval.',
            'No fitted gain, measured offset, wait, command phase, mouth driver or playback field is proposed by these diagnostic values.',
            'Long references remain ineligible as whole cues and are never truncated to force a score.',
            'The foreign Felt reference is a comparator, not a positive control for this acquisition window.',
            'No subjective listening, native CSV recovery, saved gameplay or full scene acceptance is claimed.'
        ])
    output = OUT/'review.rootfalse.json'
    data = (json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
    assert len(data)<1024*1024
    with output.open('xb') as stream:
        stream.write(data)
    print(json.dumps(dict(status=report['status'],output=str(output),bytes=len(data),sha256=digest(data),
        cueZero=report['target']['absoluteCueZeroSeconds'],interval=report['target']['fullIntervalSeconds'],
        full=fixed_full,effective=fixed_effective,quarters=[q['signedPearson'] for q in quarters],
        strongestOther=others[0],reversedFull=reverse_full['signedPearson'],
        reversedEffective=reverse_effective['signedPearson']),ensure_ascii=False))


if __name__=='__main__':
    try:
        main()
    except BaseException as error:
        with (OUT/'second-attempt-first-failure.rootfalse.json').open('x') as stream:
            json.dump(dict(rootConfirmed=False,errorType=type(error).__name__,error=str(error),
                traceback=traceback.format_exc(),noMediaInvoked=True,automaticRetry=False),stream,indent=2)
        raise
