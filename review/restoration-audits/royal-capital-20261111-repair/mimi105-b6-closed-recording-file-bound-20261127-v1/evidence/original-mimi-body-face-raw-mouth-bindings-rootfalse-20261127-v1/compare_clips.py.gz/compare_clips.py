"""Compare two actual original Unity mouth bindings with their D motion3 data.

The original controller PPtr and external CAB identity select each clip.
The complete binding tables are inspected before looking at D's curves, so a
converted curve cannot be mistaken for evidence of an original binding. All
bindings in these two clips are scalar MonoBehaviour properties; the existing
ARM reader's FindBinding method independently checks their flat channel order.
Only the selected mouth constant is compared. No player, game ELF, renderer,
texture, moc, or other animation clip is executed or decoded.
"""
from pathlib import Path
import ast
import hashlib
import inspect
import json
import os
import platform
import struct
import UnityPy
from UnityPy.helpers import CompressionHelper

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
A = ROOT / 'artifacts/stella-script-continuation-20261121'
BASE = ROOT / 'data/extracted_archives/original/com.sega.stella/files/AssetBundle/assets'
D = A / 'data-checkout/assets/models/mimi01/ac/motions'
PATH_PROOF = A / 'original-mimi-mouth-components-and-postanimation-rootfalse-20261127-v1/component-and-clip-fields.original.json'
assert platform.machine() == 'aarch64'
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
proof_raw = PATH_PROOF.read_bytes()
assert hashlib.sha256(proof_raw).hexdigest() == 'b10eb586516d451960908e57ab09c98c6e753a765eb0d1e1b32a17bf2255d0da'
proof = json.loads(proof_raw)
assert proof['mouthTags'][0]['relativePath'] == 'Parameters/ParamMouthOpenY'
assert proof['mouthTags'][0]['pathCRC32'] == 3995501637

tokens = ('act_banzai_w', 'face_egao_w')
source_paths = [BASE / 'ac_mimi01.prefab', PATH_PROOF]
source_paths += [BASE / ('ac_mimi01_' + t + '.anim') for t in tokens]
source_paths += [D / ('AC_mimi01_' + t + '.motion3.json') for t in tokens]
held = {p: p.read_bytes() for p in source_paths}


def fingerprint(path, raw):
    return dict(path=str(path.relative_to(ROOT)), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def unpacked_size(raw):
    # Read only the small block-info header before allowing either clip decode.
    cursor = 0
    for part in range(3):
        end = raw.index(0, cursor)
        cursor = end + 1
        if part == 0:
            assert raw[:end] == b'UnityFS'
            version = struct.unpack_from('>I', raw, cursor)[0]
            cursor += 4
    size, compressed, uncompressed, flags = struct.unpack_from('>QIII', raw, cursor)
    cursor += 20
    assert version == 7 and size == len(raw) and flags & 0x3f in (2, 3)
    cursor = (cursor + 15) // 16 * 16
    header = raw[-compressed:] if flags & 0x80 else raw[cursor:cursor + compressed]
    header = CompressionHelper.decompress_lz4(header, uncompressed)
    count = struct.unpack_from('>I', header, 16)[0]
    return sum(struct.unpack_from('>I', header, 20 + i * 10)[0] for i in range(count))


clip_sizes = {t: unpacked_size(held[BASE / ('ac_mimi01_' + t + '.anim')]) for t in tokens}
assert sum(clip_sizes.values()) == 57744 and sum(clip_sizes.values()) <= 5 * 1024 * 1024
prefab = BASE / 'ac_mimi01.prefab'
assert hashlib.sha256(held[prefab]).hexdigest() == '0e23ea6559998a406d49d75dc72c639a6eb21b724a535059c63025f8a950818e'
environment = UnityPy.load(held[prefab])
objects = {o.path_id: o for o in environment.objects}
controller_object = objects[1929233324985180327]
controller = controller_object.read_typetree()
assert controller['m_Name'] == 'AC_mimi01_ver2'
names = dict(controller['m_TOS'])
states = {}
for machine in controller['m_Controller']['m_StateMachineArray']:
    for entry in machine['data']['m_StateConstantArray']:
        state = entry['data']
        name = names[state['m_NameID']]
        if name in tokens:
            assert name not in states
            states[name] = state
assert set(states) == set(tokens)
comparisons = []
reader_path = None
for token in tokens:
    state = states[token]
    nodes = state['m_BlendTreeConstantArray'][0]['data']['m_NodeArray']
    assert len(nodes) == 1
    index = nodes[0]['data']['m_ClipID']
    reference = controller['m_AnimationClips'][index]
    external = controller_object.assets_file.externals[reference['m_FileID'] - 1].path
    clip_path = BASE / ('ac_mimi01_' + token + '.anim')
    clip_environment = UnityPy.load(held[clip_path])
    obj = next(o for o in clip_environment.objects if o.path_id == reference['m_PathID'])
    assert obj.type.name == 'AnimationClip'
    assert external.rsplit('/', 1)[1].lower() == obj.assets_file.name.lower()
    clip = obj.read_typetree()
    assert clip['m_Name'] == 'AC_mimi01_' + token
    bindings = clip['m_ClipBindingConstant']['genericBindings']
    assert all(b['typeID'] == 114 and b['customType'] == b['isPPtrCurve'] == 0 for b in bindings)
    assert not clip['m_ClipBindingConstant']['pptrCurveMapping']
    matches = [(i, b) for i, b in enumerate(bindings) if b['path'] == 3995501637 and b['attribute'] == 3702945584]
    assert len(matches) == 1
    flat_index, mouth = matches[0]
    script_obj = next(o for o in clip_environment.objects if o.path_id == mouth['script']['m_PathID'])
    script = script_obj.read_typetree()
    assert script['m_ClassName'] == 'CubismParameter' and script['m_Namespace'] == 'Live2D.Cubism.Core'
    packed = clip['m_MuscleClip']['m_Clip']['data']
    stream_count = packed['m_StreamedClip']['curveCount']
    dense_count = packed['m_DenseClip']['m_CurveCount']
    constants = packed['m_ConstantClip']['data']
    assert len(bindings) == stream_count + dense_count + len(constants)
    assert dense_count == 0
    constant_index = flat_index - stream_count - dense_count
    assert 0 <= constant_index < len(constants)
    constant = constants[constant_index]
    assert constant == 1.0

    # Check the existing reader's binding resolution, including its vector
    # width rule. Every source binding here is type114, so each occupies one
    # channel; the mouth cannot silently shift across a Transform vector.
    typed = obj.read()
    resolved = typed.m_ClipBindingConstant.FindBinding(flat_index)
    assert resolved.path == mouth['path'] and resolved.attribute == mouth['attribute']
    reader_path = Path(inspect.getfile(type(typed)))
    data_path = D / ('AC_mimi01_' + token + '.motion3.json')
    data = json.loads(held[data_path])
    mouth_curves = [c for c in data['Curves'] if c.get('Target') == 'Parameter' and c.get('Id') == 'ParamMouthOpenY']
    assert len(mouth_curves) == 1
    assert mouth_curves[0]['Segments'] == [0, 1, 0, 2, 1]
    assert data['Meta']['Duration'] == clip['m_MuscleClip']['m_StopTime'] - clip['m_MuscleClip']['m_StartTime'] == 2
    comparisons.append(dict(token=token, controllerStateNameID=state['m_NameID'],
        controllerClipIndex=index, originalControllerPPtr=reference, originalExternalCAB=external,
        originalBundle=fingerprint(clip_path, held[clip_path]), uncompressedAssetBytes=clip_sizes[token],
        originalClip=dict(pathID=obj.path_id, name=clip['m_Name'], bytes=obj.byte_size,
                          rawSHA256=hashlib.sha256(obj.get_raw_data()).hexdigest()),
        rawMouthBinding=mouth, matchingMouthBindingCount=len(matches), bindingOrdinal=flat_index,
        allBindingCount=len(bindings), allBindingsAreScalarMonoBehaviourProperties=True,
        streamedCurveCount=stream_count, denseCurveCount=dense_count, constantCurveCount=len(constants),
        constantArrayIndex=constant_index, rawConstantValue=constant,
        packedChannelTotalEqualsBindingCount=True, existingReaderFindBindingAgrees=True,
        scriptIdentity=dict(className=script['m_ClassName'], namespace=script['m_Namespace'], assembly=script['m_AssemblyName']),
        originalDuration=2, DFile=fingerprint(data_path, held[data_path]),
        DMouthCurve=mouth_curves[0], DDuration=data['Meta']['Duration'],
        DExplicitConstantOneAgreesWithOriginal=True, canonicalInventedAnUnboundMouthChannel=False))

reader_raw = reader_path.read_bytes()
assert all(path.read_bytes() == raw for path, raw in held.items())
output = dict(schema='stella.original-mimi-two-clip-mouth-binding-comparison.v1', rootConfirmed=False,
    sourceOnly=True, controllerName=controller['m_Name'], controllerObjectPathID=controller_object.path_id,
    sourceInputs=[fingerprint(p, b) for p, b in held.items()],
    reusedOriginalPathBinding=dict(proof=fingerprint(PATH_PROOF, proof_raw), path='Parameters/ParamMouthOpenY', pathCRC32=3995501637, attribute='Value', attributeCRC32=3702945584),
    scalarBindingResolution=dict(rule='UnityPy AnimationClipBindingConstant.FindBinding: non-Transform bindings each consume one channel; constant array follows streamed and dense channel ranges.', readerFile=fingerprint(reader_path, reader_raw), sourceLines='535-554'),
    comparisons=comparisons, totalSelectedClipUncompressedBytes=sum(clip_sizes.values()),
    allSourceBytesBeforeAfterExact=True, other39MotionClipsDecoded=False,
    playerOrGameELFExecuted=False, imagesTexturesMocMeshesOrMediaDecoded=False,
    DCOrGitWrites=False, machine=platform.machine(), UnityPyVersion=UnityPy.__version__, nice=19, cpuAffinity=[0, 1])
(OUT / 'comparison.original-vs-D.rootfalse.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(originalMouthBindings='both present', originalConstants=[c['rawConstantValue'] for c in comparisons], DAgrees=True, allSourcesUnchanged=True, clipUncompressedBytes=sum(clip_sizes.values()))))
