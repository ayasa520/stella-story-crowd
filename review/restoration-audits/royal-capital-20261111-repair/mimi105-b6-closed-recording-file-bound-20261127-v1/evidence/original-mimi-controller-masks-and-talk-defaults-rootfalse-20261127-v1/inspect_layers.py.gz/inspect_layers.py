"""Read only the known original Mimi Animator and AnimatorController typetrees.

This is an offline serialized-field audit, not an Animator simulation. The
UnityFS block table is inspected before UnityPy opens the bundle so that the
complete newly decompressed asset-data range stays below the task's 5 MiB
limit. No AnimationClip, texture, model, media, or scene object is decoded.
Compiled mask fields are preserved without inventing their engine semantics.
"""
from pathlib import Path
import hashlib
import json
import os
import platform
import struct
import UnityPy
from UnityPy.helpers import CompressionHelper

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'data/extracted_archives/original/com.sega.stella/files/AssetBundle/assets/ac_mimi01.prefab'
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
assert platform.machine() == 'aarch64'
held = SOURCE.read_bytes()
digest = hashlib.sha256(held).hexdigest()
assert len(held) == 641227
assert digest == '0e23ea6559998a406d49d75dc72c639a6eb21b724a535059c63025f8a950818e'
cursor = 0


def zero_string():
    global cursor
    end = held.index(0, cursor)
    result = held[cursor:end].decode()
    cursor = end + 1
    return result


assert zero_string() == 'UnityFS'
version = struct.unpack_from('>I', held, cursor)[0]
cursor += 4
unity, revision = zero_string(), zero_string()
size, compressed, uncompressed, flags = struct.unpack_from('>QIII', held, cursor)
cursor += 20
assert version == 7 and size == len(held)
cursor = (cursor + 15) // 16 * 16
block_info = held[-compressed:] if flags & 0x80 else held[cursor:cursor + compressed]
assert flags & 0x3f in (2, 3)
block_info = CompressionHelper.decompress_lz4(block_info, uncompressed)
count = struct.unpack_from('>I', block_info, 16)[0]
blocks = [struct.unpack_from('>IIH', block_info, 20 + i * 10) for i in range(count)]
asset_bytes = sum(row[0] for row in blocks)
assert asset_bytes == 2696916 and asset_bytes <= 5 * 1024 * 1024

# Load the held, hash-bound buffer. Only these two known object typetrees are
# interpreted; other objects' type labels are metadata, never their contents.
environment = UnityPy.load(held)
objects = {obj.path_id: obj for obj in environment.objects}
animator_object = objects[-7277071453616331086]
controller_object = objects[1929233324985180327]
assert animator_object.type.name == 'Animator'
assert controller_object.type.name == 'AnimatorController'
animator = animator_object.read_typetree()
controller = controller_object.read_typetree()
assert animator['m_Controller'] == {'m_FileID': 0, 'm_PathID': controller_object.path_id}
assert controller['m_Name'] == 'AC_mimi01_ver2'
names = dict(controller['m_TOS'])
data = controller['m_Controller']
layers = []
name_subset = {}
talk_states = []
for ordinal, entry in enumerate(data['m_LayerArray']):
    raw = entry['data']
    name = names[raw['m_Binding']]
    name_subset[raw['m_Binding']] = name
    machine = data['m_StateMachineArray'][raw['m_StateMachineIndex']]['data']
    states = [state['data'] for state in machine['m_StateConstantArray']]
    default = states[machine['m_DefaultState']]
    name_subset[default['m_NameID']] = names[default['m_NameID']]
    layers.append(dict(ordinal=ordinal, name=name, rawLayerData=raw,
                       rawDefaultStateIndex=machine['m_DefaultState'],
                       rawDefaultStateNameID=default['m_NameID'],
                       resolvedDefaultStateName=names[default['m_NameID']],
                       stateCount=len(states)))
    if name == 'talk':
        # The full four small state records preserve write-defaults/loop flags
        # and transition arrays without decoding referenced AnimationClips.
        for state in states:
            name_subset[state['m_NameID']] = names[state['m_NameID']]
            talk_states.append(dict(name=names[state['m_NameID']], rawStateData=state))


def object_witness(obj):
    raw = obj.get_raw_data()
    assert len(raw) == obj.byte_size
    return dict(pathID=obj.path_id, type=obj.type.name, bytes=obj.byte_size,
                rawSHA256=hashlib.sha256(raw).hexdigest())


assert SOURCE.read_bytes() == held
result = dict(schema='stella.original-mimi-controller-layers.raw-fields.v1',
              rootConfirmed=False, sourceOnly=True,
              source=dict(path=str(SOURCE.relative_to(ROOT)), bytes=len(held), sha256=digest),
              bundle=dict(formatVersion=version, revision=revision, blockCount=count,
                          uncompressedAssetBytes=asset_bytes, within5MiB=True),
              objects=[object_witness(animator_object), object_witness(controller_object)],
              animatorRaw=animator, controllerName=controller['m_Name'],
              controllerRootKeys=list(controller), controllerDataKeys=list(data),
              layers=layers, talkStates=talk_states,
              nameMapSubset=[[key, value] for key, value in name_subset.items()],
              avatarMaskObjectsInThisBundle=sum(o.type.name == 'AvatarMask' for o in objects.values()),
              noOtherObjectTypetreesRead=True, noAnimationClipsDecoded=True,
              allSourceBytesUnchanged=True, UnityPyVersion=UnityPy.__version__,
              machine=platform.machine(), nice=19, cpuAffinity=[0, 1])
with (OUT / 'raw-fields.original.json').open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(dict(controller=controller['m_Name'], layers=len(layers),
                      talkStates=len(talk_states), uncompressedAssetBytes=asset_bytes,
                      originalSourceUnchanged=True)))
