"""Bind a small original Cubism mouth path; never execute the game ELF.

Owner/image and code-generation-module headers are verified before token RIDs
index the original method table. File-backed PT_LOAD spans supply data only.
All selected complete bodies are small; retained disassembly is independently
bounded to 16 KiB including the raw bodies. Larger bodies retain selected call
and branch windows, never an implied reconstruction of omitted instructions.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import sys

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
LOGS = Path('/home/rikka/.local/state/stella-migration-20261112/pre-tar-update/files/logs')
sys.path.insert(0, str(ROOT))
from lost_in_memories.tools.metadata import Metadata

ELF = ROOT / 'data/libil2cpp-offline.so'
OLD = ROOT / 'data/native_recovery/royal-capital-20261110/repair-20261111/episode8-native-reentry-investigation-20261121-v1/native-reentry-bindings.json'
EXPECTED = {
    ELF: '54c97bce616bdb062f12b0bccba47b1c6ff17f61da450d8bd0efa403f8822c05',
    LOGS / 'metadata-decrypted.dat': '2cde31e37d9c6c58f3a1bb7bae6b12e51d456af7de03d604bc953116887b1b3e',
    LOGS / 'metadata-types.json': 'b45d0eedc7f4fbb7a341134965c8dfdb8699144c6c04b58b069857575a99b6bb',
    ROOT / 'lost_in_memories/config/metadata_layout.json': '6a4805e3b4137c2a7dd1dd2034d29b42f4a88a6598ac0262f82220b0338f29ec',
    ROOT / 'lost_in_memories/tools/metadata.py': '305bb47a639f46cf6d0e7ef0bdd34b0811cad2b5520ffba3b01bb6228b577a24',
    OLD: '8e3867f6275b01917e24e99f90568669bdcd1b05fa9dd254b3e13d7d87ab8e91',
}


def fingerprint(path):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == EXPECTED[path], str(path)
    return dict(path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                bytes=path.stat().st_size, sha256=digest)


assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
before = [fingerprint(p) for p in EXPECTED]
metadata = Metadata((LOGS / 'metadata-decrypted.dat').read_bytes(),
                    json.loads((ROOT / 'lost_in_memories/config/metadata_layout.json').read_bytes()),
                    json.loads((LOGS / 'metadata-types.json').read_bytes()))
module = next(m for m in json.loads(OLD.read_bytes())['modules'] if m['name'] == 'Assembly-CSharp.dll')
image = list(struct.unpack_from('<10i', metadata.data, module['imageRecordOffset']))
assert image == module['imageRecord'] and metadata.string(image[0]) == module['name']
fd = os.open(ELF, os.O_RDONLY)
data_reads = 0


def read_at(offset, count):
    global data_reads
    assert 0 < count <= 4096
    result = os.pread(fd, count, offset)
    assert len(result) == count
    data_reads += count
    return result


header = read_at(0, 64)
assert header[:7] == b'\x7fELF\x02\x01\x01'
assert struct.unpack_from('<H', header, 18)[0] == 183
phoff = struct.unpack_from('<Q', header, 32)[0]
phsize, phcount = struct.unpack_from('<HH', header, 54)
assert phsize == 56 and 0 < phcount <= 32
raw_headers = read_at(phoff, phsize * phcount)
segments = [struct.unpack_from('<IIQQQQQQ', raw_headers, i * phsize) for i in range(phcount)]


def file_offset(va, count):
    candidates = [s for s in segments if s[0] == 1 and s[3] <= va and va + count <= s[3] + s[5]]
    assert len(candidates) == 1
    s = candidates[0]
    return s[2] + va - s[3]


def read_va(va, count):
    return read_at(file_offset(va, count), count)


name_va, count, table_va = struct.unpack('<QQQ', read_va(int(module['codeGenModuleVA'], 16), 24))
assert read_va(name_va, 64).split(b'\0', 1)[0].decode() == module['name']
assert count == module['count'] and table_va == int(module['methodTableVA'], 16)
assert file_offset(table_va, count * 8) == int(module['methodTableFileOffset'], 16)
core = next(m for m in json.loads(OLD.read_bytes())['modules'] if m['name'] == 'UnityEngine.CoreModule.dll')
core_image = list(struct.unpack_from('<10i', metadata.data, core['imageRecordOffset']))
assert core_image == core['imageRecord'] and metadata.string(core_image[0]) == core['name']
core_name, core_count, core_table = struct.unpack('<QQQ', read_va(int(core['codeGenModuleVA'], 16), 24))
assert read_va(core_name, 64).split(b'\0', 1)[0].decode() == core['name']
assert core_count == core['count'] and core_table == int(core['methodTableVA'], 16)
api_bindings = []
for index in range(core_image[2], core_image[2] + core_image[3]):
    if metadata.definition_name(index) != 'UnityEngine.Behaviour':
        continue
    for method in metadata.declaration(index, True)['methods']:
        if method['name'] not in ('get_enabled', 'set_enabled'):
            continue
        slot = core_table + ((int(method['token'], 16) & 0xffffff) - 1) * 8
        va = struct.unpack('<Q', read_va(slot, 8))[0]
        api_bindings.append(dict(owner='UnityEngine.Behaviour', module=core['name'],
                                 **method, slotVA=hex(slot), VA=hex(va)))
assert {b['name']: b['VA'] for b in api_bindings} == {'get_enabled': '0x1d3b0e4', 'set_enabled': '0x1d3b124'}
declarations, bindings = [], []
# The preceding EyeBlink owner supplies the actual next start after the shared
# array BlendToValue body. Without it, sparse owner selection would incorrectly
# include neighboring methods in that body's retained span.
for index in (6088, 6092, 6093, 6094, 6097, 6128, 6129, 6199, 6201, 7141):
    owner = metadata.declaration(index, True)
    assert image[2] <= index < image[2] + image[3]
    declarations.append(owner)
    for method in owner['methods']:
        rid = int(method['token'], 16) & 0xffffff
        assert 0 < rid <= count
        slot = table_va + (rid - 1) * 8
        va = struct.unpack('<Q', read_va(slot, 8))[0]
        bindings.append(dict(owner=owner['name'], ownerIndex=index, **method,
                             slotVA=hex(slot), slotFileOffset=hex(file_offset(slot, 8)),
                             VA=hex(va), fileOffset=hex(file_offset(va, 4))))

selected_tokens = {'0x6000504', '0x6000506', '0x6000507', '0x6000509',
                   '0x600050a', '0x600048b', '0x600048c', '0x600048d', '0x600049a',
                   '0x6001871'}
bodies, raw_bytes, text_bytes = [], 0, 0
for item in bindings:
    if item['token'] not in selected_tokens:
        continue
    start = int(item['VA'], 16)
    end = min(int(b['VA'], 16) for b in bindings if int(b['VA'], 16) > start)
    assert 0 < end - start <= 1024
    raw = read_va(start, end - start)
    prefix = item['token'] + '-' + item['name'].replace('.', '_')
    (OUT / (prefix + '.original.bin')).write_bytes(raw)
    command = ['/usr/bin/llvm-objdump', '--disassemble', '--no-show-raw-insn',
               '--start-address=' + hex(start), '--stop-address=' + hex(end), str(ELF)]
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    assert not result.stderr
    instructions = [s for s in result.stdout.splitlines() if re.match(r'^\s*[0-9a-f]+:', s)]
    if item['token'] == '0x6001871':
        # Init is read only to identify callback wiring. Its raw body remains
        # available, but this packet retains only call/store windows in text.
        chosen = set()
        for i, line in enumerate(instructions):
            if any(t in line for t in ('\tbl\t', '\tstr\t', '\tstrb\t')):
                chosen.update(range(max(0, i - 1), i + 1))
        retained = [line for i, line in enumerate(instructions) if i in chosen]
        scope = 'selected callback call/store windows; full body raw retained'
    elif len(raw) <= 160:
        retained = instructions
        scope = 'all instructions in complete bounded body'
    else:
        chosen = set()
        for i, line in enumerate(instructions):
            if any(t in line for t in ('\tbl\t', '\tb\t', '\tcbz\t', '\tcbnz\t', '\ttbz\t', '\ttbnz\t', '\tcmp\t', '\tb.eq\t', '\tb.ne\t', '\tstr\t', '\tstrb\t')):
                chosen.update(range(max(0, i - 1), min(len(instructions), i + 2)))
            if item['token'] == '0x600048d' and 0x1675ac0 <= int(line.split(':', 1)[0].strip(), 16) <= 0x1675ad0:
                chosen.add(i)
        retained = [line for i, line in enumerate(instructions) if i in chosen]
        scope = 'selected call/branch/store instruction windows; full body raw retained'
    text = '\n'.join(retained) + '\n'
    (OUT / (prefix + '.disassembly.selected.txt')).write_text(text)
    raw_bytes += len(raw)
    text_bytes += len(text.encode())
    bodies.append(dict(**item, stopVAExclusive=hex(end), rawBytes=len(raw),
                       rawSHA256=hashlib.sha256(raw).hexdigest(),
                       rawFile=prefix + '.original.bin', retainedTextFile=prefix + '.disassembly.selected.txt',
                       retainedTextBytes=len(text.encode()), retainedTextScope=scope))
os.close(fd)
assert raw_bytes + text_bytes <= 16384
assert before == [fingerprint(p) for p in EXPECTED]
output = dict(schema='stella.original-mimi-mouth-native-bindings.v1', rootConfirmed=False,
              originalGameELFExecuted=False, allInputsBeforeAfterExact=True,
              inputs=before, moduleHeaderFreshVerified=True, declarations=declarations,
              coreAPIHeadersFreshVerified=True, coreAPIBindings=api_bindings,
              bindings=bindings, bodies=bodies, nativeRawBytes=raw_bytes,
              retainedDisassemblyBytes=text_bytes, boundedLookupAndBodyELFReads=data_reads,
              hashOnlyFullFileReadsSeparate=True, nice=19, cpuAffinity=[0, 1])
(OUT / 'native-bindings.original.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(bodyCount=len(bodies), rawBytes=raw_bytes, selectedTextBytes=text_bytes,
                      boundedELFReads=data_reads, originalELFExecuted=False)))
