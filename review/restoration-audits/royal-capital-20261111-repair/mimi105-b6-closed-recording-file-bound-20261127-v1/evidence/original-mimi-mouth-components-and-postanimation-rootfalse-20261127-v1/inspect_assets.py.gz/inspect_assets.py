"""Inspect selected original Mimi mouth metadata using the existing ARM reader.

Only the known prefab and two tiny controller-referenced clip bundles are
opened. Base MonoBehaviour headers locate the complete mouth-tag set without
decoding unrelated custom payloads (including the model's moc). No texture,
video, mesh, or other motion clip is decoded. Parameter binding is checked
against the actual original Transform chain and the original script identity;
normal-player indexes and recovered motion3 JSON are not inputs.
"""
from pathlib import Path
import hashlib
import json
import math
import os
import platform
import struct
import zlib
import UnityPy

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'data/extracted_archives/original/com.sega.stella/files/AssetBundle/assets'
EXPECTED = {
    'ac_mimi01.prefab': (641227, '0e23ea6559998a406d49d75dc72c639a6eb21b724a535059c63025f8a950818e'),
    'ac_mimi01_face_talk_off.anim': (6505, 'b2cbbf4bb7c75948a4a56532f2040b9832dbb0f555a3ac99931c048912008e44'),
    'ac_mimi01_face_talk_normal.anim': (6794, '0fd7eb98bfd48f79c2528e7ed982a95490c8e004aef292110a716b9fa011c910'),
}
assert platform.machine() == 'aarch64'
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
held = {name: (BASE / name).read_bytes() for name in EXPECTED}
sources = []
for name, raw in held.items():
    assert (len(raw), hashlib.sha256(raw).hexdigest()) == EXPECTED[name]
    sources.append(dict(path=str((BASE / name).relative_to(ROOT)), bytes=len(raw), sha256=EXPECTED[name][1]))
environment = UnityPy.load(held['ac_mimi01.prefab'])
objects = {obj.path_id: obj for obj in environment.objects}


def witness(obj):
    raw = obj.get_raw_data()
    return dict(pathID=obj.path_id, type=obj.type.name, bytes=len(raw),
                rawSHA256=hashlib.sha256(raw).hexdigest())


scripts = {o.path_id: o.read_typetree() for o in objects.values() if o.type.name == 'MonoScript'}
assert scripts[6232741987602782148]['m_ClassName'] == 'CubismMouthController'
assert scripts[-9199334610498929777]['m_ClassName'] == 'CubismMouthParameter'
assert [p for p, s in scripts.items() if s['m_ClassName'] == 'CubismMouthParameter'] == [-9199334610498929777]
root = objects[6964406978850909493].read_typetree()
root_components = []
mouth_controller = None
for ref in root['m_Component']:
    obj = objects[ref['component']['m_PathID']]
    if obj.type.name != 'MonoBehaviour':
        continue
    # Root custom components are all small; their exact identities establish
    # serialized defaults only, never the live mode of original scenario 105.
    raw = obj.read_typetree()
    script = scripts[raw['m_Script']['m_PathID']]
    root_components.append(dict(pathID=obj.path_id, className=script['m_ClassName'],
                                namespace=script['m_Namespace'], enabled=raw['m_Enabled']))
    if script['m_ClassName'] == 'CubismMouthController':
        mouth_controller = dict(object=witness(obj), raw=raw, scriptRaw=script)
assert mouth_controller['raw']['m_Enabled'] == 0

# The existing reader normally auto-decodes a MonoBehaviour's custom tail.
# Disable that behavior only in this in-memory reader while selecting tags;
# the verified base-header parser still reads m_GameObject/m_Enabled/m_Script.
assets = objects[1929233324985180327].assets_file
auto_tree = assets._enable_type_tree
assets._enable_type_tree = False
tag_ids, header_count = [], 0
try:
    for obj in objects.values():
        if obj.type.name == 'MonoBehaviour':
            header_count += 1
            header = obj.read()
            assert header.m_Script.file_id == 0 and header.m_Script.path_id in scripts
            if header.m_Script.file_id == 0 and header.m_Script.path_id == -9199334610498929777:
                tag_ids.append(obj.path_id)
finally:
    assets._enable_type_tree = auto_tree
tags = []
for path_id in tag_ids:
    obj = objects[path_id]
    raw = obj.read_typetree()
    game_object = objects[raw['m_GameObject']['m_PathID']].read_typetree()
    parameter, transform = None, None
    for ref in game_object['m_Component']:
        component = objects[ref['component']['m_PathID']]
        if component.type.name == 'Transform':
            transform = component
        elif component.type.name == 'MonoBehaviour':
            data = component.read_typetree()
            if scripts[data['m_Script']['m_PathID']]['m_ClassName'] == 'CubismParameter':
                parameter = dict(object=witness(component), raw=data)
    chain = []
    while transform is not None:
        data = transform.read_typetree()
        owner = objects[data['m_GameObject']['m_PathID']].read_typetree()
        chain.append(dict(transformPathID=transform.path_id, gameObjectPathID=data['m_GameObject']['m_PathID'], name=owner['m_Name']))
        parent = data['m_Father']
        assert parent['m_FileID'] == 0
        transform = objects[parent['m_PathID']] if parent['m_PathID'] else None
    assert chain[-1]['name'] == 'AC_mimi01'
    path = '/'.join(row['name'] for row in reversed(chain[:-1]))
    tags.append(dict(object=witness(obj), raw=raw, gameObjectRaw=game_object,
                     parameter=parameter, transformChainLeafToRoot=chain,
                     relativePath=path, pathCRC32=zlib.crc32(path.encode())))
assert len(tags) == 1 and tags[0]['relativePath'] == 'Parameters/ParamMouthOpenY'

controller_object = objects[1929233324985180327]
controller = controller_object.read_typetree()
names = dict(controller['m_TOS'])
talk_layer = next(e['data'] for e in controller['m_Controller']['m_LayerArray'] if names[e['data']['m_Binding']] == 'talk')
machine = controller['m_Controller']['m_StateMachineArray'][talk_layer['m_StateMachineIndex']]['data']
clip_rows = []
for entry in machine['m_StateConstantArray']:
    state = entry['data']
    name = names[state['m_NameID']]
    if name not in ('face_talk_off', 'face_talk_normal'):
        continue
    node = state['m_BlendTreeConstantArray'][0]['data']['m_NodeArray'][0]['data']
    clip_index = node['m_ClipID']
    reference = controller['m_AnimationClips'][clip_index]
    external = controller_object.assets_file.externals[reference['m_FileID'] - 1].path
    bundle_name = 'ac_mimi01_' + name + '.anim'
    clip_environment = UnityPy.load(held[bundle_name])
    clip_object = next(o for o in clip_environment.objects if o.path_id == reference['m_PathID'])
    assert clip_object.type.name == 'AnimationClip'
    assert external.rsplit('/', 1)[1].lower() == clip_object.assets_file.name.lower()
    clip = clip_object.read_typetree()
    nonpacked_counts = {k: len(clip[k]) for k in ('m_RotationCurves', 'm_CompressedRotationCurves',
                        'm_EulerCurves', 'm_PositionCurves', 'm_ScaleCurves', 'm_FloatCurves', 'm_PPtrCurves')}
    assert all(value == 0 for value in nonpacked_counts.values())
    binding = clip['m_ClipBindingConstant']['genericBindings']
    assert len(binding) == 1
    assert binding[0]['path'] == tags[0]['pathCRC32'] == 3995501637
    assert binding[0]['attribute'] == zlib.crc32(b'Value') == 3702945584
    script_object = next(o for o in clip_environment.objects if o.path_id == binding[0]['script']['m_PathID'])
    script = script_object.read_typetree()
    assert script['m_ClassName'] == 'CubismParameter' and script['m_Namespace'] == 'Live2D.Cubism.Core'
    packed = clip['m_MuscleClip']['m_Clip']['data']
    stream = packed['m_StreamedClip']
    stream_bytes = struct.pack('<' + 'I' * len(stream['data']), *stream['data'])
    cursor, keys = 0, []
    while cursor < len(stream_bytes):
        time, count = struct.unpack_from('<fI', stream_bytes, cursor)
        cursor += 8
        for _ in range(count):
            index, a, b, c, value = struct.unpack_from('<I4f', stream_bytes, cursor)
            cursor += 20
            if math.isfinite(time) and time >= 0:
                keys.append(dict(time=time, channel=index, value=value))
    clip_rows.append(dict(state=name, rawClipIndex=clip_index, controllerPPtr=reference,
                          controllerExternalPath=external, object=witness(clip_object),
                          name=clip['m_Name'], genericBindings=binding,
                          bindingScriptRaw=script, resolvedPath=tags[0]['relativePath'], resolvedAttribute='Value',
                          resolution='Exact CRC32 equality to original Transform path and original CubismParameter field name; numeric binding fields retained.',
                          sampleRate=clip['m_SampleRate'], startTime=clip['m_MuscleClip']['m_StartTime'],
                          nonpackedCurveCounts=nonpacked_counts,
                          stopTime=clip['m_MuscleClip']['m_StopTime'], loopTime=clip['m_MuscleClip']['m_LoopTime'],
                          streamedCurveCount=stream['curveCount'], streamedWordsCount=len(stream['data']),
                          streamedBytesSHA256=hashlib.sha256(stream_bytes).hexdigest(), finiteStreamedKeys=keys,
                          denseCurveCount=packed['m_DenseClip']['m_CurveCount'], constantValues=packed['m_ConstantClip']['data']))
assert len(clip_rows) == 2
assert all((BASE / name).read_bytes() == raw for name, raw in held.items())
output = dict(schema='stella.original-mimi-mouth-components-clips.v1', rootConfirmed=False,
              sourceOnly=True, sources=sources, mouthController=mouth_controller,
              rootComponents=root_components, completeMonoScriptIdentities=[dict(pathID=p, className=s['m_ClassName'], namespace=s['m_Namespace'], executionOrder=s['m_ExecutionOrder']) for p, s in scripts.items()],
              completeMouthTagHeaderSelection=dict(monoBehaviourHeadersInspected=header_count, matchedPathIDs=tag_ids),
              mouthTags=tags, selectedClips=clip_rows, allSourceBytesUnchanged=True,
              mocTexturesMeshesOrVideoDecoded=False, other39MotionClipsDecoded=False,
              machine=platform.machine(), UnityPyVersion=UnityPy.__version__, nice=19, cpuAffinity=[0, 1])
(OUT / 'component-and-clip-fields.original.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(mouthController=mouth_controller['raw'], mouthTags=len(tags), selectedClips=len(clip_rows), sourcesUnchanged=True)))
