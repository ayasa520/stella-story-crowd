// Zero-dependency timing marker. As the FIRST --import it runs before the
// transport's static dependency graph is loaded. Node bootstrap and resolution
// of this marker itself remain outside coverage. This emits only small scalar
// facts to inherited stderr; it reads no resources, env values or large data.
let sequence=0;
export function startupStage(role,stage,counts={}){
  process.stderr.write('STELLA_PRIVATE_STARTUP '+JSON.stringify({pid:process.pid,
    role,stage,monotonicNs:process.hrtime.bigint().toString(),sequence:sequence++,...counts})+'\n');
}
const entry=process.argv[1]||'';
const role=entry.endsWith('/server.mjs')?'server':entry.endsWith('/prepare.mjs')?'prepare':entry.endsWith('/driver.mjs')?'driver':'node';
startupStage(role,'logging-preload-entered');
