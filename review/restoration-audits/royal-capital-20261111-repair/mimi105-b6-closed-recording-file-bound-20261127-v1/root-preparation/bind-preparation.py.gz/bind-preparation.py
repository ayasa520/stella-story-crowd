"""Bind the reviewed private diagnostic to observed ARM tools and one inventory.

This writes only a new preparation release. It does not freeze a scene, call
an API, launch a browser, or accept a motion. The prior missing system-Xvfb
path is recorded explicitly; the preserved project-local ARM executable is
validated against its archive and current dynamic dependencies instead.
"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import os
import struct
import subprocess
import tarfile

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
B = A / 'mimi105-b1f1-lossless-owner-source-rootfalse-20261127-v3'
O = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


# Use the reviewed first-read implementation, including its independent
# fallback when an archive sink fails, without importing a CLI entry point.
seal_raw = (B / 'receipt.rootfalse.json').read_bytes()
assert hashlib.sha256(seal_raw).hexdigest() == '402cf1300790fdb8d21e17cb9a5c4e2658cd02b85f6939c07603a0f302697f0e'
try:
    kit = json.loads(seal_raw)
except json.JSONDecodeError as error:
    (O / 'binding-seal-first-read.raw.gz').write_bytes(gzip.compress(seal_raw, mtime=0))
    (O / 'binding-seal-exception-doc.gz').write_bytes(gzip.compress(error.doc.encode('utf-8', 'surrogatepass'), mtime=0))
    raise
common_ref = next(item for item in kit['payloads'] if Path(item['path']) == B / 'common.py')
assert (B / 'common.py').stat().st_size == common_ref['bytes']
assert sha(B / 'common.py') == common_ref['sha256']
spec = importlib.util.spec_from_file_location('mimi_root_read_only_common', B / 'common.py')
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)

inventory_path = O / 'inventory.rootfalse.json'
inventory = common.load(inventory_path, '6e3e4c351340f065d1d3527b0c53f356787cce16ab1f7c3aa6bc9e63c9b51218')
previous = common.load(A / 'ui31-root-preparation-2b79f247-20261126-v1/inventory.rootfalse.json',
    'f23aecfd00bb5e42750c67bb7967ad7f1414c44d3117bdeb5ab4d2f23b7135ad')
assert inventory['protectedFirstThree'] == previous['protectedFirstThree']
assert len(inventory['dataInputs']) == 34403
assert inventory['allTrackedActualBytesMatchedHeadBlobs']
assert len(inventory['sourceFiles']) == 312 and len(inventory['distFiles']) == 234
head = 'b5ea79bb239c867746ffc80aa56906f83d8c68c2'
source = '6630ac70f17332efa031d021af00532d42307568'
assert inventory['dataHead'] == head and inventory['sourceHead'] == source
assert subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD']).decode().strip() == head
assert subprocess.check_output(['git', '-C', str(D), 'status', '--short']) == b''

for item in kit['payloads']:
    assert Path(item['path']).stat().st_size == item['bytes'] and sha(item['path']) == item['sha256']
peer = A / 'mimi105-b1f1-lossless-owner-source-independent-peer-rootfalse-20261127-v3/review.rootfalse.json'
assert sha(peer) == '7a4257ae23ac487fca20fb0d220b31b5d09f970343a99ed9dc6d1c989799c75d'
assert not (B / 'frozen').exists()
release = common.load(B / 'root-inputs.draft.json')
release.update(rootConfirmed=True, freezeAuthorized=True, apiPreparationAuthorized=True,
    controlledNativeCandidateAuthorized=True, fullInventoryApproved=True,
    candidateSourcePeerAccepted=True, independentRunnerAccepted=True,
    browserLaunchAuthorized=False, finalDataHead=head, finalSourceHead=source,
    inventory={'path': str(inventory_path), 'bytes': inventory_path.stat().st_size, 'sha256': sha(inventory_path)},
    independentRunnerPeer={'path': str(peer), 'bytes': peer.stat().st_size, 'sha256': sha(peer)})
tool_paths = {'python': '/usr/bin/python3', 'node': '/usr/bin/node',
    'firefox': '/usr/lib/firefox/firefox', 'ffmpeg': '/usr/bin/ffmpeg',
    'xvfb': str(ROOT / 'artifacts/stella-p30-capture-tools-20261120/usr/bin/Xvfb')}
for name, launch in tool_paths.items():
    binary = Path(launch).resolve(strict=True)
    with binary.open('rb') as stream:
        header = stream.read(20)
    assert header[:6] == b'\x7fELF\x02\x01' and struct.unpack('<H', header[18:20])[0] == 183
    assert os.access(binary, os.X_OK)
    release['tools'][name] = {'launchPath': launch, 'binaryPath': str(binary), 'sha256': sha(binary)}
    if name in inventory['tools']:
        assert release['tools'][name]['sha256'] == inventory['tools'][name]['sha256']
    release['sourceGuards'][str(binary)] = sha(binary)

capture_tools = ROOT / 'artifacts/stella-p30-capture-tools-20261120'
archive = capture_tools / 'xorg-server-xvfb-21.1.26-1-aarch64.pkg.tar.xz'
with tarfile.open(archive, 'r:xz') as package:
    held = package.extractfile('usr/bin/Xvfb').read()
assert hashlib.sha256(held).hexdigest() == release['tools']['xvfb']['sha256']
dependencies = subprocess.run(['ldd', release['tools']['xvfb']['binaryPath']], capture_output=True, check=True)
assert b'not found' not in dependencies.stdout + dependencies.stderr
# The missing system Xvfb path was an OLD root assumption, not a failure of
# this fresh binding. Record current executable/package/dependency evidence.
observation = {'historicalCorrectionReceipt': str(A / 'mimi105-four-case-root-preparation-deb3093e-20261127-v1/observed-arm-tool-path-correction.json'),
    'observedExistingArmTool': release['tools']['xvfb'],
    'existingPackageSHA256': sha(archive), 'binaryExactlyMatchesExistingPackage': True,
    'dynamicDependenciesAllResolved': True, 'newPackageOrBrowserInstalled': False}
common.write(O / 'observed-arm-tool-paths.json', observation)
with (O / 'xvfb.dependencies.stdout.log').open('xb') as stream:
    stream.write(dependencies.stdout)
# B5 preserves B4's resource bounds: the same per-PID RSS sum is capped at
# 3 GiB while every existing budget observation enforces the 512 MiB system
# MemAvailable floor. This is neither an OOM diagnosis nor a continuous floor
# guarantee. The single-case RGB/lossless/LP2 capture policy is separately
# hash-bound; program, clocks, CPU affinity and full-source acceptance stay unchanged.
release['budgets'].update(nodeHeapMiB=512, maximumOwnedRssBytes=3221225472,
    maximumOutputBytes=268435456, minimumAvailableMemoryBytes=536870912, diskReserveBytes=1610612736)
for name, expected in [
    ('episode9-mimi-first50-final-publication-receipt-20261126-v1.json', '02a6aaa6ac0c795dea435618694dd75ce7cf71a90745727f9c71c9905118ee9f'),
    ('episode9-mimi-last50-final-publication-receipt-20261127-v1.json', '7fe4c6490c0bfb2b74b6d983e240b1530afbfb7d3ac84b4992f4552b0e197c25'),
    ('chapter1-ui31-directory-final-publication-receipt-20261127-v1.json', '4fd418188bc4bb19d80f283942dc1b2028d118c52bd94153111c16a2b7fc1c26')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
for name, expected in [
    ('episode9-mimi67-voice-final-publication-receipt-20261127-v1.json', '941d87e7d676cd509ccc72c823ab7c41fb754413b892d3beb8753f5c082699d2'),
    ('chapter1-flow-and-episode13-cumulative-final-publication-receipt-20261127-v1.json', 'de9d3cfbcd00d95a6bfe6c5f410648e61b0f950fb15f56f106cc81efea26e59e'),
    ('mimi105-b4-final-publication-receipt-20261127-v1.json', '289e9cf4852a58b12cc85265570c53fb237b238f9a5d834c08beed5aee80f301')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# The closed failure and requested cleanup are authoritative publications.
# Bind their exact receipts without treating either as a motion acceptance or
# reusing the historical runtime release after the data HEAD changed.
for name, expected in [
    ('mimi105-b5-failed-startup-final-publication-receipt-20261127-v1.json', '6e4c13f007f7fa51e879e1863eccb7b8a346ac2284073ba12434b663c5ec7099'),
    ('investigation-temp-cleanup-final-receipt-20261127-v5.json', '69e6670d3cafc59d863f4535cfedf0a1a1cfe603d04510cea252483d31aeb69d')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# Bind this fresh root decision's producer as evidence; no old release, frozen
# document or runtime output is reused as current authorization.
release['sourceGuards'][str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
assert not (B / 'prepared').exists() and not (B / 'attempt-1').exists()
disk = os.statvfs(O)
assert disk.f_bavail * disk.f_frsize > release['budgets']['diskReserveBytes'] + release['budgets']['maximumOutputBytes']
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
assert available > release['budgets']['minimumAvailableMemoryBytes'] + 536870912
target = O / 'preparation.root-approved.json'
common.write(target, release)
print(json.dumps({'release': str(target), 'sha256': sha(target), 'fiveObservedArmToolsBound': True,
    'browserAuthorized': False, 'memoryAvailableBytes': available}))
