"""Retire an explicit, reviewed allowlist of closed investigation outputs.

No recursive deletion or filename-based discovery occurs here. Every candidate
must retain its reviewed inode, timestamp, allocation and content hash before
the first unlink. Historic report references remain valid as retirement records;
the large generated screenshots and debug responses are not backed up again.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
R = ROOT / 'data/native_recovery/royal-capital-20261110/repair-20261111'
D = A / 'data-checkout'
C = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout'
OUT = Path(__file__).resolve().parent


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(base, *args):
    return subprocess.check_output(['git', '-C', str(base), *args])


def snapshot():
    return {
        'dataHead': git(D, 'rev-parse', 'HEAD').decode().strip(),
        'dataStatus': git(D, 'status', '--porcelain=v1').decode(),
        'sourceHead': git(C, 'rev-parse', 'HEAD').decode().strip(),
        'sourceStatus': git(C, 'status', '--porcelain=v1').decode(),
        'rootTrackedStatus': git(ROOT, 'status', '--porcelain=v1', '--untracked-files=no').decode(),
        'rootTrackedDiffSHA256': hashlib.sha256(git(ROOT, 'diff', '--binary', 'HEAD')).hexdigest(),
    }


def free_space():
    return {str(p): os.statvfs(p).f_bavail * os.statvfs(p).f_frsize
            for p in (ROOT, Path('/tmp'))}


def write(name, value):
    raw = (json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
    with (OUT / name).open('xb') as stream:
        stream.write(gzip.compress(raw, mtime=0) if name.endswith('.gz') else raw)


def main():
    assert len(sys.argv) == 7
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19
    assert sorted(os.sched_getaffinity(0)) == [0, 1]
    entries, reports, retained, pinned_proofs = {}, [], set(), {}
    for name, expected in zip(sys.argv[1::2], sys.argv[2::2]):
        path = Path(name)
        assert digest(path) == expected
        report = json.loads(path.read_bytes())
        assert report.get('deletionPerformed') is False
        reports.append({'path': name, 'sha256': expected})
        rows = report.get('entries', report.get('candidates'))
        assert isinstance(rows, list) and rows
        for row in rows:
            assert row['path'] not in entries
            entries[row['path']] = row
        retained.update(report.get('explicitlyExcludedOriginalOrMixedImages', []))
        for proof in report.get('keptProofRefs', []):
            retained.add(proof['path'])
            pinned_proofs[proof['path']] = proof
        for row in rows:
            retained.update(row.get('retainedReviewPaths', []))
            retained.update(row.get('retainedGeneratorPaths', []))
        for group in report.get('groups', {}).values():
            if isinstance(group, dict):
                for key in ('generator', 'closedEvidence'):
                    if group.get(key):
                        retained.add(group[key])

    # These are the live, unpublished work inputs. Whole directories are kept
    # outside the deletion scope, and the primary seals are checked afterwards.
    for folder, leaf in (
        ('mimi100-normal-voice-candidate-rootfalse-20261127-v1', 'node-fields.rootfalse.json'),
        ('mimi100-source780p5-784p5-material-recovery-rootfalse-20261127-v1', 'index.rootfalse.json'),
        ('mimi100-source780p5-784p5-visual-review-rootfalse-20261127-v1', 'review.rootfalse.json'),
        ('mimi100-source99-100-independent-image-peer-20261127-v1', 'report.rootfalse.json'),
        ('mimi105-b1f1-lossless-owner-source-rootfalse-20261127-v5', 'receipt.rootfalse.json'),
        ('mimi105-b1f1-lossless-owner-source-independent-peer-rootfalse-20261127-v5', 'review.rootfalse.json'),
    ):
        retained.add(str(A / folder / leaf))

    tracked = {str(ROOT / name) for name in git(ROOT, 'ls-files', '-z').decode().split('\0') if name}
    observed, groups, devices = {}, {}, {}
    for name, row in entries.items():
        path = Path(name)
        assert path.is_absolute() and path.resolve() == path
        assert name not in tracked and name not in retained
        assert not path.is_relative_to(D) and not path.is_relative_to(C)
        if path.is_relative_to(R):
            assert row.get('group')
        elif path.is_relative_to(A):
            assert path.parent == A / 'adapter-preparation'
        else:
            top_level_scratch = path.parent == Path('/tmp') and path.name.startswith(
                ('stella-cleanup-', 'stella-repair-log-compression-candidates-20261126-'))
            closed_cleanup_scratch = path.parent == Path('/tmp/stella-log-screenshot-cleanup-20261126-v2')
            assert top_level_scratch or closed_cleanup_scratch, path
            assert '-v6-' not in path.name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
        assert info.st_ino == row['inode']
        assert info.st_mtime_ns == int(row['mtimeNs'])
        assert info.st_size == row.get('size', row.get('bytes'))
        assert info.st_blocks * 512 == row['allocatedBytes']
        assert digest(path) == row['sha256']
        observed[name] = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
        category = row.get('category', row.get('group', 'closed_adapter_debug_response'))
        group = groups.setdefault(category, {'files': 0, 'logicalBytes': 0, 'allocatedBytes': 0})
        group['files'] += 1
        group['logicalBytes'] += info.st_size
        group['allocatedBytes'] += info.st_blocks * 512
        devices[info.st_dev] = devices.get(info.st_dev, 0) + info.st_blocks * 512

    proofs = []
    for name in sorted(retained):
        path = Path(name)
        assert name not in entries and path.is_file()
        proofs.append({'path': name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
        if name in pinned_proofs:
            assert proofs[-1]['bytes'] == pinned_proofs[name]['bytes']
            assert proofs[-1]['sha256'] == pinned_proofs[name]['sha256']

    # An output held by a running process would not release its allocation.
    # Inspect descriptor targets only; do not collect unrelated argv or env.
    denied_processes = 0
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            descriptors = list((process / 'fd').iterdir())
        except (OSError, PermissionError):
            denied_processes += 1
            continue
        for descriptor in descriptors:
            try:
                target = os.readlink(descriptor)
            except OSError:
                continue
            assert target not in entries, (process.name, target)

    before = snapshot()
    assert before['dataHead'] == '60341167f30532dd066e2a45e85b0c83974bfc8c'
    assert before['dataStatus'] == ''
    assert before['sourceHead'] == '6630ac70f17332efa031d021af00532d42307568'
    assert before['sourceStatus'] == '?? scripts/__pycache__/\n'
    available = free_space()
    ledger = {'schema': 'stella.reviewed-investigation-cleanup.v6',
              'rootConfirmed': True, 'deletionAuthorizedByUser': True,
              'sourceReports': reports, 'before': before,
              'retainedProofs': proofs, 'entries': list(entries.values()),
              'unreadableForeignProcessFDDirectories': denied_processes,
              'noMatchingReadableProcessFD': True,
              'historicalDeletedPathReferencesAreRetired': True,
              'earlierDeletedFilesNotCounted': True}
    write('deletion-manifest.root-approved.json.gz', ledger)

    # Recheck the complete allowlist before removal and each inode immediately
    # before unlink. Any changed file stops the operation; there is no glob/rm.
    for name, previous in observed.items():
        info = Path(name).lstat()
        assert (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) == previous
    removed = []
    try:
        for name, previous in observed.items():
            path = Path(name)
            info = path.lstat()
            assert (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) == previous
            path.unlink()
            removed.append(name)
    except BaseException:
        write('partial-deletion.json', {'removed': removed})
        raise
    assert all(not os.path.lexists(name) for name in entries)
    assert snapshot() == before
    for proof in proofs:
        assert digest(Path(proof['path'])) == proof['sha256']
    report = {'schema': 'stella.investigation-cleanup.receipt.v6',
              'status': 'deleted_and_verified', 'deletedFiles': len(removed),
              'groups': groups, 'releasedAllocationByDevice': devices,
              'releasedDiskBytes': devices.get(ROOT.stat().st_dev, 0),
              'releasedTmpfsBytes': devices.get(Path('/tmp').stat().st_dev, 0),
              'availableBefore': available, 'availableAfter': free_space(),
              'retainedFilesHashVerified': len(proofs),
              'dataCanonicalAndRootTrackedWorkUnchanged': True,
              'originalSourceFramesRecordingsAssetsAndArmPreserved': True,
              'deletionManifestSHA256': digest(OUT / 'deletion-manifest.root-approved.json.gz'),
              'noReplacementBackupCreated': True, 'noBrowserStarted': True,
              'wholeRestorationGoalStillActive': True}
    write('receipt.json', report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
