"""Prepare one explicit original voice packet or review its normal stage.

This helper never imports or installs a business batch. The unchanged native
repair/install CLIs remain separate, observable calls. Historical data-file
references are verified against their real Git blobs before rebinding; source
recordings, audio and original resources must match their sealed bytes exactly.
"""
import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
REFERENCE = A / 'episode10-scene54-27-characters-root-preparation-87482d95-v1/preflight.root-approved.json'
CONTRACT_EXAMPLE = A / 'episode10-scene54-27-characters-root-preparation-87482d95-v1/node-fields.root-approved.json'
FIELDS = {'bg_music', 'bg_picture', 'character', 'character_image', 'motion',
          'msg_character', 'msg_text', 'position', 'se', 'talk_chara', 'video', 'voice', 'command'}
READ_NUMBER = 0


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def load(path):
    global READ_NUMBER
    # Keep exactly the held bytes given to JSON, before parsing. A previous
    # read-only review failed on a control character without retaining its
    # input; a later successful disk read cannot substitute for that missing
    # observation. This records every original input and never retries it.
    READ_NUMBER += 1
    raw = Path(path).read_bytes()
    stem = Path(args.read_log) / f'{READ_NUMBER:03d}'
    stem.with_suffix('.raw.gz').write_bytes(gzip.compress(raw, mtime=0))
    fact = dict(path=str(path), bytes=len(raw), sha256=sha(raw), retryCount=0)
    try:
        result = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        fact.update(error=str(error), errorType=type(error).__name__, cause='unknown')
        if isinstance(error, json.JSONDecodeError):
            doc = error.doc.encode('utf-8', 'surrogatepass')
            stem.with_suffix('.exception-doc.gz').write_bytes(gzip.compress(doc, mtime=0))
            fact.update(position=error.pos, line=error.lineno, column=error.colno,
                exceptionDocSHA256=sha(doc))
        write_new(stem.with_suffix('.json'), fact)
        raise
    fact['parsed'] = True
    write_new(stem.with_suffix('.json'), fact)
    return result


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(D), *args])


def assert_current(head):
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('status', '--short') == b''


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value))


def verify_guards(guards):
    for path, expected in guards.items():
        with Path(path).open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected, path


def prepare(args):
    candidate, out = Path(args.candidate).resolve(), Path(args.preparation).resolve()
    assert candidate.is_relative_to(A) and not candidate.is_relative_to(D)
    assert out.parent == A and not out.exists()
    raw = candidate.read_bytes()
    assert sha(raw) == args.candidate_sha256
    packet = json.loads(raw)
    assert packet.get('requiredAssetImports', []) == []
    head = git('rev-parse', 'HEAD').decode().strip()
    assert_current(head)
    historical = args.evidence_base
    assert re.fullmatch('[0-9a-f]{40}', historical)
    git('merge-base', '--is-ancestor', historical, head)
    field = args.field
    changes = packet['changes']
    scenes = {c['sceneId'] for c in changes}
    assert len(scenes) == 1 and len(changes) == args.count
    scene = next(iter(scenes))
    before = load(D / f'native/scenes/{scene}.json')
    review = load(D / f'review/scenes/{scene}.json')
    catalog = load(D / 'assets/catalog.json')
    old_catalog = json.loads(git('show', historical + ':assets/catalog.json'))
    selected = set()
    rebindable_data = {'manifest.json', 'review/native-restoration.json',
        'assets/catalog.json', 'assets/package.json',
        f'native/scenes/{scene}.json', f'review/scenes/{scene}.json'}
    for c in changes:
        assert set(c['fields']) == {field} and set(c['expected']) == FIELDS
        index = c['arrayIndex']
        row = before['scenario_list'][index]
        assert index not in selected
        selected.add(index)
        assert row['scenario_id'] == c['scenarioId'] and row['uniq_id'] == c['uniqueId']
        assert review['scenarios'][str(c['scenarioId'])]['stableKey'] == c['stableKey']
        assert all(row[k] == v for k, v in c['expected'].items())
        assert c['expected'][field] == '' and c['fields'][field]
        if 'fullNativeRowBefore' in c:
            assert row == c['fullNativeRowBefore']
        # Voice tokens identify one cue inside an original voice-bank block.
        # Compare the entire bank with the stated ancestor, require one exact
        # cue match, and validate its own payload URL. Actor/CG lookups cannot
        # establish a voice identity, and duplicate cue entries must fail.
        token = c['fields'][field]
        bank_name, separator, cue_name = token.partition(',')
        assert separator == ',' and bank_name and cue_name and ',' not in cue_name
        voice_block = catalog['voices'][bank_name]
        assert voice_block == old_catalog['voices'][bank_name]
        cue_matches = [entry for entry in voice_block['cues'] if entry['cue'] == cue_name]
        assert len(cue_matches) == 1
        assert (D / 'assets' / cue_matches[0]['url']).is_file()
        c.update(rootConfirmed=True, rootReviewed=True, executionAuthorized=True,
                 installationAuthorized=True)
    # Follow explicit sealed references only. A stale data reference is not
    # silently accepted: its old digest must match the stated ancestor's blob.
    # Current selected rows and every other formal file are guarded separately.
    guards, rebounds, visited = {}, [], set()
    pending = list(sorted(candidate.parent.glob('*.json')))
    while pending:
        path = pending.pop().resolve()
        if path in visited:
            continue
        visited.add(path)
        data = path.read_bytes()
        current_sha = sha(data)
        assert str(path) not in guards or guards[str(path)] == current_sha
        guards[str(path)] = current_sha
        if path.suffix != '.json':
            continue
        try:
            value = json.loads(data)
        except json.JSONDecodeError:
            # Preserve the actual failing bytes, never a replacement parse.
            out.mkdir(exist_ok=True)
            (out / 'preparation-json-failure.raw.gz').write_bytes(gzip.compress(data, mtime=0))
            raise

        def visit(obj):
            if isinstance(obj, list):
                for item in obj:
                    visit(item)
            elif isinstance(obj, dict):
                if isinstance(obj.get('path'), str) and re.fullmatch('[0-9a-f]{64}', str(obj.get('sha256', ''))):
                    raw_ref = Path(obj['path'])
                    if raw_ref.is_absolute():
                        ref = raw_ref.resolve()
                    else:
                        # Existing packets use project-root-relative source
                        # references; file-index members use document-relative
                        # names. Resolve both explicit forms instead of silently
                        # dropping all relative image/resource evidence.
                        assert '..' not in raw_ref.parts, str(raw_ref)
                        project_prefixes = {'data', 'artifacts', 'story_studio',
                            'logs', 'lost_in_memories'}
                        base = ROOT if raw_ref.parts[0] in project_prefixes else path.parent
                        ref = (base / raw_ref).resolve()
                        assert ref.is_relative_to(base), str(ref)
                    actual_raw = ref.read_bytes()
                    actual = sha(actual_raw)
                    if actual != obj['sha256']:
                        assert ref.is_relative_to(D), str(ref)
                        relative = str(ref.relative_to(D))
                        # Historical metadata can legitimately advance after
                        # another owned publication. Original model/image/media
                        # payload drift always fails rather than being rebound.
                        assert relative in rebindable_data, relative
                        assert sha(git('show', historical + ':' + relative)) == obj['sha256'], str(ref)
                        rebounds.append(dict(path=str(ref), historicalSHA256=obj['sha256'],
                            historicalHead=historical, currentSHA256=actual, currentHead=head))
                    assert str(ref) not in guards or guards[str(ref)] == actual
                    guards[str(ref)] = actual
                    # The packet explicitly labels this historical file as
                    # referencePacketReadOnlyShapeOnly. Lock its exact bytes,
                    # but do not reinterpret its old Julius evidence graph as
                    # evidence for the current Ram/Mimi/Otto character packet.
                    if (ref != CONTRACT_EXAMPLE and ref.is_relative_to(A)
                            and not ref.is_relative_to(D) and ref.suffix == '.json'):
                        pending.append(ref)
                for item in obj.values():
                    visit(item)
        visit(value)
    assert_current(head)
    for path, expected in {
        ROOT / 'story_studio/recovery/native_repair.py': '0efd16bc38b9406865fd8fe6936be0b2f0dd670ae74059798ace156fb2d0d1a2',
        ROOT / 'story_studio/recovery/native_install.py': '6b8196319ca7afc44943cb26341caf23cec2f8ed3649c82a8248f62b2a47db27',
    }.items():
        assert sha(path.read_bytes()) == expected, str(path)
        guards[str(path)] = expected
    for path in [Path(__file__).resolve(), A / 'observe-original-business-gate-v1.py']:
        guards[str(path)] = sha(path.read_bytes())
    formal = {p: sha(Path(p).read_bytes()) for p in load(REFERENCE)['all285GlobalSceneMetadataAndAssetGuards']}
    assert len(formal) == 285
    protected = load(REFERENCE)['protectedFirstThree']
    verify_guards({str(D / p): h for p, h in protected.items()})
    packet.update(rootConfirmed=True, rootReviewed=True, executionAuthorized=True,
        installationAuthorized=True, candidateOnly=False, baseSha=head, expectedHead=head,
        normalSaveOrAPIPacketReady=True,
        rootMustFreshRebindHEADOwnershipManifestFullGlobalAndNormalSaveBeforeApplying=False)
    packet['rootHistoricalDataRebindings'] = rebounds
    packet['rootScope'] = 'Explicit short original voice resource identity and recording-panel attribution only; subjective listening, original command phases and saved gameplay remain unaccepted.'
    out.mkdir()
    packet_path = out / 'node-fields.root-approved.json'
    write_new(packet_path, packet)
    approval = dict(rootConfirmed=True, stageAuthorized=True, applyAuthorized=False,
        dataHead=head, all285GlobalSceneMetadataAndAssetGuards=formal,
        protectedFirstThree=protected, sourceReviewAndModelGuards=guards,
        candidate=dict(path=str(candidate), sha256=sha(raw)),
        nodeFieldsSHA256=sha(packet_path.read_bytes()), field=field, exactVisualFieldLeaves=len(changes),
        historicalDataRebindings=rebounds, mainThreadViewedImages=False,
        fullEntryBodyFaceTimingAndSavedGameplayAccepted=False)
    write_new(out / 'preflight.root-approved.json', approval)
    print(json.dumps(dict(preparation=str(out), head=head, scene=scene, changes=len(changes),
        sourceGuards=len(guards), historicalReferencesRebound=len(rebounds))))


def review_stage(args):
    out, stage = Path(args.preparation).resolve(), Path(args.staging).resolve()
    approval = load(out / 'preflight.root-approved.json')
    assert_current(approval['dataHead'])
    verify_guards(approval['all285GlobalSceneMetadataAndAssetGuards'])
    verify_guards(approval['sourceReviewAndModelGuards'])
    packet = load(out / 'node-fields.root-approved.json')
    field = args.field
    assert approval['field'] == field
    assert sha((out / 'node-fields.root-approved.json').read_bytes()) == approval['nodeFieldsSHA256']
    manifest = load(stage / 'manifest.json')
    assert manifest['recordings'] == [] and manifest['directoryEntryUpdates'] == []
    assert manifest['structuralValidation'] == 'passed'
    assert manifest['restorationStatus'] == 'rough' and manifest['playbackValidation'] == 'not-run'
    for name, expected in manifest['files'].items():
        assert sha((stage / name).read_bytes()) == expected
    scene = packet['changes'][0]['sceneId']
    assert [entry['id'] for entry in manifest['scenes']] == [scene]
    old = load(D / f'native/scenes/{scene}.json')
    actual = load(stage / f'native/scenes/{scene}.json')
    undo = deepcopy(actual)
    old_review = load(D / f'review/scenes/{scene}.json')
    new_review = load(stage / f'review/scenes/{scene}.json')
    undo_review = deepcopy(new_review)
    for c in packet['changes']:
        row = undo['scenario_list'][c['arrayIndex']]
        assert row['scenario_id'] == c['scenarioId'] and row['uniq_id'] == c['uniqueId']
        assert set(c['fields']) == {field}
        assert row[field] == c['fields'][field]
        row[field] = c['expected'][field]
        key = str(c['scenarioId'])
        was, got = old_review['scenarios'][key], undo_review['scenarios'][key]
        expected_evidence = dict(packet=str(out / 'node-fields.root-approved.json'),
            fields=[field], evidence=c.get('evidence', {}))
        assert got['repairEvidence']['performance'][-1] == expected_evidence
        assert got['repairEvidence']['performance'][:-1] == was.get('repairEvidence', {}).get('performance', [])
        assert got['unknownFields'] == [f for f in was.get('unknownFields', []) if f != field]
        expected_issues = []
        for issue in was.get('issues', []):
            item = deepcopy(issue)
            if item.get('code') == 'performance_unrecovered':
                item['fields'] = [f for f in item.get('fields', []) if f != field]
                if not item['fields']:
                    continue
            expected_issues.append(item)
        assert got['issues'] == expected_issues
        # Undo only the permitted sidecar deltas, then compare the entire
        # document. This catches changed dialogue, branches and other rows.
        got['unknownFields'] = deepcopy(was.get('unknownFields', []))
        got['issues'] = deepcopy(was.get('issues', []))
        got['repairEvidence']['performance'].pop()
        if 'performance' not in was.get('repairEvidence', {}):
            assert got['repairEvidence']['performance'] == []
            del got['repairEvidence']['performance']
        if 'repairEvidence' not in was:
            # Do not replace this whole object from the baseline: doing so
            # would erase evidence of an unrelated sibling-key mutation.
            assert got['repairEvidence'] == {}
            del got['repairEvidence']
    assert undo == old
    expected_global = [i for i in old_review['issues'] if 'scenarioId' not in i]
    for row in actual['scenario_list']:
        expected_global.extend(new_review['scenarios'][str(row['scenario_id'])].get('issues', []))
    assert new_review['issues'] == expected_global
    undo_review['issues'] = deepcopy(old_review['issues'])
    assert undo_review == old_review
    entry = next(e for e in load(D / 'manifest.json')['scenes'] if e['id'] == scene)
    expected_entry = deepcopy(entry)
    expected_entry.update(nodeCount=len(actual['scenario_list']),
        reviewCounts=dict(Counter(s.get('status', 'draft') for s in new_review['scenarios'].values())),
        issues=new_review['issues'], readyForGame=False, reviewStatus='draft', repairStatus='in-progress')
    assert manifest['scenes'][0] == expected_entry
    review = dict(rootConfirmed=True, field=field, exactNativeVisualFieldLeaves=len(packet['changes']),
        completeNativeUndoOnlySelectedFieldExact=True,
        completeReviewOnlyExactEvidenceAppendsAndSelectedFieldWarningRemovals=True,
        completeSceneSummaryOnlyNormalSelectedFieldWarningRemovals=True,
        allStagedManifestHashesExact=True, all285FormalAndSourceGuardsFreshExact=True,
        sourceGuards=len(approval['sourceReviewAndModelGuards']), all22ProtectedExact=True,
        stageManifestSHA256=sha((stage / 'manifest.json').read_bytes()),
        batchId=sha((stage / 'manifest.json').read_bytes())[:20],
        onlySelectedVoiceLeavesOtherFieldsPreserved=True, fullSceneOrEpisodeAccepted=False)
    write_new(out / 'stage.root-review.json', review)
    print(json.dumps(review))


parser = argparse.ArgumentParser()
parser.add_argument('operation', choices=['prepare', 'review'])
parser.add_argument('--preparation', required=True)
parser.add_argument('--candidate')
parser.add_argument('--candidate-sha256')
parser.add_argument('--evidence-base')
parser.add_argument('--count', type=int)
parser.add_argument('--staging')
parser.add_argument('--field', choices=['voice'], required=True)
parser.add_argument('--read-log', required=True)
args = parser.parse_args()
read_log = Path(args.read_log).resolve()
assert read_log.is_relative_to(A) and not read_log.is_relative_to(D)
read_log.mkdir()
(prepare if args.operation == 'prepare' else review_stage)(args)
