# Episode11 CG41–44 independent static identity peer

Limited pass: all four selected original witnesses show `ADV_still_009`. Felt/Subaru/Rom occupy the left/center/right foreground, Emilia and Pack stand behind them, and the green shard/interior composition directly matches the original PNG and existing WebP.

Each original source frame and its stable-key/source row is bound in `peer.rootfalse.json`. Recorded225/228.5/231/233.5s are inherited annotations, not new exactPTS or continuous-animation proof. Visible card openings support row association; exact punctuation/repetition, full text and existing text review statuses are not newly accepted or altered.

Only the static character_image candidate is supported. No live-character scalar, blueFX, motion/face, animation phase/timing, geometry, audio, URL contract or saved-gameplay acceptance. WebP matching is visual identity, not compression numeric equivalence. All six viewed files were freshly SHA-checked. No old material or D/C was modified; no pixels were generated.

