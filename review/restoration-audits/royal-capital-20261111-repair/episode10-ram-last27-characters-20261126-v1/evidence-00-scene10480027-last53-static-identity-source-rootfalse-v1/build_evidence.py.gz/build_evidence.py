#!/usr/bin/env python3
"""Seal a bounded, read-only static identity review in this new evidence directory.

The visual decisions below were made by /root/scene27_identity_last53 after
directly viewing every listed full original frame. This program only binds those
decisions to current bytes. It does not decode media, infer identities from the
speaker, change native/review data, install candidates, or authorize execution.
All file writes are constrained to this newly allocated evidence directory.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


PROJECT = Path('/home/rikka/Projects/stella')
A = PROJECT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
OUT = Path(__file__).resolve().parent
ORIGINAL = PROJECT / 'data/extracted_archives/limeos'
OCR = PROJECT / 'data/native_recovery/royal-capital-20261110/ocr/36'
HEAD_METADATA = 'e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8'
REVIEWER = '/root/scene27_identity_last53'
FALSE_APPROVALS = {
    'rootConfirmed': False,
    'rootApproved': False,
    'acceptance': False,
    'executionAuthorized': False,
    'installationAuthorized': False,
    'browserAuthorized': False,
    'mediaDecodeAuthorized': False,
    'publicationAuthorizedByThisPacket': False,
}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode('utf-8')


def value_hash(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def pin(path):
    path = Path(path)
    if not path.exists():
        return {'path': str(path), 'exists': False}
    content = path.read_bytes()
    return {'path': str(path), 'exists': True, 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}


def load(path):
    return json.loads(Path(path).read_text())


def write_new(name, value):
    """Exclusive creation prevents this evidence run from rewriting old receipts."""
    target = OUT / name
    with target.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(target)


def flags(schema):
    return {'schema': schema, **FALSE_APPROVALS, 'reviewer': REVIEWER,
            'createdUTC': datetime.now(timezone.utc).isoformat()}


# Each node set is a manual full-frame pixel decision. They deliberately are not
# derived from msg_character/sourceSpeaker. In particular, nodes 97-106 all show
# the same complete illustration while the speaker changes among three people.
GROUPS = {
    'ram01': [63, 67, 77, 95, 107, 115],
    'subaru01': [64, 65, 70, 76, 80, 82, 113, 114],
    'elsa_nomantle01': [68, 73, 74, 75],
    'felt01': [69, 78, 83, 86, 87, 88, 92, 93, 111],
    'pack01': [72, 79, 81, 90, 109],
    'ADV_still_017': list(range(97, 107)),
}
UNKNOWN_EMILIA = [66, 71, 84, 85, 89, 91, 94, 96, 108, 110, 112]
FEATURES = {
    'ram01': [
        'The full frame shows a pink bob covering one eye, a floral headband, crossed hairpins and the black/white frilled maid uniform.',
        'The visible black sleeves, scalloped white collar, neck ribbon and fitted front correspond to the directly viewed ram01 texture atlas. The source has no raised hood.',
        'Only the model/costume identity is proposed; the visible pose, eyes and mouth do not select a motion or face field.',
    ],
    'subaru01': [
        'The full frame exposes a white zip-up tracksuit front with black sleeves, orange collar/shoulder stripe and the N chest emblem.',
        'Those garment features match the directly viewed original-byte-equivalent subaru01 texture and existing assembled subaru01 reference.',
        'The tracksuit body is directly visible. No speaker-name, dialogue crop, audio or inherited preceding actor is used for this decision.',
    ],
    'elsa_nomantle01': [
        'The source exposes both bare shoulders, the deep open front of the black/purple dress, detached arm sleeves and a long braid over the image-right torso.',
        'The source has neither the shoulder mantle/clasp nor the large purple hair flower of the separately viewed elsa01 assembled control.',
        'Its bare-shoulder silhouette and braid match the directly viewed elsa_nomantle01 assembled control and original-byte-equivalent texture atlas. This is a costume/model decision only.',
    ],
    'felt01': [
        'The full frame shows blonde short hair with a large dark bow, red scarf, an open brown/red vest with pale fur edging and a black bandeau.',
        'The matching bow, red scarf, bare midriff, bandeau and fur-trimmed garment pieces are visible in the directly viewed felt01 original-byte-equivalent texture atlas.',
        'The exact static costume identity is proposed without accepting the observed arm, face or body pose.',
    ],
    'pack01': [
        'The full frame shows the small upright pale cat with a long tail, chest fur, asymmetrical folded ear and a purple shoulder bag with round gold fasteners.',
        'The cat body, blue/green eye artwork, purple bag and strap match the directly viewed pack01 original-byte-equivalent texture atlas.',
        'No face, limb pose, appearance phase or animation is selected by this static identity comparison.',
    ],
    'ADV_still_017': [
        'The complete source frame shows Ram in the image-left foreground turned partly away, Emilia at image-right with fingertips together, and Pack behind her shoulder.',
        'The rear crisscross dress straps, floral hairband and bow on Ram, Emilia hand arrangement, small Pack and the brown/gold gabled building match the directly viewed original ADV_still_017.png and D preview variant.',
        'This is one multi-person illustration identity, not three character model assignments. No CG entry/exit transition, crop geometry, command or timing is accepted.',
    ],
    'emilia_exact_variant_unknown': [
        'The complete source frame visibly shows the silver-haired girl in a white/purple dress, green pendant, hair braid/flower and detached sleeves.',
        'Both directly viewed emilia01 and original emilia02 texture atlases contain this near-identical base costume. The source static frame alone does not establish an exact 01/02 resource discriminator.',
        'The current D catalog contains emilia01 while emilia02 has a loose descriptor only. Catalog presence or absence is not original-video identity proof.',
        'Keep character and character_image empty until a closed exact-variant reference or original resource linkage resolves 01/02; do not choose from the speaker name or source subtitle.',
    ],
}


def model_binding(model):
    native_id = 'live2d/AC_' + model
    member_root = 'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_' + model + '/ac/'
    entry = catalog['models'].get(native_id)
    original_descriptor = ORIGINAL / (member_root + 'ac.model3.json')
    descriptor = load(original_descriptor)
    refs = descriptor['FileReferences']
    components = ['ac.model3.json', refs['Moc'], *refs['Textures']]
    bindings = []
    for component in components:
        member = member_root + component
        current = D / 'assets/models' / model / 'ac' / component
        original = ORIGINAL / member
        cpin, opin = pin(current), pin(original)
        bindings.append({
            'component': component,
            'original': opin,
            'currentD': cpin,
            'currentAndOriginalByteExact': cpin.get('sha256') == opin.get('sha256') if cpin['exists'] else False,
            'opaqueMember': member,
            'opaqueMembersMappingValue': catalog['members'].get(member),
            'opaqueAssetMembersMappingValue': catalog['asset_members'].get(member),
            'mappingInterpretation': 'Literal member/key mapping only; no full map copied and no missing entry invented.',
        })
    return {
        'resourceKey': model, 'nativeID': native_id,
        'catalogEntryExists': entry is not None,
        'catalogSummary': ({k: entry.get(k) for k in ['id', 'native_id', 'label', 'model_url', 'member', 'detail_url']} if entry else None),
        'catalogEntryCanonicalSHA256': value_hash(entry) if entry else None,
        'descriptorReferencesOnly': {'Moc': refs['Moc'], 'Textures': refs['Textures']},
        'files': bindings,
        'textureDirectlyViewed': True,
        'textureActuallyViewedAt': str(ORIGINAL / (member_root + refs['Textures'][0])) if model == 'emilia02' else str(D / 'assets/models' / model / 'ac' / refs['Textures'][0]),
        'viewedDTextureFreshByteExactOriginal': model != 'emilia02' and all(x['currentAndOriginalByteExact'] for x in bindings),
        'mocReadAsOpaqueBytesOnly': True,
        'nativeModelOrControllerNotExecuted': True,
        'motionOrExpressionBindingAccepted': False,
    }


candidate_source = A / 'chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json'
native_path = D / 'native/scenes/10480027.json'
review_path = D / 'review/scenes/10480027.json'
catalog_path = D / 'assets/catalog.json'
index_path = OCR / 'root-review/index.json'
manifest_path = D / 'manifest.json'
source_list = load(candidate_source)
selection = next(s for s in source_list['scenes'] if s['sceneId'] == 10480027)['rows'][53:106]
native, review, catalog = load(native_path), load(review_path), load(catalog_path)
manifest, index = load(manifest_path), load(index_path)
events = {q['id']: q for q in index['events']}
native_by_id = {q['scenario_id']: q for q in native['scenario_list']}
assert len(selection) == 53
assert [q['scenarioId'] for q in selection] == list(range(63, 116))
assert sorted([x for g in GROUPS.values() for x in g] + UNKNOWN_EMILIA) == list(range(63, 116))

resources = flags('stella.scene10480027.last53.static-identity-resources.v1')
resources['currentCatalog'] = pin(catalog_path)
resources['opaqueMappingPolicy'] = 'Only selected exact logical member/key mappings and byte hashes are copied. MOC files remain opaque binary evidence; no model/control execution or whole-map copy occurs.'
resources['models'] = [model_binding(n) for n in ['ram01', 'subaru01', 'elsa01', 'elsa_nomantle01', 'felt01', 'pack01', 'emilia01', 'emilia02']]
cg_id = 'ADV_still_017'
cg = catalog['pictures'][cg_id]
cg_member = cg['member']
cg_original = ORIGINAL / cg_member
cg_current = D / 'assets' / cg['url']
resources['picture'] = {
    'resourceKey': cg_id, 'candidateField': 'character_image', 'catalogEntry': cg,
    'catalogEntryCanonicalSHA256': value_hash(cg),
    'original': pin(cg_original), 'currentDPreview': pin(cg_current),
    'originalPNGAndDPreviewWEBPDirectlyViewed': True,
    'formatAndSizeDifferByPreviewCompression': True,
    'byteEqualityClaimed': False,
    'opaqueMember': cg_member,
    'opaqueMembersMappingValue': catalog['members'].get(cg_member),
    'opaqueAssetMembersMappingValue': catalog['asset_members'].get(cg_member),
    'descriptorMOCTextureApplicable': False,
    'basis': FEATURES[cg_id],
}
resources['existingAssembledControlsDirectlyViewed'] = [
    pin(PROJECT / 'data/native_recovery/royal-capital-20261110/repair-20261111/visual-high/target-p30-elsa01-reference-revalidation-20261112-v1/elsa01-historical-sampler-anchor.png'),
    pin(PROJECT / 'data/native_recovery/royal-capital-20261110/repair-20261111/visual-high/target-p30-elsa01-reference-revalidation-20261112-v1/elsa_nomantle01-historical-sampler-anchor.png'),
    pin(PROJECT / 'data/native_recovery/royal-capital-20261110/repair-20261111/visual-high/agent-reviewed-p28-identity-v1/reference-subaru01-anchor.png'),
]
resources['assembledControlContext'] = 'Historical closed static controls only. Their conditional normal/body/face contexts are not accepted for any source node in this task.'
resource_pin = write_new('resources.rootfalse.json', resources)

ledger = []
patches = []
for offset, selected in enumerate(selection, start=53):
    sid = selected['scenarioId']
    current = native_by_id[sid]
    current_review = review['scenarios'][str(sid)]
    assert current['uniq_id'] == selected['UID']
    assert current_review['stableKey'] == selected['stableKey']
    assert current_review['sourceText'] == selected['sourceText']
    assert current['character'] == current['character_image'] == ''
    rec = current_review['recordings'][0]
    ev = events[rec['ocrEventId']]
    frame = Path(ev['frame'])
    assert frame.exists()
    group = next((k for k, sids in GROUPS.items() if sid in sids), None)
    key = group if group else 'emilia_exact_variant_unknown'
    if group:
        field = 'character_image' if group == cg_id else 'character'
        value = cg_id if group == cg_id else 'live2d/AC_' + group
        fields = {field: value}
    else:
        fields = {}
    record = {
        'candidateListOffset': offset,
        'sceneId': 10480027, 'scenarioId': sid, 'UID': current['uniq_id'],
        'stableKey': current_review['stableKey'],
        'fullCurrentNativeRow': current,
        'fullCurrentNativeRowCanonicalSHA256': value_hash(current),
        'currentChineseGuard': {'msg_character': current['msg_character'], 'msg_text': current['msg_text'], 'canonicalSHA256': value_hash({'msg_character': current['msg_character'], 'msg_text': current['msg_text']})},
        'originalJapaneseGuard': {'sourceSpeaker': current_review.get('sourceSpeaker'), 'sourceText': current_review['sourceText'], 'canonicalSHA256': value_hash({'sourceSpeaker': current_review.get('sourceSpeaker'), 'sourceText': current_review['sourceText']}), 'provenance': 'Existing review sourceText; reconstructed source-video/OCR evidence, not a newly recovered native authored Japanese row.', 'textAcceptanceByThisTask': False},
        'currentReviewRowCanonicalSHA256': value_hash(current_review),
        'sourceRecording': rec,
        'sourceIndexEventID': ev['id'],
        'sourceIndexEventCanonicalSHA256': value_hash(ev),
        'sourceFullFrame': pin(frame),
        'sourceDimensions': [480, 856],
        'sourceFrameIndexFromExistingIndex': ev['frame_index'],
        'sourceFrameSecondsAsStoredInExistingIndex': ev['source_frame_time'],
        'sourceFramePrecision': 'Exact numeric value preserved from existing sparse index (up to 3 decimal places). This task did not decode, measure PTS, or establish a native frame boundary. Filename/frame_index is a cache identifier, not fresh PTS evidence.',
        'sourceIndexInterval': [ev['start'], ev['end']],
        'currentRecordingInterval': [rec['start'], rec['end']],
        'sourceVideoPathFromExistingIndex': ev['source_video'],
        'sourceVideoSHA256FromExistingIndex': ev['source_sha256'],
        'sourceVideoSHA256FreshlyRehashed': False,
        'fullFrameDirectlyViewedBy': REVIEWER,
        'fullFrameDirectViewDeclaration': 'I directly viewed this existing complete 480x856 original frame with view_image during this task, including the foreground/body and surrounding game screen. I did not use its dialogue crop, choice portrait or speaker name to assign a resource.',
        'identityObservationKey': key,
        'staticVisualBasis': FEATURES[key],
        'resourceEvidence': {'file': resource_pin, 'key': group if group else ['emilia01', 'emilia02']},
        'verdict': 'static_identity_candidate_supported' if group else 'unknown_exact_model_variant_keep_foreground_empty',
        'candidateFields': fields,
        'candidateFieldCount': len(fields),
        'unknownReason': None if group else 'A closed source discriminator between original emilia01 and emilia02 is missing; static common-costume identity is insufficient for exact resource selection.',
        'minimumNewExtractionRequirement': None,
        'noNewFullFrameExtractionNeededForStaticObservation': True,
        'furtherEvidenceNeeded': None if group else 'Directly inspect closed exact emilia01/emilia02 assembled controls or obtain original resource linkage. Request a bounded original source extraction only if that comparison identifies a missing discriminator; no decoder execution is authorized here.',
        'sourceMotionFaceBodyExtraEntryExitPhaseTimingAudioOrWholeSceneAccepted': False,
        **FALSE_APPROVALS,
    }
    if sid == 81:
        record['staticFrameLimitation'] = 'The indexed full frame is darkened; the cat silhouette, tail and shoulder bag remain directly visible. This supports only static pack01 identity, with no phase/timing/fade conclusion.'
    if sid == 68:
        record['sourceIntervalDifferencePreserved'] = 'Current recording merges 1073.999-1074.999 while the selected merged-0272 index event ends at1074.499. The exact selected source witness is1073.999; no boundary is inferred or corrected.'
    if sid == 106:
        record['sourceIntervalDifferencePreserved'] = 'Current review recording starts1241.498 after prior guard work; existing merged-0316 index interval starts1242.998. The exact selected source witness is1243.998 and lies inside both; no boundary is inferred or corrected.'
    ledger.append(record)
    if fields:
        patches.append({
            'sceneId': 10480027, 'scenarioId': sid,
            'UID': current['uniq_id'], 'stableKey': current_review['stableKey'],
            'expectedFullCurrentRow': current,
            'expectedFullCurrentRowCanonicalSHA256': value_hash(current),
            'expectedCurrentReviewRowCanonicalSHA256': value_hash(current_review),
            'expectedJapaneseGuard': record['originalJapaneseGuard'],
            'expectedChineseGuard': record['currentChineseGuard'],
            'fields': fields,
            'sourceFullFrame': record['sourceFullFrame'],
            'sourceFrameSecondsAsStoredInExistingIndex': ev['source_frame_time'],
            'identityEvidenceLedgerOffset': len(ledger) - 1,
            'reviewChanges': {},
            **FALSE_APPROVALS,
        })

chapter = next(c for c in manifest['chapters'] if c['id'] == 1)
section = next(s for s in chapter['sections'] if s['id'] == 1048)
recording = next(r for r in manifest['recordings'] if r['id'] == 'bili-capital-36')
report = flags('stella.scene10480027.last53.static-identity-source-review.v1')
report.update({
    'scope': {'chapterId': 1, 'chapterTitle': chapter['title'], 'section': section, 'sceneId': 10480027, 'sceneTitle': '最後の戦い', 'candidateOffset': 53, 'candidateCount': 53, 'candidateOffsetIsNotNodeNumber': True, 'scenarioIds': list(range(63,116)), 'route': 'Existing manifest recording P36:10本篇Ver拉姆「共通作战」; section1048 scenes10480024→10480025→10480026→10480027→10480028 observed branch metadata. This task accepts only the static foreground of the selected scene rows.'},
    'dataHeadReadOnlyMetadata': HEAD_METADATA,
    'dataHeadIsNotCleanWorktreeAssertion': True,
    'inputFiles': [pin(p) for p in [candidate_source, native_path, review_path, catalog_path, index_path, manifest_path]],
    'recordingIdentityFromCurrentManifest': recording,
    'recordingIdentityNotFreshMediaProbe': True,
    'existingSceneSegments': review['sceneSegments'],
    'canonicalGuardEncoding': 'UTF-8 JSON ensure_ascii=False sort_keys=True separators=(comma,colon)',
    'perRowLedger': ledger,
    'resources': resource_pin,
    'result': {'totalReviewedFullFrames': 53, 'supportedCharacterCandidates': 32, 'supportedCharacterImageCandidates': 10, 'unknownExactModelVariantRows': UNKNOWN_EMILIA, 'originallyNoForegroundObservedRows': [], 'missingFullFrames': [], 'minimumNewMediaExtractionRequests': [], 'candidateFieldsPerSupportedRow': 1, 'formalRowsChanged': 0},
    'allSourceFramesDirectlyViewedByAssignedSubagent': True,
    'mainRootAgentViewedImages': False,
    'nativeOrReviewTextCorrectedOrAccepted': False,
    'scopeLimits': ['Static foreground identity candidates only.', 'No body, face, extra layer, entry/exit, phase, timing, geometry, audio, voice, BGM, command, route-link, whole-scene or whole-route acceptance.', 'No browser, FFmpeg, media decoder, installation, helper API or model runtime was launched.', 'No D/C/native/review/legacy evidence or Git state was changed by this task.', 'All root, install, execution and publication approvals remain false. Root is the sole formal writer and must independently bind any later package to then-current bytes.'],
})
report_pin = write_new('review.rootfalse.json', report)
packet = flags('stella.scene10480027.last53.static-identity-candidates.v1')
packet.update({'dataHeadReadOnlyMetadata': HEAD_METADATA, 'headNotCleanlinessAssertion': True,
               'sourceReview': report_pin, 'resources': resource_pin,
               'changes': patches, 'unknownScenarioIdsKeepEmpty': UNKNOWN_EMILIA,
               'formalApplyPerformed': False, 'reviewChanges': {},
               'fieldScope': ['character', 'character_image'], 'singleFieldPerChange': True})
packet_pin = write_new('candidate.packet.rootfalse.json', packet)

views = [q['sourceFullFrame'] for q in ledger]
atlas_models = ['ram01', 'subaru01', 'emilia01', 'elsa01', 'elsa_nomantle01', 'felt01', 'pack01']
views += [pin(D / 'assets/models' / n / 'ac/textures/texture_00.png') for n in atlas_models]
views += [pin(ORIGINAL / 'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_emilia02/ac/textures/texture_00.png')]
views += [pin(ORIGINAL / cg_member)]
picture_controls = ['ADV_pic_101006', 'ADV_pic_101007', 'ADV_pic_101010', 'ADV_pic_101011', 'ADV_still_001', 'ADV_still_003', 'ADV_still_005', 'ADV_still_007', 'ADV_still_008', 'ADV_still_009', 'ADV_still_010', 'ADV_still_014', 'ADV_still_015', 'ADV_still_017']
views += [pin(D / 'assets/preview/pictures' / (n+'.webp')) for n in picture_controls]
views += resources['existingAssembledControlsDirectlyViewed']
view_index = flags('stella.scene10480027.last53.direct-view-index.v1')
view_index.update({'fullSourceFrameCount': 53, 'referenceViewCount': 26,
                   'totalDirectViewCount': 79, 'allDirectlyViewedBy': REVIEWER,
                   'allImagesExistingAndNotCopiedOrGenerated': True,
                   'viewedImages': views,
                   'failedViewAttempt': {'path': str(D/'assets/models/emilia02/ac/textures/texture_00.png'), 'result': 'file absent; original emilia02 atlas was subsequently viewed directly instead', 'notCountedAsViewed': True}})
view_pin = write_new('direct-views.rootfalse.json', view_index)
receipt = flags('stella.scene10480027.last53.static-identity-receipt.v1')
receipt.update({'status': 'bounded_static_review_complete_with11_exact_variant_unknowns',
                'review': report_pin, 'resources': resource_pin,
                'candidatePacket': packet_pin, 'directViews': view_pin,
                'counts': report['result'],
                'candidateGroups': GROUPS, 'unknownExactEmiliaVariant': UNKNOWN_EMILIA,
                'sourceFrameTimesUseExistingSparseIndexOnly': True,
                'freshHashBindingOfSelectedFramesAndOpaqueResources': True,
                'sourceVideoRehashedOrDecoded': False,
                'heavyWorkProfile': {'observedAvailableCPUs': list(range(8)), 'requestedNice': 19, 'requestedCPUAffinity': [0,1], 'execution': 'This evidence builder only; no media/model runtime.'},
                'noD_CGitWritesOrOldEvidenceMutation': True,
                'wholeRestorationGoalComplete': False,
                'requiresRootAndIndependentReviewBeforeAnyFormalInstall': True})
write_new('receipt.rootfalse.json', receipt)
print(json.dumps({'outputDirectory': str(OUT), 'sourceFramesReviewed': 53,
                  'characterCandidates': 32, 'characterImageCandidates': 10,
                  'unknownExactEmiliaVariant': UNKNOWN_EMILIA,
                  'allApprovalsFalse': True}, ensure_ascii=False))
