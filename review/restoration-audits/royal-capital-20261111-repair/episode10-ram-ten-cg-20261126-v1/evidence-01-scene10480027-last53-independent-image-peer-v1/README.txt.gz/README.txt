Independent last53: all53 existing full source JPEGs directly viewed and fresh hash-bound.27 static model candidates,10 CG identity candidates(ADV_still_017),16 unresolved exact variants stay empty(Emilia11,Pack5).

Original CG017 directly matches the painted Ram/Emilia/Pack exterior in source97–106. CG and model fields remain distinct. Reused own17 original model atlas observations;30 original CG images directly viewed; metadata/hash bindings cover78models/253files+105CGs. No exhaustive visual comparison of every variant is claimed.

Source times remain nominal sparse-cache anchors, not fresh PTS. Body/face/motion/phase/tint/geometry/audio/runtime/whole-scene are unaccepted. Primary aggregate summaries were accidentally exposed by discovery; no per-row recommendations/reports read. Root must freshly bind any eventual field edits. No browser/decoder/render/Git/D/C changes.
