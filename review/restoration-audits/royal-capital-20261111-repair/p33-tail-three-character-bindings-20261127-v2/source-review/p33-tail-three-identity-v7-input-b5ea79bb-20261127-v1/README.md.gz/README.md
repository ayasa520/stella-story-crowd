# P33三叶：可复用v7 helper的静态输入

本目录另封v7兼容输入，保留原调查包`bdf2a943…`不变。未运行helper、business或任何stage/audit/apply；D的runtime hold仍保留。

候选`node-fields.rootfalse.json` SHA-256：

`3018ec07f5df7dd5cae82c98c3ad8a01b8ac2d2e2367ce1651603958746073c6`

实际可复用helper是：

`/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121/review-explicit-visual-field-batch-v7.py`

SHA `019eace6abb930e91bff315a8761594142ff9e6155999c5aee3a2fde59f04e15`。只读代码确认它支持单scene `--field character --count 3`。不存在本次提及的`review-explicit-native-field-batch-v7.py`同名文件；本包不修改或改名helper。

## 已补齐的输入合同

每change现在都有helper要求的完整13项expected：`bg_music`、`bg_picture`、`character`、`character_image`、`motion`、`msg_character`、`msg_text`、`position`、`se`、`talk_chara`、`video`、`voice`、`command`。全部从b5ea79bb正式row读取，不是只补13个空字符串。只改character，其他12项原值进入守卫。

- n25/26/27的`arrayIndex`为24/25/26；`uniqueId`为1004003600025/26/27，并保留旧schema的`nativeUniqueId`。
- 各自`scenarioId`、stableKey、JA sourceText、中文msg_text、完整`fullNativeRowBefore`和当前branch均已提供。
- 原guard保留全30条scenario/UID顺序及完整有序数组摘要、native/review/global摘要；28已存Ferris和29/30结束结构不在拟改范围。
- source report、原packet、原PTS、3张witness、11张现成顺序表、原影片及9个已注册资源payload都用绝对`path`和既有SHA作sealed references。没有引用已发布28的peer来冒充25–27接受。
- 新目录不放旧调查包的relative-D-path输入清单。所有新JSON sealed-reference路径均为绝对路径；helper自己的历史285/22模板只记作标量路径/hash，避免额外递归到不相关的旧证据图。

所有批准/执行/安装标志仍为false。**新增独立完整身份复核和hold释放仍是根级前提。** 原487帧、11张顺序表与报告实际路径见兄弟目录`p33-tail-three-identity-candidate-b5ea79bb-20261127-v1/source-evidence-paths.json`；新peer可直接复用原件，无需截图或解码。

## helper实际保证与root还需做的事

`prepare`会读取真实clean HEAD，要求evidence-base为其ancestor；检查3个index/UID、stable、完整13字段及fullNativeRowBefore，比较三个模型的完整catalog entry，然后重新采集285 formal guards和22 protected guards。`native_repair`在后续独立business调用中再检查JA sourceText。

`review`会要求保持prepared clean HEAD及全部守卫；把stage中仅3个character反向恢复后，必须与完整当前native精确相等；sidecar只允许正常的证据追加和该字段warning移除。这会保护分支、顺序及其他row。

仍需说清一个细节：v7准备过程直接检查选中3条的index/UID/full row，**没有单独执行“其余27条ordered-ID列表与b5ea快照相等”的断言**。Root在hold释放后的fresh binding应显式核对本包全30条顺序/UID/数组摘要；若有合法数据推进则重新审查并封新candidate，不能把后续stage的当前baseline反校验冒称旧快照全部顺序守卫已自动执行。

helper内固定的代码守卫当前仍匹配：native_repair=`0efd16bc…`，native_install=`6b819631…`。本轮只读源码并做AST/schema静态检查，未导入或运行这些模块。未来prepare/review参数数组保存在`helper-contract-and-guards.rootfalse.json`，其中preparation/read-log/staging是显式占位符，必须选新absent A目录；不是已执行命令。

正常顺序：新的25–27独立review接受 → 原runtime终端/rootclosure释放D hold → fresh完整HEAD/UID/order/metadata/resource绑定 → root正常prepare → 独立原business stage → v7 stage review → 原installer audit/apply及保存核验 → 立即提交/push/ACK。身份小包不等待Mimi动作接受，但不能越过当前hold。
