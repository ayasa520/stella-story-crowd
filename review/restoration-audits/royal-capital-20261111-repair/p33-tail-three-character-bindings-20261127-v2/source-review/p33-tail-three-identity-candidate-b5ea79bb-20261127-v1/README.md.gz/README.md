# 一个实际未保存的小包：P33尾部三个人物身份

只准备scene10040036的三个`character`标量，绑定正式D `b5ea79bb239c867746ffc80aa56906f83d8c68c2`。**没有执行stage/audit/apply或任何business，也没有写D/C/Git。** 当前D由root的runtime freeze持有，必须等原runtime终端和root closure释放后再做fresh绑定及正常保存。

候选：[node-fields.rootfalse.json](node-fields.rootfalse.json)，SHA-256：

`bdf2a943b7630e72300254ab8c927283760d95124096cb1039fccaa9c99ce780`

| 正式row | stableKey / UID | 现character | 唯一拟填字段 |
|---|---|---|---|
| 25 | `s10040036-p33-at0553` / `1004003600025` | 空 | `live2d/AC_wilhelm01` |
| 26 | `s10040036-p33-at0556` / `1004003600026` | 空 | `live2d/AC_subaru01` |
| 27 | `s10040036-p33-at0560` / `1004003600027` | 空 | `live2d/AC_felt01` |

已经正式保存的28→Ferris dress不在包内。P31的背景70、人物69/71/105–108以及Ricardo9人物/语音也均已排除，避免重复。

## 原片与接受强度

原报告是`repair-20261111/episode9-10-audit-20261121-v1/p33-tail-character-review.md`，SHA `4b8e43668b9e8108e6466c9280f463102d98146761a2e30affbf5b2ca7d2456d`。独立于原始还原数据生成的子代理`/root/p31_route_evidence`明确记录：亲自看完0000–0486共487张连续原帧，551.423–567.623秒，包含前一张Subaru、25/26/27各自完整入场/说话/保持/退场及28之后黑场；并看完整原模型纹理。报告只接受人物身份。

原source packet为同目录`p33-tail-character-bindings.packet.json`，SHA `73b5d6285ad80da5d656f5c0cfd16b19c5fe563eb8f796f8619daae4521693c3`。queue128 SHA `49c952db037461434f4ead4893f15bfc5fd8d5c9dbda6a08acda098a01dd7450`是后续整合，**queue本身不是新的识图接受**。

另一个独立图审`/root/p43_scene16_cg_fx`的`p33-source-identity-review.json`只签了已发布的**28**；不能搬给25–27。本轮没有新增识图，也未找到25–27的第二人完整复核，所以候选所有rootConfirmed仍为false。Root将指定另一识图子代理直接使用下面现存原件复核，不必重截图或解码。

## 给独立review的实际原件

共同绝对前缀：`/home/rikka/Projects/stella/data/native_recovery/royal-capital-20261110/repair-20261111/`

- 全487原帧：`p31-route-evidence-20261121-v1/source33/frames/0000.jpg`至`0486.jpg`，均存在。原目录另外还有0487–0867，不在本次接受范围。
- 原index：`p31-route-evidence-20261121-v1/source33/pts.tsv`，SHA `c04842465599bc705702a09e654a4e51ac6085f1055882247f97d14a2821665e`。保留其完整868条原记录，只选0000–0486查看。
- 现成顺序表：`p31-route-evidence-20261121-v1/source33-full-tail-contacts/`，11张`all-0000-0047.jpg`…`all-0480-0486.jpg`，完整覆盖487帧。具体11个绝对路径及SHA在[source-evidence-paths.json](source-evidence-paths.json)。
- 原片：P33 / `bili-capital-33`，既有source SHA `77a8fbdd161419929296f8f34d3fe9e5e0a4fcf5f8ecfa8ac37b6c6ce488df23`；本轮未重新哈希或解码整部影片。
- 25入场552.090、退净555.023；26入场555.223、退净558.923；27入场559.123、退净564.156。任务仍查看完整487以保留前后边界。
- 全尺寸文字见证分别是`source33/frames/0035.jpg`、`0145.jpg`、`0275.jpg`；三张已仅按原bytes重新校验SHA，本轮没有打开图像。
- 完整Wilhelm01/Subaru01/Felt01原纹理与现资源绝对路径也在`source-evidence-paths.json`，无需新资源。

## 保存前守卫与剩余缺口

当前完整native SHA `74cb6ea87821b58ce323935b644371cdb175eb9e6489d21fdc3d6e3f8fc96e8f`，完整review SHA `0636755cf9e426f2cfe83a6e84ebaf23856da67de583eb2c13cce0f52e24d1e0`。三条UID/stable/日文与原source packet完全一致，旧expected中的空character_image/video也仍符合。

`target-guards.rootfalse.json`保留当前三条完整row/review、30条有序ID/UID与数组摘要、ownership、29/30新增结束结构和28已发布身份。九项模型descriptor/MOC/texture在当前committed package中的SHA均与旧接受记录相等，资源已注册；本轮只stat这些payload，未把metadata匹配冒称重新读取了全部资源bytes。

实际剩余：25–27第二独立身份复核；hold释放后的真实HEAD、完整目标/ownership/global summary和原件资源重绑定；正常保存后24→25→26→27→28核验。`draft`、`text_review_pending`、其他性能字段、分支、数组顺序及28/29/30均应保留。本包不接受motion/face/pose/geometry/timing/audio，也不声称整scene完成。

本轮仅轻量JSON/报告检查和少量原bytes哈希，nice19/CPU0,1；无新识图、媒体计算、外网或浏览器。
