# P33 scene10040036 tail identities

Reviewer `/root/p31_route_evidence` directly viewed every original frame0000–0486
under `p31-route-evidence-20261121-v1/source33/frames`, using the eleven complete
`source33-full-tail-contacts` sheets. Coverage is551.423–567.623s, including the
preceding Subaru card, each full entrance/action/hold/exit of Wilhelm25, Subaru26,
Felt27 and Felis28, then the black stage after28. These are reused consecutive
source frames; no FPS subsampling or original-video decode was performed.
The source PTS table and original decode log are retained in `source33`.

Source hash77a8fbdd161419929296f8f34d3fe9e5e0a4fcf5f8ecfa8ac37b6c6ce488df23
matches the current reviewed scene's recording evidence. Source panel text was
also read at full resolution in frames0035,0145,0275 and0430, and matches the
four installed Japanese sidecar rows. Native/review stable keys and blank
character preconditions are retained in the packet. Models were identified by
direct inspection of the exact current model texture atlases, rather than names
or the prior audit. The ferris_dress01 two texture sheets and corresponding
portrait were both inspected; the regularferris01 uniform and ferris_robe01
were viewed as controls. The former has a closed military collar/cape and the
latter a plain wrapped garment; neither matches the sleeveless striped dress.

Wilhelm enters from552.090 with eyes initially closed, becomes clear, opens his
eyes and speaks, then fades away by555.023. Subaru appears from555.223, faces
forward in his zipped tracksuit and speaks with an intent expression, then is
gone by558.923. Felt appears from559.123, briefly closes her eyes/lowers her
head during the speech, opens her eyes again and is gone by564.156. Felis
appears from564.323 in the dress, speaks, blinks and is gone by567.223. These
observed actions do **not** identify an exact body/face/lip token. No such token,
extra layer, placement parameter, audio, timing or expression is accepted here.

The only accepted installation scope is four previously empty `character`
scalars:25→AC_wilhelm01,26→AC_subaru01,27→AC_felt01,28→AC_ferris_dress01.
The packet has four`rootConfirmed:false` flags for root review and uses the
current native_repair`changes/expected/fields`schema. Formal installation,
player resource readback, direct preview and continuous24→25→26→27→28 playback
remain pending. Identity acceptance does not imply complete performances or a
complete scene/route.
