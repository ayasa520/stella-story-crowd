# P30 scene10450054 —27 missing foreground identity candidates

All27 requested CARD rows now have full original static identity evidence. Two delegated image reviewers directly inspected27 existing480×856 originals plus the two existing node22 choice witnesses. No new extraction was needed; subtitle crops were used only to locate the originals.

Candidate groups:

- Subaru short-sleeved tshirt01:12,13,14,15,22,28,45,47,50.
- Julius jersey01:18,19,24,25,29,34.
- Julius knight julius01:36,38,40,44,48,51.
- Elsa mantle elsa01:30,35,37,39,46,49.

The original/current near-variant resources and original-MOC static controls distinguish tshirt01/02, Julius jersey/knight and Elsa mantle/no-mantle. Node22 UI portraits are not treated as scalar stage actors. Node37 black-background tool display and node39 darkness remain observations without a cause or BG acceptance.

`candidate.packet.rootfalse.json` proposes character only for27 currently empty foregrounds; it is not an execution release or normal-save packet. `current-inputs-before-review.rootfalse.json` binds the full current native rows and full-scene Japanese/Chinese guards. Both child receipts and exact source-frame paths/hashes appear in `review.rootfalse.json`.

No CG candidate or unknown/extraction gap remains in this static-identity batch. Existing roles/voices and text-review states are preserved. Body, face, phase, timing, geometry, audio, gameplay and whole-scene acceptance remain false. Root must independently review and freshly rebind normal-save constraints before any formal action. No D/C/Git/browser/API/media/new pixels or old evidence were changed.

A separate sealed neutral index supplies the same original sources and all near-variant resource families to the independent peer without node identity opinions. Root did not view images.
