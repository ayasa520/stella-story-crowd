# P30 missing foreground nodes34–51: independent still identity review

All15 requested nodes have directly viewed original full480×856 cached witnesses. No subtitle crop was used as identity evidence and no new extraction is needed.

- 34: `live2d/AC_julius_jersey01`, lavender-haired actor in the pale zip-front N-mark sports jacket.
- 36/38/40/44/48/51: `live2d/AC_julius01`, the white/red high-collar shoulder cape and gold clasp.
- 35/37/39/46/49: `live2d/AC_elsa01`, rose ornament, purple feathered trim and cloak with circular gold clasp.
- 45/47/50: `live2d/AC_subaru_tshirt01`, plain round-neck shirt with visible short sleeves; the02 original control is sleeveless.

Current portraits, the raw Julius jersey texture, closed original Elsa cloak/no-cloak controls and original Subaru01/02 controls were directly compared. Current and original descriptor/MOC/texture bytes for all six selected/contrast models were freshly matched. Controls identify costumes only; they do not replace the15 source witnesses or accept a motion.

Node37 appears against black backing in the tool view and39 is dark/faded. Clothing remains recognizable; no black-screen cause or background field is inferred. Cache times are nominal annotations, not newly established originalPTS or transition timing. Every existing text status and non-character field is preserved.

`inputs-and-coverage.rootfalse.json` binds all full witnesses, current native/JA/Chinese guards, resource versions and reference images. `candidate.rootfalse.json` is a15-row character-only proposal for root rebinding, not execution or installation authorization. All rootConfirmed flags remain false.

No body/face/extra/phase/geometry/timing/audio/whole-scene acceptance. No D/C, old evidence, Git, browser, API, media, new rendering or image output was changed or run.
