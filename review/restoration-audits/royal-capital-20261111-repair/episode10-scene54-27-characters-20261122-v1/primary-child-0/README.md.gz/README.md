# P30 missing foreground nodes12–30: static identity peer

All12 requested nodes have a directly reviewed existing full-frame source witness. No extraction gap remains in this group. Limited character-only candidates are Subaru short-sleeved tshirt01 at12/13/14/15/22/28, Julius jersey01 at18/19/24/25/29, and mantle Elsa01 at30.

Subaru sleeve/shoulder construction was checked against both original-model variants and their current byte-exact resources. Node22 also uses existing130/133s full witnesses: short sleeves are visible despite choice UI; small jacket portraits in that UI do not replace the main actor. Julius's high zipped collar/orange stripe/pale N panel matches jersey01; Elsa30 visibly has the purple-feathered mantle and circular gold fastening.

The12 selected fullframes plus2 existing node22 witnesses were newly viewed, with3 raw atlases, Elsa portrait and1 historical original-model shirt control. Old observation records supply exact paths/provenance only; speaker names and historical accepted labels are not image evidence. All source/current resource bytes were freshly bound.

See `review.rootfalse.json`, `inputs-and-coverage.rootfalse.json` and the non-executable `candidate.packet.rootfalse.json`. Only static identity is supported: no acting/body/face/phase/timing/geometry/audio/branches or whole-scene acceptance. Current text/voice/commands/IDs/transitions and other targets remain untouched. No new pixels/media/browser/API/Git or formalD/C changes.
