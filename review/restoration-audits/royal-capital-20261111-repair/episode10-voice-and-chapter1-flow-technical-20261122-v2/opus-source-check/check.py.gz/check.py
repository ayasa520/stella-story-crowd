"""One authorized Opus EOF decode and reuse of the pinned PCM identity test.

This owns only a single audio decoder. Original WAVs and metadata stay read-only;
the numerical phase cannot begin until that decoder has exited and its process
group is absent. Waveform lags are evidence coordinates, never authored offsets.
"""
from pathlib import Path
import ast
import contextlib
import gzip
import hashlib
import io
import json
import os
import resource
import selectors
import signal as signals
import subprocess
import sys
import time
import traceback

P = Path('/home/rikka/Projects/stella')
A = P / 'artifacts/stella-script-continuation-20261121'
R = P / 'data/native_recovery/royal-capital-20261110/repair-20261111'
HERE = Path(__file__).resolve().parent
FF = Path('/usr/bin/ffmpeg')
OPUS = A / 'data-checkout/assets/preview/voices/vo_adv_julius/advk_julius_emilia.opus'
WAV = A / 'data-checkout/assets/voices/vo_adv_julius/advk_julius_emilia.wav'
SOURCE = R / 'p30-bgm-identification-20261113-v1/p30-original-source.wav'
VERIFIER = R / 'p30-next-voice-preflight-20261113-v1/verify38.py'
ADAPTER = A / 'episode10-gap-audit-20261121-v1/verify-voice58-6.py'
OLD = A / 'episode10-gap-audit-20261121-v1/voice58-6-measurements.json'
MODULE = P / 'story_studio/recovery/audio_correlation.py'
EXPECTED = {
    FF: 'fc5db7b88a2a96e9a9036fbc9533d8b3ec16abbc31526b285e996ae1d81b9fcd',
    OPUS: '82e52de64d8e553ecd591f36f7588944e4aa8ab108122b3254a05860762e2718',
    WAV: 'b7ab09e687e7783e982ce565706d32b6214da29cc71458ddf130373a597c3318',
    SOURCE: 'ce16138f1b12168383cdb88c7bdb7e390b7b0c0fb67b2fad9c6d7eac53e01831',
    VERIFIER: '4fb78b5d38bfc20a7db1b7609e2ca9a1fed8e651be9f6affd3e3b5201642a9bf',
    ADAPTER: '9164b5a52e3eff0c5ee3e832361689d8be55c7171d51fb0c1814864dff4a2980',
    MODULE: '55d38019873e50244ada14cbaa4172467ed11e90a0ad86e1e1dc972827d49444',
}
MAX_OUTPUT = 1024 * 1024
MAX_PCM = 1024 * 1024
MAX_STDERR = 128 * 1024
cancel = []


def deferred_signal(number, _frame):
    # A signal may arrive between Popen and assignment. Merely recording it keeps
    # child registration and the surrounding finally block in control of cleanup.
    cancel.append(number)


def checkpoint():
    if cancel:
        raise RuntimeError(f'Cancellation requested: {cancel}')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_row(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def save(name, data):
    if isinstance(data, str):
        data = data.encode()
    current = sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())
    if current + len(data) >= MAX_OUTPUT:
        raise RuntimeError('Total new artifact output would exceed 1 MiB')
    with (HERE / name).open('xb') as out:
        out.write(data)


def save_json(name, value):
    save(name, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def preserve_unhandled_error(kind, value, tb):
    # A numerical or metadata error must preserve the first failure without
    # authorizing another decode. Decoder terminal/input records already exist.
    if not (HERE / 'first-error.txt').exists():
        save('first-error.txt', ''.join(traceback.format_exception(kind, value, tb)))
    if globals().get('inputs') and not (HERE / 'inputs-on-error.json').exists():
        save_json('inputs-on-error.json', {str(p): file_row(p) for p in inputs})
    sys.__excepthook__(kind, value, tb)


sys.excepthook = preserve_unhandled_error


def ffmpeg_processes():
    found = []
    unavailable = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            if (p / 'comm').read_text().strip() == 'ffmpeg':
                found.append(dict(pid=int(p.name), pgid=os.getpgid(int(p.name))))
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            unavailable.append(int(p.name))
    return dict(ffmpeg=found, unreadableProcessEntries=unavailable)


def group_members(pgid):
    result = []
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            try:
                if os.getpgid(int(p.name)) == pgid:
                    result.append(int(p.name))
            except ProcessLookupError:
                pass
    return result


resource.setrlimit(resource.RLIMIT_NICE, (1, 1))
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
assert sorted(os.sched_getaffinity(0)) == [0, 1]
for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    assert os.environ[key] == '1'
for number in [signals.SIGINT, signals.SIGTERM]:
    signals.signal(number, deferred_signal)

inputs = [FF, OPUS, WAV, SOURCE, VERIFIER, ADAPTER, MODULE, OLD]
before = {str(p): file_row(p) for p in inputs}
for p, expected in EXPECTED.items():
    assert before[str(p)]['sha256'] == expected, str(p)
assert before[str(OPUS)]['bytes'] == 3885
assert before[str(WAV)]['bytes'] == 52504
assert before[str(SOURCE)]['bytes'] == 8053500
assert FF.read_bytes()[18:20] == b'\xb7\x00', 'ELF must be AArch64'
save_json('inputs-before.json', before)
pre = ffmpeg_processes()
save_json('processes-before.json', pre)
assert not pre['ffmpeg'] and not pre['unreadableProcessEntries'], pre

# No resampling, seeking, duration limit, filter or encoded intermediary is used.
# Input and output codec threads are explicit; PCM is native-rate sample transport.
command = [str(FF), '-hide_banner', '-nostdin', '-nostats', '-loglevel', 'info',
           '-threads', '1', '-filter_threads', '1', '-filter_complex_threads', '1',
           '-i', str(OPUS), '-map', '0:a:0', '-vn', '-sn', '-dn',
           '-c:a', 'pcm_s16le', '-threads:a', '1', '-f', 's16le', 'pipe:1']
save_json('command.json', dict(argv=command, cwd=str(P), nice=19, affinity=[0, 1],
                             inputEOFRequired=True, pcmRAMCap=MAX_PCM,
                             stderrCap=MAX_STDERR, totalArtifactCap=MAX_OUTPUT,
                             automaticRetry=False))
pcm = bytearray()
stderr = bytearray()
process = None
selector = selectors.DefaultSelector()
state = dict(supervisorPid=os.getpid(), supervisorPgid=os.getpgrp(),
             decoderPid=None, decoderPgid=None, exitCode=None,
             stdoutEOF=False, stderrEOF=False, forcedStop=False)
failure = None
try:
    checkpoint()
    process = subprocess.Popen(command, cwd=P, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               start_new_session=True)
    state['decoderPid'] = process.pid
    state['decoderPgid'] = process.pid
    state['actualPgidAtRegistration'] = os.getpgid(process.pid)
    save_json('decoder-start.json', state)
    print('DECODER_STARTED ' + json.dumps(state), flush=True)
    checkpoint()
    assert state['actualPgidAtRegistration'] == process.pid
    for stream, label in [(process.stdout, 'stdout'), (process.stderr, 'stderr')]:
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, label)
    deadline = time.monotonic() + 30
    while selector.get_map():
        checkpoint()
        if time.monotonic() > deadline:
            raise RuntimeError('Decoder exceeded bounded 30 second ownership deadline')
        for key, _ in selector.select(.1):
            block = os.read(key.fd, 65536)
            if not block:
                state[key.data + 'EOF'] = True
                selector.unregister(key.fileobj)
                key.fileobj.close()
                continue
            destination, cap = (pcm, MAX_PCM) if key.data == 'stdout' else (stderr, MAX_STDERR)
            if len(destination) + len(block) > cap:
                raise RuntimeError(key.data + ' exceeded authorized bounded RAM output')
            destination.extend(block)
    state['exitCode'] = process.wait(timeout=5)
    assert state['exitCode'] == 0, state
except BaseException:
    failure = traceback.format_exc()
finally:
    if process is not None:
        if process.poll() is None:
            state['forcedStop'] = True
            try:
                os.killpg(process.pid, signals.SIGKILL)
            except ProcessLookupError:
                pass
        state['exitCode'] = process.wait(timeout=5)
        for stream in [process.stdout, process.stderr]:
            if stream and not stream.closed:
                stream.close()
        state['remainingGroupMembers'] = group_members(process.pid)
    selector.close()
    save('ffmpeg.stderr.log', bytes(stderr))
    state['pcmBytes'] = len(pcm)
    state['pcmSHA256'] = sha(pcm)
    state['stderrBytes'] = len(stderr)
    state['stderrSHA256'] = sha(stderr)
    save_json('decoder-terminal.json', state)
    save('decoded-native-s16le.pcm.gz', gzip.compress(bytes(pcm), compresslevel=6, mtime=0))
    after = {str(p): file_row(p) for p in inputs}
    save_json('inputs-after.json', after)
    assert after == before, 'An original input changed'
    save_json('processes-after.json', ffmpeg_processes())
if failure:
    save('first-error.txt', failure)
    print(failure, file=sys.stderr, flush=True)
    raise SystemExit(1)
assert state['stdoutEOF'] and state['stderrEOF'] and not state['forcedStop']
assert not state['remainingGroupMembers']
print('DECODER_TERMINAL ' + json.dumps(state), flush=True)

# The closed decoder's own complete header must establish native PCM geometry.
# The transport has no header, so this assertion prevents guessing a sample rate.
log = bytes(stderr).decode('utf-8', errors='strict')
assert 'Audio: opus, 48000 Hz, mono' in log
assert 'Audio: pcm_s16le' in log and '48000 Hz, mono, s16' in log
assert len(pcm) % 2 == 0 and len(pcm) > 0
checkpoint()
sys.path.insert(0, str(P))
import numpy as np
import wave
from story_studio.recovery.audio_correlation import WaveformCorrelation

template = VERIFIER.read_text()
tree = ast.parse(template)
names = ['read_pcm', 'to_4k', 'measure']
nodes = {name: next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)
         for name in names}
extracted = '\n\n'.join(ast.get_source_segment(template, nodes[name]) for name in names) + '\n'
save('reused-functions.py', extracted)
scope = {'np': np, 'wave': wave, 'RATE': 4000}
exec(compile(ast.Module(body=[nodes[name] for name in names], type_ignores=[]),
             str(VERIFIER), 'exec'), scope)
read_pcm, to_4k, measure = [scope[name] for name in names]
source, source_layout = read_pcm(SOURCE, 811, 818)
native, native_layout = read_pcm(WAV)
assert source_layout == dict(channels=1, sampleBytes=2, rate=4000, frames=4026711)
assert native_layout == dict(channels=1, sampleBytes=2, rate=32000, frames=26230)
decoded = np.frombuffer(pcm, '<i2').astype(np.float64) / 32768
native4 = to_4k(native, 32000)
decoded4 = to_4k(decoded, 48000)
comparisons = []
settings = dict(backend='cpu', query_fft_cache_bytes=8388608,
                memory_limit_bytes=67108864, fft_plan_cache_bytes=0)
numerical_stdout = io.StringIO()
with contextlib.redirect_stdout(numerical_stdout):
    with WaveformCorrelation(settings) as compute:
        # This is the original seven-second window, original mean removal and
        # original FFT geometry, scoring formula and five-peak reduction.
        source -= source.mean()
        sig = compute.signal(source, 1 << (len(source) + 8000 - 2).bit_length())
        scope.update(compute=compute, source=source, signal=sig, WINDOW=(811, 818),
                     comparisons=comparisons)
        for label, converted in [('native-WAV', native4), ('decoded-Opus', decoded4)]:
            active = np.flatnonzero(np.abs(converted) >= np.max(np.abs(converted)) * .02)
            left = max(0, int(active[0]) - round(4000 * .025))
            right = min(len(converted), int(active[-1]) + round(4000 * .025) + 1)
            measure(label + '-active-versus-source7s', converted[left:right], left / 4000)
            measure(label + '-whole-versus-source7s', converted)
            selected = converted[left:right]
            borders = [0, len(selected) // 3, len(selected) * 2 // 3, len(selected)]
            for i in range(3):
                a, b = borders[i:i + 2]
                measure(label + f'-piece{i + 1}-versus-source7s', selected[a:b], (left + a) / 4000)
        # Direct original-cue comparison uses the same original measure/NCC.
        # Choose the shorter whole template, with no padding, cropping or hidden
        # length equality assumption. The direction and both counts are saved.
        direct_source, direct_template = ((native4, decoded4) if len(decoded4) <= len(native4)
                                          else (decoded4, native4))
        direct_source = direct_source.copy()
        direct_source -= direct_source.mean()
        sig = compute.signal(direct_source, 1 << (len(direct_source) + 8000 - 2).bit_length())
        scope.update(source=direct_source, signal=sig, WINDOW=(0, len(direct_source) / 4000))
        direct = measure('direct-whole-shorter-cue-NCC', direct_template)
save('analysis.stdout.log', numerical_stdout.getvalue())
old = json.loads(OLD.read_text())
old_target = [x for x in old['comparisons'] if x['label'] in
              ['vo_adv_julius/advk_julius_emilia-active',
               'vo_adv_julius/advk_julius_emilia-whole-existing-cue']]
old_active = next(x for x in old_target if x['label'].endswith('-active'))
old_whole = next(x for x in old_target if x['label'].endswith('-whole-existing-cue'))
native_active = comparisons[0]
native_whole = comparisons[1]
assert abs(native_active['peaks'][0]['signedNcc'] - old_active['peaks'][0]['signedNcc']) < 1e-12
assert abs(native_whole['peaks'][0]['signedNcc'] - old_whole['peaks'][0]['signedNcc']) < 1e-12
for item in comparisons:
    item['templateSamplesAt4k'] = round(item['templateDuration'] * 4000)
    for peak in item['peaks']:
        peak['lagSamplesInComparedSignalAt4k'] = round(
            (peak['templateStartPcmSeconds'] - (0 if item is direct else 811)) * 4000)
result = dict(schema='stella.p30.voice58-6.opus-source-check.v1', rootConfirmed=False,
              bank='vo_adv_julius', cue='advk_julius_emilia',
              decode=state, decodedLayout=dict(channels=1, sampleBytes=2, rate=48000,
                                              frames=len(decoded), seconds=len(decoded) / 48000),
              nativeLayout=native_layout, sourceLayout=source_layout,
              sourceWindowSeconds=[811, 818], sourceWindowSamples=28000,
              native4kSamples=len(native4), decoded4kSamples=len(decoded4),
              wholeCueDirectSignal='native-WAV' if len(decoded4) <= len(native4) else 'decoded-Opus',
              wholeCueDirectQuery='decoded-Opus' if len(decoded4) <= len(native4) else 'native-WAV',
              originalSignedNCCReproduced=True, originalAcceptedComparisons=old_target,
              comparisons=comparisons, noWholeBankSearch=True,
              method=dict(verifier=file_row(VERIFIER), adapter=file_row(ADAPTER),
                          correlationModule=file_row(MODULE),
                          extractedFunctions=[dict(name=n, originalFirstLine=nodes[n].lineno,
                                                   originalLastLine=nodes[n].end_lineno,
                                                   exactSourceSHA256=sha(ast.get_source_segment(template, nodes[n]).encode()))
                                              for n in names],
                          resampling='Original 129-tap Hamming sinc 1800Hz, same convolution; 32k/8 and 48k/12 decimation to4k',
                          settings=settings, numpy=np.__version__),
              opusCueIdentityQuantitativelySupported=None, rootIdentityReviewPending=True,
              identityScopeOnly=True, listeningPerformed=False,
              originalCsvRecovered=False, originalPhaseOffsetGainRecovered=False,
              authoredTimingAccepted=False, wholeSceneAccepted=False,
              sourceVideoDecoded=False, browserAPIOrFormalWrite=False)
save_json('measurements.json', result)
checkpoint()
final_inputs = {str(p): file_row(p) for p in inputs}
assert final_inputs == before
save_json('inputs-final.json', final_inputs)
payloads = {p.name: file_row(p) for p in sorted(HERE.iterdir()) if p.is_file()}
save_json('receipt.rootfalse.json', dict(schema='stella.p30.voice58-6.opus-source-check.receipt.v1',
                                       rootConfirmed=False, payloads=payloads,
                                       oneDecoderExecution=True, naturalEOF=True,
                                       decoderExitCode=0, decoderPgidAbsent=True,
                                       allOriginalInputsBeforeAfterFinalExact=True,
                                       outputCapBytes=MAX_OUTPUT,
                                       noListeningOrPhaseAcceptance=True))
print('RESULT ' + json.dumps(dict(
    nativeSamples=len(native), decodedSamples=len(decoded), native4kSamples=len(native4),
    decoded4kSamples=len(decoded4), direct=direct,
    sourceNativeActive=comparisons[0]['peaks'][0], sourceOpusActive=comparisons[5]['peaks'][0],
    totalNewArtifactBytes=sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())),
    ensure_ascii=False), flush=True)
