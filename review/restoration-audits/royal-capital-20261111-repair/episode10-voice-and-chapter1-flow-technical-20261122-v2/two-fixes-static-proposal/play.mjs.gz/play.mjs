// Single saved 10450058 voice route through the unchanged complete Worker and
// canonical player. This audio-only scope has no screenshot, recorder, actor
// tap, curve audit, seeded before or post-load media/clock/layer mutation.
import assert from 'node:assert/strict';
import {readFile,writeFile,appendFile,realpath} from 'node:fs/promises';
import {resolve} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {sha,verifyInputs,expandInventory} from './guards.mjs';
import {connect} from '../../stella-p30-firefox-20261120/bidi.mjs';
import {installRenderProbe} from '../../stella-p30-firefox-20261120/render-probe.mjs';
import {installSavedVoiceObserver} from './media-observer.mjs';
const here=new URL('./',import.meta.url),origin='http://127.0.0.1:5198';
const output=process.env.STELLA_REVIEW_OUTPUT;assert.ok(output);
const load=async name=>JSON.parse(await readFile(new URL(name,here),'utf8'));
const plan=await load('capture-plan.json'),binding=await expandInventory(await load('input-binding.json'));
const offlinePrepare=await load('normal-prepare-receipt.json');
assert.equal(offlinePrepare.allStatus200,true);
assert.equal(offlinePrepare.productionOrigin,'https://stella-preview.jaoushingan.com');
assert.equal(await realpath(process.execPath),await realpath(binding.tools.node.binaryPath));
assert.equal(sha(await readFile(process.execPath)),binding.tools.node.sha256);
let route,activeCase,traceStart=0,observerHandle=null,observerCleanup=null,sourceProof=null;
const driver=await connect(process.argv[2]);
const traces=[],records=[],errors=[],http=[],played=[],captures=[],actions=[],eventWrites=[];
const rawConsole=[],fatalFacts=[],hitches=[],cancellations=[],diagnosticFailures=[];
const fatalProductNames=new Set(['STORY_PLAYER_ERROR','STORY_NORMAL_CLOCK_LISTENER_ERROR','STORY_NORMAL_CLOCK_REPORT_ERROR',
  'STORY_FX_ERROR','STORY_BACKGROUND_ERROR','STORY_PICTURE_ERROR','STORY_BGM_LOAD_FAILED']);
let target,stage='connect',capabilities,prepared,panelConfig,totalCaptureBytes=0;
let firstFailure=null,pendingResult=null,lastKnownDocumentIdentity=null,sessionRetired=false;
let diagnosticBytes=0,diagnosticBudgetExceeded=false;
const failureExports=[],savedFailureNames=new Set();
function rejectFatalDiagnostics(boundary){
  assert.deepEqual(fatalFacts,[],'Original fatal diagnostics at '+boundary);
  assert.deepEqual(errors,[],'Original exceptions/HTTP failures at '+boundary);
  assert.deepEqual(diagnosticFailures,[],'Diagnostic write/export failures at '+boundary);
}
function queueDiagnosticWrite(name,row){
  // BiDi has already received the original invocation. This handler neither
  // wraps nor rethrows into the product console or its Normal-clock callback.
  const line=JSON.stringify(row)+'\n';diagnosticBytes+=Buffer.byteLength(line);
  if(diagnosticBytes>binding.budgets.diagnosticTraceBytes&&!diagnosticBudgetExceeded){
    diagnosticBudgetExceeded=true;diagnosticFailures.push({operation:'diagnostic-budget',diagnosticBytes,
      qualification:'Complete crossing row and subsequent original errors retained; abort before another input'});
  }
  const job=appendFile(resolve(output,name),line).catch(error=>{
    diagnosticFailures.push({operation:'append',name,error:String(error),stack:error.stack});
  });
  eventWrites.push(job);
}
async function flushDiagnosticWrites(){
  let index=0;
  for(let round=0;round<32;round++){
    const batch=eventWrites.slice(index);if(!batch.length)return;
    index=eventWrites.length;await Promise.allSettled(batch);
  }
  throw Error('Diagnostic writes did not quiesce within the bounded flush');
}
function retainFirstFailure(error,boundary){
  if(!firstFailure)firstFailure={boundary,stage,requestedCase:activeCase?.id||null,
    error:String(error),stack:error?.stack||'',observedEpochMilliseconds:Date.now()};
}
const save=async(name,value)=>writeFile(resolve(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
async function evaluate(fn,arg){
  const reply=await driver.call('script.evaluate',{target,awaitPromise:true,
    expression:`(async()=>JSON.stringify(await (${fn})(${JSON.stringify(arg)})))()`});
  if(reply.type!=='success'){
    diagnosticFailures.push({operation:'original-script-evaluate',reply});
    throw Error(reply.exceptionDetails?.text||'Firefox evaluation failed');
  }
  return reply.result.type==='undefined'?null:JSON.parse(reply.result.value);
}
async function saveGzip(name,value){
  const raw=JSON.stringify(value),compressed=gzipSync(raw);
  await writeFile(resolve(output,name),compressed,{flag:'wx'});
  return {file:name,rawBytes:Buffer.byteLength(raw),rawSha256:sha(raw),bytes:compressed.length,sha256:sha(compressed)};
}
async function snapshot(){return evaluate(()=>({
  epochMilliseconds:Date.now(),performanceMilliseconds:performance.now(),body:{...document.body.dataset},
  status:document.getElementById('status').textContent,error:document.getElementById('status').classList.contains('error'),
  accessibleText:document.getElementById('accessibleText').textContent,
  auto:document.getElementById('auto').getAttribute('aria-pressed'),
  card:{opacity:getComputedStyle(document.getElementById('cardMotion')).opacity},
  panel:{opacity:getComputedStyle(document.getElementById('subtitles')).opacity,
    translate:getComputedStyle(document.getElementById('subtitles')).translate},
  render:window.reviewRenderProbe.snapshot()
}));}
async function click(selector,cleanupStop=false){
  // Existing original errors forbid any further route input. Cleanup may still
  // attempt the product's own Stop button, without permitting advance/retry.
  if(cleanupStop)assert.equal(selector,'#stop');
  else rejectFatalDiagnostics('before ordinary input');
  const point=await evaluate(selector=>{
    const e=document.querySelector(selector);if(!e||e.disabled||!e.checkVisibility())return null;
    e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();
    return {x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)};
  },selector);assert.ok(point,'Visible enabled ordinary control '+selector);
  actions.push({selector,before:await snapshot()});
  await driver.call('input.performActions',{context:target.context,actions:[{type:'pointer',id:'mouse',parameters:{pointerType:'mouse'},
    actions:[{type:'pointerMove',origin:'viewport',...point,duration:0},{type:'pointerDown',button:0},{type:'pointerUp',button:0}]}]});
  actions.at(-1).afterEpochMilliseconds=Date.now();
}
async function waitFor(fn,arg,timeout=45000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    rejectFatalDiagnostics('condition poll');
    const value=await evaluate(fn,arg);if(value)return value;
    for(const selector of ['#movieContinue','#voiceContinue']){
      const blocked=await evaluate(selector=>{const e=document.querySelector(selector);return e&&!e.hidden&&!e.disabled&&e.checkVisibility();},selector);
      if(blocked)throw Error('Original media permission gate requires a separate root decision; no automatic retry '+selector);
    }
    await delay(70);
  }
  throw Error('Ordinary player condition timed out at '+stage);
}
function parsed(prefix){return traces.slice(traceStart).filter(line=>line.startsWith(prefix)).map(line=>JSON.parse(line.slice(prefix.length)));}
async function waitTrace(test,timeout=15000){
  const end=Date.now()+timeout;
  while(Date.now()<end){rejectFatalDiagnostics('event poll');const value=test();if(value)return value;await delay(50);}
  throw Error('Actual player event timed out at '+stage);
}
async function panelReady(step,node){
  const group=!node.speaker?panelConfig.player.panels.narration:node.character_image?panelConfig.player.panels.picture:panelConfig.player.panels.dialogue;
  const profile=panelConfig.transitions.panel_entries?.[group];
  if(!profile){assert.equal(parsed('STORY_PANEL_IN_START ').filter(e=>e.node===step.id).length,0);return {group,profile:null};}
  // Match the owning node/group/token rather than treating ENTER, ready phase
  // or an arbitrary elapsed delay as evidence that its panel became visible.
  const owner=await waitTrace(()=>parsed('STORY_PANEL_IN_START ').filter(e=>e.node===step.id).at(-1));
  assert.equal(owner.group,group);
  const complete=await waitTrace(()=>{
    assert.ok(!parsed('STORY_PANEL_IN_CANCELLED ').some(e=>e.group===group&&e.token===owner.token),'Owned panel cancelled');
    return parsed('STORY_PANEL_IN_COMPLETE ').find(e=>e.node===step.id&&e.group===group&&e.token===owner.token);
  });
  return {group,profile,owner,complete};
}
async function actorReady(step){
  assert.equal(traces.filter(e=>e.startsWith('STORY_DISPLAY_COMMIT '+step.id+' ')).at(-1),
    'STORY_DISPLAY_COMMIT '+step.id+' actor '+step.expectedModel);
  const before=await evaluate(()=>window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor'));
  assert.ok(before?.attached&&!before.lost);
  // Positive new draw submissions belong to the attached actor canvas. A
  // stale Subaru screenshot, an ENTER event or a scratch GL context cannot
  // satisfy this ordinary display gate. This audio-only case accepts no pose.
  return waitFor(draws=>{
    const e=window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor');
    return e?.attached&&!e.lost&&e.draws>draws+3&&document.getElementById('actor')
      .checkVisibility({opacityProperty:true,visibilityProperty:true})&&e;
  },before.draws,10000);
}

async function media(method){
  assert.ok(observerHandle,'Retained original media handle required');
  assert.ok(['snapshot','result','cleanup','proveSource'].includes(method));
  const reply=await driver.call('script.callFunction',{target,awaitPromise:true,resultOwnership:'none',
    functionDeclaration:'async api => JSON.stringify(await api.'+method+'())',arguments:[{handle:observerHandle}]});
  if(reply.type!=='success'){
    diagnosticFailures.push({operation:'original-media-evaluate',reply});
    throw Error(reply.exceptionDetails?.text||'Original media observation failed');
  }
  return JSON.parse(reply.result.value);
}
async function ready(step){
  await waitFor(id=>document.body.dataset.node===id&&document.body.dataset.phase==='ready'&&
    document.getElementById('auto').getAttribute('aria-pressed')==='false',step.id);
  const node=prepared.nodes.find(n=>n.id===step.id);assert.ok(node);
  const panel=await panelReady(step,node),render=await actorReady(step);
  await waitFor(()=>{const card=document.getElementById('cardMotion'),panel=document.getElementById('subtitles');
    return Number(getComputedStyle(card).opacity)>=.99&&Number(getComputedStyle(panel).opacity)>=.99&&
      getComputedStyle(panel).translate==='none'&&card.checkVisibility({opacityProperty:true,visibilityProperty:true})&&
      panel.checkVisibility({opacityProperty:true,visibilityProperty:true});});
  const state=await snapshot();assert.equal(state.body.node,step.id);assert.equal(state.body.phase,'ready');
  assert.equal(state.error,false);assert.ok(state.accessibleText.includes(step.native.msg_text));
  played.push({id:step.id,panel,render,state});return state;
}
async function waitNaturalEnd(){
  const end=Date.now()+45000;
  while(Date.now()<end){
    rejectFatalDiagnostics('original voice natural-end poll');
    const observed=await media('result');
    assert.deepEqual(observed.failures,[]);assert.equal(observed.overflow,false);
    const ended=observed.events.find(e=>e.kind==='ended'&&e.node===activeCase.steps[1].id);
    if(ended)return ended;
    await delay(50);
  }
  throw Error('Original voice natural end was not observed; no seek/replay/fallback');
}
async function exportActualDocument(reason){
  const exported={reason,requestedCase:activeCase?.id||null,exportErrors:[]};
  try{exported.document={state:await snapshot(),identity:await evaluate(()=>({
    href:location.href,timeOrigin:performance.timeOrigin,node:document.body?.dataset.node||'',
    phase:document.body?.dataset.phase||''})),trustedInputs:await evaluate(()=>window.reviewTrustedInputs||[])};}
  catch(error){exported.exportErrors.push({operation:'actual-document',error:String(error),stack:error.stack});}
  if(observerHandle)try{exported.media=await media('result');exported.mediaSnapshot=await media('snapshot');}
  catch(error){exported.exportErrors.push({operation:'original-media',error:String(error),stack:error.stack});}
  exported.observerCleanup=observerCleanup;failureExports.push(exported);return exported;
}
async function retainFailureEvidence(name){
  if(savedFailureNames.has(name))return;savedFailureNames.add(name);
  const exported=sessionRetired?{sessionRetired:true,earlierDocumentExports:failureExports}:await exportActualDocument(name);
  try{const archive=await saveGzip(name+'.gz',{firstFailure,exported,preparedIdentity:prepared&&{
      start:prepared.start,headSha:prepared.headSha,before:prepared.before},played,actions,traces,records,
      rawConsole,fatalFacts,hitches,cancellations,diagnosticFailures,errors,http,sourceProof});
    await save(name,{firstFailure,archive,actualDocumentIdentity:exported.document?.identity||null});
  }catch(error){diagnosticFailures.push({operation:'failure-export',name,error:String(error),stack:error.stack});
    console.error('VOICE_FAILURE_EXPORT_FAILED',{firstFailure,error:String(error),stack:error.stack});}
}
function noPending(value,boundary){
  assert.equal(value.sameOwnerAndAudio,true,boundary);
  assert.equal(value.voice,null,boundary);assert.equal(value.pendingPrepare,false,boundary);
  assert.equal(value.delayedPlay,false,boundary);assert.equal(value.pendingPlay,false,boundary);
  assert.equal(value.blockedPlayback,false,boundary);assert.equal(value.audio.paused,true,boundary);
  assert.equal(value.audio.currentTime,0,boundary);
}
try{
  ({capabilities}=await driver.call('session.new',{capabilities:{}}));
  const {contexts}=await driver.call('browsingContext.getTree');target={context:contexts[0].context};
  driver.events((event,value)=>{
    if(event==='log.entryAdded'){
      const line=value.text||'',name=line.split(/\s+/,1)[0];
      const raw={event,rawEntry:value,requestedCaseAtReceipt:activeCase?.id||null,
        lastKnownDocumentIdentity,observedEpochMilliseconds:Date.now()};
      const reason=value.type==='javascript'?'original-javascript-exception':
        value.level==='error'?'original-console.error':
        fatalProductNames.has(name)?'explicit-original-product-fatal-event':null;
      if(reason)fatalFacts.push({...raw,name,reason});
      if(name==='STORY_NORMAL_FRAME_HITCH')hitches.push(raw);
      if(/_CANCELLED$/.test(name))cancellations.push(raw);
      rawConsole.push(raw);queueDiagnosticWrite('raw-console.jsonl',raw);
      if(/^(?:STORY_|STELLA_|MODEL_|PREVIEW_|VOICE_)/.test(line)){
        traces.push(line);const row={sequence:traces.length-1,eventEpochMilliseconds:value.timestamp,
          observedEpochMilliseconds:Date.now(),line,rawEntry:value};
        records.push(row);queueDiagnosticWrite('events.jsonl',row);
      }
    }
    if(event==='network.responseCompleted'){
      const url=new URL(value.response.url);
      if(url.origin===origin){const row={url:url.href,status:value.response.status,mimeType:value.response.mimeType,
        rawEntry:value,observedEpochMilliseconds:Date.now()};http.push(row);queueDiagnosticWrite('http.jsonl',row);
        if(row.status>=400&&url.pathname!=='/favicon.ico')errors.push('HTTP '+row.status+' '+row.url);}
    }
  });
  await driver.call('session.subscribe',{events:['log.entryAdded','network.responseCompleted'],contexts:[target.context]});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:installRenderProbe.toString()});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:(()=>{
    window.reviewReady=false;window.reviewTrustedInputs=[];
    window.addEventListener('message',event=>{
      if(event.source===window&&event.origin===location.origin&&event.data?.type==='stella-player-ready')window.reviewReady=true;});
    document.addEventListener('click',event=>{const e=event.target.closest('button');if(e)window.reviewTrustedInputs.push({
      button:e.id,trusted:event.isTrusted,node:document.body.dataset.node,phase:document.body.dataset.phase,
      epochMilliseconds:Date.now(),performanceMilliseconds:performance.now()});},true);
  }).toString()});
  await driver.call('browsingContext.setViewport',{context:target.context,viewport:plan.captureFormat.viewport,devicePixelRatio:1});
  assert.equal(plan.cases.length,1);activeCase=plan.cases[0];
  const item=activeCase,offline=offlinePrepare.programs[item.id];
  route=await load('prepared/'+item.id+'.route.json');
  await verifyInputs(binding);await flushDiagnosticWrites();rejectFatalDiagnostics('before fresh navigation');
  stage='fresh-saved-document';
  await driver.call('browsingContext.navigate',{context:target.context,
    url:origin+'/player/player.html?assetRevision='+binding.revision,wait:'interactive'});
  await waitFor(()=>window.reviewReady===true);
  lastKnownDocumentIdentity=await evaluate(()=>({href:location.href,timeOrigin:performance.timeOrigin}));
  assert.equal(await evaluate(()=>document.getElementById('auto').getAttribute('aria-pressed')),'false');
  assert.equal(await evaluate(()=>document.getElementById('language').value),'zh');
  panelConfig=await evaluate(async()=>({player:await(await fetch('/player/player_config.json')).json(),
    transitions:await(await fetch('/player-assets/transitions.json')).json()}));
  stage='complete-ordinary-cloudflare-prepare';
  const actual=await evaluate(async request=>{
    const response=await fetch('/api/player/prepare',{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify(request)});
    return {status:response.status,headers:Object.fromEntries(response.headers),raw:await response.text()};
  },{id:item.start,baseSha:binding.revision,choices:{}});
  // The original body is stored before parsing or dispatching it to the real
  // player. Large programs stay in RAM plus this gzip; no sliced payload exists.
  const rawGzip=gzipSync(actual.raw);
  await writeFile(resolve(output,'normal-http-program.json.gz'),rawGzip,{flag:'wx'});
  await save('normal-http-receipt.json',{status:actual.status,headers:actual.headers,rawResponseSha256:sha(actual.raw),
    rawResponseBytes:Buffer.byteLength(actual.raw),productionOrigin:binding.productionOrigin,programLoaded:false});
  assert.equal(actual.status,200,'Original cloudflare prepare failure retained; stop without auth change');
  assert.ok(rawGzip.length<=binding.budgets.programGzipBytes);
  prepared=JSON.parse(actual.raw);assert.equal(sha(JSON.stringify(prepared)),offline.programSha256);
  const baselineRaw=gunzipSync(await readFile(binding.productionBaseline.raw.path));
  assert.equal(sha(baselineRaw),binding.productionBaseline.rawBodySha256);
  const baseline=JSON.parse(baselineRaw);
  assert.deepEqual(Object.keys(prepared),Object.keys(baseline));assert.deepEqual(prepared,baseline);
  assert.deepEqual(prepared.scopeSceneIds,binding.scopeSceneIds);
  assert.equal(prepared.start,item.start);assert.equal(prepared.headSha,binding.revision);
  assert.equal(prepared.nodes.length,binding.programCounts.programNodes);
  assert.equal(prepared.edges.length,binding.programCounts.programEdges);assert.deepEqual(prepared.before,route.before);
  await evaluate(program=>window.postMessage({type:'stella-player-load',program},location.origin),prepared);
  stage='normal-5-ready';await ready(item.steps[0]);
  const cue={...plan.cue,beforeId:item.steps[0].id,targetId:item.steps[1].id,revision:binding.revision,
    maximumEvents:binding.budgets.mediaEvents,opus:plan.cue.resources['assets/preview/voices/vo_adv_julius/advk_julius_emilia.opus']};
  const installed=await driver.call('script.evaluate',{target,awaitPromise:true,resultOwnership:'root',
    expression:'('+installSavedVoiceObserver.toString()+')('+JSON.stringify(cue)+')'});
  if(installed.type!=='success'){
    diagnosticFailures.push({operation:'original-media-install',reply:installed});
    throw Error(installed.exceptionDetails?.text||'Original voice observer installation failed');
  }
  observerHandle=installed.result.handle;assert.ok(observerHandle);
  assert.equal((await media('result')).overflow,false);
  stage='trusted-51';await click('#advance');
  assert.equal(actions.at(-1).before.body.node,item.steps[0].id);assert.equal(actions.at(-1).before.body.phase,'ready');
  stage='normal-6-ready-and-natural-ended';
  const [targetReady,ended]=await Promise.all([ready(item.steps[1]),waitNaturalEnd()]);
  const complete=await media('snapshot'),observed=await media('result');
  assert.deepEqual(observed.failures,[]);assert.equal(observed.overflow,false);assert.equal(complete.sameOwnerAndAudio,true);
  assert.equal(complete.model,'julius01');assert.equal(complete.voice.cue,plan.cue.cue);
  assert.equal(complete.voice.member,plan.cue.member);assert.equal(complete.sourceIdentity,true);
  const descriptor=[plan.cue,plan.cue.previewDescriptor].find(row=>row.url===complete.voice.url);assert.ok(descriptor);
  for(const key of ['cue','label','member','url'])assert.equal(complete.voice[key],descriptor[key]);
  const tolerance=1/plan.cue.sampleRate+1e-6;
  assert.ok(Math.abs(complete.audio.duration-plan.cue.durationSeconds)<=tolerance);
  assert.ok(Math.abs(complete.audio.currentTime-complete.audio.duration)<=tolerance);
  assert.equal(complete.audio.ended,true);assert.equal(complete.audio.paused,true);assert.equal(complete.audio.loop,false);
  assert.equal(complete.audio.muted,false);assert.ok(complete.audio.volume>0);assert.ok(complete.audio.playbackRate>0);
  for(const kind of ['play','ended'])assert.equal(observed.events.filter(row=>row.kind===kind).length,1);
  assert.ok(observed.events.some(row=>row.kind==='playing'));
  assert.ok(observed.events.some(row=>row.kind==='loadedmetadata'&&row.voice?.cue===plan.cue.cue));
  assert.ok(observed.events.some(row=>row.kind==='timeupdate'&&row.audio.currentTime>0&&row.audio.currentTime<complete.audio.duration));
  assert.ok(observed.events.some(row=>row.kind==='pointerdown'&&row.trusted&&row.button==='advance'&&row.node===item.steps[0].id));
  sourceProof=await media('proveSource');
  // Actual network preparation can occur at5 through canonical lookahead.
  // Neither bank/prefetch request counts nor repeated playing imply replay.
  const directURL=observed.sourceURL;
  const assetRequests=http.filter(row=>row.url===directURL);
  assert.ok(assetRequests.some(row=>row.status===200&&row.mimeType==='audio/ogg'),'Actual default Opus HTTP200 absent');
  const bankRequests=http.filter(row=>new URL(row.url).pathname==='/api/voices/'+plan.cue.bank&&
    new URL(row.url).searchParams.get('revision')===binding.revision);
  assert.ok(bankRequests.some(row=>row.status===200),'Actual normal bank HTTP200 absent');
  stage='trusted-61';await click('#advance');
  assert.equal(actions.at(-1).before.body.node,item.steps[1].id);assert.equal(actions.at(-1).before.body.phase,'ready');
  assert.ok(actions.at(-1).before.epochMilliseconds>=ended.timeOrigin+ended.performanceMs);
  stage='normal-7-ready';await ready(item.steps[2]);
  noPending(await media('snapshot'),'next7');
  const enters=traces.filter(e=>e.startsWith('STORY_PLAYER_ENTER ')).map(e=>e.split(' ')[1]);
  const transitions=parsed('STORY_PLAYER_TRANSITION ');
  assert.deepEqual(enters,item.steps.map(step=>step.id));assert.equal(transitions.length,2);
  for(const [index,row]of transitions.entries()){
    assert.equal(row.edge,item.steps[index].edge.id);assert.equal(row.target,item.steps[index+1].id);
    assert.equal(row.action,'continue');assert.deepEqual(row.native,item.steps[index].edge.native);
  }
  assert.ok(!transitions.some(row=>row.edge===item.stop.forbiddenEdge));
  stage='normal-stop';await click('#stop');
  await waitFor(()=>document.body.dataset.phase==='stopped');
  noPending(await media('snapshot'),'normalStop');
  observerCleanup=await media('cleanup');
  assert.equal(observerCleanup.listenersRemoved,true);assert.equal(observerCleanup.listenerCount,17);
  assert.deepEqual(observerCleanup.errors,[]);assert.deepEqual(observerCleanup.failures,[]);assert.equal(observerCleanup.overflow,false);
  const finalEvents=observerCleanup.events,endedIndex=finalEvents.findIndex(row=>row.kind==='ended');
  for(const kind of ['play','ended'])assert.equal(finalEvents.filter(row=>row.kind===kind).length,1);
  assert.ok(!finalEvents.slice(endedIndex+1).some(row=>row.kind==='play'||row.kind==='playing'));
  assert.equal(traces.filter(line=>line.startsWith('STORY_VOICE_PLAY '+plan.cue.cue+' ')).length,1);
  const trusted=await evaluate(()=>window.reviewTrustedInputs);
  assert.ok(trusted.every(row=>row.trusted));
  assert.deepEqual(trusted.map(row=>row.button),['advance','advance','stop']);
  await driver.call('script.disown',{target,handles:[observerHandle]});observerHandle=null;
  await flushDiagnosticWrites();rejectFatalDiagnostics('completed voice before provider proof');
  const providers=(await readFile(resolve(output,'proxy-events.jsonl'),'utf8')).trim().split('\n').filter(Boolean).map(row=>JSON.parse(row));
  const opusRelative='assets/preview/voices/vo_adv_julius/advk_julius_emilia.opus';
  const opus=plan.cue.resources[opusRelative];
  const deliveries=providers.filter(row=>row.phase==='response-complete'&&row.method==='GET'&&row.url===directURL);
  assert.ok(deliveries.some(row=>row.status===200));
  assert.ok(deliveries.every(row=>row.status===200&&row.bodySha256===opus.sha256&&row.bodyBytes===opus.bytes&&row.bodyTransferred));
  for(const row of deliveries){
    // Rebuild the fixed production origin so the local :5198 port cannot
    // survive; the unchanged full-href assertion still checks path/query/host/port.
    const localURL=new URL(directURL),wanted=new URL(localURL.pathname+localURL.search,binding.productionOrigin);
    assert.equal(row.upstreamURL,wanted.href);assert.equal(row.forwardedRequestHeaders['accept-encoding'],'identity');
    assert.equal(row.forwardedResponseHeaders['content-encoding'],undefined);
    assert.equal(row.forwardedResponseHeaders['content-length'],String(opus.bytes));
  }
  const descriptorPath=descriptor===plan.cue?'assets/voices/vo_adv_julius/index.json':'assets/preview/voices/vo_adv_julius/index.json';
  const metadata=plan.cue.resources[descriptorPath];
  assert.ok(providers.some(row=>row.method==='GET'&&new URL(row.url).pathname==='/api/voices/'+plan.cue.bank&&
    new URL(row.url).searchParams.get('revision')===binding.revision&&row.status===200&&
    row.bodySha256===metadata.sha256&&row.bodyBytes===metadata.bytes));
  assert.ok(!providers.some(row=>row.error),'Original production forwarding error retained');
  const providerProof=await saveGzip('provider-proof.json.gz',{deliveries,descriptorPath,providers,sourceProof,
    bankRequests,assetRequests,wholeProgramBeforeExact:true,productionOrigin:binding.productionOrigin,
    actualDefaultOpusBytesVerified:true,originalWavNotSubstituted:true});
  const prep=parsed('STORY_VOICE_PREPARATION ').filter(row=>row.node===item.steps[1].id);
  for(const name of ['started','ready','joined'])assert.equal(prep.filter(row=>row.stage===name).length,1);
  pendingResult={caseId:item.id,revision:binding.revision,sourceHead:binding.source.head,productionOrigin:binding.productionOrigin,
    completeProgramSha256:offline.programSha256,before:prepared.before,played,enters,transitions,actions,trusted,
    targetReady,ended,complete,observerCleanup,sourceProof,providerProof,voicePreparation:prep,
    durationEvidence:{originalWavSeconds:plan.cue.durationSeconds,knownFullDecodedOpus:plan.cue.knownDecodedOpus,
      browserObservedSeconds:complete.audio.duration,existingSampleToleranceSeconds:tolerance,
      browserMinusOriginalWavSeconds:complete.audio.duration-plan.cue.durationSeconds,
      browserMinusKnownOpusSeconds:complete.audio.duration-plan.cue.knownDecodedOpus.durationSeconds,
      mediaDurationOrSamplesChangedByHelper:false},
    prefetch:traces.filter(row=>row.startsWith('STORY_VOICE_PREFETCH_')),capabilities,
    rawConsole,fatalFacts,hitches,cancellations,diagnosticFailures,errors,http,diagnosticDroppedRows:0,
    scope:plan.acceptanceScope,requiresTerminalAcceptanceReceipt:true};
}catch(error){
  retainFirstFailure(error,'ordinary saved voice');await retainFailureEvidence('failure.json');
}finally{
  // Normal Stop and listener/handle cleanup are independent best-effort
  // operations on the same observed document, including partial installation.
  if(observerHandle){
    try{await click('#stop',true);assert.equal(await evaluate(()=>document.body.dataset.phase),'stopped');}
    catch(error){retainFirstFailure(error,'failure Stop');}
    try{observerCleanup=await media('cleanup');}
    catch(error){retainFirstFailure(error,'media cleanup');}
    try{await driver.call('script.disown',{target,handles:[observerHandle]});observerHandle=null;}
    catch(error){retainFirstFailure(error,'media handle disposal');}
  }
  // Late product or asynchronous append failures reject before retirement and
  // before any next case. Preserve the first failure while the actual
  // document still exists; diagnostic failures never replace that first cause.
  try{
    await flushDiagnosticWrites();rejectFatalDiagnostics('before session retirement');
    if(pendingResult){
      const finalRender=await evaluate(()=>window.reviewRenderProbe.snapshot());
      assert.equal(finalRender.losses.filter(e=>e.canvas==='actor'||e.attached).length,0);
      pendingResult.finalRenderHistory=finalRender;
    }
  }
  catch(error){retainFirstFailure(error,'pre-retirement flush');}
  if(firstFailure)await retainFailureEvidence('pre-retirement-failure.json');
  try{await driver.call('session.end');sessionRetired=true;}
  catch(error){retainFirstFailure(error,'session.end');}
  finally{try{driver.close();}catch(error){retainFirstFailure(error,'driver.close');}}
}
try{
  // After the acknowledged BiDi session end, drain its retained original
  // events/append facts and recheck after every output await. The browser OS
  // process still belongs to supervisor cleanup; session.end is not its exit
  // proof. A result file alone is never terminal acceptance or an exit0 promise.
  await flushDiagnosticWrites();rejectFatalDiagnostics('after session retirement');
  if(firstFailure)throw Error('An earlier failure is retained');
  assert.equal(sessionRetired,true);assert.ok(pendingResult);
  const resultArchive=await saveGzip('result.json.gz',pendingResult);
  await flushDiagnosticWrites();rejectFatalDiagnostics('after final result write');
  await save('terminal-acceptance.json',{accepted:true,sessionRetired,diagnosticWritesFlushed:true,
    fatalFacts,hitches,cancellations,diagnosticFailures,rawConsoleCount:rawConsole.length,
    cases:1,entered:3,captures:0,resultArchive,defaultOpusVerified:true,requiresRootIndependentOsClosure:true});
  await flushDiagnosticWrites();rejectFatalDiagnostics('after terminal receipt write');
  console.log(JSON.stringify({cases:1,entered:3,captures:0,totalCaptureBytes,errors,terminalAccepted:true}));
}catch(error){
  retainFirstFailure(error,'terminal diagnostics');await retainFailureEvidence('terminal-failure.json');
  process.exitCode=1;
  console.error(JSON.stringify({firstFailure,played:played.length,captures:captures.length,
    fatalFacts:fatalFacts.length,diagnosticFailures:diagnosticFailures.length}));
}
