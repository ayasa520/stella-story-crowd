# Second preserved manifest failure

The saved raw and saved actual exception.doc differ only at UTF-8 byte range
**[884329,884336)** (zero-based, end-exclusive). Raw contains
`20 20 20 20 20 22 63` (five spaces, quote, c); exception.doc contains seven
`00` bytes. All bytes before and after are identical. The first difference is
Python character868156, line30138 column8, matching the preserved original
`Expecting value` failure on the command-list entry.

Both buffers have4478914 bytes and match their recorded SHA-256 values.
Read-only Git show of commit4f865d44cf83971c42a749c174ad72d9e06df4d5:manifest.json
is byte-for-byte equal to saved raw. The current worktree manifest was not read.
Both gzip CRC/ISIZE checks pass. The original Python verifier remains
**failed/unknown**; this comparison does not reclassify it or identify a cause.
No buffers, parser, D/C, Git state or old evidence were changed.
