"""Compile and compare the voice specialization without executing its CLI.

Only the documented resource block, voice-only CLI option and truthful scope
labels are excluded from exact AST equality. All row guards, historic metadata
rules, raw-input logging and complete stage/review inverse checks stay covered.
This verifier never imports either helper or calls a restoration operation.
"""

import ast
from copy import deepcopy
import difflib
import gzip
import hashlib
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
A = OUT.parent
OLD = A / 'review-explicit-visual-field-batch-v4.py'
NEW = OUT / 'review-explicit-voice-field-batch-v1.py'
old_raw, new_raw = OLD.read_bytes(), NEW.read_bytes()
old_sha = hashlib.sha256(old_raw).hexdigest()
assert old_sha == 'be1f0dd0c2bd1005e9f652c21d91392c261d61b2853aad1612096053e3dcff7a'
old_source, new_source = old_raw.decode(), new_raw.decode()
compile(old_source, str(OLD), 'exec')
compile(new_source, str(NEW), 'exec')
old_tree, new_tree = ast.parse(old_source), ast.parse(new_source)


def dumped(node):
    return ast.dump(node, include_attributes=False)


old_functions = {node.name: node for node in old_tree.body if isinstance(node, ast.FunctionDef)}
new_functions = {node.name: node for node in new_tree.body if isinstance(node, ast.FunctionDef)}
assert old_functions.keys() == new_functions.keys()
unchanged = []
for name in old_functions:
    if name not in {'prepare', 'review_stage'}:
        assert dumped(old_functions[name]) == dumped(new_functions[name]), name
        unchanged.append(name)


def collapsed_resource(function):
    function = deepcopy(function)
    loop = [node for node in function.body if isinstance(node, ast.For)
        and isinstance(node.target, ast.Name) and node.target.id == 'c'
        and isinstance(node.iter, ast.Name) and node.iter.id == 'changes']
    assert len(loop) == 1
    body = loop[0].body
    begin = [i for i, node in enumerate(body) if isinstance(node, ast.Assign)
        and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == 'token']
    end = [i for i, node in enumerate(body) if isinstance(node, ast.Expr)
        and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
        and isinstance(node.value.func.value, ast.Name)
        and node.value.func.value.id == 'c' and node.value.func.attr == 'update']
    assert len(begin) == len(end) == 1 and begin[0] < end[0]
    resource = body[begin[0]:end[0]]
    loop[0].body = body[:begin[0]] + [ast.Pass()] + body[end[0]:]
    return function, resource


class NormalizePermittedLabels(ast.NodeTransformer):
    def visit_Constant(self, node):
        if node.value == 'Static explicit resource identity only; complete entry, acting, phase and gameplay remain unaccepted.':
            node.value = 'Explicit short original voice resource identity and recording-panel attribution only; subjective listening, original command phases and saved gameplay remain unaccepted.'
        return node

    def visit_keyword(self, node):
        if node.arg == 'voicesTextMotionBranchesOrderPreserved':
            node.arg = 'onlySelectedVoiceLeavesOtherFieldsPreserved'
        return self.generic_visit(node)


old_prepare, old_resource = collapsed_resource(old_functions['prepare'])
new_prepare, new_resource = collapsed_resource(new_functions['prepare'])
assert len(old_resource) == 4 and len(new_resource) == 8
normalizer = NormalizePermittedLabels()
assert dumped(normalizer.visit(old_prepare)) == dumped(new_prepare)
assert dumped(normalizer.visit(deepcopy(old_functions['review_stage']))) == dumped(new_functions['review_stage'])


def module_remainder(tree):
    result = []
    for number, node in enumerate(tree.body):
        if number == 0 and isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
            continue
        if isinstance(node, ast.FunctionDef):
            continue
        if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                and node.value.args and isinstance(node.value.args[0], ast.Constant)
                and node.value.args[0].value == '--field'):
            options = {keyword.arg: keyword.value for keyword in node.value.keywords}
            expected = ['character', 'character_image'] if tree is old_tree else ['voice']
            assert ast.literal_eval(options['choices']) == expected
            assert ast.literal_eval(options['required']) is True
            continue
        result.append(node)
    return dumped(ast.Module(body=result, type_ignores=[]))


assert module_remainder(old_tree) == module_remainder(new_tree)
diff = ''.join(difflib.unified_diff(old_source.splitlines(keepends=True),
    new_source.splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name))
(OUT / 'source.diff').write_text(diff)
(OUT / 'original-v4-source.py.gz').write_bytes(gzip.compress(old_raw, mtime=0))
proof = dict(rootConfirmed=False, compileOnly=True, helperImportedOrExecuted=False,
    unchangedFunctionASTs=unchanged,
    fullPrepareASTExactExceptResourceIdentityAndScopeLabel=True,
    fullReviewStageASTExactExceptTruthfulVoicePreservationLabel=True,
    remainingModuleASTExactExceptHeaderAndVoiceOnlyFieldOption=True,
    exact13FieldsGlobal285Protected22AndCodePinsPreserved=True,
    recursiveSourceHashGuardsAndTargetOnlyHistoricalRebindingPreserved=True,
    heldRawJSONAndOriginalFailureLoggingASTExact=True,
    completeNativeAndReviewSidecarInverseASTExact=True,
    oldResourceStatements=[ast.unparse(node) for node in old_resource],
    newResourceStatements=[ast.unparse(node) for node in new_resource],
    cliFieldChoices=['voice'],
    legacyCountAndGuardDictionaryKeysRetainedForCompatibility=True,
    formalOrSourceEvidenceInputsReadByHelper=False,
    old=dict(path=str(OLD), bytes=len(old_raw), sha256=old_sha),
    new=dict(path=str(NEW), bytes=len(new_raw), sha256=hashlib.sha256(new_raw).hexdigest()),
    diffSHA256=hashlib.sha256(diff.encode()).hexdigest())
(OUT / 'ast-invariants.rootfalse.json').write_text(json.dumps(proof, indent=2)+'\n')
assert OLD.read_bytes() == old_raw
print(json.dumps(proof))
