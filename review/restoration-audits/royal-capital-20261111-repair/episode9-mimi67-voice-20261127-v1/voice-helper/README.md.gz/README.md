# Voice-only specialization of the unchanged V4 reviewer

`review-explicit-voice-field-batch-v1.py` is source-only preparation. It has not
been imported or executed. Root must approve its exact bytes before invoking
prepare/review separately from the original repair/install CLIs.

The narrow specialization permits only `--field voice`. A voice value must
contain one nonempty bank and cue separated by one comma. The complete current
`catalog.voices[bank]` must equal that bank in the explicitly stated historical
catalog. Exactly one entry in its `cues` list must match `entry.cue`, and its
local payload URL must exist. The selected field, full row, 13 expected values,
source payload hashes and normal saved-state constraints remain separate guards.
No original cue is imported or rewritten by this helper.

The scope label explicitly keeps subjective listening, original phases and
saved gameplay unaccepted. The stage label is now
`onlySelectedVoiceLeavesOtherFieldsPreserved`; it does not falsely say that all
voices are unchanged. Existing count and guard dictionary keys are retained for
the saved-field verifier's compatibility, including the legacy `exactVisual...`
names; their `field` is constrained to `voice` and the count remains one here.

`source.diff` is the exact original/new source difference.
`verify_ast_invariants.py` compiled both programs without executing either.
It proves exact AST equality for seven unchanged functions, prepare outside the
resource block and scope label, the complete native/review inverse outside its
truthful metadata label, and the rest of the module outside the header/CLI
choice. JSON held-byte/failure logging, all 285 global guards, 22 protected
files, source pins, recursive reference handling and target-only historical
metadata rebinding are unchanged. No V5 role-policy behavior is added.

The old V4 source remains byte exact. Its lossless snapshot is retained as
`original-v4-source.py.gz`. Root's eventual historical-bank comparison and
current HEAD/clean-status checks have not been executed in this preparation.
