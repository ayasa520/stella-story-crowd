"""Compare the voice specialization without importing either helper.

The exact-byte reconstruction below admits only documented voice-resource and
scope/CLI-label changes. It creates no fixtures and invokes no restoration,
Git, network, audio, image, or browser operation.
"""
import ast
from copy import deepcopy
import difflib
import gzip
import hashlib
import json
from pathlib import Path

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
OUT = Path(__file__).parent
OLD = A / 'review-explicit-visual-field-batch-v4.py'
PACKAGE = A / 'mimi67-voice-only-helper-rootfalse-20261127-v1'
NEW = PACKAGE / 'review-explicit-voice-field-batch-v1.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


old_raw, new_raw = OLD.read_bytes(), NEW.read_bytes()
assert sha(old_raw) == 'be1f0dd0c2bd1005e9f652c21d91392c261d61b2853aad1612096053e3dcff7a'
assert sha(new_raw) == 'e67d2cf9a51f227a1e557391c83eda220744d7a68cf8e76ce6f9c62638c20350'
compile(old_raw, str(OLD), 'exec')
compile(new_raw, str(NEW), 'exec')
old_source, new_source = old_raw.decode(), new_raw.decode()
expected = old_source
replacements = [
    ('Prepare one explicit character or CG packet or review its normal stage.',
     'Prepare one explicit original voice packet or review its normal stage.'),
    ('images and original resources must still match their sealed bytes exactly.',
     'recordings, audio and original resources must match their sealed bytes exactly.'),
    ('''        # A scalar CG is an explicit picture resource, not a Live2D actor.
        # Validate its own catalog contract and payload rather than inferring
        # model inheritance or reusing the character detail-url requirement.
        token = c['fields'][field]
        section, url_key = ('models', 'detail_url') if field == 'character' else ('pictures', 'url')
        assert catalog[section][token] == old_catalog[section][token]
        assert (D / 'assets' / catalog[section][token][url_key]).is_file()
''', '''        # Voice tokens identify one cue inside an original voice-bank block.
        # Compare the entire bank with the stated ancestor, require one exact
        # cue match, and validate its own payload URL. Actor/CG lookups cannot
        # establish a voice identity, and duplicate cue entries must fail.
        token = c['fields'][field]
        bank_name, separator, cue_name = token.partition(',')
        assert separator == ',' and bank_name and cue_name and ',' not in cue_name
        voice_block = catalog['voices'][bank_name]
        assert voice_block == old_catalog['voices'][bank_name]
        cue_matches = [entry for entry in voice_block['cues'] if entry['cue'] == cue_name]
        assert len(cue_matches) == 1
        assert (D / 'assets' / cue_matches[0]['url']).is_file()
'''),
    ('Static explicit resource identity only; complete entry, acting, phase and gameplay remain unaccepted.',
     'Explicit short original voice resource identity and recording-panel attribution only; subjective listening, original command phases and saved gameplay remain unaccepted.'),
    ('voicesTextMotionBranchesOrderPreserved=True', 'onlySelectedVoiceLeavesOtherFieldsPreserved=True'),
    ("parser.add_argument('--field', choices=['character', 'character_image'], required=True)",
     "parser.add_argument('--field', choices=['voice'], required=True)"),
]
for before, after in replacements:
    assert expected.count(before) == 1, before
    expected = expected.replace(before, after)
assert expected.encode() == new_raw
assert gzip.decompress((PACKAGE / 'original-v4-source.py.gz').read_bytes()) == old_raw
actual_diff = ''.join(difflib.unified_diff(old_source.splitlines(True), new_source.splitlines(True),
    fromfile=OLD.name, tofile=NEW.name))
assert actual_diff.encode() == (PACKAGE / 'source.diff').read_bytes()

old_tree, new_tree = ast.parse(old_raw), ast.parse(new_raw)
old_defs = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
new_defs = {n.name: n for n in new_tree.body if isinstance(n, ast.FunctionDef)}
unchanged = {}
for name in ['sha', 'encode', 'load', 'git', 'assert_current', 'write_new', 'verify_guards']:
    unchanged[name] = ast.dump(old_defs[name], include_attributes=False) == ast.dump(new_defs[name], include_attributes=False)
assert all(unchanged.values())
old_walk = next(n for n in old_defs['prepare'].body if isinstance(n, ast.While))
new_walk = next(n for n in new_defs['prepare'].body if isinstance(n, ast.While))
assert ast.dump(old_walk, include_attributes=False) == ast.dump(new_walk, include_attributes=False)
for name in ['FIELDS', 'rebindable_data']:
    values = []
    for tree in [old_tree, new_tree]:
        values.append(next(n.value for n in ast.walk(tree) if isinstance(n, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == name for target in n.targets)))
    assert ast.dump(values[0], include_attributes=False) == ast.dump(values[1], include_attributes=False)
    if name == 'FIELDS':
        assert len(ast.literal_eval(values[1])) == 13

class VoiceReviewLabel(ast.NodeTransformer):
    def visit_keyword(self, node):
        if node.arg == 'voicesTextMotionBranchesOrderPreserved':
            node.arg = 'onlySelectedVoiceLeavesOtherFieldsPreserved'
        return self.generic_visit(node)

assert ast.dump(VoiceReviewLabel().visit(deepcopy(old_defs['review_stage'])), include_attributes=False) == ast.dump(new_defs['review_stage'], include_attributes=False)
seal = json.loads((PACKAGE / 'receipt.rootfalse.json').read_bytes())
for row in seal['files']:
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
assert OLD.read_bytes() == old_raw and NEW.read_bytes() == new_raw
report = dict(schema='stella.voice-helper.independent-static-checks.v1',
    reviewer='/root/visual_ref_peer', compileOnly=True, helperImportedOrExecuted=False,
    newSourceSHA256=sha(new_raw), originalV4SHA256=sha(old_raw),
    exactWholeFileReconstructionWithOnlySixDocumentedChanges=True,
    unchangedFunctionASTs=unchanged, completeSourceRecursionWhileASTUnchanged=True,
    thirteenExpectedFieldsAndHistoricalDataAllowlistUnchanged=True,
    completeReviewASTUnchangedExceptTruthfulVoicePreservationLabel=True,
    originalSourceArchiveAndDeclaredDiffByteExact=True, allSixAuthorPayloadsExact=True,
    fieldCLIAllowlist=['voice'], allNormalGateCodePins285Guards22ProtectedUnchanged=True,
    requiredResourceChecks=['exactly one bank,cue token', 'whole current bank equals supplied historical ancestor bank',
        'exactly one matching cue', 'matching cue URL points to an existing asset file'],
    actualCatalogGitHistoryOrPayloadExistenceQueried=False, sourceEvidenceAcceptanceClaimed=False,
    rootMustBindEvidenceBaseToE2AtActualPreparation=True, mustFix=[])
path = OUT / 'checks.rootfalse.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='SOURCE_ONLY_PASS', checks=str(path), sha256=sha(path.read_bytes()))))
