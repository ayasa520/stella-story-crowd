"""Compare preserved gzip buffers and one immutable Git blob, without repair.

The worktree manifest is never opened. Source gzip files are CRC/ISIZE checked,
hashed before/after, and decompressed into bounded byte buffers. Node receives
each exact buffer on stdin in a fresh process. Git show supplies only the
immutable requested commit's blob. Successful later parses are independent
observations and do not replace or reclassify the recorded original failure.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import struct
import subprocess
import sys
import unicodedata
import zlib

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'artifacts/stella-script-continuation-20261121/episode9-mimi67-voice-stage-review-inputs-eeb08601-20261127-v1'
META = SOURCE / '008.json'
RAW_GZ = SOURCE / '008.raw.gz'
DOC_GZ = SOURCE / '008.exception-doc.gz'
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
EXPECTED_SIZE = 4479414
EXPECTED_RAW = '81f075f53a1b4483046e29225ce8473c0a1c3f0a1914229dc33a1849320f7dd8'
EXPECTED_DOC = '8cf38e43008d9087f6cf204413c7d6ce41f2288c79c72e8a3b6e5664b20a2f51'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def witness(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
def emit(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.write('\n')
before = [witness(path) for path in (META, RAW_GZ, DOC_GZ)]
record = json.loads(META.read_bytes())
assert (record['bytes'], record['sha256'], record['exceptionDocSHA256']) == (EXPECTED_SIZE, EXPECTED_RAW, EXPECTED_DOC)
assert (record['position'], record['line'], record['column']) == (1593148, 54505, 28)

def decompress_checked(path, expected_hash):
    compressed = path.read_bytes()
    assert compressed[:3] == b'\x1f\x8b\x08'
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    data = decoder.decompress(compressed, EXPECTED_SIZE + 1)
    assert not decoder.unconsumed_tail and decoder.eof and not decoder.unused_data
    data += decoder.flush()
    footer_crc, footer_size = struct.unpack('<II', compressed[-8:])
    actual_crc = zlib.crc32(data) & 0xffffffff
    assert len(data) == EXPECTED_SIZE == footer_size
    assert actual_crc == footer_crc
    assert digest(data) == expected_hash
    return data, {'compressed': witness(path), 'singleGzipMember': True,
        'gzipCRCValidatedByDecoder': True, 'footerCRC32': hex(footer_crc),
        'computedCRC32': hex(actual_crc), 'footerISIZE': footer_size,
        'decompressedBytes': len(data), 'decompressedSHA256': digest(data)}
raw, raw_gzip = decompress_checked(RAW_GZ, EXPECTED_RAW)
doc, doc_gzip = decompress_checked(DOC_GZ, EXPECTED_DOC)
raw_text, doc_text = raw.decode('utf8', errors='strict'), doc.decode('utf8', errors='strict')
positions = [i for i, (left, right) in enumerate(zip(raw, doc)) if left != right]
assert len(raw) == len(doc)
ranges = []
for position in positions:
    if ranges and ranges[-1][1] == position:
        ranges[-1][1] += 1
    else:
        ranges.append([position, position + 1])
assert ranges == [[1609747, 1609752]]
start, stop = ranges[0]
assert raw[start:stop] == b'rder"' and doc[start:stop] == b'\0' * 5
assert raw[:start] == doc[:start] and raw[stop:] == doc[stop:]

# JSONDecodeError.pos uses Python Unicode code points, whereas Node reports
# UTF-16 units. Map both explicitly to the exact UTF-8 byte span; no offset is
# silently treated as a byte index and no malformed buffer is normalized.
position = record['position']
byte_offset = len(doc_text[:position].encode('utf8'))
utf16_offset = len(doc_text[:position].encode('utf-16-le')) // 2
line_start = doc_text.rfind('\n', 0, position) + 1
line_stop = doc_text.find('\n', position)
line = doc_text.count('\n', 0, position) + 1
column = position - line_start + 1
assert (byte_offset, line, column) == (start, record['line'], record['column'])
codepoints = []
for offset in range(5):
    a, b = raw_text[position + offset], doc_text[position + offset]
    codepoints.append({'pythonCharacterOffset0': position + offset,
        'raw': {'escaped': repr(a), 'codepoint': f'U+{ord(a):04X}', 'name': unicodedata.name(a, 'CONTROL')},
        'exceptionDoc': {'escaped': repr(b), 'codepoint': f'U+{ord(b):04X}', 'name': 'NULL' if b == '\0' else unicodedata.name(b, 'CONTROL')}})
diff = {'byteLengthEqual': True, 'differingByteCount': len(positions), 'allRanges0BasedEndExclusive': ranges,
    'rangeHex': {'raw': raw[start:stop].hex(' '), 'exceptionDoc': doc[start:stop].hex(' ')},
    'equalBeforeRange': True, 'equalAfterRange': True,
    'recordedPythonFailure': record,
    'offsetMapping': {'pythonCodepointOffset0': position, 'UTF8ByteOffset0': byte_offset,
        'UTF16CodeUnitOffset0': utf16_offset, 'line1': line, 'column1': column,
        'differingPythonCodepointRange0EndExclusive': [position, position + 5]},
    'rawLine': raw_text[line_start:line_stop], 'exceptionDocLine': doc_text[line_start:line_stop],
    'rawContext': raw_text[position - 48:position + 53],
    'exceptionDocContext': doc_text[position - 48:position + 53],
    'contextRawBytesHex': raw[start - 32:stop + 32].hex(' '),
    'contextExceptionDocBytesHex': doc[start - 32:stop + 32].hex(' '),
    'changedCodepoints': codepoints,
    'rawStrictUTF8DecodedCodepoints': len(raw_text), 'docStrictUTF8DecodedCodepoints': len(doc_text)}
emit('buffer-difference.json', diff)

node_results = []
for label, data in [('saved-raw-input', raw), ('saved-exception-doc', doc)]:
    argv = ['/usr/bin/node', '--max-old-space-size=128', str(OUT / 'json-parse-probe.mjs')]
    began = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv, input=data, capture_output=True, timeout=20)
    with (OUT / (label + '.node.stdout.json')).open('xb') as stream:
        stream.write(process.stdout)
    with (OUT / (label + '.node.stderr.log')).open('xb') as stream:
        stream.write(process.stderr)
    assert process.returncode == 0 and not process.stderr
    result = json.loads(process.stdout)
    assert result['inputSHA256Before'] == result['inputSHA256After'] == result['decodedTextUTF8SHA256'] == digest(data)
    assert result['inputBytes'] == len(data) and result['nice'] >= 19
    node_results.append({'label': label, 'argv': argv, 'startedUTC': began,
        'exitCode': process.returncode, 'stderrBytes': len(process.stderr),
        'stdoutSHA256': digest(process.stdout), 'result': result})
emit('node-independent-execution.json', node_results)

# The captured metadata path determines the repository directory only. Never
# open that worktree manifest as an alleged copy of the failed input.
repository = Path(record['path']).parent
relative_blob_path = 'manifest.json'
git_runs = []
def git_read(arguments):
    argv = ['/usr/bin/git', '-C', str(repository), '--no-pager', *arguments]
    process = subprocess.run(argv, capture_output=True, timeout=20)
    git_runs.append({'argv': argv, 'exitCode': process.returncode,
                     'stdoutBytes': len(process.stdout), 'stdoutSHA256': digest(process.stdout),
                     'stderr': process.stderr.decode('utf8', errors='replace')})
    assert process.returncode == 0 and not process.stderr
    return process.stdout
commit = git_read(['rev-parse', '--verify', 'eeb08601^{commit}']).decode().strip()
assert commit.startswith('eeb08601')
blob_oid = git_read(['rev-parse', '--verify', commit + ':' + relative_blob_path]).decode().strip()
blob = git_read(['show', '--no-ext-diff', '--no-textconv', commit + ':' + relative_blob_path])
object_header = b'blob ' + str(len(blob)).encode('ascii') + b'\0'
hash_algorithm = 'sha1' if len(blob_oid) == 40 else 'sha256'
assert hashlib.new(hash_algorithm, object_header + blob).hexdigest() == blob_oid
git_result = {'repository': str(repository), 'requestedCommit': 'eeb08601', 'fullCommit': commit,
    'blobPath': relative_blob_path, 'blobOID': blob_oid, 'GitObjectHashVerified': True,
    'blobBytes': len(blob), 'blobSHA256': digest(blob), 'blobEqualsSavedRawByteForByte': blob == raw,
    'blobEqualsSavedExceptionDocByteForByte': blob == doc,
    'blobVsExceptionDocDifferingByteCount': sum(x != y for x, y in zip(blob, doc)) if len(blob) == len(doc) else None,
    'worktreeManifestOpened': False, 'worktreeManifestUsedAsOriginalInput': False, 'readOnlyGitRuns': git_runs}
emit('immutable-git-blob-comparison.json', git_result)
after = [witness(path) for path in (META, RAW_GZ, DOC_GZ)]
assert before == after
summary = {'schema': 'stella.saved-manifest-buffer-diagnostic.rootfalse.v1', 'rootConfirmed': False,
    'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'originalFailurePreserved': True, 'originalFailureOverriddenByLaterParse': False,
    'originalHelperRerun': False, 'parserModifiedOrReplaced': False,
    'worktreeManifestRead': False, 'DCOrGitWritesPerformed': False,
    'browserNetworkOrGlobalChanges': False, 'nice': os.getpriority(os.PRIO_PROCESS, 0),
    'cpuAffinity': sorted(os.sched_getaffinity(0)), 'pythonVersion': sys.version,
    'gzipVerification': {'raw': raw_gzip, 'exceptionDoc': doc_gzip},
    'bufferDifference': diff,
    'independentNodeSummary': [{'label': n['label'], **n['result']} for n in node_results],
    'immutableGitBlob': {key: value for key, value in git_result.items() if key != 'readOnlyGitRuns'},
    'cause': 'Unknown. These artifacts prove a five-byte divergence between the two saved buffers, not the operation, moment or mechanism that produced it.',
    'allSourceArtifactsBefore': before, 'allSourceArtifactsAfter': after, 'allSourceArtifactsUnchanged': True}
emit('report.rootfalse.json', summary)
print(json.dumps({'differenceRangeBytes0': ranges, 'differingByteCount': len(positions),
    'rawSHA256': digest(raw), 'exceptionDocSHA256': digest(doc),
    'nodeParseOk': [n['result']['parseOk'] for n in node_results],
    'gitBlobEqualsRaw': blob == raw, 'fullCommit': commit, 'blobOID': blob_oid,
    'allSourceArtifactsUnchanged': True}, indent=2))
