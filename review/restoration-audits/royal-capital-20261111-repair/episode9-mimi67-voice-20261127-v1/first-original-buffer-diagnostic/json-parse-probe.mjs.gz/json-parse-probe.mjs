// Parse only the exact bytes supplied on stdin. This independent Node probe
// does not open the repository manifest or alter Python's parser/helper.
import fs from 'node:fs';
import crypto from 'node:crypto';
import os from 'node:os';

const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const bytes = fs.readFileSync(0);
const text = bytes.toString('utf8');
const result = {
  nodeVersion: process.version,
  architecture: process.arch,
  nice: os.getPriority(0),
  inputBytes: bytes.length,
  inputSHA256Before: digest(bytes),
  decodedTextUTF8SHA256: digest(Buffer.from(text, 'utf8')),
  decodedTextUTF16CodeUnits: text.length,
};
try {
  const value = JSON.parse(text);
  result.parseOk = true;
  result.rootType = Array.isArray(value) ? 'array' : value === null ? 'null' : typeof value;
  result.rootKeyCount = value && typeof value === 'object' ? Object.keys(value).length : null;
} catch (error) {
  result.parseOk = false;
  result.errorName = error.name;
  result.errorMessage = error.message;
}
result.inputSHA256After = digest(bytes);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
