# Preserved manifest buffers: exact difference

The two saved buffers are different. Exactly **five consecutive bytes** differ;
all bytes before and after that range are identical. The original Python
failure remains a failed observation and has not been replaced by a later
successful parse. The mechanism that produced the divergence remains unknown.

| Measurement | Saved raw input | Saved exception.doc UTF-8 |
|---|---|---|
| Decompressed bytes | 4,479,414 | 4,479,414 |
| SHA-256 | 81f075f53a1b4483046e29225ce8473c0a1c3f0a1914229dc33a1849320f7dd8 | 8cf38e43008d9087f6cf204413c7d6ce41f2288c79c72e8a3b6e5664b20a2f51 |
| Gzip CRC32 | 0x29663fc4, valid | 0x55105aa9, valid |
| Gzip ISIZE | 4,479,414, valid | 4,479,414, valid |
| Independent Node JSON.parse | success | SyntaxError at position1593148, line54505, column28 |

Both gzip streams are single members. Their decoder CRC checks, independently
recomputed CRC32, footer ISIZE and complete decompressed SHA-256 all agree.
Compressed-file hashes and fresh before/after hashes are retained in the report.

The exact differing UTF-8 byte range is **[1609747,1609752)**, zero-based and
end-exclusive:

```text
raw hex:           72 64 65 72 22     (r d e r ")
exception.doc hex: 00 00 00 00 00
```

The complete affected line is:

```text
raw:           "native_array_order",
exception.doc: "native_array_o\u0000\u0000\u0000\u0000\u0000,
```

The original line has twelve leading spaces, preserved in `buffer-difference.json`.
The five changed code points occupy Python character offsets
**[1593148,1593153)**, line54505 columns28–32. The first is U+0072 in raw and
U+0000 NULL in exception.doc. Python character offset1593148 maps to UTF-8
byte1609747 and UTF-16 code-unit offset1593148. Thus Node and the original
Python record identify the same first invalid NULL; byte and character offsets
have not been conflated.

Two separate Node v26.13.0 arm64 processes parsed the exact decompressed buffers
through stdin. Each reports the expected input SHA-256 before and after parsing,
and its decoded text re-encoded as UTF-8 has that same SHA-256. Raw succeeds as
an object with ten root keys. Exception.doc fails with:

```text
Bad control character in string literal in JSON at position 1593148 (line 54505 column 28)
```

Only immutable, read-only Git commands were used for the repository comparison:

- Commit: `eeb08601e639ff85838d7fc07e4aa7e0b79e9d9e`
- Blob path: `manifest.json`
- Blob OID: `13590c2d4ecd87f949f3f1ff5318e1703ae95027`

The complete `git show` blob is **byte-for-byte identical to saved raw** and has
SHA-256 `81f075f5…`; its Git object hash was independently verified. It differs
from saved exception.doc only at the same five bytes. The current D worktree
manifest was never opened or substituted for the failed input.

This packet proves the saved-buffer discrepancy and the independent parse
outcomes. It does not identify an operation, time or mechanism responsible for
the five NULLs. The original helper was not rerun; no parser was changed,
replaced or repaired. No D/C/Git writes, browser, network, API, ELF work or global
changes occurred. All processing used nice19/CPU0,1. The three source artifacts
remain byte-for-byte unchanged. No full decompressed input was copied into this
packet; the original gzip artifacts remain the complete evidence.
