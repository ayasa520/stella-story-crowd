# Mimi 67 single-voice normal candidate, awaiting root

The candidate changes only scene10040043 / scenario67 / UID1004004300067 /
stableKey `s10040043-p31-at0628`, from empty voice to
`vo_adv_subaru,advk_subaru_akireru`.

The actual current D native/review files were read once and retained before
parsing. All 13 expected fields and the complete ordered native row are bound,
including the now-installed `live2d/AC_subaru01` character. Native branches,
text, IDs and commands remain identical. The complete document undoes to its
held baseline by reverting only this one voice leaf. The source/resource bank
has one exact matching cue among 119 entries; its shipped WAV is byte exact to
the original identified cue (`dc9194e8...`). No asset import is required.

The independent signed-DSP and full-panel reviews support the original cue's
identity and attribution to node67. Their accepted JSON bytes are preserved as
lossless gzip snapshots. The canonical absolute leaf closure separately binds
all 314 source frames, nine sheets, source PCM, templates and original audio
payloads. This avoids treating the child panel report's source-root-relative
paths as if they were relative to its subdirectory. No report, source pixel,
audio value or V4 recursive-resolution policy was changed. The prior source
capture and eight-cue DSP search were not repeated.

All new root flags remain false; baseSha and expectedHead remain null.
`deb3093e...` is the parent's HEAD hint, not an independent Git/clean-status
claim. Root must freshly bind HEAD/ownership/manifest/global guards and run the
normal one-voice stage, full inverse review, audit and apply. The proposed helper
is source-only and separately reviewed. Saved playback must cover66 ->67 ->68
and verify the exact cue resolves, starts and ends naturally.

No subjective listening, original CSV phase, measured gain/offset/Wait,
body/face token or whole-scene acceptance is implied. No D or C write, Git,
browser, API, normal prepare/stage/import or new source decode occurred here.
