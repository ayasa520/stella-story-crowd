"""Commit only a verified field batch and its completed evidence archive.

The archive plan defines the complete formal write set. Refuse unrelated
changes, pre-staged files, a different parent, or changed saved payloads before
staging anything. After the commit, compare every committed blob with the held
working digest. Network publication is deliberately a separate observed call.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
D = A / 'data-checkout'
parser = argparse.ArgumentParser()
parser.add_argument('--preparation', required=True)
parser.add_argument('--message-file', required=True)
args = parser.parse_args()
out = Path(args.preparation)
assert out.parent == A
plan = json.loads((out / 'archive-plan.root-approved.json').read_bytes())
audit = D / plan['targetRelativeDirectory']
assert audit.is_relative_to(D / 'review/restoration-audits')
files = sorted(set(plan['savedDataFiles']) | {str(p.relative_to(D)) for p in audit.rglob('*') if p.is_file()})


def run(*args):
    return subprocess.run(['/usr/bin/git', '-C', str(D), *args], check=True, text=True, capture_output=True)


assert run('rev-parse', 'HEAD').stdout.strip() == plan['expectedHead']
assert run('diff', '--cached', '--name-only').stdout == ''
actual = {r[3:] for r in run('status', '--short', '--untracked-files=all', '-z').stdout.split('\0') if r}
assert actual == set(files), (actual - set(files), set(files) - actual)
expected = {name: hashlib.sha256((D / name).read_bytes()).hexdigest() for name in files}
assert all(expected[n] == h for n, h in plan['savedDataFiles'].items())
(out / 'commit-expected-blobs.json').write_text(json.dumps(expected, indent=2) + '\n')
pathspec = out / 'commit-paths.nul'
pathspec.write_bytes(b'\0'.join(n.encode() for n in files) + b'\0')
run('add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul')
assert set(run('diff', '--cached', '--name-only').stdout.splitlines()) == set(files)
run('diff', '--cached', '--check')
run('-c', 'commit.gpgsign=false', 'commit', '--file', args.message_file)
head = run('rev-parse', 'HEAD').stdout.strip()
assert run('rev-parse', 'HEAD^').stdout.strip() == plan['expectedHead']
assert set(run('diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD').stdout.splitlines()) == set(files)
for name, digest in expected.items():
    raw = subprocess.check_output(['/usr/bin/git', '-C', str(D), 'show', head + ':' + name])
    assert hashlib.sha256(raw).hexdigest() == digest, name
assert run('status', '--short').stdout == ''
receipt = dict(rootConfirmed=True, commit=head, parent=plan['expectedHead'], files=len(files),
    auditFiles=len(files) - len(plan['savedDataFiles']), allCommittedBlobsExact=True, worktreeClean=True)
(out / 'committed-blobs.root-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
