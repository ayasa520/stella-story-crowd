/** Independent, read-only saved-state proof for the current one-leaf voice batch.
 *
 * This is intentionally a separate engine and result name. The preserved Python
 * saved verifier remains failed; a Node pass never rewrites that observation.
 * Every source read is held and archived before interpretation. JSON.parse gets
 * the very same captured string, with a reject-only numeric reviver. No business
 * stage/apply helper, parser repair, retry, normalization, or D/Git mutation runs.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {spawnSync} from 'node:child_process';

const ROOT = '/home/rikka/Projects/stella';
const A = path.join(ROOT, 'artifacts/stella-script-continuation-20261121');
const D = path.join(A, 'data-checkout');
const ENCODER = path.join(ROOT, 'story_studio/crowd_seed.py');
const ENCODER_SHA = '01806188ca7391882d9d74c0a2cfaa3ab987fcd722a719c80f940b8f25386956';
const PACKAGE_INIT = path.join(ROOT, 'story_studio/__init__.py');
const PACKAGE_INIT_SHA = 'a76726422c5494f0e49d1981248b7e9f5073522fbc8524c825631e029d842675';
const PYTHON = path.join(ROOT, '.venv-video-ocr/bin/python');
const REFERENCE_PYTHON = path.join(A, 'verify-saved-field-batch-with-input-capture-v2.py');
const REFERENCE_PYTHON_SHA = 'bb476c56fe49911915463e198e85b67798646b32cbdcd905e95400d6a9f1e81f';
const FIELD = 'voice';
const EXPECTED_FIELDS = ['bg_music', 'bg_picture', 'character', 'character_image',
  'motion', 'msg_character', 'msg_text', 'position', 'se', 'talk_chara', 'video', 'voice', 'command'];
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);

function requireThat(condition, message, details = undefined) {
  if (condition) return;
  const error = new Error(message);
  error.name = 'SavedVerificationInvariantError';
  if (details !== undefined) error.details = details;
  throw error;
}

// Python JSON equality ignores object key order and preserves array order.
// Finite numeric values use normal double equality; no stringify round trip
// collapses unknown document structure, insertion order, or numeric lexemes.
function jsonEqual(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (typeof left !== 'object') return false;
  if (Array.isArray(left) !== Array.isArray(right)) return false;
  if (Array.isArray(left)) return left.length === right.length && left.every((v, i) => jsonEqual(v, right[i]));
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length && keys.every(k => own(right, k) && jsonEqual(left[k], right[k]));
}
function sameSet(left, right) {
  return left.size === right.size && [...left].every(value => right.has(value));
}
function assertEqual(left, right, message) { requireThat(jsonEqual(left, right), message); }
function assertKeys(value, expected, message) {
  requireThat(value && typeof value === 'object' && !Array.isArray(value), message);
  requireThat(sameSet(new Set(Object.keys(value)), new Set(expected)), message);
}
function repoName(name) {
  requireThat(typeof name === 'string' && name.length > 0 && !name.includes('\\'), 'Invalid repository path');
  requireThat(!path.posix.isAbsolute(name) && path.posix.normalize(name) === name && !name.startsWith('../'), 'Path escapes repository');
  return name;
}
function dataRelative(absolute) {
  const name = path.relative(D, path.resolve(absolute));
  repoName(name);
  requireThat(path.join(D, name) === path.resolve(absolute), 'Guard path is outside D');
  return name;
}
function safeInteger(value, label) {
  requireThat(Number.isSafeInteger(value), `Unsafe/noninteger identifier: ${label}`);
  return value;
}
function newJSON(file, value) {
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`, {flag: 'wx'});
}

class Captures {
  constructor(directory) {
    fs.mkdirSync(directory); // Fail rather than overwrite/reuse prior evidence.
    this.directory = directory;
    this.records = [];
    this.files = new Map();
    this.hashGuards = new Map();
    this.parsed = new Map();
    this.indexFD = fs.openSync(path.join(directory, 'inputs.jsonl'), 'wx');
  }
  note(value) { fs.writeSync(this.indexFD, `${JSON.stringify(value)}\n`); }
  hold(raw, label, provenance = {}) {
    requireThat(Buffer.isBuffer(raw), 'Capture input must be the actual Buffer');
    const id = String(this.records.length + 1).padStart(4, '0');
    const digest = sha(raw);
    const archive = `${id}.raw.gz`;
    const compressed = zlib.gzipSync(raw, {mtime: 0});
    requireThat(zlib.gunzipSync(compressed).equals(raw), 'Capture gzip round trip differs');
    fs.writeFileSync(path.join(this.directory, archive), compressed, {flag: 'wx'});
    requireThat(sha(raw) === digest, 'Held Buffer changed while capturing');
    const record = {id, label, bytes: raw.length, sha256: digest, archive,
      archiveSHA256: sha(compressed), ...provenance};
    const held = {raw, record};
    this.records.push(record);
    this.note({kind: 'held-input', ...record});
    return held;
  }
  stable(held) { requireThat(sha(held.raw) === held.record.sha256, `Held Buffer changed: ${held.record.label}`); }
  file(file, label) {
    const absolute = path.resolve(file);
    requireThat(!this.hashGuards.has(absolute), 'A hash-only source cannot be reread as a replacement parse input');
    if (this.files.has(absolute)) {
      const existing = this.files.get(absolute);
      this.stable(existing);
      this.note({kind: 'reuse-held-input', inputId: existing.record.id, label});
      return existing;
    }
    const before = fs.statSync(absolute, {bigint: true});
    requireThat(before.isFile() && before.size <= 134217728n, `Not a bounded regular source file: ${absolute}`);
    const raw = fs.readFileSync(absolute);
    const after = fs.statSync(absolute, {bigint: true});
    const identity = stat => [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].map(String);
    requireThat(jsonEqual(identity(before), identity(after)), `Source changed during read: ${absolute}`);
    const held = this.hold(raw, label, {sourcePath: absolute, sourceIdentity: identity(after)});
    this.files.set(absolute, held);
    return held;
  }
  hashOnly(file, label) {
    const absolute = path.resolve(file);
    if (this.files.has(absolute)) {
      const held = this.files.get(absolute);
      this.stable(held);
      this.note({kind: 'reuse-held-hash-guard', inputId: held.record.id, label});
      return held.record;
    }
    if (this.hashGuards.has(absolute)) {
      const record = this.hashGuards.get(absolute);
      this.note({kind: 'reuse-hash-only-guard', sourcePath: absolute, label, sha256: record.sha256});
      return record;
    }
    // Noninterpreted library/protected files require one held hash and stable
    // stat identity, not a duplicate gzip backup of the immutable library.
    const before = fs.statSync(absolute, {bigint: true});
    requireThat(before.isFile() && before.size <= 134217728n, 'Hash guard is not a bounded regular file');
    const raw = fs.readFileSync(absolute);
    const digest = sha(raw);
    const after = fs.statSync(absolute, {bigint: true});
    const identity = stat => [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].map(String);
    requireThat(jsonEqual(identity(before), identity(after)) && sha(raw) === digest, 'Hash-only source changed during held read');
    const record = {kind: 'hash-only-guard', label, sourcePath: absolute, bytes: raw.length,
      sha256: digest, sourceIdentity: identity(after), archived: false, JSONInterpreted: false};
    this.hashGuards.set(absolute, record);
    this.note(record);
    return record;
  }
  json(held) {
    this.stable(held);
    if (this.parsed.has(held.record.id)) return this.parsed.get(held.record.id);
    // Capture the actual immutable string before JSON.parse, as well as the
    // raw bytes. A failure captures that same string again, never a new read.
    const text = held.raw.toString('utf8');
    const textInput = this.hold(Buffer.from(text, 'utf8'), `parse-string:${held.record.label}`,
      {fromInputId: held.record.id, UTF16CodeUnits: text.length});
    requireThat(textInput.record.sha256 === held.record.sha256, 'UTF-8 decoding changed source bytes; no repair attempted');
    try {
      const result = JSON.parse(text, (_key, value) => {
        // Fail closed rather than let rounding hide an unknown integer edit.
        // This reviver never rewrites a value or replaces JSON.parse.
        if (typeof value === 'number') {
          requireThat(Number.isFinite(value), 'Non-finite JSON number is unsupported');
          requireThat(!Number.isInteger(value) || Number.isSafeInteger(value), 'Unsafe integer rejected before whole-document comparison');
        }
        return value;
      });
      this.stable(held);
      requireThat(sha(Buffer.from(text, 'utf8')) === textInput.record.sha256, 'Actual parse string changed during JSON.parse');
      this.note({kind: 'parse-success', rawInputId: held.record.id, parseStringId: textInput.record.id,
        rawSHA256After: sha(held.raw), parseStringUTF8SHA256After: sha(Buffer.from(text, 'utf8'))});
      this.parsed.set(held.record.id, result);
      return result;
    } catch (error) {
      const actualDoc = this.hold(Buffer.from(text, 'utf8'), `actual-exception-document:${held.record.label}`,
        {fromInputId: held.record.id, parseStringInputId: textInput.record.id});
      const failure = {verificationEngine: 'independent Node', originalPythonSavedVerifier: 'failed_preserved',
        input: held.record, actualParseString: textInput.record, actualExceptionDocument: actualDoc.record,
        errorName: error.name, errorMessage: error.message, stack: error.stack, cause: 'unknown',
        rawSHA256AtCatch: sha(held.raw), actualDocumentUTF8SHA256: actualDoc.record.sha256,
        rereadOrRetryPerformed: false, parserRepairedOrReplaced: false};
      newJSON(path.join(this.directory, 'failure.node-v1.json'), failure);
      throw error;
    }
  }
  sourceJSON(file, label) { const held = this.file(file, label); return {held, value: this.json(held)}; }
  process(executable, argv, label, input = undefined, cwd = ROOT) {
    const stdin = input === undefined ? null : this.hold(input, `${label}:stdin`, {kind: 'subprocess-stdin'});
    const outcome = spawnSync(executable, argv, {cwd, input, timeout: 30000, maxBuffer: 67108864,
      env: {...process.env, PYTHONDONTWRITEBYTECODE: '1', GIT_OPTIONAL_LOCKS: '0'}, encoding: null});
    const stdout = this.hold(outcome.stdout ?? Buffer.alloc(0), `${label}:stdout`, {kind: 'subprocess-stdout'});
    const stderr = this.hold(outcome.stderr ?? Buffer.alloc(0), `${label}:stderr`, {kind: 'subprocess-stderr'});
    if (stdin) this.stable(stdin);
    const execution = {executable, argv, cwd, label, exitCode: outcome.status, signal: outcome.signal,
      error: outcome.error ? {name: outcome.error.name, message: outcome.error.message, code: outcome.error.code} : null,
      stdin: stdin?.record ?? null, stdout: stdout.record, stderr: stderr.record, retryCount: 0};
    this.note({kind: 'subprocess-execution', ...execution});
    requireThat(!outcome.error && outcome.status === 0 && outcome.signal === null, `Subprocess failed without retry: ${label}`, execution);
    requireThat(stderr.raw.length === 0, `Subprocess stderr is nonempty: ${label}`, execution);
    return {stdout, stderr, execution};
  }
  checkSourceIdentities() {
    for (const [file, held] of this.files) {
      const stat = fs.statSync(file, {bigint: true});
      const identity = [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].map(String);
      requireThat(jsonEqual(identity, held.record.sourceIdentity), `Source identity changed after held read: ${file}`);
      this.stable(held);
    }
    for (const [file, record] of this.hashGuards) {
      const stat = fs.statSync(file, {bigint: true});
      const identity = [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].map(String);
      requireThat(jsonEqual(identity, record.sourceIdentity), `Hash-only source identity changed: ${file}`);
    }
  }
  close() { fs.closeSync(this.indexFD); }
}

// BEGIN_PYTHON_SUMMARY_ENCODER
const PYTHON_SUMMARY_ENCODER = String.raw`
import gzip, hashlib, json, os, sys, traceback
from pathlib import Path
root, scene, expected_source_sha, expected_init_sha, exception_base = sys.argv[1:]
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
source = Path(root) / 'story_studio/crowd_seed.py'
package = Path(root) / 'story_studio/__init__.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected_source_sha
assert hashlib.sha256(package.read_bytes()).hexdigest() == expected_init_sha
sys.path.insert(0, root)
from story_studio.crowd_seed import encoded
assert Path(encoded.__code__.co_filename).resolve() == source.resolve()
raw = sys.stdin.buffer.read()
try:
    stage = json.loads(raw)
except json.JSONDecodeError as error:
    doc = error.doc.encode('utf-8', 'surrogatepass')
    with open(exception_base + '.actual-doc.gz', 'xb') as stream:
        stream.write(gzip.compress(doc, mtime=0))
    with open(exception_base + '.failure.json', 'x') as stream:
        json.dump(dict(errorType=type(error).__name__, error=str(error), position=error.pos,
            rawSHA256=hashlib.sha256(raw).hexdigest(), actualDocSHA256=hashlib.sha256(doc).hexdigest(),
            cause='unknown', retryCount=0), stream, indent=2)
        stream.write('\n')
    traceback.print_exc()
    raise SystemExit(2)
matches = [summary for summary in stage['scenes'] if summary['id'] == int(scene)]
assert len(matches) == 1
sys.stdout.buffer.write(encoded(matches[0]))
`;
// END_PYTHON_SUMMARY_ENCODER

function argumentsForRun() {
  const values = new Map();
  const allowed = new Set(['--preparation', '--staging', '--parent', '--field']);
  const argv = process.argv.slice(2);
  requireThat(argv.length % 2 === 0, 'Arguments require explicit flag/value pairs');
  for (let index = 0; index < argv.length; index += 2) {
    requireThat(allowed.has(argv[index]) && !values.has(argv[index]), `Unknown/duplicate argument ${argv[index]}`);
    values.set(argv[index], argv[index + 1]);
  }
  for (const key of ['--preparation', '--staging', '--parent']) requireThat(values.has(key), `Missing ${key}`);
  requireThat((values.get('--field') ?? FIELD) === FIELD, 'This source supports the current voice batch only');
  const O = path.resolve(values.get('--preparation')), S = path.resolve(values.get('--staging'));
  requireThat(path.dirname(O) === A && path.dirname(S) === A && O !== S, 'Preparation/staging must be distinct direct children of A');
  const parent = values.get('--parent');
  requireThat(/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(parent), 'Parent must be a complete immutable commit ID');
  return {O, S, parent};
}
function changedPaths(store, label) {
  const held = store.process('/usr/bin/git', ['--no-optional-locks', '-C', D, 'status',
    '--porcelain=v1', '-z', '--untracked-files=all'], label).stdout;
  const text = held.raw.toString('utf8');
  requireThat(Buffer.from(text, 'utf8').equals(held.raw), 'Git paths are not lossless UTF-8');
  const records = text.split('\0');
  requireThat(records.pop() === '', 'Git status was not NUL terminated');
  const names = new Set();
  for (const record of records) {
    requireThat(record.length >= 4 && record[2] === ' ', 'Unexpected Git status record');
    const code = record.slice(0, 2);
    requireThat(!/[RCDU]/.test(code) && (code === '??' || /^[ MA]{2}$/.test(code)), 'Deleted/renamed/copied/unmerged path is outside this saved batch');
    const name = repoName(record.slice(3));
    requireThat(!names.has(name), 'Duplicate Git dirty path');
    names.add(name);
  }
  return names;
}
function gitHead(store, label) {
  return store.process('/usr/bin/git', ['--no-optional-locks', '-C', D, 'rev-parse', '--verify', 'HEAD'], label)
    .stdout.raw.toString('ascii').trim();
}
function parentJSON(store, approval, parent, name) {
  repoName(name);
  const held = store.process('/usr/bin/git', ['--no-optional-locks', '-C', D, 'show',
    '--no-ext-diff', '--no-textconv', `${parent}:${name}`], `parent-git:${name}`).stdout;
  requireThat(held.record.sha256 === approval.all285GlobalSceneMetadataAndAssetGuards[path.join(D, name)], `Parent blob guard mismatch: ${name}`);
  return {held, value: store.json(held)};
}

let store;
try {
  const {O, S, parent} = argumentsForRun();
  const resultPath = path.join(O, 'root-saved-verification.node-v1.json');
  requireThat(!fs.existsSync(resultPath), 'Independent Node result already exists');
  store = new Captures(path.join(O, 'saved-verification-inputs.node-v1'));
  requireThat(os.getPriority(0) >= 19, 'Verifier must run at nice19');
  const runtimeStatus = store.hold(fs.readFileSync('/proc/self/status'), 'runtime-cpu-affinity');
  const cpuLine = runtimeStatus.raw.toString('ascii').match(/^Cpus_allowed_list:\s*(.+)$/m)?.[1]?.trim();
  requireThat(cpuLine === '0-1' || cpuLine === '0,1', 'Verifier must run on CPUs0,1');
  const referenceSource = store.file(REFERENCE_PYTHON, 'original-Python-saved-verifier-source-only');
  requireThat(referenceSource.record.sha256 === REFERENCE_PYTHON_SHA, 'Reference Python verifier source changed');

  const priorFailurePath = path.join(O, 'saved-verification-inputs-v1/failure.json');
  const priorFailure = store.sourceJSON(priorFailurePath, 'preserved-original-Python-failure');
  requireThat(priorFailure.value.cause === 'unknown' && typeof priorFailure.value.error === 'string', 'Original failure record is missing');
  const approvalInput = store.sourceJSON(path.join(O, 'preflight.root-approved.json'), 'root-preflight');
  const approval = approvalInput.value;
  const packetInput = store.sourceJSON(path.join(O, 'node-fields.root-approved.json'), 'root-packet');
  const packet = packetInput.value;
  const stageInput = store.sourceJSON(path.join(S, 'manifest.json'), 'stage-manifest');
  const stage = stageInput.value;
  const stageReviewInput = store.sourceJSON(path.join(O, 'stage.root-review.json'), 'root-reviewed-stage');
  const stageReview = stageReviewInput.value;
  const applyReleaseInput = store.sourceJSON(path.join(O, 'apply.root-approved.json'), 'original-once-apply-release');
  const applyRelease = applyReleaseInput.value;
  requireThat(approval.rootConfirmed === true && approval.stageAuthorized === true && approval.applyAuthorized === false, 'Original stage-only preflight contract differs');
  requireThat(approval.dataHead === parent && packet.baseSha === parent && approval.field === FIELD, 'Parent/voice approval binding differs');
  requireThat(packetInput.held.record.sha256 === approval.nodeFieldsSHA256, 'Approved packet hash differs');
  requireThat(stageReview.rootConfirmed === true && stageReview.field === FIELD && stageReview.stageManifestSHA256 === stageInput.held.record.sha256, 'Reviewed staging manifest binding differs');
  requireThat(applyRelease.rootConfirmed === true && applyRelease.applyAuthorizedOnce === true &&
    applyRelease.dataHead === parent && applyRelease.stageManifestSHA256 === stageInput.held.record.sha256 &&
    applyRelease.stageReviewSHA256 === stageReviewInput.held.record.sha256, 'Original once-apply release is not bound to the actual stage/review');
  requireThat(stageReview.completeNativeUndoOnlySelectedFieldExact === true &&
    stageReview.completeReviewOnlyExactEvidenceAppendsAndSelectedFieldWarningRemovals === true &&
    stageReview.completeSceneSummaryOnlyNormalSelectedFieldWarningRemovals === true &&
    stageReview.allStagedManifestHashesExact === true, 'Complete staging review assertions are missing');
  requireThat(Array.isArray(packet.changes) && packet.changes.length === 1 && approval.exactVisualFieldLeaves === 1, 'Only the current one-leaf voice packet is supported');
  requireThat(Array.isArray(packet.requiredAssetImports) && packet.requiredAssetImports.length === 0, 'This voice packet must not import assets');
  const change = packet.changes[0];
  assertKeys(change.fields, [FIELD], 'Only voice may be changed');
  assertKeys(change.expected, EXPECTED_FIELDS, 'All13 expected-field guards are required');
  safeInteger(change.sceneId, 'sceneId'); safeInteger(change.scenarioId, 'scenarioId');
  safeInteger(change.uniqueId, 'uniqueId'); safeInteger(change.arrayIndex, 'arrayIndex');
  requireThat(change.arrayIndex >= 0 && change.UID === change.uniqueId, 'Target index/UID binding differs');
  requireThat(typeof change.fields.voice === 'string', 'Saved voice value must remain a string');
  requireThat(change.fields.voice !== change.expected.voice, 'The approved voice leaf must actually change');
  requireThat(change.fullNativeRowBefore && typeof change.fullNativeRowBefore === 'object', 'Complete old native row is required');
  const scene = change.sceneId;
  const nativeName = `native/scenes/${scene}.json`, reviewName = `review/scenes/${scene}.json`;
  const stagedDataNames = new Set([nativeName, reviewName]);
  requireThat(stage.files && typeof stage.files === 'object', 'Staging files map is missing');
  const stageNames = Object.keys(stage.files);
  requireThat(sameSet(new Set(stageNames), new Set([nativeName, reviewName, 'plan.json', 'repair-report.json'])), 'Unexpected staged file set');
  requireThat(Array.isArray(stage.scenes) && stage.scenes.length === 1 && stage.scenes[0].id === scene, 'Only the exact target summary is allowed');
  const summary = stage.scenes[0];
  const batch = stageInput.held.record.sha256.slice(0, 20);
  requireThat(stageReview.batchId === batch, 'Reviewed batch ID differs');
  const batchName = `review/restoration-batches/${batch}.json`;
  const changed = new Set([nativeName, reviewName, 'manifest.json', 'review/native-restoration.json']);
  const savedNames = new Set([...changed, batchName]);
  requireThat(savedNames.size === 5, 'Saved data boundary must have exactly5 files');
  requireThat(gitHead(store, 'data-HEAD:before') === parent, 'D HEAD differs from approved parent');
  requireThat(sameSet(changedPaths(store, 'data-dirty:before'), savedNames), 'Dirty file names differ from the exact5-file batch');

  const staged = new Map(), saved = new Map(), savedFiles = {};
  for (const name of stageNames) {
    repoName(name);
    requireThat(/^[0-9a-f]{64}$/.test(stage.files[name]), 'Invalid staged SHA256');
    const held = store.file(path.join(S, name), `staged:${name}`);
    requireThat(held.record.sha256 === stage.files[name], `Staged raw hash differs: ${name}`);
    staged.set(name, held);
    if (stagedDataNames.has(name)) {
      const actual = store.file(path.join(D, name), `saved:${name}`);
      requireThat(actual.record.sha256 === stage.files[name] && actual.raw.equals(held.raw), `Saved/staged raw bytes differ: ${name}`);
      saved.set(name, actual); savedFiles[name] = actual.record.sha256;
    }
  }
  const oldNative = parentJSON(store, approval, parent, nativeName).value;
  const newNative = store.json(saved.get(nativeName));
  const stagedNative = store.json(staged.get(nativeName));
  assertEqual(newNative, stagedNative, 'Complete saved native document differs from reviewed staging');
  requireThat(Array.isArray(oldNative.scenario_list) && Array.isArray(newNative.scenario_list), 'Native row arrays are required');
  const oldRow = oldNative.scenario_list[change.arrayIndex], newRow = newNative.scenario_list[change.arrayIndex];
  requireThat(oldRow && newRow, 'Target array index is missing');
  for (const row of [oldRow, newRow]) requireThat(row.scenario_id === change.scenarioId && row.uniq_id === change.uniqueId, 'Target identifiers/order differ');
  assertEqual(oldRow, change.fullNativeRowBefore, 'Complete parent target row differs from approved fullNativeRowBefore');
  for (const field of EXPECTED_FIELDS) {
    assertEqual(oldRow[field], change.expected[field], `Parent13-field guard differs: ${field}`);
    assertEqual(newRow[field], field === FIELD ? change.fields[FIELD] : change.expected[field], `Saved13-field guard differs: ${field}`);
  }
  const undo = structuredClone(newNative);
  // Preserve document/array order and every unknown field. The only undo is
  // the approved voice leaf, applied at the exact original array index.
  undo.scenario_list[change.arrayIndex][FIELD] = change.expected[FIELD];
  assertEqual(undo, oldNative, 'Complete ordered native undo differs from immutable parent');
  const savedReview = store.json(saved.get(reviewName)), stagedReview = store.json(staged.get(reviewName));
  assertEqual(savedReview, stagedReview, 'Complete review document differs from reviewed staging');

  const oldManifestInput = parentJSON(store, approval, parent, 'manifest.json');
  const savedManifestInput = store.sourceJSON(path.join(D, 'manifest.json'), 'saved:manifest.json');
  const expectedManifest = structuredClone(oldManifestInput.value);
  requireThat(Array.isArray(expectedManifest.scenes), 'Complete manifest scene array is missing');
  requireThat(expectedManifest.scenes.filter(row => row.id === scene).length === 1, 'Target scene summary is missing/duplicated in parent');
  expectedManifest.scenes = expectedManifest.scenes.map(row => row.id === scene ? structuredClone(summary) : row);
  assertEqual(savedManifestInput.value, expectedManifest, 'Complete manifest changed beyond the target summary');

  const oldOwnershipInput = parentJSON(store, approval, parent, 'review/native-restoration.json');
  const savedOwnershipInput = store.sourceJSON(path.join(D, 'review/native-restoration.json'), 'saved:review/native-restoration.json');
  const oldOwnership = oldOwnershipInput.value;
  const expectedOwnership = structuredClone(oldOwnership);
  requireThat(expectedOwnership.files && expectedOwnership.scenes && Array.isArray(expectedOwnership.batches), 'Ownership schema differs');
  for (const name of stagedDataNames) expectedOwnership.files[name] = savedFiles[name];
  const encoderSource = store.file(ENCODER, 'original-Python-summary-encoder-source');
  const packageInit = store.file(PACKAGE_INIT, 'original-Python-summary-encoder-package');
  requireThat(encoderSource.record.sha256 === ENCODER_SHA && packageInit.record.sha256 === PACKAGE_INIT_SHA, 'Original encoder source binding changed');
  const encoderBase = path.join(store.directory, `python-summary-${scene}`);
  // Send the ORIGINAL held stage bytes to Python, not a JS-reserialized
  // summary. Python selects the small summary and calls the original encoded
  // function, preserving its float lexemes/types, key order and Unicode format.
  const encoding = store.process(PYTHON, ['-B', '-c', PYTHON_SUMMARY_ENCODER, ROOT, String(scene),
    ENCODER_SHA, PACKAGE_INIT_SHA, encoderBase], `Python-original-encoded-summary:${scene}`, stageInput.held.raw);
  store.stable(stageInput.held);
  requireThat(encoding.stdout.raw.length > 0, 'Original Python encoder returned no bytes');
  const summaryToken = encoding.stdout.record.sha256; // Hash exact stdout only; never parse/reformat it.
  expectedOwnership.scenes[String(scene)] = summaryToken;
  requireThat(!oldOwnership.batches.includes(batch), 'Batch already existed before apply');
  expectedOwnership.batches.push(batch);
  assertEqual(savedOwnershipInput.value, expectedOwnership, 'Complete ownership changed beyond target hashes/token/one append');

  const applyInput = store.sourceJSON(path.join(O, 'apply.original.stdout.log'), 'original-apply');
  const apply = applyInput.value;
  requireThat(apply.applied === true && apply.batchId === batch && apply.stagingManifestSha256 === stageInput.held.record.sha256 &&
    apply.previousManifestSha256 === oldManifestInput.held.record.sha256 && path.resolve(apply.staging) === S, 'Original apply is not bound to this held stage/parent');
  assertEqual(apply.addedScenes, [], 'Voice update must not add scenes');
  assertEqual(apply.updatedScenes, [scene], 'Original apply target scene list differs');
  const expectedBatch = Object.fromEntries(Object.entries(apply).filter(([key]) => key !== 'applied'));
  const batchInput = store.sourceJSON(path.join(D, batchName), `saved:${batchName}`);
  assertEqual(batchInput.value, expectedBatch, 'Complete batch sidecar differs from original apply minus applied');

  const globalEntries = Object.entries(approval.all285GlobalSceneMetadataAndAssetGuards ?? {});
  requireThat(globalEntries.length === 285, 'Exactly285 original global guards are required');
  const guardedNames = new Set(globalEntries.map(([file]) => dataRelative(file)));
  requireThat([...changed].every(name => guardedNames.has(name)), 'A changed data file was not in the approved global guard set');
  let otherGuardsChecked = 0;
  for (const [file, digest] of globalEntries) {
    const name = dataRelative(file);
    if (changed.has(name)) continue;
    const held = store.hashOnly(file, `unchanged-global:${name}`);
    requireThat(held.sha256 === digest, `Unchanged global guard differs: ${name}`);
    otherGuardsChecked += 1;
  }
  requireThat(otherGuardsChecked === globalEntries.length - changed.size, 'Actual unchanged-guard count differs');
  const protectedEntries = Object.entries(approval.protectedFirstThree ?? {});
  requireThat(protectedEntries.length === 22, 'Exactly22 protected baseline guards are required');
  for (const [name, digest] of protectedEntries) {
    repoName(name);
    requireThat(store.hashOnly(path.join(D, name), `protected-first-three:${name}`).sha256 === digest, `Protected guard differs: ${name}`);
  }
  for (const name of savedNames) savedFiles[name] = store.file(path.join(D, name), `final-held-saved:${name}`).record.sha256;
  requireThat(sameSet(new Set(Object.keys(savedFiles)), savedNames), 'Result file set differs from exact5 saved files');
  requireThat(gitHead(store, 'data-HEAD:after') === parent, 'D HEAD changed during independent verification');
  requireThat(sameSet(changedPaths(store, 'data-dirty:after'), savedNames), 'Dirty paths changed during independent verification');
  store.checkSourceIdentities();
  const result = {schema: 'stella.saved-field-independent-node-verification.v1', rootConfirmed: false,
    verificationEngine: 'independent Node', independentVerificationPassed: true,
    originalPythonSavedVerifier: 'failed_preserved', originalPythonFailureCause: 'unknown',
    originalPythonFailure: {sourcePath: priorFailurePath, capturedInput: priorFailure.held.record,
      error: priorFailure.value.error, input: priorFailure.value.input, actualDocSHA256: priorFailure.value.docSHA256},
    originalOnceApplyRelease: {sourcePath: path.join(O, 'apply.root-approved.json'),
      sha256: applyReleaseInput.held.record.sha256, stageReviewSHA256: stageReviewInput.held.record.sha256},
    parentHead: parent, batchId: batch, field: FIELD, exactNativeLeafChanges: 1,
    expectedFieldGuardsPerTarget: EXPECTED_FIELDS.length, orderedFullNativeUndoExact: true,
    completeNativeRowsOtherFieldsBranchesAndOrderExact: true, savedNativeAndReviewRawBytesEqualFullyReviewedStaging: true,
    all4StagedRawHashesExact: true, completeManifestOnlyTargetSummaryReplacement: true,
    completeOwnershipOnlyTargetHashesSummaryTokenAndOneBatchAppend: true,
    summaryTokenEncoding: 'SHA256(exact original Python story_studio.crowd_seed.encoded(summary) stdout)',
    summaryEncoderInput: 'Original held stage manifest bytes; Python selects scene summary; no JS JSON.stringify input',
    summaryEncoderExecution: encoding.execution, oldBatches: oldOwnership.batches.length,
    newBatches: savedOwnershipInput.value.batches.length, completeOriginalApplyBatchSidecarExact: true,
    globalGuards: globalEntries.length, unchangedGlobalGuardsActuallyChecked: otherGuardsChecked,
    protectedGuardsActuallyChecked: protectedEntries.length, all22ProtectedExact: true,
    noninterpretedHashGuardsArchived: false, hashOnlySourceRecords: [...store.hashGuards.values()],
    exactly5SavedDataFiles: true, dirtyFileNameSetExact: true, savedFiles,
    actualReadBuffersAndParseStringsPreserved: true, parseFailurePolicy: 'capture exact held raw and actual parse string; no reread/repair/retry',
    unsafeIntegerGuard: 'JSON.parse reviver rejects Number.isInteger&&!Number.isSafeInteger; non-finite numbers rejected',
    numericValuesNormalized: false, noBusinessGateRerun: true, DCOrGitMutationPerformed: false,
    fullEntryMotionFaceGeometryTimingOrSavedGameplayAccepted: false, wholeSceneOrEpisodeAccepted: false,
    captureDirectory: store.directory, capturedBuffers: store.records.length, nice: os.getPriority(0), cpuAffinity: cpuLine};
  newJSON(path.join(store.directory, 'parse-inputs.node-v1.json'), store.records);
  newJSON(resultPath, result);
  process.stdout.write(`${JSON.stringify({verificationEngine: result.verificationEngine,
    originalPythonSavedVerifier: result.originalPythonSavedVerifier, batchId: batch, field: FIELD,
    nativeLeaves: 1, savedFiles: Object.keys(savedFiles).length, result: resultPath})}\n`);
} catch (error) {
  if (store) {
    const failure = {verificationEngine: 'independent Node', originalPythonSavedVerifier: 'failed_preserved',
      independentVerificationPassed: false, errorName: error.name, errorMessage: error.message,
      stack: error.stack, details: error.details ?? null, cause: 'unknown', retryCount: 0};
    const target = path.join(store.directory, 'verification-failure.node-v1.json');
    if (!fs.existsSync(target)) newJSON(target, failure);
    const index = path.join(store.directory, 'parse-inputs.node-v1.json');
    if (!fs.existsSync(index)) newJSON(index, store.records);
  }
  process.stderr.write(`${error.stack ?? error}\n`);
  process.exitCode = 1;
} finally {
  if (store) store.close();
}
