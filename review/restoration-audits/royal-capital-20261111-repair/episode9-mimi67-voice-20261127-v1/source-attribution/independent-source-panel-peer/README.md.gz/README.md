# Independent source-panel review, nodes 66 → 67 → 68

Only the named source PTS index, its nine supplied contact sheets and selected original JPEGs were read. All 314 contact-sheet cells were reviewed in chronological order. No new video decode, browser, API, D/C/Git inspection or Git write was performed. No audio, motion/face token, or runtime-command verdict is made.

The written JPEG range is frame 1 (raw PTS 9984352 / 16000 = 624.022) through frame 314 (10151280 / 16000 = 634.455). The index's filter tail at 634.488 has no JPEG and was not visually reviewed. All 314 JPEGs and nine sheets matched their indexed byte counts and SHA-256 values.

| Layer/event | Last before | First after |
| --- | --- | --- |
| Ricardo Chinese disappears | 89 / 626.955 | 90 / 626.988 |
| Ricardo disappears (96 still has a ghost) | 96 / 627.188 | 97 / 627.222 |
| Old native Japanese stops being readable | 97 / 627.222 | 98 / 627.255 |
| Old native panel disappears | 98 / 627.255 | 99 / 627.288 |
| Subaru begins visible entry | 102 / 627.388 | 103 / 627.422 |
| Node 67 Chinese appears | 106 / 627.522 | 107 / 627.555 |
| Node 67 native panel appears | 110 / 627.655 | 111 / 627.688 |
| Node 67 first body glyph 勘 | 112 / 627.722 | 113 / 627.755 |
| Chinese switches 67 → 68 | 231 / 631.688 | 232 / 631.722 |
| Node 67 native panel disappears | 233 / 631.755 | 234 / 631.788 |
| Node 68 native panel appears | 234 / 631.788 | 235 / 631.822 |
| Node 68 first body glyph コ | 236 / 631.855 | 237 / 631.888 |

Native name スバル has one-frame faint/readable ambiguity at 111/112 for node 67 and 235/236 for node 68. The body-glyph boundaries above are independently visible. Node 66 name/text is already present in frame 1, so its initial appearance lies outside this window. Subaru is continuously present across 67 → 68 and remains in the final written frame 314.

`review.json` contains raw PTS, exact paths and indexed SHA-256 references for every boundary. It separately describes actor presence, native name/body/panel and burned Chinese; these are not interchangeable sentence clocks.
