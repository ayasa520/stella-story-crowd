"""Capture one bounded original window with unchanged source timestamps.

This is offline evidence acquisition, not a player or restoration operation.
Every original video frame is preserved; only spatial JPEG encoding is applied.
The same FFmpeg invocation writes mono PCM with an independent audio PTS log so
cue-zero calculations never borrow nominal OCR timestamps as an audio clock.
"""

import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


OUT = Path(__file__).resolve().parent
CONFIG = json.loads((OUT / 'inputs.rootfalse.json').read_bytes())
assert sorted(os.sched_getaffinity(0)) == [0, 1]
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
SOURCE = Path(CONFIG['video']['path'])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == CONFIG['video']['sha256']
START, END = CONFIG['sourceWindowSeconds']
assert 0 < END - START <= 12
FRAMES = OUT / 'source-frames'
FRAMES.mkdir()
PCM = OUT / 'source-mono-16000.f32le'
LOG = OUT / 'source-decode.original.log'
assert not PCM.exists() and not LOG.exists()
command = [
    '/usr/bin/ffmpeg', '-hide_banner', '-nostdin', '-loglevel', 'info',
    '-threads', '1', '-ss', str(START), '-copyts', '-i', str(SOURCE),
    '-map', '0:v:0', '-an', '-to', str(END), '-filter_threads', '1',
    '-filter_complex_threads', '1', '-vf',
    f'trim=start={START}:end={END},showinfo', '-fps_mode', 'passthrough',
    '-q:v', '3', '-threads', '1', str(FRAMES / '%04d.jpg'),
    '-map', '0:a:0', '-vn', '-to', str(END), '-filter_threads', '1',
    '-filter_complex_threads', '1', '-af',
    f'atrim=start={START}:end={END},aformat=channel_layouts=mono,aresample=16000,ashowinfo',
    '-ac', '1', '-ar', '16000', '-threads', '1', '-c:a', 'pcm_f32le',
    '-f', 'f32le', str(PCM),
]
(OUT / 'source-decode.command.json').write_text(json.dumps(command, indent=2) + '\n')
started = time.monotonic()
termination = None
with LOG.open('xb') as log:
    process = subprocess.Popen(command, stdout=log, stderr=log, start_new_session=True)
    try:
        while process.poll() is None:
            allocated = sum(p.stat().st_blocks * 512 for p in OUT.rglob('*') if p.is_file())
            count = len(list(FRAMES.glob('*.jpg')))
            if allocated > CONFIG['captureStopAllocatedBytes'] or count > CONFIG['maximumFrames']:
                termination = 'bounded_capture_storage_or_frame_limit'
                os.killpg(process.pid, signal.SIGTERM)
                break
            if time.monotonic() - started > 120:
                termination = 'bounded_capture_wall_clock_limit'
                os.killpg(process.pid, signal.SIGTERM)
                break
            time.sleep(.2)
        code = process.wait(timeout=10)
    except BaseException:
        # Cleanup is restricted to this exact subprocess group. User browser,
        # editor and unrelated decoders must never be selected by a broad name.
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        raise

receipt = dict(originalExitCode=code, termination=termination,
    originalCommand=command, retries=0, wallSeconds=time.monotonic() - started,
    sourceBefore=CONFIG['video'], frames=len(list(FRAMES.glob('*.jpg'))),
    sourcePCMBytes=PCM.stat().st_size if PCM.exists() else 0,
    logSHA256=hashlib.sha256(LOG.read_bytes()).hexdigest(),
    sourceSHA256After=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    outputAllocatedBytes=sum(p.stat().st_blocks * 512 for p in OUT.rglob('*') if p.is_file()),
    temporalResamplingApplied=False, formalDataOrBrowserTouched=False)
(OUT / 'source-capture.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert code == 0 and termination is None, receipt
assert receipt['sourceSHA256After'] == CONFIG['video']['sha256']
assert 0 < receipt['frames'] <= CONFIG['maximumFrames']
assert receipt['outputAllocatedBytes'] <= CONFIG['maximumTotalAllocatedBytes']
print(json.dumps(receipt))
