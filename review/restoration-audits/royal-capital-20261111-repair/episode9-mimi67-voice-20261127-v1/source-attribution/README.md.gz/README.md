# Mimi route node 67: original voice identity and panel attribution

This offline review supports the source-only candidate
`vo_adv_subaru,advk_subaru_akireru` for scene `10040043`, scenario `67`,
UID `1004004300067`, stable key `s10040043-p31-at0628`.
Root approval, fresh current native/resource bindings, normal installation and
saved playback are separate. Nothing in D or C was read or written, and no
browser, API or Git operation was performed by this reviewer.

One original video window, 624.0–634.5 seconds, was decoded in a single FFmpeg
invocation. Its 314 written original frames span PTS 624.022–634.455 on the
original 1/16000 video time base. A final filtered frame at 634.488 was not
written as JPEG and is explicitly recorded as an unwritten observation.
There was no temporal frame sampling or interpolation. The same invocation
wrote 168,000 mono float PCM samples at 16 kHz, with every audio block indexed
to continuous original timestamps from 624.0 through 634.5 seconds.

Both the primary reviewer and a separately delegated reviewer inspected all
314 written frames through nine ordered sheets. The primary also inspected
13 original-size witnesses; the independent reviewer inspected 29 original-size
boundary witnesses. The latter did not read the primary findings or the new
audio result. The sequence is Ricardo holding node 66, his exit, Subaru's entry,
the node 67 native text, then node 68 while the same Subaru remains present.

Native node 67's first readable character `勘` is at frame 113 / 627.755 s.
The old approximate OCR start of 627.999 s is not the real first native text
witness. Cue zero 627.9465 s is bracketed by original frames 118 / 627.922 s
and 119 / 627.955 s. Both show Subaru alone, native name `スバル`, and the
node 67 `勘弁` prefix. Ricardo has exited and the node 68 `コンポタ` text has
not begun. The independent review retains exact adjacent-frame boundaries and
the faint-name readability ambiguity instead of inventing command timestamps.

The fresh 16 kHz signed comparison finds the same cue zero, 627.9465 s.
The complete 1.1723125-second reference has signed Pearson correlation
0.997493770. The active padded query gives 0.997493859. All 13,649 samples
above the reference threshold have nonzero recorded samples. Four consecutive
quarters of the active span give 0.993452490, 0.994344969, 0.998795089 and
0.999137541. Thus the result does not rest on a zero-energy window or one
favorable fragment of the cue.

Seven original same-bank contextual alternatives were compared in this same
recorded window and within the directly witnessed native node 67 interval.
Their maximum signed score is 0.184922061 (`advk_subaru_tanomu`); the remaining
six are at or below 0.127165278. A reversed target reaches only 0.285927844.
Shifting the target by +/-1 ms reduces the complete-cue score to 0.107326541
and 0.125148575. All source sound, exact silence and UI effects remain in the
recording; there is no source separation or synthesized replacement audio.
This fresh comparison is bounded to eight cues, not a new exhaustive-bank
search. The old 242-cue search remains historical evidence with its original
0.55 returned-peak threshold and original 0.997654 result.

`voice-source-candidate.rootfalse.json` provides the precise target and logical
resource value. Its full current native row, HEAD, catalog/package, ownership
and normal save bindings intentionally remain for root to establish. It is not
an executable normal-import packet. Normal saved playback should cover
66 -> 67 -> 68 and confirm the exact cue resolves, starts and naturally ends.
Do not turn the measured cue zero or fitted gain into a Wait, node offset,
gain field or literal original command phase.

Subjective audio listening and transcription were not available and were not
claimed. This identifies the short original cue; it does not claim that the
long displayed dialogue is fully voiced. No motion/face token, original CSV,
phase, exact timing, whole scene, continuous gameplay or full goal is accepted.

All acquisition and DSP ran at nice 19 on CPUs 0 and 1. Every FFmpeg
decoder/filter/encoder and every BLAS/OpenMP worker was limited to one thread.
The existing ARM video environment was reused without installation. This
directory is original-source evidence, not a temporary browser screenshot dump.
