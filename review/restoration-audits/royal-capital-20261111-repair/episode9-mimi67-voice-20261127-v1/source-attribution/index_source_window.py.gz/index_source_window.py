"""Index actual written frames and independent audio PTS without resampling.

Contact sheets preserve ordering and only reduce spatial size for inspection.
Showinfo may include an unencoded final read-ahead frame; it is recorded as an
unwritten observation rather than being assigned to a nonexistent JPEG.
"""

import hashlib
import json
from pathlib import Path
import re

from PIL import Image, ImageDraw


OUT = Path(__file__).resolve().parent
CONFIG = json.loads((OUT / 'inputs.rootfalse.json').read_bytes())
lines = (OUT / 'source-decode.original.log').read_text().splitlines()
video = []
audio = []
for line in lines:
    if 'Parsed_showinfo_' in line and 'pts_time:' in line:
        match = re.search(r'n:\s*(\d+) pts:\s*(\d+) pts_time:([\d.]+)', line)
        assert match, line
        number, pts, printed = match.groups()
        video.append(dict(filterFrame=int(number), pts=int(pts),
            sourceSeconds=int(pts) / 16000, printedPTSSeconds=printed))
    if 'Parsed_ashowinfo_' in line and 'pts_time:' in line:
        match = re.search(r'n:(\d+) pts:(\d+) pts_time:([\d.]+).*?rate:(\d+) nb_samples:(\d+) checksum:([0-9A-F]+)', line)
        assert match, line
        number, pts, printed, rate, count, checksum = match.groups()
        assert int(rate) == CONFIG['sourceAudioRate']
        audio.append(dict(filterFrame=int(number), pts=int(pts),
            sourceSeconds=int(pts) / int(rate), sampleRate=int(rate),
            samples=int(count), checksum=checksum, printedPTSSeconds=printed))

frames = sorted((OUT / 'source-frames').glob('*.jpg'))
assert [r['filterFrame'] for r in video] == list(range(len(video)))
assert len(video) - len(frames) == 1
assert video[-1]['sourceSeconds'] >= video[len(frames)-1]['sourceSeconds']
assert [r['filterFrame'] for r in audio] == list(range(len(audio)))
assert audio[0]['pts'] == 624 * 16000
assert all(b['pts'] == a['pts'] + a['samples'] for a, b in zip(audio, audio[1:]))
samples = sum(row['samples'] for row in audio)
assert samples * 4 == (OUT / 'source-mono-16000.f32le').stat().st_size
assert audio[-1]['pts'] + audio[-1]['samples'] == int(634.5 * 16000)

indexed = []
for number, (path, timing) in enumerate(zip(frames, video)):
    with Image.open(path) as image:
        assert list(image.size) == CONFIG['nativeDimensions']
    indexed.append(dict(path=str(path.relative_to(OUT)), bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(), frame=number + 1,
        sourcePTS=timing['pts'], sourceTimeBase=[1, 16000],
        sourceSeconds=timing['sourceSeconds']))

sheets = []
sheet_dir = OUT / 'source-sheets'
sheet_dir.mkdir()
for start in range(0, len(frames), 36):
    group = frames[start:start + 36]
    sheet = Image.new('RGB', (960, 1878), '#111111')
    draw = ImageDraw.Draw(sheet)
    for offset, frame in enumerate(group):
        image = Image.open(frame).convert('RGB')
        image.thumbnail((160, 285))
        x, y = (offset % 6) * 160, (offset // 6) * 313
        sheet.paste(image, (x, y + 25))
        entry = indexed[start + offset]
        draw.text((x + 2, y + 4), f"{entry['frame']:03d} {entry['sourceSeconds']:.4f}", fill='white')
    target = sheet_dir / f'{start+1:04d}-{start+len(group):04d}.jpg'
    sheet.save(target, quality=86)
    sheets.append(dict(path=str(target.relative_to(OUT)), firstFrame=start + 1,
        lastFrame=start + len(group), bytes=target.stat().st_size,
        sha256=hashlib.sha256(target.read_bytes()).hexdigest()))

index = dict(schema='stella.source-window-pts-index.v1', sourceVideo=CONFIG['video'],
    requestedWindowSeconds=CONFIG['sourceWindowSeconds'], frames=indexed,
    firstWrittenPTS=indexed[0]['sourceSeconds'], lastWrittenPTS=indexed[-1]['sourceSeconds'],
    unwrittenVideoFilterTail=video[len(frames):],
    discardedTailScope='One filter read-ahead frame was not encoded at the output duration boundary; no JPEG is assigned to it.',
    audioEvents=audio, audioFirstSourceSeconds=audio[0]['sourceSeconds'],
    audioSamples=samples, audioEndExclusiveSourceSeconds=(audio[-1]['pts'] + audio[-1]['samples'])/16000,
    audioContinuousSourcePTS=True, sheets=sheets,
    temporalFrameSamplingOrInterpolationApplied=False)
(OUT / 'source-pts-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps(dict(frames=len(indexed), firstPTS=indexed[0]['sourceSeconds'],
    lastPTS=indexed[-1]['sourceSeconds'], unwrittenFilterTail=video[len(frames):],
    audioFirst=audio[0]['sourceSeconds'], audioSamples=samples, sheets=len(sheets))))
