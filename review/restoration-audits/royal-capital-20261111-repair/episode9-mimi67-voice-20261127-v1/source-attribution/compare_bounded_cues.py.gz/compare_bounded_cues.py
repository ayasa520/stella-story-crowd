"""Compare eight original cues against one newly captured, PTS-indexed window.

This preserves the recorded signal, including silence and UI sounds. Signed
Pearson correlation, full-cue support and fitted residuals are reported instead
of treating a historical absolute-value peak as probability or acceptance.
No template is shortened to a favorable fragment for the full-cue checks.
"""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import wave

import numpy as np


OUT = Path(__file__).resolve().parent
CONFIG = json.loads((OUT / 'inputs.rootfalse.json').read_bytes())
INDEX = json.loads((OUT / 'source-pts-index.json').read_bytes())
assert sorted(os.sched_getaffinity(0)) == [0, 1]
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
RATE = CONFIG['sourceAudioRate']
START = INDEX['audioFirstSourceSeconds']
signal = np.fromfile(OUT / 'source-mono-16000.f32le', dtype='<f4').astype(np.float64)
assert len(signal) == INDEX['audioSamples'] == 168000
assert RATE == 16000 and START == 624
templates_dir = OUT / 'templates-mono-16000'
templates_dir.mkdir()
commands = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def decode_template(binding):
    path = Path(binding['path'])
    raw = path.read_bytes()
    assert len(raw) == binding['bytes'] and sha(raw) == binding['sha256']
    command = ['/usr/bin/ffmpeg', '-v', 'error', '-nostdin', '-threads', '1',
        '-i', str(path), '-filter_threads', '1', '-filter_complex_threads', '1',
        '-ac', '1', '-ar', str(RATE), '-threads', '1', '-f', 'f32le', 'pipe:1']
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True)
    fact = dict(cue=binding['cue'], command=command, originalExitCode=result.returncode,
        stderr=result.stderr.decode(errors='replace'), seconds=time.monotonic()-started,
        sourceSHA256Before=binding['sha256'], sourceSHA256After=sha(path.read_bytes()),
        pcmBytes=len(result.stdout), pcmSHA256=sha(result.stdout), retries=0)
    commands.append(fact)
    (OUT / 'template-decodes.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert result.returncode == 0 and fact['sourceSHA256After'] == binding['sha256'], fact
    target = templates_dir / (binding['cue'] + '.f32le')
    with target.open('xb') as stream:
        stream.write(result.stdout)
    return np.frombuffer(result.stdout, dtype='<f4').astype(np.float64)


templates = [(binding, decode_template(binding)) for binding in CONFIG['sourceCues']]
assert len(templates) == 8
fft_size = 1 << (len(signal)+max(len(samples) for _, samples in templates)-2).bit_length()
signal_fft = np.fft.rfft(signal, n=fft_size)
prefix = np.r_[0., np.cumsum(signal)]
energy = np.r_[0., np.cumsum(signal*signal)]


def fixed_comparison(source, template):
    assert len(source) == len(template) and len(source) > 0
    x = source - source.mean()
    y = template - template.mean()
    source_energy, template_energy = float(x@x), float(y@y)
    valid = source_energy > 0 and template_energy > 0
    dot = float(x@y)
    gain = dot/template_energy if template_energy else None
    correlation = dot/np.sqrt(source_energy*template_energy) if valid else None
    residual = x-gain*y if valid else x
    active = np.abs(template) >= np.max(np.abs(template))*.02
    return dict(samples=len(source), validNonzeroEnergy=valid,
        signedPearson=None if correlation is None else float(correlation),
        fittedGain=gain,
        sourceRMS=float(np.sqrt(np.mean(source*source))),
        templateRMS=float(np.sqrt(np.mean(template*template))),
        sourcePeak=float(np.max(np.abs(source))),
        templatePeak=float(np.max(np.abs(template))),
        sourceNonzeroSamples=int(np.count_nonzero(source)),
        referenceNonzeroSamples=int(np.count_nonzero(template)),
        activeReferenceSamples=int(np.count_nonzero(active)),
        activeReferenceSamplesWithNonzeroSource=int(np.count_nonzero(source[active])),
        residualRMSFraction=None if not valid else float(np.linalg.norm(residual)/np.linalg.norm(x)))


def all_signed_scores(query):
    centered = query-query.mean()
    count = len(query)
    cross = np.fft.irfft(signal_fft*np.fft.rfft(centered[::-1], n=fft_size), n=fft_size)[count-1:len(signal)]
    variance = energy[count:]-energy[:-count]-(prefix[count:]-prefix[:-count])**2/count
    template_energy = float(centered@centered)
    denominator = np.sqrt(np.maximum(variance, 0)*template_energy)
    valid = denominator > 1e-14
    scores = np.divide(cross, denominator, out=np.zeros_like(cross), where=valid)
    return scores, valid


# These conservative bounds use directly viewed, unambiguous native text
# frames, not the nominal OCR start. Boundary and independent image reports
# retain earlier actor entry and the later panel transition separately.
first_panel, last_panel = INDEX['frames'][114], INDEX['frames'][228]
LOCAL_START, LOCAL_END = first_panel['sourceSeconds'], last_panel['sourceSeconds']
results = []
for binding, template in templates:
    active = np.flatnonzero(np.abs(template) >= np.max(np.abs(template))*.02)
    assert len(active) > 0
    left = max(0, int(active[0])-round(RATE*.025))
    right = min(len(template), int(active[-1])+round(RATE*.025)+1)
    query = template[left:right]
    scores, valid = all_signed_scores(query)
    cue_zeros = START + (np.arange(len(scores))-left)/RATE
    allowed = valid & (cue_zeros+active[0]/RATE >= LOCAL_START) & (cue_zeros+active[-1]/RATE <= LOCAL_END)
    assert np.any(allowed)
    global_peak = int(np.argmax(scores))
    local_peak = int(np.argmax(np.where(allowed, scores, -np.inf)))

    def measurement(peak):
        zero = peak-left
        assert zero >= 0 and zero+len(template) <= len(signal)
        source = signal[zero:zero+len(template)]
        return dict(cueZeroSeconds=START+zero/RATE,
            trimmedSignedPearson=float(scores[peak]),
            querySourceInterval=[START+peak/RATE, START+(peak+len(query))/RATE],
            effectiveSourceInterval=[START+(zero+int(active[0]))/RATE, START+(zero+int(active[-1])+1)/RATE],
            fullCueSourceInterval=[START+zero/RATE, START+(zero+len(template))/RATE],
            fullCue=fixed_comparison(source, template))

    result = dict(cue=binding['cue'], sourceBinding=binding,
        templateSamples=len(template), templateSeconds=len(template)/RATE,
        firstEffectiveSample=int(active[0]), lastEffectiveSample=int(active[-1]),
        effectiveNonzeroThreshold=float(np.max(np.abs(template))*.02),
        trimmedQuerySampleBounds=[left, right],
        queryIncludesEveryAboveThresholdSample=True,
        globalWindow=measurement(global_peak), nativePanelLocalWindow=measurement(local_peak),
        exactZeroEnergyAlignments=int(np.count_nonzero(~valid)),
        localEligibleAlignments=int(np.count_nonzero(allowed)))
    if binding['cue'] == 'advk_subaru_akireru':
        zero = local_peak-left
        result['activeSubwindows'] = []
        splits = np.linspace(int(active[0]), int(active[-1])+1, 5, dtype=int)
        for a, b in zip(splits, splits[1:]):
            result['activeSubwindows'].append(dict(
                referenceSampleBounds=[int(a), int(b)],
                sourceInterval=[START+(zero+int(a))/RATE, START+(zero+int(b))/RATE],
                **fixed_comparison(signal[zero+a:zero+b], template[a:b])))
        result['localCueZeroTimingControls'] = []
        for delta in [-.05, -.01, -.001, 0., .001, .01, .05]:
            shifted=zero+round(delta*RATE)
            result['localCueZeroTimingControls'].append(dict(
                offsetSeconds=delta,
                **fixed_comparison(signal[shifted:shifted+len(template)], template)))
        reversed_scores, reversed_valid = all_signed_scores(query[::-1])
        reversed_peak = int(np.argmax(np.where(allowed & reversed_valid, reversed_scores, -np.inf)))
        result['reversedReferenceLocalMaximum'] = dict(
            signedPearson=float(reversed_scores[reversed_peak]),
            cueZeroSeconds=float(cue_zeros[reversed_peak]))
    results.append(result)

old_index_path = Path(CONFIG['existingMatchedClip']['path']).parent.parent/'voices-00510.00-00690.00.json'
old_raw=old_index_path.read_bytes()
old_index=json.loads(old_raw)
old_near=[]
for cue in old_index['results']:
    for peak in cue['matches']:
        if LOCAL_START <= peak['time_seconds'] <= LOCAL_END:
            old_near.append(dict(member=cue['member'], **peak))

quarter_rms=[]
for start in np.arange(0, len(signal), RATE//4):
    stop=min(len(signal), int(start)+RATE//4)
    local=signal[int(start):stop]
    quarter_rms.append(dict(sourceStartSeconds=START+int(start)/RATE,
        sourceEndSeconds=START+stop/RATE, rms=float(np.sqrt(np.mean(local*local))),
        exactNonzeroSamples=int(np.count_nonzero(local)), samples=len(local)))

report=dict(schema='stella.mimi67.bounded-signed-audio-comparison.v1',
    rootConfirmed=False, installationAuthorized=False,
    sourceWindow=[START, INDEX['audioEndExclusiveSourceSeconds']],
    sourcePCM=dict(path='source-mono-16000.f32le', bytes=(OUT/'source-mono-16000.f32le').stat().st_size,
        sha256=sha((OUT/'source-mono-16000.f32le').read_bytes()), sampleRate=RATE,
        audioOriginalTimeBase=[1,44100], analyzedPCMTimeBase=[1,RATE], firstSourcePCMPTS=INDEX['audioEvents'][0]['pts'],
        everyPCMBlockPTSContiguous=True),
    cueCount=8, boundedCompetitionNotFreshExhaustiveBankSearch=True,
    nativePanelConservativeInterval=[LOCAL_START, LOCAL_END],
    nativePanelBounds=dict(firstFrame=first_panel, lastFrame=last_panel,
        scope='Directly viewed unambiguous native67 text interval, not a command phase or exact node timestamp'),
    candidates=sorted(results,key=lambda r:r['nativePanelLocalWindow']['trimmedSignedPearson'],reverse=True),
    entireSourceQuarterSecondEnergy=quarter_rms,
    historicalFullBankSearch=dict(path=str(old_index_path), sha256=sha(old_raw),
        minimumReturnedScore=old_index['profile']['minimum_peak_score'],
        searchedCues=old_index['cues_searched'], matchingPeaksWithinCurrentVisualInterval=old_near,
        freshSearchPerformedHere=False),
    subjectiveListeningPerformed=False,
    inferenceBoundary='Waveform identity and recording-panel attribution only. Correlation is not a probability; no literal original command phase, gain, timing offset or saved gameplay is certified.',
    numpyVersion=np.__version__, fftSize=fft_size, noAudioSourceSeparation=True)
(OUT/'bounded-comparison.rootfalse.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(cueCount=8, nativePanelBounds=[LOCAL_START,LOCAL_END],
    top=[dict(cue=r['cue'],zero=r['nativePanelLocalWindow']['cueZeroSeconds'],
        trimmed=r['nativePanelLocalWindow']['trimmedSignedPearson'],full=r['nativePanelLocalWindow']['fullCue']['signedPearson'])
        for r in report['candidates']],subjectiveListeningPerformed=False)))
