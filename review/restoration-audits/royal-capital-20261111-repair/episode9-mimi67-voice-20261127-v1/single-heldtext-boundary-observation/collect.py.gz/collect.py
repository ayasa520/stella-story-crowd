"""One authorized observation of a saved buffer, never a verification retry.

All input buffers remain strongly held through every phase. This collector does
not replace a parser, repair bytes, read a D worktree input, or infer the cause
of the two preserved historical failures. Its exclusive marker prevents a
second attempt in this output directory.
"""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import sys
import time
import traceback
import zlib


OUT = Path(__file__).resolve().parent
A = OUT.parent
INPUT = A / 'episode9-mimi67-voice-root-preparation-4f865d44-20261127-v1/saved-verification-inputs-v1/08.raw.gz'
EXPECTED_GZIP_SHA = 'a9aaf975f667d05eac0b84f87284d9cf71e99d63a268bd52b14ed47549d69307'
EXPECTED_RAW_SHA = '35de0adcf6498ae3d772becb4070e0772b4df38f8af4a80ef1beef7a4bdcae78'
EXPECTED_RAW_BYTES = 4478914
MAX_OUTPUT_BYTES = 1024 * 1024
phases = []


def byte_proof(raw):
    return {'type': type(raw).__name__, 'identity': id(raw), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def metadata_bytes(value):
    return (json.dumps(value, ensure_ascii=True, separators=(',', ':')) + '\n').encode('ascii')


def output_bytes():
    return sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())


def save(name, raw):
    # The one-MiB aggregate includes this source, phase log, gzip artifacts and
    # final metadata. A capacity failure is evidence, never permission to retry.
    assert output_bytes() + len(raw) <= MAX_OUTPUT_BYTES, 'Diagnostic output cap'
    p = OUT / name
    with p.open('xb') as stream:
        stream.write(raw)
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def phase(name, **facts):
    event = {'phase': name, 'monotonicNs': time.monotonic_ns(), **facts}
    raw = metadata_bytes(event)
    assert output_bytes() + len(raw) <= MAX_OUTPUT_BYTES, 'Diagnostic output cap'
    with (OUT / 'phases.jsonl').open('ab') as stream:
        stream.write(raw)
        stream.flush()
    phases.append(event)


def first_difference(left, right):
    index = next((i for i, (a, b) in enumerate(zip(left, right)) if a != b), None)
    if index is None and len(left) != len(right):
        index = min(len(left), len(right))
    if index is None:
        return None
    lo, hi = max(0, index - 16), index + 24
    return {'byteOffset0': index, 'leftBytes': len(left), 'rightBytes': len(right),
            'contextStartByte0': lo, 'leftContextHex': left[lo:hi].hex(),
            'rightContextHex': right[lo:hi].hex()}


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
save('single-attempt-started.json', metadata_bytes({
    'rootConfirmed': False, 'diagnosticOnly': True, 'startedUTC': started,
    'pid': os.getpid(), 'targetJsonLoadsCallsAuthorized': 1,
    'verificationGateRerun': False, 'input': str(INPUT)}))
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
assert sorted(os.sched_getaffinity(0)) == [0, 1]

# Report/source files are hashed as opaque evidence, not parsed as extra target
# documents. The sole json.loads call below is visible and has no custom hooks.
evidence = []
for p in [
    A / 'mimi67-manifest-buffer-diagnostic-eeb08601-rootfalse-20261127-v1/report.rootfalse.json',
    A / 'mimi67-parent-manifest-buffer-diagnostic-4f865d44-rootfalse-20261127-v1/report.rootfalse.json',
    Path(json.__file__),
]:
    raw_evidence = p.read_bytes()
    evidence.append({'path': str(p), **byte_proof(raw_evidence)})
loads_function = json.loads
loads_identity_before = id(loads_function)
phase('BEFORE_SAVED_GZIP_READ', input=str(INPUT))
held_gzip = INPUT.read_bytes()
gzip_proof = byte_proof(held_gzip)
phase('AFTER_SAVED_GZIP_READ', gzip=gzip_proof)
assert len(held_gzip) == 121228 and gzip_proof['sha256'] == EXPECTED_GZIP_SHA

phase('BEFORE_GZIP_DECOMPRESS', gzip=byte_proof(held_gzip))
decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
held_raw = decoder.decompress(held_gzip, EXPECTED_RAW_BYTES + 1)
raw_initial = byte_proof(held_raw)
phase('AFTER_GZIP_DECOMPRESS', gzip=byte_proof(held_gzip), raw=raw_initial,
      eof=decoder.eof, unusedBytes=len(decoder.unused_data),
      unconsumedBytes=len(decoder.unconsumed_tail))
assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
assert len(held_raw) == EXPECTED_RAW_BYTES and raw_initial['sha256'] == EXPECTED_RAW_SHA

phase('BEFORE_UTF8_SURROGATEPASS_DECODE', gzip=byte_proof(held_gzip), raw=byte_proof(held_raw))
# Keep these adjacent: the first roundtrip captures the freshly returned str
# before any collector logging or other allocation-heavy operation occurs.
held_text = held_raw.decode('utf-8', 'surrogatepass')
held_roundtrip = held_text.encode('utf-8', 'surrogatepass')
text_initial = {'type': type(held_text).__name__, 'identity': id(held_text),
                'codepoints': len(held_text), 'utf8Surrogatepass': byte_proof(held_roundtrip)}
phase('AFTER_UTF8_SURROGATEPASS_DECODE', raw=byte_proof(held_raw), text=text_initial,
      roundtripEqualsHeldRaw=held_roundtrip == held_raw,
      firstDifferenceRawVsRoundtrip=first_difference(held_raw, held_roundtrip))
before_text_gzip = save('text-immediate-roundtrip.gz', gzip.compress(held_roundtrip, compresslevel=1, mtime=0))

held_text_before_parse_bytes = held_text.encode('utf-8', 'surrogatepass')
raw_before_parse = byte_proof(held_raw)
text_before_parse = {'type': type(held_text).__name__, 'identity': id(held_text),
                     'codepoints': len(held_text), 'utf8Surrogatepass': byte_proof(held_text_before_parse_bytes)}
phase('BEFORE_JSON_LOADS_HELD_TEXT', raw=raw_before_parse, text=text_before_parse,
      sameTextIdentityAsDecode=id(held_text) == text_initial['identity'],
      roundtripVsBeforeParse=first_difference(held_roundtrip, held_text_before_parse_bytes),
      jsonLoadsFunctionIdentity=id(json.loads))

parsed = None
held_error = None
held_exception_doc = None
held_exception_doc_bytes = None
original_traceback = None
parse_ok = False
target_loads_call_count = 1
try:
    parsed = json.loads(held_text)
    parse_ok = True
except BaseException as error:
    held_error = error
    held_exception_doc = getattr(error, 'doc', None)
    if isinstance(held_exception_doc, str):
        held_exception_doc_bytes = held_exception_doc.encode('utf-8', 'surrogatepass')
    original_traceback = traceback.format_exc()

# Capture the same held objects, never reread or reconstruct an input. The
# original exception, its doc and parsed result all remain held until exit.
raw_after_parse = byte_proof(held_raw)
held_text_after_parse_bytes = held_text.encode('utf-8', 'surrogatepass')
text_after_parse = {'type': type(held_text).__name__, 'identity': id(held_text),
                    'codepoints': len(held_text), 'utf8Surrogatepass': byte_proof(held_text_after_parse_bytes)}
exception_metadata = None
if held_error is not None:
    exception_metadata = {'type': type(held_error).__name__, 'identity': id(held_error),
        'message': str(held_error), 'position': getattr(held_error, 'pos', None),
        'line': getattr(held_error, 'lineno', None), 'column': getattr(held_error, 'colno', None),
        'docType': type(held_exception_doc).__name__, 'docIdentity': id(held_exception_doc),
        'docIsHeldText': held_exception_doc is held_text, 'traceback': original_traceback}
    if held_exception_doc_bytes is not None:
        exception_metadata.update(docCodepoints=len(held_exception_doc),
            docUtf8Surrogatepass=byte_proof(held_exception_doc_bytes),
            firstDifferenceBeforeTextVsDoc=first_difference(held_text_before_parse_bytes, held_exception_doc_bytes),
            firstDifferenceAfterTextVsDoc=first_difference(held_text_after_parse_bytes, held_exception_doc_bytes))
phase('AFTER_JSON_LOADS_HELD_TEXT', parseOk=parse_ok, raw=raw_after_parse, text=text_after_parse,
      sameRawIdentity=raw_after_parse['identity'] == raw_before_parse['identity'],
      sameTextIdentity=text_after_parse['identity'] == text_before_parse['identity'],
      firstDifferenceBeforeVsAfterText=first_difference(held_text_before_parse_bytes, held_text_after_parse_bytes),
      firstDifferenceRawVsAfterText=first_difference(held_raw, held_text_after_parse_bytes),
      jsonLoadsFunctionIdentity=id(json.loads), exception=exception_metadata)

archives = {'immediateTextRoundtrip': before_text_gzip}
if held_exception_doc_bytes is not None:
    archives['originalExceptionDoc'] = save('original-exception-doc.gz', gzip.compress(held_exception_doc_bytes, compresslevel=1, mtime=0))
if raw_after_parse['sha256'] != raw_initial['sha256']:
    archives['changedHeldRawAfter'] = save('held-raw-after.gz', gzip.compress(held_raw, compresslevel=1, mtime=0))
if held_text_after_parse_bytes != held_text_before_parse_bytes:
    archives['changedHeldTextAfter'] = save('held-text-after.gz', gzip.compress(held_text_after_parse_bytes, compresslevel=1, mtime=0))

report = {'schema': 'stella.mimi67.single-heldtext-phase-boundary.rootfalse.v1',
    'rootConfirmed': False, 'diagnosticOnly': True, 'startedUTC': started,
    'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pythonVersion': sys.version, 'pythonExecutable': sys.executable,
    'nice': os.getpriority(os.PRIO_PROCESS, 0), 'cpuAffinity': sorted(os.sched_getaffinity(0)),
    'inputPath': str(INPUT), 'inputCompressedHeldProof': gzip_proof,
    'expectedRawBytes': EXPECTED_RAW_BYTES, 'expectedRawSha256': EXPECTED_RAW_SHA,
    'gzipSingleMemberAndCRCValidated': True,
    'targetJsonLoadsCallCount': target_loads_call_count, 'inputTypePassedToLoads': 'str',
    'explicitDecode': {'encoding': 'utf-8', 'errors': 'surrogatepass'},
    'parseOk': parse_ok, 'resultType': type(parsed).__name__ if parse_ok else None,
    'resultRootLength': len(parsed) if parse_ok and isinstance(parsed, (dict, list)) else None,
    'rawBeforeDecode': raw_initial, 'rawBeforeParse': raw_before_parse, 'rawAfterParse': raw_after_parse,
    'textImmediatelyAfterDecode': text_initial, 'textBeforeParse': text_before_parse,
    'textAfterParse': text_after_parse, 'exception': exception_metadata,
    'rawHashesEqual': raw_initial['sha256'] == raw_before_parse['sha256'] == raw_after_parse['sha256'],
    'textRoundtripHashesEqual': text_initial['utf8Surrogatepass']['sha256'] == text_before_parse['utf8Surrogatepass']['sha256'] == text_after_parse['utf8Surrogatepass']['sha256'],
    'loadsFunctionIdentityUnchanged': id(json.loads) == loads_identity_before,
    'archives': archives, 'evidenceReferences': evidence,
    'phaseCount': len(phases), 'phaseLog': str(OUT / 'phases.jsonl'),
    'aggregateOutputCapBytes': MAX_OUTPUT_BYTES,
    'historicalFailuresRemainFailed': True, 'originalErrorDisappearanceClaimed': False,
    'mechanismOrCause': 'unknown', 'savedVerifierOrGateRerun': False,
    'savedGzipReadCount': 1, 'targetInputRereadOrRetry': False,
    'parserModifiedOrReplaced': False, 'bufferNormalizedOrRepaired': False,
    'worktreeInputContentsRead': False, 'DOrCWrite': False, 'gitMutation': False,
    'browserApiInstallGlobalChange': False,
    'discoveryBoundary': 'Prior path discovery enumerated filenames under A including D paths; no D file content was opened. This process reads only exact saved/evidence/stdlib paths.',
    'conclusionScope': 'Only this one explicit decoded-str invocation and its held-buffer boundaries. Success cannot erase either historical failed bytes-input parse or establish a cause; failure preserves its original doc and traceback.'}
report_ref = save('report.rootfalse.json', metadata_bytes(report))
assert output_bytes() <= MAX_OUTPUT_BYTES
print(json.dumps({'report': report_ref, 'parseOk': parse_ok,
    'outputBytesIncludingSource': output_bytes(), 'phaseCount': len(phases),
    'targetJsonLoadsCalls': target_loads_call_count}, separators=(',', ':')), flush=True)
sys.exit(0 if parse_ok else 1)
