"""Freeze a future published choice-label repair; never run or repair it here.

Root must first bind the ordinary translations stage/audit/apply, postapply and
exact publication proof. This helper only reads that saved revision and writes
new private binding/plan files. It never promotes proposal flags or fills state.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = HERE.parent / 'data-checkout'
SOURCE = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout'
PROPOSAL = HERE.parent / 'episode11-choice92-translation-normal-rootfalse-v1/translations.rootfalse.json'
MINIMUM_GLOBAL = HERE.parent / 'episode11-current-saved-global-guards-v1.json'
PREVIOUS_PLAN = HERE.parent / 'episode11-scene10110003-normal-saved-runtime-rootfalse-v1/capture-plan.json'

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()

def write(name, value):
    with (HERE / name).open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

parser = argparse.ArgumentParser()
parser.add_argument('--root-inputs', required=True)
parser.add_argument('--root-inputs-sha256', required=True)
args = parser.parse_args()
release_path = Path(args.root_inputs).resolve()
assert sha(release_path) == args.root_inputs_sha256
release = load(release_path)
assert release['rootConfirmed'] is True and release['preparationAuthorized'] is True
assert release['browserLaunchAuthorized'] is False
assert re.fullmatch('[0-9a-f]{40}', release['publishedHead'] or '')
assert git(DATA, 'rev-parse', 'HEAD') == release['publishedHead']
assert git(DATA, 'status', '--short') == ''
assert git(SOURCE, 'rev-parse', 'HEAD') == release['sourceHead']
assert git(SOURCE, 'status', '--short') == release['sourceStatus']
assert git(SOURCE, 'diff', '--name-only', 'HEAD') == ''
assert isinstance(release['browserOwner'], str) and release['browserOwner'].startswith('/root/')
assert sha(SOURCE / 'dist/server/index.js') == release['expectedDistServerSha256']
for kind, key in [('native', 'expectedNativeSha256'), ('review', 'expectedReviewSha256')]:
    assert sha(DATA / f'{kind}/scenes/10110003.json') == release[key]

assert sha(PROPOSAL) == '1d4ab9100ab2f763d8fab7ea142a5b2dc9372a32427358602b59ecb20b12b8c4'
assert sha(MINIMUM_GLOBAL) == '35069e57eebc7e71cfba6cf93c6e35290463a1c95b29299d0985301738a0f859'
packet_ref = release['approvedTranslationsPacket']
assert sha(packet_ref['path']) == packet_ref['sha256']
packet, proposal = load(packet_ref['path']), load(PROPOSAL)
assert packet['rootConfirmed'] is True and packet['language'] == 'zh-CN'
assert packet['sceneId'] == 10110003 and packet['preserveUnchanged'] is True
assert len(packet['scenarios']) == 46
keys = ('scenarioId', 'stableKey', 'sourceText', 'translation', 'branches')
assert [{k: row[k] for k in keys} for row in packet['scenarios']] == [
    {k: row[k] for k in keys} for row in proposal['scenarios']]
assert [(row['scenarioId'], b['branchId']) for row in packet['scenarios'] for b in row['branches']] == [(9, 92)]
guards = {str(release_path): sha(release_path), packet_ref['path']: packet_ref['sha256'],
          str(PROPOSAL): sha(PROPOSAL), str(MINIMUM_GLOBAL): sha(MINIMUM_GLOBAL),
          str(PREVIOUS_PLAN): sha(PREVIOUS_PLAN)}
assert set(release['normalSaveReceipts']) == {'stage', 'audit', 'apply', 'postapply', 'exactMainACK'}
for ref in release['normalSaveReceipts'].values():
    assert ref['acceptedByRoot'] is True and ref['path'] and ref['sha256']
    assert sha(ref['path']) == ref['sha256']
    guards[ref['path']] = ref['sha256']
guards.update(release['additionalEvidenceGuards'])
global_ref = release['globalGuardSnapshot']
assert sha(global_ref['path']) == global_ref['sha256']
guards[global_ref['path']] = global_ref['sha256']
global_guards = load(global_ref['path'])['guards']
assert set(load(MINIMUM_GLOBAL)['guards']) <= set(global_guards)
assert len(global_guards) >= 951
for path, digest in {**guards, **global_guards}.items():
    assert sha(ROOT / path) == digest, path

native, review = [load(DATA / f'{kind}/scenes/10110003.json') for kind in ('native', 'review')]
rows = {row['scenario_id']: row for row in native['scenario_list']}
assert list(rows) == list(range(1, 47))
# The accepted full-scene plan holds the complete saved rows before this label
# repair. Project only that one leaf for comparison; do not write the projection
# or use it as a replacement player program. All commands/IDs/targets stay exact.
baseline_rows = [deepcopy(step['native']) for step in load(PREVIOUS_PLAN)['steps']]
assert len(baseline_rows) == 46
left_before = next(b for b in baseline_rows[8]['branch_list'] if b['branch_id'] == 92)
assert left_before['msg_quote_subject'] == '感叹结果'
left_before['msg_quote_subject'] = '哀叹结果'
assert native['scenario_list'] == baseline_rows
left = next(b for b in rows[9]['branch_list'] if b['branch_id'] == 92)
right = next(b for b in rows[9]['branch_list'] if b['branch_id'] == 93)
assert left['type'] == 2 and left['msg_quote_subject'] == '哀叹结果'
assert left['msg_quote'] == '' and left['transition_list'] == []
assert right['type'] == 3 and right['msg_quote_subject'] == '回答问题'
note = next(b for b in review['scenarios']['9']['branches'] if b['branchId'] == 92)
assert note['sourceLabel'] == '結果を嘆く' and note['sourceQuote'] == '' and note['state'] == 'missing'
steps = []
for scenario, model, branch_id in [(8, 'subaru01', 81), (9, 'rom01', 93), (10, 'rom01', 101)]:
    row, note = rows[scenario], review['scenarios'][str(scenario)]
    assert row['character'] == 'live2d/AC_' + model and row['bg_picture'] == ''
    uid = note.get('studioNodeId') or row['uniq_id']
    branch = next(b for b in row['branch_list'] if b['branch_id'] == branch_id)
    assert len(branch['transition_list']) == 1
    assert branch['transition_list'][0]['next_scenario_id'] == scenario + 1
    steps.append({'id': f'node:10110003:{uid}', 'scenario': scenario, 'native': row,
                  'expectedModel': model, 'branchId': branch_id, 'expectedTransition': branch['transition_list'][0]})
assert steps[0]['id'] == 'node:10110003:1011000300008'
assert rows[2]['bg_picture'] == 'bg/bg031b_stealshop'
manifest = load(DATA / 'manifest.json')
paths = {'manifest.json', 'review/native-restoration.json', 'assets/catalog.json', 'assets/package.json', 'assets/preview/catalog.json'}
paths.update(s[key] for s in manifest['scenes'] for key in ('path', 'reviewPath'))
paths.update(str(p.relative_to(DATA)) for p in (DATA / 'review/restoration-batches').glob('*.json'))
for model in ('subaru01', 'rom01'):
    for pattern in [f'assets/models/{model}/**/*', f'assets/preview/models/{model}/**/*',
                    f'assets/portraits/{model}.*', f'assets/preview/portraits/{model}.*']:
        paths.update(str(p.relative_to(DATA)) for p in DATA.glob(pattern) if p.is_file())
for pattern in ['assets/player/**/*', 'assets/backgrounds/ADV_bg031b_stealshop.*',
                'assets/preview/backgrounds/ADV_bg031b_stealshop.*', 'assets/music/*', 'assets/preview/music/*']:
    paths.update(str(p.relative_to(DATA)) for p in DATA.glob(pattern) if p.is_file())
for path in paths:
    if path.startswith(('native/', 'review/restoration-batches/')) or path in (
            'manifest.json', 'review/native-restoration.json', 'assets/catalog.json', 'assets/package.json'):
        assert str((DATA / path).relative_to(ROOT)) in global_guards, path
protected = load(HERE.parent / 'p42-six-visual-saved-runtime-v1/input-binding.json')['protectedFirstThree']
assert len(protected) == 22 and {p: sha(DATA / p) for p in protected} == protected
source_files = {p: sha(SOURCE / p) for p in sorted(git(SOURCE, 'ls-files').splitlines()) if (SOURCE / p).is_file()}
dist_files = {str(p.relative_to(SOURCE / 'dist')): sha(p) for p in sorted((SOURCE / 'dist').rglob('*')) if p.is_file()}
plan = {'schema': 'stella.choice92.saved-plan.v1', 'rootConfirmed': False, 'sceneId': 10110003,
        'start': steps[0]['id'], 'steps': steps, 'sceneRows': 46,
        'allLibraryNodes': sum(len(load(DATA / s['path'])['scenario_list']) for s in manifest['scenes']),
        'recordedChoice': {'scenario': 9, 'branchId': 93, 'label': right['msg_quote_subject'], 'quote': right['msg_quote']},
        'unknownBranch': {'scenario': 9, 'branchId': 92, 'label': left['msg_quote_subject']},
        'expectedChoiceUI': {'left': '← 哀叹结果 · 未恢复', 'right': '→ ' + right['msg_quote_subject']},
        'expectedEffectiveBackground': 'bg/bg031b_stealshop', 'expectedBackgroundProvider': 2,
        'stop': {'scenario': 10, 'phase': 'ready', 'forbiddenBranch': 101, 'forbiddenScenario': 11},
        'captureFormat': {'type': 'image/jpeg', 'quality': .9, 'viewport': {'width': 440, 'height': 900},
                          'count': 3, 'maximumCaptureBytes': 750000},
        'acceptanceScope': 'Only saved choice92 label visibility/missing state, unchanged93 label/quote, and ordinary8→9→10 traversal with unchanged actors/store BG. No choice92 or101 execution, body/face/extra/audio/timing/FX or whole-scene/episode/goal acceptance.'}
write('capture-plan.json', plan)
write('input-binding.json', {'schema': 'stella.choice92.saved-inputs.v1', 'rootConfirmed': False,
      'dataRoot': str(DATA), 'sourceRoot': str(SOURCE), 'dataHead': release['publishedHead'], 'dataStatus': '',
      'revision': release['publishedHead'], 'revisionMeaning': 'Actual published ordinary Git commit',
      'dataInputs': {p: sha(DATA / p) for p in sorted(paths)}, 'protectedFirstThree': protected,
      'resourceAndSourceGuards': guards, 'globalGuards': global_guards, 'browserOwner': release['browserOwner'],
      'source': {'head': release['sourceHead'], 'status': release['sourceStatus'],
                 'sourceFiles': source_files, 'distFiles': dist_files},
      'planSha256': sha(HERE / 'capture-plan.json'), 'browserOrServerStarted': False})
print(json.dumps({'status': 'frozen-not-executed', 'dataHead': release['publishedHead'],
                  'sourceHead': release['sourceHead'], 'nodes': 3, 'dataInputs': len(paths), 'globalGuards': len(global_guards)}))
