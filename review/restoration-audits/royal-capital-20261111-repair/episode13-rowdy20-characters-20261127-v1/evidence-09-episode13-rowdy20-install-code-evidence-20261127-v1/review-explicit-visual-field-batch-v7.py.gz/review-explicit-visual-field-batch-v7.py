"""Prepare one explicit character or CG packet or review its normal stage.

This helper never imports or installs a business batch. The unchanged native
repair/install CLIs remain separate, observable calls. Historical data-file
references are verified against their real Git blobs before rebinding; source
images and original resources must still match their sealed bytes exactly.
"""
import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
REFERENCE = A / 'episode10-scene54-27-characters-root-preparation-87482d95-v1/preflight.root-approved.json'
CONTRACT_EXAMPLE = A / 'episode10-scene54-27-characters-root-preparation-87482d95-v1/node-fields.root-approved.json'
FIELDS = {'bg_music', 'bg_picture', 'character', 'character_image', 'motion',
          'msg_character', 'msg_text', 'position', 'se', 'talk_chara', 'video', 'voice', 'command'}
READ_NUMBER = 0


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def load(path, expected_sha256=None):
    global READ_NUMBER
    # Keep exactly the held bytes given to JSON, before parsing. A previous
    # read-only review failed on a control character without retaining its
    # input; a later successful disk read cannot substitute for that missing
    # observation. This records every original input and never retries it.
    READ_NUMBER += 1
    raw = Path(path).read_bytes()
    stem = Path(args.read_log) / f'{READ_NUMBER:03d}'
    stem.with_suffix('.raw.gz').write_bytes(gzip.compress(raw, mtime=0))
    fact = dict(path=str(path), bytes=len(raw), sha256=sha(raw), retryCount=0)
    if expected_sha256 is not None:
        fact['expectedSHA256'] = expected_sha256
        if fact['sha256'] != expected_sha256:
            fact.update(parsed=False, errorType='ExpectedJsonDigestMismatch')
            write_new(stem.with_suffix('.json'), fact)
            raise ValueError(f'Expected JSON digest mismatch: {path}')
    try:
        result = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        fact.update(error=str(error), errorType=type(error).__name__, cause='unknown')
        if isinstance(error, json.JSONDecodeError):
            doc = error.doc.encode('utf-8', 'surrogatepass')
            stem.with_suffix('.exception-doc.gz').write_bytes(gzip.compress(doc, mtime=0))
            fact.update(position=error.pos, line=error.lineno, column=error.colno,
                exceptionDocSHA256=sha(doc))
        write_new(stem.with_suffix('.json'), fact)
        raise
    fact['parsed'] = True
    write_new(stem.with_suffix('.json'), fact)
    return result


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(D), *args])


def assert_current(head):
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('status', '--short') == b''


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value))


def verify_guards(guards):
    for path, expected in guards.items():
        with Path(path).open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected, path



def resolve_reference(name, document):
    """Use the same project/document-relative reference rule as the old walker."""
    raw_ref = Path(name)
    if raw_ref.is_absolute():
        return raw_ref.resolve()
    assert '..' not in raw_ref.parts, str(raw_ref)
    project_prefixes = {'data', 'artifacts', 'story_studio', 'logs', 'lost_in_memories'}
    base = ROOT if raw_ref.parts[0] in project_prefixes else document.parent
    ref = (base / raw_ref).resolve()
    assert ref.is_relative_to(base), str(ref)
    return ref


def direct_evidence_references(packet, candidate):
    """Protect every path declared directly inside each change's evidence."""
    references = set()

    def visit(value):
        if isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            # Do not require a valid digest to recognize protected evidence.
            # A malformed source/peer digest must not make its path eligible
            # for a role override that would suppress recursive validation.
            if isinstance(value.get('path'), str):
                references.add(resolve_reference(value['path'], candidate))
            for item in value.values():
                visit(item)
    for change in packet['changes']:
        visit(change.get('evidence', {}))
    return references



def actual_evidence_reference_closure(packet, candidate):
    """Protect actual evidence before considering any proposed role override."""
    protected = direct_evidence_references(packet, candidate)
    guards, visited, pending = {}, set(), []

    def discover(value, document):
        if isinstance(value, list):
            for item in value:
                discover(item, document)
        elif isinstance(value, dict):
            # Match the existing walker's explicit sealed-reference contract.
            # Discovery is independent of the new role manifest, so a proposed
            # guard-only index cannot hide itself or any actual descendants.
            if (isinstance(value.get('path'), str)
                    and re.fullmatch('[0-9a-f]{64}', str(value.get('sha256', '')))):
                ref = resolve_reference(value['path'], document)
                protected.add(ref)
                if (ref != CONTRACT_EXAMPLE and ref.is_relative_to(A)
                        and not ref.is_relative_to(D) and ref.suffix == '.json'):
                    pending.append((ref, value['sha256']))
            for item in value.values():
                discover(item, document)

    for change in packet['changes']:
        discover(change.get('evidence', {}), candidate)
    while pending:
        path, expected = pending.pop()
        if path in visited:
            assert guards[str(path)] == expected, str(path)
            continue
        # Only A-owned evidence JSON is parsed here. D metadata and binary
        # payloads are protected as referenced paths but are not read during
        # discovery; the normal fresh/ancestor-aware walker still validates
        # every payload later. The old CONTRACT_EXAMPLE remains hash-only.
        value = load(path, expected_sha256=expected)
        visited.add(path)
        guards[str(path)] = expected
        discover(value, path)
    return protected, guards


class GuardOnlyReferenceRoles:
    """Validate a root decision without weakening any file-content guard."""

    def __init__(self, manifest, expected_sha256, candidate, candidate_sha256, packet):
        self.references = {}
        self.used = set()
        self.manifest_guard = {}
        self.evidence_guards = {}
        self.receipt = None
        if manifest is None:
            assert expected_sha256 is None
            return
        assert isinstance(expected_sha256, str) and re.fullmatch('[0-9a-f]{64}', expected_sha256)
        path = Path(manifest)
        assert path.is_absolute() and path == path.resolve()
        assert path.is_relative_to(A) and not path.is_relative_to(D)
        assert path.suffix == '.json' and path.is_file() and path != candidate
        # The original candidate directory is an explicit walker seed. A role
        # manifest placed there would otherwise count its own listed targets
        # as used, even when the sealed candidate never referenced them.
        assert path.parent != candidate.parent
        decision = load(path, expected_sha256=expected_sha256)
        assert set(decision) == {'schema', 'rootConfirmed', 'rootReviewed', 'candidate',
                                 'guardOnlyReferences'}
        assert decision['schema'] == 'stella.root-reference-roles.v1'
        assert decision['rootConfirmed'] is True and decision['rootReviewed'] is True
        assert decision['candidate'] == dict(path=str(candidate), sha256=candidate_sha256)
        entries = decision['guardOnlyReferences']
        assert isinstance(entries, list) and entries
        protected, self.evidence_guards = actual_evidence_reference_closure(packet, candidate)
        for entry in entries:
            assert set(entry) == {'path', 'sha256', 'role', 'reason', 'rootConfirmed'}
            assert entry['rootConfirmed'] is True
            assert entry['role'] == 'guard-only-shape-contract'
            assert isinstance(entry['reason'], str) and entry['reason'].strip()
            assert isinstance(entry['sha256'], str) and re.fullmatch('[0-9a-f]{64}', entry['sha256'])
            ref = Path(entry['path'])
            assert ref.is_absolute() and ref == ref.resolve()
            assert ref.is_relative_to(A) and not ref.is_relative_to(D)
            assert ref.suffix == '.json' and ref.is_file()
            # Root may classify an external schema/example contract, never
            # this candidate's inputs or any direct or indirect actual
            # source/peer/model/frame evidence. The immutable packet is not edited
            # and all remaining references follow the unchanged recursive path.
            assert ref != candidate and ref != path and ref.parent != candidate.parent
            assert ref not in protected and ref not in self.references
            self.references[ref] = dict(entry)
        self.manifest_guard[str(path)] = expected_sha256
        self.receipt = dict(path=str(path), sha256=expected_sha256,
                            guardOnlyReferences=entries,
                            protectedActualEvidencePaths=len(protected),
                            protectedActualEvidenceJsonGuards=self.evidence_guards)

    def omit_recursion(self, ref, declared_sha256, actual_sha256):
        entry = self.references.get(ref)
        if entry is None:
            return False
        # This decision is considered only after the normal walker has read
        # and hashed the actual file. Suppression changes graph traversal,
        # never the requirement that declared, root-bound and held bytes agree.
        assert declared_sha256 == actual_sha256 == entry['sha256'], str(ref)
        self.used.add(ref)
        return True

    def require_all_used(self):
        # A stale, misspelled or unrelated role entry must not silently pass.
        assert self.used == set(self.references), 'Unused guard-only reference roles'


def prepare(args):
    candidate, out = Path(args.candidate).resolve(), Path(args.preparation).resolve()
    assert candidate.is_relative_to(A) and not candidate.is_relative_to(D)
    assert out.parent == A and not out.exists()
    raw = candidate.read_bytes()
    assert sha(raw) == args.candidate_sha256
    packet = json.loads(raw)
    reference_roles = GuardOnlyReferenceRoles(args.reference_roles,
        args.reference_roles_sha256, candidate, sha(raw), packet)
    assert packet.get('requiredAssetImports', []) == []
    head = git('rev-parse', 'HEAD').decode().strip()
    assert_current(head)
    historical = args.evidence_base
    assert re.fullmatch('[0-9a-f]{40}', historical)
    git('merge-base', '--is-ancestor', historical, head)
    # Metadata snapshots can predate a separately published resource import.
    # Keep that metadata epoch authoritative for every sealed-reference drift;
    # the optional resource epoch changes ONLY the positive catalog comparison.
    # An explicit resource commit must still be a real ancestor of this HEAD,
    # so selecting it cannot waive the current package or source-evidence guards.
    resource_historical = historical
    if args.resource_evidence_base is not None:
        resource_historical = args.resource_evidence_base
        assert re.fullmatch('[0-9a-f]{40}', resource_historical)
        git('merge-base', '--is-ancestor', resource_historical, head)
    field = args.field
    changes = packet['changes']
    scenes = {c['sceneId'] for c in changes}
    assert len(scenes) == 1 and len(changes) == args.count
    scene = next(iter(scenes))
    before = load(D / f'native/scenes/{scene}.json')
    review = load(D / f'review/scenes/{scene}.json')
    catalog = load(D / 'assets/catalog.json')
    old_catalog = json.loads(git('show', resource_historical + ':assets/catalog.json'))
    resource_entry_proofs = {}
    selected = set()
    rebindable_data = {'manifest.json', 'review/native-restoration.json',
        'assets/catalog.json', 'assets/package.json',
        f'native/scenes/{scene}.json', f'review/scenes/{scene}.json'}
    for c in changes:
        assert set(c['fields']) == {field} and set(c['expected']) == FIELDS
        index = c['arrayIndex']
        row = before['scenario_list'][index]
        assert index not in selected
        selected.add(index)
        assert row['scenario_id'] == c['scenarioId'] and row['uniq_id'] == c['uniqueId']
        assert review['scenarios'][str(c['scenarioId'])]['stableKey'] == c['stableKey']
        assert all(row[k] == v for k, v in c['expected'].items())
        assert c['expected'][field] == '' and c['fields'][field]
        if 'fullNativeRowBefore' in c:
            assert row == c['fullNativeRowBefore']
        # A scalar CG is an explicit picture resource, not a Live2D actor.
        # Validate its own catalog contract and payload rather than inferring
        # model inheritance or reusing the character detail-url requirement.
        token = c['fields'][field]
        section, url_key = ('models', 'detail_url') if field == 'character' else ('pictures', 'url')
        current_entry = catalog[section][token]
        historical_entry = old_catalog[section][token]
        assert current_entry == historical_entry
        # Retain the WHOLE entries, once per selected token, in both the packet
        # and approval. A chosen commit or entry digest alone would not expose
        # which catalog contract was proved; scenario IDs bind every use of it.
        if token not in resource_entry_proofs:
            resource_entry_proofs[token] = dict(
                field=field, catalogSection=section, token=token,
                selectedScenarioIds=[], currentHead=head,
                resourceEvidenceBase=resource_historical,
                currentCatalogEntry=deepcopy(current_entry),
                historicalCatalogEntry=deepcopy(historical_entry),
                completeEntriesExact=True)
        resource_entry_proofs[token]['selectedScenarioIds'].append(c['scenarioId'])
        assert (D / 'assets' / catalog[section][token][url_key]).is_file()
        c.update(rootConfirmed=True, rootReviewed=True, executionAuthorized=True,
                 installationAuthorized=True)
    # Follow explicit sealed references only. A stale data reference is not
    # silently accepted: its old digest must match the stated ancestor's blob.
    # Current selected rows and every other formal file are guarded separately.
    guards = {**reference_roles.manifest_guard, **reference_roles.evidence_guards}
    rebounds, visited = [], set()
    pending = list(sorted(candidate.parent.glob('*.json')))
    while pending:
        path = pending.pop().resolve()
        if path in visited:
            continue
        visited.add(path)
        data = path.read_bytes()
        current_sha = sha(data)
        assert str(path) not in guards or guards[str(path)] == current_sha
        guards[str(path)] = current_sha
        if path.suffix != '.json':
            continue
        try:
            value = json.loads(data)
        except json.JSONDecodeError:
            # Preserve the actual failing bytes, never a replacement parse.
            out.mkdir(exist_ok=True)
            (out / 'preparation-json-failure.raw.gz').write_bytes(gzip.compress(data, mtime=0))
            raise

        def visit(obj):
            if isinstance(obj, list):
                for item in obj:
                    visit(item)
            elif isinstance(obj, dict):
                if isinstance(obj.get('path'), str) and re.fullmatch('[0-9a-f]{64}', str(obj.get('sha256', ''))):
                    ref = resolve_reference(obj['path'], path)
                    actual_raw = ref.read_bytes()
                    actual = sha(actual_raw)
                    if actual != obj['sha256']:
                        assert ref.is_relative_to(D), str(ref)
                        relative = str(ref.relative_to(D))
                        # Historical metadata can legitimately advance after
                        # another owned publication. Original model/image/media
                        # payload drift always fails rather than being rebound.
                        assert relative in rebindable_data, relative
                        assert sha(git('show', historical + ':' + relative)) == obj['sha256'], str(ref)
                        rebounds.append(dict(path=str(ref), historicalSHA256=obj['sha256'],
                            historicalHead=historical, currentSHA256=actual, currentHead=head))
                    assert str(ref) not in guards or guards[str(ref)] == actual
                    guards[str(ref)] = actual
                    # The packet explicitly labels this historical file as
                    # referencePacketReadOnlyShapeOnly. Lock its exact bytes,
                    # but do not reinterpret its old Julius evidence graph as
                    # evidence for the current Ram/Mimi/Otto character packet.
                    guard_only = reference_roles.omit_recursion(ref, obj['sha256'], actual)
                    if (not guard_only and ref != CONTRACT_EXAMPLE and ref.is_relative_to(A)
                            and not ref.is_relative_to(D) and ref.suffix == '.json'):
                        pending.append(ref)
                for item in obj.values():
                    visit(item)
        visit(value)
    reference_roles.require_all_used()
    assert_current(head)
    for path, expected in {
        ROOT / 'story_studio/recovery/native_repair.py': '0efd16bc38b9406865fd8fe6936be0b2f0dd670ae74059798ace156fb2d0d1a2',
        ROOT / 'story_studio/recovery/native_install.py': '6b8196319ca7afc44943cb26341caf23cec2f8ed3649c82a8248f62b2a47db27',
    }.items():
        assert sha(path.read_bytes()) == expected, str(path)
        guards[str(path)] = expected
    for path in [Path(__file__).resolve(), A / 'observe-original-business-gate-v1.py']:
        guards[str(path)] = sha(path.read_bytes())
    formal = {p: sha(Path(p).read_bytes()) for p in load(REFERENCE)['all285GlobalSceneMetadataAndAssetGuards']}
    assert len(formal) == 285
    protected = load(REFERENCE)['protectedFirstThree']
    verify_guards({str(D / p): h for p, h in protected.items()})
    packet.update(rootConfirmed=True, rootReviewed=True, executionAuthorized=True,
        installationAuthorized=True, candidateOnly=False, baseSha=head, expectedHead=head,
        normalSaveOrAPIPacketReady=True,
        rootMustFreshRebindHEADOwnershipManifestFullGlobalAndNormalSaveBeforeApplying=False)
    packet['rootHistoricalDataRebindings'] = rebounds
    evidence_bases = dict(metadataEvidenceBase=historical,
        resourceEvidenceBase=resource_historical, currentHead=head,
        explicitResourceEvidenceBase=args.resource_evidence_base is not None)
    resource_catalog_proofs = [resource_entry_proofs[token] for token in sorted(resource_entry_proofs)]
    packet['rootEvidenceBases'] = evidence_bases
    packet['rootResourceCatalogEntryProofs'] = resource_catalog_proofs
    if reference_roles.receipt is not None:
        packet['rootReferenceRoles'] = reference_roles.receipt
    packet['rootScope'] = 'Static explicit resource identity only; complete entry, acting, phase and gameplay remain unaccepted.'
    out.mkdir()
    packet_path = out / 'node-fields.root-approved.json'
    write_new(packet_path, packet)
    approval = dict(rootConfirmed=True, stageAuthorized=True, applyAuthorized=False,
        dataHead=head, all285GlobalSceneMetadataAndAssetGuards=formal,
        protectedFirstThree=protected, sourceReviewAndModelGuards=guards,
        candidate=dict(path=str(candidate), sha256=sha(raw)),
        nodeFieldsSHA256=sha(packet_path.read_bytes()), field=field, exactVisualFieldLeaves=len(changes),
        historicalDataRebindings=rebounds, mainThreadViewedImages=False,
        fullEntryBodyFaceTimingAndSavedGameplayAccepted=False,
        rootEvidenceBases=evidence_bases,
        rootResourceCatalogEntryProofs=resource_catalog_proofs)
    if reference_roles.receipt is not None:
        approval['rootReferenceRoles'] = reference_roles.receipt
    write_new(out / 'preflight.root-approved.json', approval)
    print(json.dumps(dict(preparation=str(out), head=head, scene=scene, changes=len(changes),
        sourceGuards=len(guards), historicalReferencesRebound=len(rebounds))))


def review_stage(args):
    out, stage = Path(args.preparation).resolve(), Path(args.staging).resolve()
    approval = load(out / 'preflight.root-approved.json')
    assert_current(approval['dataHead'])
    verify_guards(approval['all285GlobalSceneMetadataAndAssetGuards'])
    verify_guards(approval['sourceReviewAndModelGuards'])
    packet = load(out / 'node-fields.root-approved.json')
    field = args.field
    assert approval['field'] == field
    assert sha((out / 'node-fields.root-approved.json').read_bytes()) == approval['nodeFieldsSHA256']
    manifest = load(stage / 'manifest.json')
    assert manifest['recordings'] == [] and manifest['directoryEntryUpdates'] == []
    assert manifest['structuralValidation'] == 'passed'
    assert manifest['restorationStatus'] == 'rough' and manifest['playbackValidation'] == 'not-run'
    for name, expected in manifest['files'].items():
        assert sha((stage / name).read_bytes()) == expected
    scene = packet['changes'][0]['sceneId']
    assert [entry['id'] for entry in manifest['scenes']] == [scene]
    old = load(D / f'native/scenes/{scene}.json')
    actual = load(stage / f'native/scenes/{scene}.json')
    undo = deepcopy(actual)
    old_review = load(D / f'review/scenes/{scene}.json')
    new_review = load(stage / f'review/scenes/{scene}.json')
    undo_review = deepcopy(new_review)
    for c in packet['changes']:
        row = undo['scenario_list'][c['arrayIndex']]
        assert row['scenario_id'] == c['scenarioId'] and row['uniq_id'] == c['uniqueId']
        assert set(c['fields']) == {field}
        assert row[field] == c['fields'][field]
        row[field] = c['expected'][field]
        key = str(c['scenarioId'])
        was, got = old_review['scenarios'][key], undo_review['scenarios'][key]
        expected_evidence = dict(packet=str(out / 'node-fields.root-approved.json'),
            fields=[field], evidence=c.get('evidence', {}))
        assert got['repairEvidence']['performance'][-1] == expected_evidence
        assert got['repairEvidence']['performance'][:-1] == was.get('repairEvidence', {}).get('performance', [])
        assert got['unknownFields'] == [f for f in was.get('unknownFields', []) if f != field]
        expected_issues = []
        for issue in was.get('issues', []):
            item = deepcopy(issue)
            if item.get('code') == 'performance_unrecovered':
                item['fields'] = [f for f in item.get('fields', []) if f != field]
                if not item['fields']:
                    continue
            expected_issues.append(item)
        assert got['issues'] == expected_issues
        # Undo only the permitted sidecar deltas, then compare the entire
        # document. This catches changed dialogue, branches and other rows.
        got['unknownFields'] = deepcopy(was.get('unknownFields', []))
        got['issues'] = deepcopy(was.get('issues', []))
        got['repairEvidence']['performance'].pop()
        if 'performance' not in was.get('repairEvidence', {}):
            assert got['repairEvidence']['performance'] == []
            del got['repairEvidence']['performance']
        if 'repairEvidence' not in was:
            # Do not replace this whole object from the baseline: doing so
            # would erase evidence of an unrelated sibling-key mutation.
            assert got['repairEvidence'] == {}
            del got['repairEvidence']
    assert undo == old
    expected_global = [i for i in old_review['issues'] if 'scenarioId' not in i]
    for row in actual['scenario_list']:
        expected_global.extend(new_review['scenarios'][str(row['scenario_id'])].get('issues', []))
    assert new_review['issues'] == expected_global
    undo_review['issues'] = deepcopy(old_review['issues'])
    assert undo_review == old_review
    entry = next(e for e in load(D / 'manifest.json')['scenes'] if e['id'] == scene)
    expected_entry = deepcopy(entry)
    expected_entry.update(nodeCount=len(actual['scenario_list']),
        reviewCounts=dict(Counter(s.get('status', 'draft') for s in new_review['scenarios'].values())),
        issues=new_review['issues'], readyForGame=False, reviewStatus='draft', repairStatus='in-progress')
    assert manifest['scenes'][0] == expected_entry
    review = dict(rootConfirmed=True, field=field, exactNativeVisualFieldLeaves=len(packet['changes']),
        completeNativeUndoOnlySelectedFieldExact=True,
        completeReviewOnlyExactEvidenceAppendsAndSelectedFieldWarningRemovals=True,
        completeSceneSummaryOnlyNormalSelectedFieldWarningRemovals=True,
        allStagedManifestHashesExact=True, all285FormalAndSourceGuardsFreshExact=True,
        sourceGuards=len(approval['sourceReviewAndModelGuards']), all22ProtectedExact=True,
        stageManifestSHA256=sha((stage / 'manifest.json').read_bytes()),
        batchId=sha((stage / 'manifest.json').read_bytes())[:20],
        voicesTextMotionBranchesOrderPreserved=True, fullSceneOrEpisodeAccepted=False)
    write_new(out / 'stage.root-review.json', review)
    print(json.dumps(review))


parser = argparse.ArgumentParser()
parser.add_argument('operation', choices=['prepare', 'review'])
parser.add_argument('--preparation', required=True)
parser.add_argument('--candidate')
parser.add_argument('--candidate-sha256')
parser.add_argument('--evidence-base')
parser.add_argument('--resource-evidence-base')
parser.add_argument('--count', type=int)
parser.add_argument('--staging')
parser.add_argument('--field', choices=['character', 'character_image'], required=True)
parser.add_argument('--read-log', required=True)
parser.add_argument('--reference-roles')
parser.add_argument('--reference-roles-sha256')
args = parser.parse_args()
assert (args.reference_roles is None) == (args.reference_roles_sha256 is None)
assert args.operation == 'prepare' or args.reference_roles is None
assert args.operation == 'prepare' or args.resource_evidence_base is None
read_log = Path(args.read_log).resolve()
assert read_log.is_relative_to(A) and not read_log.is_relative_to(D)
read_log.mkdir()
(prepare if args.operation == 'prepare' else review_stage)(args)
