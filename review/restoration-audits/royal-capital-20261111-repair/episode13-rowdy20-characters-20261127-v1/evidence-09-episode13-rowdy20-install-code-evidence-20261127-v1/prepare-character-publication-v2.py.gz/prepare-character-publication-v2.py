"""Collect a compact, immutable audit for one already verified character batch.

This does not install or publish anything. The saved-field verifier supplies
the precise formal write set; original selected source frames are retained once
by digest, while source/peer/root metadata is losslessly gzip archived. Model
payloads already in the formal asset package are referenced, not duplicated.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--preparation', required=True)
parser.add_argument('--staging', required=True)
parser.add_argument('--evidence-directory', action='append', required=True)
parser.add_argument('--slug', required=True)
parser.add_argument('--title', required=True)
args = parser.parse_args()
out, stage = Path(args.preparation), Path(args.staging)
assert out.parent == stage.parent == A
# The date/version suffix names an immutable archive only; it does not change
# the saved proof, source-evidence dates, accepted field, or resource constraints.
# Full ASCII matching excludes path separators and dot segments from the slug.
assert re.fullmatch(r'[A-Za-z0-9]+(?:[-_][A-Za-z0-9]+)*-[0-9]{8}-v[1-9][0-9]*', args.slug, re.ASCII)
proof = json.loads((out / 'root-saved-verification.json').read_bytes())
packet = json.loads((out / 'node-fields.root-approved.json').read_bytes())
head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
assert head == proof['parentHead'] == packet['baseSha']
field = proof['field']
assert field in {'character', 'character_image'}
assert proof['exactNativeLeafChanges'] == len(packet['changes'])
assert all(set(c['fields']) == {field} for c in packet['changes'])
assert proof['completeNativeRowsOtherFieldsBranchesAndOrderExact']
for name, expected in proof['savedFiles'].items():
    assert digest(D / name) == expected
entries = []
for number, directory in enumerate([*(Path(p) for p in args.evidence_directory), stage, out]):
    assert directory.parent == A and directory.is_dir()
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.name == 'archive-plan.root-approved.json':
            continue
        # Inputs are small authored evidence and the reviewed source program.
        # Binary models, downloaded media, temporary renders and raw PCM are
        # not duplicated into an identity audit. Existing gzip stays exact.
        assert path.suffix.lower() not in {'.moc3', '.png', '.jpg', '.wav', '.mp4'}
        encoding = 'identity' if path.suffix == '.gz' else 'gzip'
        name = f'evidence-{number:02d}-{directory.name}/' + str(path.relative_to(directory))
        entries.append(dict(source=str(path), sourceBytes=path.stat().st_size,
            sourceSHA256=digest(path), destination=name + ('.gz' if encoding == 'gzip' else ''),
            encoding=encoding))
for filename in ['review-character-batch-v2.py', 'review-explicit-visual-field-batch-v3.py',
                 'review-explicit-visual-field-batch-v4.py', 'verify-saved-field-batch-with-input-capture-v1.py',
                 'verify-saved-field-batch-with-input-capture-v2.py',
                 'observe-original-business-gate-v1.py']:
    path = A / filename
    entries.append(dict(source=str(path), sourceBytes=path.stat().st_size, sourceSHA256=digest(path),
        destination='helpers/' + filename + '.gz', encoding='gzip'))
frames = {}


def source_frames(value):
    if isinstance(value, list):
        for item in value:
            source_frames(item)
    elif isinstance(value, dict):
        name = value.get('path')
        if isinstance(name, str):
            p = Path(name)
            p = p if p.is_absolute() else ROOT / p
            if '/ocr/' in str(p) and p.suffix.lower() == '.jpg':
                assert p.is_file() and digest(p) == value['sha256']
                frames[digest(p)] = p
        for item in value.values():
            source_frames(item)


for change in packet['changes']:
    source_frames(change['evidence'])
assert frames
for sha, path in sorted(frames.items()):
    entries.append(dict(source=str(path), sourceBytes=path.stat().st_size,
        sourceSHA256=sha, destination='original-source-frames/' + sha + '.jpg', encoding='identity'))
readme = f'''# {args.title}

Save only {len(packet['changes'])} explicit {field} fields after the preserved original-frame and independent resource-identity reviews. Root did not view images. The original source JPEGs selected by these changes are retained by digest; original model/CG resources and existing packaged payloads remain locked by their exact source/current hashes.

These are static identity bindings. Source-cache timestamps are nominal historical anchors, not newly measured original PTS. Body, face, extra layers, complete entry/exit, original CSV phases, audible listening, geometry, timing and whole-scene/episode/gameplay acceptance remain incomplete. Uncertain model variants and choice-UI portraits are excluded according to the source and peer decisions.

Normal native_repair staging, complete undo review, native_install audit/apply and full saved-field verification were performed separately. Complete ordered native documents undo to the parent by reverting only the selected {field} leaves; all text, voices, branches, commands, unrelated unknown fields, other139 scene pairs and protected22 files are preserved. Review-side evidence appends and selected-field-warning removals remain draft, and only one owned batch is added. No frontend change or invented link/background/BGM/animation is included.

The user's2026-11-26 cleanup intentionally removed old temporary QA logs/screenshots. Those historical recipes were not reused as fresh acceptance. The selected original source frames and the current candidate/source/peer facts were freshly checked against retained originals. Compact metadata archives preserve original bytes rather than creating new repeated full diagnostic dumps.
'''
plan = dict(rootConfirmed=True, archiveAuthorized=True, dataRoot=str(D), expectedHead=head,
    savedDataFiles=proof['savedFiles'], targetRelativeDirectory='review/restoration-audits/royal-capital-20261111-repair/' + args.slug,
    entries=entries, originalRunStatus='normal-stage-audit-apply-and-full-saved-verification-passed-static-character-identity-only',
    readme=readme)
p = out / 'archive-plan.root-approved.json'
with p.open('x') as stream:
    json.dump(plan, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(dict(plan=str(p), sha256=digest(p), entries=len(entries), originalSourceFrames=len(frames))))
