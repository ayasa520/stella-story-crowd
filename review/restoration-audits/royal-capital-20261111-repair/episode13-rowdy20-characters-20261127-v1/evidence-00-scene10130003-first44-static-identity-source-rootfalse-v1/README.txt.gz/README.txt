scene10130003 / candidate rows[0:44] / delegated static identity source review

Reviewer: /root/scene03_identity_first44
Scope: First 44 entries of the named candidate list, not a scenario-ID range.
Formal D and C are read-only for this reviewer. No Git mutation was performed.
Observed D HEAD is metadata only; this packet makes no D-clean claim.

Route binding
The current manifest explicitly places this scene in chapter 1, section 1013,
第13話[♪]. Its JA title is 悪い予感はよく当たる and its Chinese title is
坏预感总会应验. Recording metadata identifies P40 as
13-IF奥托「从零开始的异世界商贩」. Review stable keys, preserved JP lines and
existing event/frame anchors agree. These facts were read, not inferred from
the size or order of scene/part IDs.

Actual image review
Every one of the 44 existing full-frame source JPEGs was opened directly with
view_image. No subtitle crop or choice portrait was used as identity evidence.
All 44 have visible character foreground. Offset 20 / node 24 is darkening,
but its white/orange tracksuit, chest N, dark sleeves and hair remain legible.
The original LIMEOS texture atlases for the five candidates and five excluded
variants were directly viewed. Packaged subaru01/otto01 portraits were also
viewed. Original/current exact-byte bindings are recorded separately.

Files
- rows.rootfalse.json: 44 full current native rows, UID/stable key, JP/ZH and
  canonical-row guards, full-frame paths/bytes/SHA256, inherited index times,
  direct-view records, 30 one-field character candidates, and 14 resource-
  blocked known-identity observations with deferred character values.
- resources.rootfalse.json: source/D descriptor -> MOC/texture paths and
  SHA256 equality, catalog/member mappings, positive and excluded appearance,
  and source Unity bundle hashes. MOC/texture are treated as opaque binary
  files and bound by paths, complete SHA256 and byte counts; their contents
  are not interpreted. There is no separate missing opaque-map file.
- receipt.rootfalse.json: scope, route, source references, counts and limits.
- files-index.rootfalse.json: byte/SHA256 binding for primary outputs.
- build-evidence.py: bounded offline artifact assembly, nice 19 / CPUs 0,1.

Results
subaru01 16; otto01 12; rowdy01 12; rowdy02 2; citizen_beast01 2.
0 missing fullframes; 0 observed original-blank foreground rows; 0 unknown.
30 rows have one-field character candidates using complete existing D assets;
14 rows have a visually known identity but await resource closure. Their
fields object stays empty; fieldAfterResourceClosure preserves the exact
deferred character token without pretending the resource is ready.
Only rowdy01 and rowdy02 lack D catalog registration, MOC and texture.
citizen_beast01 is present and exact-byte bound in D. The descriptors for
rowdy01/rowdy02 are present, but descriptor existence is not resource closure.

Limits and next consumer
Every root/acceptance/execution/installation/browser/installable flag is false.
These are static identity candidates, not an install authorization. Preserve
text-review-pending and all unrelated unknowns. Root must bind fresh guards
and review resource closure before any publication. Native IDs are authored.
No entry sequence, body, face, additional layer, phase, timing, audio, BGM,
FX, continuous playback, battle, whole scene or complete goal is accepted.
Existing index times are nominal seconds to 0.001s, not freshly verified PTS
or cue/phase-boundary measurements. No new video hash/probe/decode was run.
No browser, FFmpeg/media command, dependency installation or image copy ran.
