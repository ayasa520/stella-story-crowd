"""Assemble bounded static identity evidence; never write formal story data.

The manual classifications below were made by this delegated reviewer after
opening every original full-frame JPEG with view_image.  The script only binds
those observations to current rows, source indices, and exact resource bytes.
It cannot infer a character from a speaker label, install a field, accept an
entry sequence, or authorize any browser/media/production operation.
"""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

P = Path('/home/rikka/Projects/stella')
A = P / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
OUT = Path(__file__).parent
OCR = P / 'data/native_recovery/royal-capital-20261110/ocr/40'
LIME = P / 'data/extracted_archives/limeos'
ORIGINAL = P / 'data/extracted_archives/original'
REVIEWER = '/root/scene03_identity_first44'
FALSE = dict(rootReviewed=False, rootConfirmed=False, acceptance=False,
             executionAuthorized=False, installationAuthorized=False,
             browserAuthorized=False, installable=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode()


def ref(path):
    path = Path(path)
    if not path.is_file():
        return dict(path=str(path), exists=False, bytes=None, sha256=None)
    data = path.read_bytes()
    return dict(path=str(path), exists=True, bytes=len(data), sha256=digest(data))


def load(path):
    return json.loads(Path(path).read_text())


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


# These positional decisions follow candidate rows[0:44], not a node-number
# interval.  Node 37 is the excluded battle boundary between offsets 32 and 33.
MODELS = [
    'subaru01', 'otto01', 'subaru01', 'otto01', 'otto01', 'subaru01',
    'otto01', 'subaru01', 'rowdy01', 'otto01', 'rowdy01', 'rowdy01',
    'rowdy02', 'citizen_beast01', 'subaru01', 'subaru01', 'rowdy01',
    'otto01', 'subaru01', 'subaru01', 'subaru01', 'rowdy01', 'rowdy01',
    'otto01', 'subaru01', 'rowdy01', 'subaru01', 'rowdy01', 'rowdy01',
    'subaru01', 'otto01', 'rowdy01', 'otto01', 'rowdy01', 'rowdy02',
    'citizen_beast01', 'otto01', 'subaru01', 'subaru01', 'otto01',
    'subaru01', 'rowdy01', 'subaru01', 'otto01',
]
FEATURES = {
    'subaru01': {
        'positive': ['Dark spiky hair and youthful narrow face.',
                     'White zip-front tracksuit torso with dark sleeves/shoulders, orange collar and shoulder stripe, and black/orange chest N emblem.'],
        'excluded': ['subaru_tshirt01: directly viewed original atlas has plain black short-sleeved T-shirt, without the white jacket, orange collar or chest N.',
                     'subaru_tshirt02: directly viewed original atlas also lacks the white/orange jacket; visible source sleeves and collar exclude it.'],
        'sourceNotAccepted': 'Facial drawing, head tilt, arms and apparent lean are only descriptive pixels; no face/body token is assigned.',
    },
    'otto01': {
        'positive': ['Silver bobbed hair and pale blue/violet eyes.',
                     'Tall green hat with gold curved trim and white feather, green cloak with gold triangle borders, and red throat bow.'],
        'excluded': ['otto_prison01: directly viewed original atlas has horizontal black/white prisoner stripes and collar, and lacks the green merchant hat, feather and cloak.'],
    },
    'rowdy01': {
        'positive': ['Muscular human man with short red-brown spiky hair and pointed matching chin beard.',
                     'Dark sleeveless vest with ragged pale fur edging over a black lace-up chest panel.'],
        'excluded': ['rowdy02: directly viewed atlas has bald head, blue headband, purple vest and exposed belly; source has hair, beard and fur edging.',
                     'ton01: directly viewed atlas has dark braided hair, green vest sides, pale tunic and yellow sash, unlike the source vest/beard.'],
    },
    'rowdy02': {
        'positive': ['Heavy bald human man with blue/purple headband and long hanging tie.',
                     'Open purple sleeveless vest over pale torn-hem shirt exposing lower belly.'],
        'excluded': ['rowdy01: directly viewed atlas has red-brown spiky hair, beard and pale fur-trim vest absent in this source.',
                     'ton01: directly viewed atlas has braided dark hair and green vest, unlike the bald head/headband/purple vest.'],
    },
    'citizen_beast01': {
        'positive': ['Grey canine face, pointed pink-inner ears, grey pointed forelock, black nose and small fangs.',
                     'Large pale blue scarf over blue/purple tunic with brown diagonal strap and gold rectangular buckle.'],
        'excluded': ['ajin01: directly viewed atlas has olive/brown scales or skin, brown mane, metal shoulder plate and much larger fangs, unlike the grey-furred scarf-wearing source.',
                     'rowdy01 and rowdy02: directly viewed atlases are human heads and sleeveless clothing, without canine ears or pale blue scarf.'],
    },
}


candidate_path = A / 'chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json'
scene_path = D / 'native/scenes/10130003.json'
review_path = D / 'review/scenes/10130003.json'
manifest_path = D / 'manifest.json'
catalog_path = D / 'assets/catalog.json'
index_path = OCR / 'root-review/index.json'
candidate = next(s for s in load(candidate_path)['scenes'] if s['sceneId'] == 10130003)
selected = candidate['rows'][:44]
assert len(selected) == len(MODELS) == 44
native = load(scene_path)['scenario_list']
reviews = load(review_path)['scenarios']
manifest = load(manifest_path)
catalog = load(catalog_path)
events = {event['id']: event for event in load(index_path)['events']}
head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
chapter = next(c for c in manifest['chapters'] if any(10130003 in s['sceneIds'] for s in c['sections']))
section = next(s for s in chapter['sections'] if 10130003 in s['sceneIds'])
scene = next(s for s in manifest['scenes'] if s['id'] == 10130003)
recording = next(r for r in manifest['recordings'] if r['id'] == 'bili-capital-40')

resource_rows = {}
for model in sorted(set(MODELS)):
    token = 'live2d/AC_' + model
    member = f'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_{model}/ac/ac.model3.json'
    original_descriptor = LIME / member
    current_descriptor = D / f'assets/models/{model}/ac/ac.model3.json'
    file_refs = load(original_descriptor)['FileReferences']
    current_refs = load(current_descriptor)['FileReferences']
    paths = ['ac.model3.json', file_refs['Moc'], *file_refs['Textures']]
    pairs = []
    for relative in paths:
        original_ref = ref(original_descriptor.parent / relative)
        current_ref = ref(current_descriptor.parent / relative)
        member_ref = str(Path(member).parent / relative)
        pairs.append(dict(relative=relative, original=original_ref, D=current_ref,
                          byteExact=original_ref['sha256'] == current_ref['sha256'],
                          catalogMemberMapping=catalog['members'].get(member_ref)))
    resource_rows[model] = dict(
        nativeToken=token,
        positiveAndExcludedAppearance=FEATURES[model],
        originalDescriptorMember=member,
        descriptorReferences={k: file_refs[k] for k in ['Moc', 'Textures']},
        DDescriptorReferences={k: current_refs[k] for k in ['Moc', 'Textures']},
        files=pairs,
        catalogRegistered=token in catalog['models'],
        catalogPointer='/models/' + token.replace('/', '~1') if token in catalog['models'] else None,
        catalogEntryCanonicalSHA256=digest(canonical(catalog['models'][token])) if token in catalog['models'] else None,
        catalogIdentityURLs={k: v for k, v in catalog['models'].get(token, {}).items()
                             if k in ['native_id', 'id', 'model_url', 'member', 'detail_url', 'portrait_url']},
        staticTextureDirectlyViewed=True,
        staticTextureView=dict(tool='view_image', reviewer=REVIEWER,
                               path=str(original_descriptor.parent / file_refs['Textures'][0])),
        originalUnityBundles=[ref(ORIGINAL / f'com.sega.stella/files/AssetBundle/assets/ac_{model}.prefab'),
                              ref(ORIGINAL / f'com.sega.stella/files/AssetBundle/assets/ac_base_{model}.prefab')],
        opaqueMappingStatus='completed: MOC/texture treated as uninterpreted binary files and bound by exact paths, byte counts and SHA256; missing D files remain explicitly missing',
        opaqueBinaryInterpretationPerformed=False,
        DResourceClosureComplete=token in catalog['models'] and all(p['D']['exists'] for p in pairs),
        **FALSE,
    )

rows = []
for offset, (source, model) in enumerate(zip(selected, MODELS)):
    array_index, row = next((i, r) for i, r in enumerate(native) if r['uniq_id'] == source['UID'])
    rv = reviews[str(row['scenario_id'])]
    rec = source['recordings'][0]
    event = events[rec['ocrEventId']]
    full = Path(event['frame'])
    assert full.is_file() and full.parent.name == 'frames'
    assert rv['stableKey'] == source['stableKey']
    assert rv['sourceText'] == source['sourceText']
    assert row['character'] == row['character_image'] == ''
    assert rec['start'] <= event['source_frame_time'] <= rec['end']
    note = 'Clear complete source image shows the listed distinctive head and costume features.'
    if offset == 20:
        note = 'The full source image is darkening. The white/orange jacket, dark sleeves, chest N and hair remain recognizable. This still signs neither a fade phase nor its timing.'
    rows.append(dict(
        selectionOffset=offset, sceneId=10130003, scenarioId=row['scenario_id'],
        UID=row['uniq_id'], nativeArrayIndex=array_index, stableKey=rv['stableKey'],
        authoredNativeIdsPreserved=rv.get('nativeIdOrigin') == 'authored',
        currentRow=row, currentRowCanonicalSHA256=digest(canonical(row)),
        guard=dict(sourceJP=rv['sourceText'], sourceJPSHA256=digest(rv['sourceText'].encode()),
                   sourceSpeakerMetadataOnly=rv.get('sourceSpeaker'),
                   currentChinese=row['msg_text'], currentChineseSHA256=digest(row['msg_text'].encode()),
                   reviewTranslation=rv.get('translation'),
                   currentCharacter=row['character'], currentCharacterImage=row['character_image'],
                   unknownFields=rv.get('unknownFields', []),
                   textReviewPendingPreserved=any(i.get('code') == 'text_review_pending' for i in rv.get('issues', []))),
        sourceRecording=rec,
        fullframe=dict(**ref(full), sourceEventId=event['id'],
                       sourceFrameTimeFromExistingIndex=event['source_frame_time'],
                       sourceFrameIndexFromExistingIndex=event['frame_index'],
                       sourceVideo=event['source_video'],
                       sourceVideoSHA256Inherited=event['source_sha256'],
                       sourceVideoRehashedHere=False,
                       timePrecision='Existing index nominal seconds printed to 0.001s; no fresh video decode or native PTS verification; does not measure cue/phase boundaries.',
                       directView=dict(viewed=True, tool='view_image', reviewer=REVIEWER,
                                       viewBatch=offset // 8 + 1 if offset < 32 else 5,
                                       imageWasFullFrame=True, usedSubtitleCropOrChoicePortrait=False),
                       sourceAlignment='Index event ID, index source-frame path, exact review stable key and JP text, and witness within recording interval all agree.'),
        decision=dict(status='static-character-only-candidate' if resource_rows[model]['DResourceClosureComplete'] else 'static-identity-known-resource-closure-pending', identityVisualSupport=True,
                      originalBlankForegroundObserved=False, unknown=False,
                      fields={'character': 'live2d/AC_' + model} if resource_rows[model]['DResourceClosureComplete'] else {},
                      fieldAfterResourceClosure={'character': 'live2d/AC_' + model},
                      fieldCandidateReadyForRootBinding=resource_rows[model]['DResourceClosureComplete'],
                      resourceKey=model, sourceObservation=note,
                      visibleAppearance=FEATURES[model]['positive'],
                      variantExclusions=FEATURES[model]['excluded'],
                      DResourceClosureComplete=resource_rows[model]['DResourceClosureComplete'],
                      sourceEntryBodyFacePhaseTimingAudioOrWholeSceneAccepted=False,
                      **FALSE),
    ))

stamp = datetime.now(timezone.utc).isoformat()
common = dict(createdUTC=stamp, reviewer=REVIEWER, dataHeadObservedMetadataOnly=head,
              DWorkingTreeCleanClaim=False, offset=0, count=44, **FALSE)
save('rows.rootfalse.json', dict(schema='stella.static_identity_source_rows.v1', **common, rows=rows))
save('resources.rootfalse.json', dict(schema='stella.static_identity_resource_bindings.v1', **common,
    resources=resource_rows,
    excludedVariantTextures=[dict(model=n, directView=True, **ref(LIME / f'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_{n}/ac/textures/texture_00.png'))
                             for n in ['ton01', 'ajin01', 'otto_prison01', 'subaru_tshirt01', 'subaru_tshirt02']],
    directlyViewedPortraits=[ref(D / f'assets/portraits/{n}.png') for n in ['subaru01', 'otto01']]))
save('receipt.rootfalse.json', dict(schema='stella.static_identity_source_receipt.v1', **common,
    status='44-source-stills-viewed-30-character-only-candidates-14-resource-closure-pending',
    chapter={k: v for k, v in chapter.items() if k != 'sections'}, section=section,
    scene={k: scene[k] for k in ['id', 'chapterId', 'sectionId', 'title', 'titleJa', 'nodeCount', 'nativeIdentifierOrigins']},
    route='P40 recording metadata identifies 13-IF奥托「从零开始的异世界商贩」; scene title and continuous reviewed recording anchors bind this scene. No episode/route deduction from numeric IDs.',
    recording=recording, candidateInput=ref(candidate_path), nativeSceneInput=ref(scene_path),
    reviewInput=ref(review_path), manifestInput=ref(manifest_path), catalogInput=ref(catalog_path),
    existingSourceFrameIndex=ref(index_path), coarseManifest=ref(OCR / 'coarse-1hz/manifest.json'),
    modelCounts=dict(Counter(MODELS)), sourceFullframesDirectlyViewed=44,
    missingFullframes=0, unknownRows=0, observedOriginalBlankRows=0,
    excludedBoundary=dict(scenarioId=37, classification='Existing review battle boundary 629.999–651.999s; not in candidate rows[0:44] and not reviewed or accepted in this task.'),
    DResourceClosureIncompleteModels=[n for n, r in resource_rows.items() if not r['DResourceClosureComplete']],
    characterOnlyCandidatesWithExistingDResourceClosure=sum(r['decision']['fieldCandidateReadyForRootBinding'] for r in rows),
    staticKnownIdentitiesAwaitingResourceClosure=sum(not r['decision']['fieldCandidateReadyForRootBinding'] for r in rows),
    opaqueResourceBindingComplete=True,
    rootViewsImages=False, newBrowserSessions=0, newFFmpegOrMediaCommands=0,
    dependencyInstallations=0, formalFilesWritten=0, formalGitMutations=0,
    imageCopiesMade=0, dataCleanVerified=False,
    cpuAffinity=sorted(os.sched_getaffinity(0)), nice=os.getpriority(os.PRIO_PROCESS, 0),
    motion=False, body=False, face=False, extraLayers=False, phase=False,
    timing=False, voice=False, bgm=False, fx=False, continuousPlayback=False,
    wholeSceneAccepted=False, wholeRestorationGoalComplete=False,
    outputScope=str(OUT), needsRootFreshGuardBindingAndIndependentReview=True))
save('files-index.rootfalse.json', dict(schema='stella.static_identity_output_files.v1', **common,
    files=[ref(OUT / name) for name in ['README.txt', 'build-evidence.py', 'rows.rootfalse.json', 'resources.rootfalse.json', 'receipt.rootfalse.json']]))
print(json.dumps(dict(status='written', rows=len(rows), counts=dict(Counter(MODELS)),
    resourceClosureIncomplete=[n for n, r in resource_rows.items() if not r['DResourceClosureComplete']],
    bytes=sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())), ensure_ascii=False))
