V7 is a source-only, minimal extension of the exact V6 helper. V6 remains unchanged.

The optional --resource-evidence-base defaults to --evidence-base. An explicit resource commit must be 40 lowercase hex characters and an ancestor of the same current HEAD. Only the positive historical catalog-entry comparison uses that resource epoch. Every old sealed-reference drift still requires the original metadata --evidence-base, with unchanged recursive closure and root reference-role rules.

This addresses the observed Rowdy split: original metadata catalog/package snapshots are E2, while rowdy01/02 were registered by 372b679c. Selecting the later resource epoch does not authorize skipping old guards, changing old packets, or accepting a current resource entry that differs from its bound historical entry.

The prepared packet and approval both record rootEvidenceBases and rootResourceCatalogEntryProofs. Each selected token retains complete current/history catalog entries, equality proof, field/section, current/resource commits, and all selected scenario IDs. No synthetic entry or SHA-only substitute is recorded.

Only compile(source), exact diff and AST invariants were checked. No real prepare/review, business gate, D/C/Git mutation, browser or fixture library was run/created. Independent source peer is required before root considers actual execution.
