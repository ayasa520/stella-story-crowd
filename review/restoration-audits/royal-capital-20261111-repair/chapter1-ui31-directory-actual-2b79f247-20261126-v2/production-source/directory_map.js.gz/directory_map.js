const NS='http://www.w3.org/2000/svg';
const svg=(name,attributes={},text)=>{
  const node=document.createElementNS(NS,name);
  for(const[key,value]of Object.entries(attributes))node.setAttribute(key,String(value));
  if(text!==undefined)node.textContent=text;
  return node;
};

// Map presentation owns only geometry and camera state. Native grid positions
// locate cards; only saved edges produce lines. Selection/edit callbacks stay
// in DirectoryEditor, so dragging, zooming and fitting never mutate a project.
export class DirectoryMap {
  constructor({host,select,open,editEdge}){
    Object.assign(this,{host,select,open,editEdge});this.views=new Map();this.serial=0;
    this.viewport=document.createElement('div');this.viewport.className='directory-map-viewport';
    this.viewport.tabIndex=0;this.viewport.setAttribute('aria-label','剧情流程地图：拖动平移，滚轮缩放');
    this.host.append(this.viewport);
    this.bind();
    new ResizeObserver(()=>{
      const width=this.viewport.clientWidth,height=this.viewport.clientHeight;
      if(!width||!height)return;
      if(this.camera&&this.size){this.camera.x+=(width-this.size.width)/2;this.camera.y+=(height-this.size.height)/2;this.paint();}
      this.size={width,height};
    }).observe(this.viewport);
  }
  configure(settings){this.settings=settings;}
  polygon(x,y,w,h,n){return `${x+n},${y} ${x+w-n},${y} ${x+w},${y+h/2} ${x+w-n},${y+h} ${x+n},${y+h} ${x},${y+h/2}`;}
  render({key,kind,entries,edges,allEntries,selected,current,thumbnails,counts,focus=false}){
    const changed=this.key!==key;
    if(this.camera&&this.key)this.views.set(this.key,{...this.camera});
    this.key=key;this.kind=kind;this.entries=new Map(entries.map(row=>[row.id,row]));
    this.allEntries=new Map(allEntries.map(row=>[row.id,row]));this.edges=new Map(edges.map(edge=>[edge.id,edge]));
    this.selected=selected;this.current=current;
    const {card,grid,padding,portal,connection}=this.settings;
    this.positions=new Map();
    const minX=Math.min(0,...entries.map(row=>row.pos_x)),minY=Math.min(0,...entries.map(row=>row.pos_y));
    for(const row of entries)this.positions.set(row.id,{x:padding+(row.pos_x-minX)*grid[kind].x,y:padding+(row.pos_y-minY)*grid[kind].y});
    const right=Math.max(padding,...[...this.positions.values()].map(p=>p.x+card.width));
    let bottom=Math.max(padding,...[...this.positions.values()].map(p=>p.y+card.height+connection.end_offset+48)),width=right+padding;
    const root=svg('svg',{class:'directory-map-canvas',role:'group','aria-label':kind==='section'?'本章各话的流程':'本话各场景的流程'});
    const defs=svg('defs');root.append(defs);
    const shade=svg('linearGradient',{id:'directory-card-shade',x1:0,y1:0,x2:0,y2:1});
    shade.append(svg('stop',{offset:'25%','stop-color':'#161322','stop-opacity':0}),svg('stop',{offset:'100%','stop-color':'#161322','stop-opacity':.94}));defs.append(shade);
    // External and unresolved destinations remain first-class edge targets.
    // Give each a separate portal slot, without moving native cards or
    // collapsing several missing routes into one clickable label.
    const portals=new Map();let previousBottom=0;
    const outside=edges.filter(edge=>this.positions.has(edge.source)&&!this.positions.has(edge.target))
      .sort((a,b)=>this.positions.get(a.source).y-this.positions.get(b.source).y);
    for(const edge of outside){
      const source=this.positions.get(edge.source);
      const y=Math.max(source.y+(card.height-portal.height)/2,previousBottom+portal.gap);
      portals.set(edge.id,{x:right+portal.offset,y});previousBottom=y+portal.height;
      width=Math.max(width,right+portal.offset+portal.width+padding);bottom=Math.max(bottom,previousBottom);
    }
    for(const edge of edges){
      const source=this.positions.get(edge.source);if(!source)continue;
      const target=this.positions.get(edge.target),port=portals.get(edge.id);
      const x=source.x+card.width/2,y=source.y+card.height;
      let path,midX,midY;
      if(target){
        const tx=target.x+card.width/2,ty=target.y;
        // Branches leave the source stem just below its card, before the END
        // rule. A midpoint-based elbow extends the stem through the ending
        // and creates an extra step. Aligned nodes share a straight stem;
        // displaced branches retain the native horizontal/vertical shape.
        midX=(x+tx)/2;
        if(x===tx&&ty>y){midY=(y+ty)/2;path=`M${x} ${y} V${ty}`;}
        else if(source.y===target.y){
          const startX=tx>x?source.x+card.width:source.x,endX=tx>x?target.x:target.x+card.width;
          midY=source.y+card.height/2;path=`M${startX} ${midY} H${endX}`;
        }else{
          midY=ty>y?Math.min(y+connection.branch_offset,ty):Math.max(y,ty+card.height)+connection.branch_offset;
          path=`M${x} ${y} V${midY} H${tx} V${ty>y?ty:ty+card.height}`;
        }
      }else{
        const startX=source.x+card.width,startY=source.y+card.height/2,endY=port.y+portal.height/2;
        midX=(startX+port.x)/2;midY=(startY+endY)/2;
        path=startY===endY?`M${startX} ${startY} H${port.x}`:`M${startX} ${startY} H${midX} V${endY} H${port.x}`;
      }
      const group=svg('g',{class:'directory-map-edge '+edge.state+(edge.source===selected||edge.target===selected?' selected':''),
        role:'button',tabindex:0,'data-flow-edge':edge.id,'aria-label':`编辑连接：${this.entries.get(edge.source).name} → ${this.allEntries.get(edge.target)?.name||'目标待恢复'}`});
      group.append(svg('path',{d:path,class:'map-line'}),svg('path',{d:path,class:'map-line-hit'}),svg('title',{},edge.label||group.getAttribute('aria-label')));
      if(edge.label)group.append(svg('text',{x:midX,y:midY-10,class:'map-edge-label','text-anchor':'middle'},edge.label));
      root.append(group);
      if(port){
        const destination=this.allEntries.get(edge.target),portalGroup=svg('g',{class:'map-portal '+edge.state,role:'button',tabindex:0,'data-flow-edge':edge.id,'aria-label':group.getAttribute('aria-label')});
        portalGroup.append(svg('polygon',{points:this.polygon(port.x,port.y,portal.width,portal.height,18)}),
          svg('text',{x:port.x+26,y:port.y+25,class:'map-portal-caption'},destination?'跨话／跨章':'后续待恢复'));
        this.label(portalGroup,port.x+26,port.y+32,portal.width-52,30,destination?.description||destination?.name||'？','map-portal-name');
        root.append(portalGroup);
      }
    }
    entries.forEach((row,index)=>{
      const p=this.positions.get(row.id),{width:w,height:h,notch:n,wing}=card;
      const points=this.polygon(p.x,p.y,w,h,n),clip=svg('clipPath',{id:'directory-card-'+index});clip.append(svg('polygon',{points}));defs.append(clip);
      const selectedCard=row.id===selected,group=svg('g',{class:'directory-map-card'+(selectedCard?' selected':'')+(counts.get(row.id)?' restored':''),
        role:'button',tabindex:0,'data-flow-entry':row.id,'aria-label':[row.name,row.description,row.route].filter(Boolean).join(' · '),'aria-pressed':selectedCard});
      group.append(svg('polygon',{points:this.polygon(p.x-wing,p.y+12,w+wing*2,h-24,n+wing),class:'map-card-wings'}),
        svg('polygon',{points,class:'map-card-base'}));
      if(thumbnails.includes(row.native_id))group.append(svg('image',{x:p.x,y:p.y,width:w,height:h,
        href:`/directory-thumbnail/${kind}/${encodeURIComponent(row.native_id)}`,'clip-path':`url(#directory-card-${index})`,preserveAspectRatio:'xMidYMid slice'}));
      group.append(svg('polygon',{points,fill:'url(#directory-card-shade)'}),svg('polygon',{points,class:'map-card-outline'}));
      if(kind==='section')group.append(svg('text',{x:p.x+34,y:p.y+30,class:'map-episode'},row.name));
      this.label(group,p.x+32,p.y+(kind==='section'?54:48),w-64,65,kind==='section'?(row.description||row.name):row.name,'map-card-title');
      if(row.is_root||selectedCard||row.id===current)group.append(svg('text',{x:p.x+28,y:p.y-13,class:'map-card-status'},selectedCard?'SELECTED':row.id===current?'工作区':'START'));
      if(counts.get(row.id))group.append(svg('text',{x:p.x+w-22,y:p.y-13,class:'map-draft-count','text-anchor':'end'},`${counts.get(row.id)} 段录像`));
      if(row.is_end){
        const center=p.x+w/2,baseline=p.y+h+connection.end_offset;
        group.append(svg('path',{d:`M${center} ${p.y+h} V${baseline} M${p.x+32} ${baseline} H${p.x+w-32}`,class:'map-end-rule'}),
          svg('path',{d:`M${center} ${baseline-6} l6 6 -6 6 -6 -6 Z`,class:'map-end-diamond'}),
          svg('text',{x:center,y:baseline-10,class:'map-end-label','text-anchor':'middle'},'END'));
        this.label(group,p.x,baseline+11,w,28,row.route,'map-route-name');
      }else if(row.route)this.label(group,p.x,p.y+h+12,w,28,row.route,'map-route-name');
      group.append(svg('title',{},group.getAttribute('aria-label')));root.append(group);
    });
    this.bounds={width,height:bottom+padding};root.setAttribute('viewBox',`0 0 ${width} ${this.bounds.height}`);
    root.style.width=width+'px';root.style.height=this.bounds.height+'px';this.viewport.replaceChildren(root);this.canvas=root;
    if(!entries.length){const empty=document.createElement('p');empty.className='directory-map-empty';empty.textContent='这里还没有目录条目';this.viewport.append(empty);}
    if(changed)this.camera=this.views.get(key)||{x:0,y:0,zoom:this.settings.camera.initial_zoom};
    // Selection replaces the SVG while the next pointer event may already be
    // queued. Apply its camera immediately so the second click hits the same
    // card; defer only centering that needs the newly opened dialog's size.
    this.paint();
    const serial=++this.serial;
    requestAnimationFrame(()=>{
      if(serial!==this.serial)return;
      if(focus||(changed&&!this.views.has(key))){
        // The active workspace may belong to another scope. Focus a card in
        // this map; an off-map scene must not prevent the new camera painting.
        const target=[selected,current,entries.find(row=>row.is_root)?.id,entries[0]?.id].find(id=>this.positions.has(id));
        if(target)this.center(target);
      }
      this.paint();
    });
    console.info('STORY_DIRECTORY_MAP',JSON.stringify({scope:key,entries:entries.length,edges:edges.length,external:portals.size}));
  }
  label(parent,x,y,width,height,text,className){
    const box=svg('foreignObject',{x,y,width,height,'pointer-events':'none'}),label=document.createElement('div');
    label.className=className;label.textContent=text;box.append(label);parent.append(box);
  }
  paint(){
    if(!this.camera||!this.canvas)return;
    const {x,y,zoom}=this.camera;this.canvas.style.transform=`translate(${x}px,${y}px) scale(${zoom})`;
    this.host.dispatchEvent(new CustomEvent('map-camera',{detail:{zoom}}));
  }
  center(id){
    const p=this.positions.get(id);if(!p||!this.camera)return;
    const {width,height}=this.settings.card,z=this.camera.zoom;
    this.camera.x=this.viewport.clientWidth/2-(p.x+width/2)*z;
    const anchor=this.entries.get(id).is_root?this.settings.camera.root_anchor:this.settings.camera.focus_anchor;
    this.camera.y=this.viewport.clientHeight*anchor-(p.y+height/2)*z;this.paint();
  }
  fit(){
    const inset=this.settings.camera.fit_padding;
    this.camera.zoom=Math.min(this.settings.camera.max_zoom,(this.viewport.clientWidth-inset*2)/this.bounds.width,(this.viewport.clientHeight-inset*2)/this.bounds.height);
    this.camera.x=(this.viewport.clientWidth-this.bounds.width*this.camera.zoom)/2;
    this.camera.y=(this.viewport.clientHeight-this.bounds.height*this.camera.zoom)/2;this.paint();
  }
  zoom(factor,point){
    if(!this.camera)return;
    const p=point||{x:this.viewport.clientWidth/2,y:this.viewport.clientHeight/2},before=this.camera.zoom;
    const value=Math.max(this.settings.camera.min_zoom,Math.min(this.settings.camera.max_zoom,before*factor));
    this.camera.x=p.x-(p.x-this.camera.x)*value/before;this.camera.y=p.y-(p.y-this.camera.y)*value/before;this.camera.zoom=value;this.paint();
  }
  activate(target,open=false){
    console.info('STORY_DIRECTORY_MAP_ACTIVATE',JSON.stringify({entry:target?.dataset.flowEntry,edge:target?.dataset.flowEdge,open}));
    if(target?.dataset.flowEntry)(open?this.open:this.select)(target.dataset.flowEntry);
    else if(target?.dataset.flowEdge)this.editEdge(this.edges.get(target.dataset.flowEdge));
  }
  bind(){
    const view=this.viewport;
    view.addEventListener('wheel',event=>{
      if(!this.camera)return;event.preventDefault();const rect=view.getBoundingClientRect();
      this.zoom(Math.exp(-event.deltaY*this.settings.camera.wheel_rate),{x:event.clientX-rect.left,y:event.clientY-rect.top});
    },{passive:false});
    view.addEventListener('pointerdown',event=>{
      if(event.button!==0||!this.camera)return;
      this.drag={id:event.pointerId,x:event.clientX,y:event.clientY,camera:{...this.camera},target:event.target.closest('[data-flow-entry],[data-flow-edge]'),moved:false};
      view.setPointerCapture(event.pointerId);view.classList.add('dragging');
    });
    view.addEventListener('pointermove',event=>{
      const drag=this.drag;if(!drag||drag.id!==event.pointerId)return;
      const dx=event.clientX-drag.x,dy=event.clientY-drag.y;
      if(Math.hypot(dx,dy)>this.settings.camera.drag_threshold)drag.moved=true;
      if(drag.moved){this.camera.x=drag.camera.x+dx;this.camera.y=drag.camera.y+dy;this.paint();}
    });
    view.addEventListener('pointerup',event=>{
      const drag=this.drag;if(!drag||drag.id!==event.pointerId)return;
      this.drag=null;view.classList.remove('dragging');view.releasePointerCapture(event.pointerId);
      if(drag.moved)return;
      const key=drag.target?.dataset.flowEntry||drag.target?.dataset.flowEdge,time=performance.now();
      const twice=key&&this.lastClick?.key===key&&time-this.lastClick.time<this.settings.camera.double_click_ms;
      this.lastClick=twice?null:{key,time};this.activate(drag.target,twice);
    });
    view.addEventListener('pointercancel',()=>{this.drag=null;view.classList.remove('dragging');});
    view.addEventListener('keydown',event=>{
      if(!this.camera)return;
      if(event.key==='Enter'||event.key===' '){event.preventDefault();this.activate(event.target.closest('[data-flow-entry],[data-flow-edge]'),event.ctrlKey);}
      if(event.key==='+'||event.key==='='){event.preventDefault();this.zoom(this.settings.camera.step);}
      if(event.key==='-'){event.preventDefault();this.zoom(1/this.settings.camera.step);}
    });
  }
}
