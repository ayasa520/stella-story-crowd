# Fresh UI31 inventory collector source

This is unexecuted collector source. It grants no browser, API, media, Git write,
publication or production-source authority. Root remains the only D/C writer.

The collector replaces the deleted-history dependency with the current complete
D HEAD tree and index membership. Every tracked regular file is read once for
SHA256 and for its actual Git blob identity; that identity must equal its HEAD
blob. A single inventory stores the SHA256 map and an ordered blob-OID list.
The assets/native/review filesystem membership must exactly equal their tracked
HEAD membership. The 22 first-three native/review files derive from these same
fresh reads. No historical screenshots are traversed or recreated.

C has all 312 tracked files and all 234 dist files freshly read and guarded.
Its expected status is supplied explicitly, preserving the existing
`?? scripts/__pycache__/` observation. This program never deletes or imports it.
The actual installed ARM Python, Node, Firefox and Git binaries are hashed;
Firefox is never run to obtain its version. Wrapper, installed version INIs,
and the existing owner process-inspection utilities are also guarded.

Only one full inventory is persisted. `globalGuards` is empty because the new
owner core must check native/review membership against absolute D/dataInputs
paths. Non-D references are the small `evidenceGuards` map. The original owner
core's membership check cannot consume this new inventory unchanged.

The small input file uses schema `stella.ui31-fresh-inventory-inputs.v1`, final
`expectedDataHead`, `expectedSourceHead`, exact `expectedSourceStatus`, and a
`references` list of `{role,path,sha256}` records. It must contain exactly one
`plan`, `publication`, `previousClosure` and `sourcePeer`, plus all final runtime
source/dependency files under descriptive `runtime:*` roles. Additional peer,
deployment or root-proof references can appear without copying their old
capture trees. This list is byte binding, never an approval or release.

The input JSON parser holds its first raw read and byte proof across the original
parser call. Parse failure exclusively archives that exact raw and the parser's
exception document/position; it never retries or changes the input. Successful
metadata keeps only the small proof. Root supplies all final refs and separately
reviews this source before any one-time collection. No input file or runnable
release is created here.

Version 2 preserves v1 and its existing references. It narrowly rejects a
symlink/non-directory traversal root and requires its resolved path to remain
inside the expected D/C checkout before `os.walk`. This closes the top-level
`dist` symlink boundary found by the independent collector peer. No collector
execution or runtime acceptance follows from this source correction.


Version 3 preserves v1/v2 and their references. Its only code change from v2
uses `stat.S_IXUSR` for Git's canonical executable mode instead of accepting any
user/group/other execute bit. The independent peer identified this distinction;
no collector or browser is executed by the correction.


Version 4 preserves v1-v3 and their references. Its only code change from v3
includes nested `.git` directories in the four scoped membership walks. These
walks start inside assets/native/review/dist, rather than at a repository root;
therefore a nested `.git` is part of the exact scope membership and must not be
silently skipped. Root repository `.git` is never traversed by these walks.

