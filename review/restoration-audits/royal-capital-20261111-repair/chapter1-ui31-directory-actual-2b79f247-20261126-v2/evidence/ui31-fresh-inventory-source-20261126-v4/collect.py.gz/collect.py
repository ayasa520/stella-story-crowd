"""Collect one fresh UI31 input inventory; never launch or publish anything.

This source has no execution authority. The root writer supplies the FINAL
published data HEAD and a small exact-reference input after publication ACK.
Every formal data file comes from the CURRENT Git tree, not a previous capture
inventory. Deleted historical QA files therefore cannot re-enter this scope.
"""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import struct
import subprocess
import sys
import time
import traceback


ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
C = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout'
PROTECTED_SCENES = (
    '10010020', '10010001', '10010016', '10140002', '10140003',
    '10190004', '10190005', '10190008', '10190007', '10190017', '10190009',
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def exclusive_json(path, value):
    with path.open('xb') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode() + b'\n')


def held_json(path, failure_directory):
    """Parse the held FIRST read, retaining exactly that input on failure.

    A later successful reread cannot explain a failed first parse. Keep raw
    bytes alive across the original parser call; never retry, normalize, trim,
    replace NULs, or reconstruct input from an exception. Successful reads need
    only the small byte proof. Failure archives preserve both the first raw
    bytes and JSONDecodeError.doc independently, because their relationship is
    part of the evidence rather than an assumption about the decoder.
    """
    raw = path.read_bytes()
    proof = {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}
    try:
        value = json.loads(raw)
    except BaseException as error:
        prefix = failure_directory / ('json-first-read-failure-' + str(time.time_ns()))
        raw_archive = prefix.with_suffix('.raw.json.gz')
        with raw_archive.open('xb') as stream:
            stream.write(gzip.compress(raw, compresslevel=1, mtime=0))
        doc = getattr(error, 'doc', None)
        doc_proof = None
        if isinstance(doc, str):
            doc_raw = doc.encode('utf-8', errors='surrogatepass')
            doc_archive = prefix.with_suffix('.exception-doc.utf8.gz')
            with doc_archive.open('xb') as stream:
                stream.write(gzip.compress(doc_raw, compresslevel=1, mtime=0))
            doc_proof = {'path': str(doc_archive), 'bytes': len(doc_raw),
                         'sha256': digest(doc_raw), 'encoding': 'utf-8/surrogatepass'}
        exclusive_json(prefix.with_suffix('.proof.json'), {
            'firstRead': proof, 'rawArchive': str(raw_archive), 'exceptionDoc': doc_proof,
            'exception': type(error).__name__, 'message': str(error),
            'pos': getattr(error, 'pos', None), 'lineno': getattr(error, 'lineno', None),
            'colno': getattr(error, 'colno', None), 'traceback': traceback.format_exc(),
            'retried': False, 'inputModified': False,
        })
        raise
    return value, proof


def git(root, *arguments):
    # GIT_OPTIONAL_LOCKS=0 keeps these observations free of optional index
    # refresh writes. No subcommand here changes refs, index or worktree.
    return subprocess.check_output(
        ['/usr/bin/git', '--no-optional-locks', '-C', str(root), *arguments],
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'},
    )


def repository_state(root):
    return {'head': git(root, 'rev-parse', 'HEAD').decode().strip(),
            'status': git(root, 'status', '--short').decode().strip(),
            'index': git(root, 'ls-files', '--stage', '-z'),
            'tree': git(root, 'ls-tree', '-r', '-z', 'HEAD'),
            'objectFormat': git(root, 'rev-parse', '--show-object-format').decode().strip()}


def tracked_tree(state):
    tree = {}
    for row in state['tree'].split(b'\0'):
        if not row:
            continue
        attributes, raw_name = row.split(b'\t', 1)
        mode, kind, oid = attributes.decode().split()
        name = raw_name.decode('utf-8')
        assert kind == 'blob' and mode in ('100644', '100755'), (name, mode, kind)
        assert not Path(name).is_absolute() and not {'.git', '..'} & set(Path(name).parts), name
        assert name not in tree, name
        tree[name] = (mode, oid)
    index = {}
    for row in state['index'].split(b'\0'):
        if not row:
            continue
        attributes, raw_name = row.split(b'\t', 1)
        mode, oid, stage = attributes.decode().split()
        name = raw_name.decode('utf-8')
        assert stage == '0' and name not in index, name
        index[name] = (mode, oid)
    assert index == tree, 'Current index membership/modes/blob identities differ from HEAD'
    return tree


def file_digests(path, object_format=None):
    """Read each regular file once for SHA256 and optional actual Git blob ID.

    Git clean status alone is insufficient byte evidence. Compute the Git
    object digest from the held size header and the actual worktree byte
    stream, then compare it with HEAD. The independent SHA256 is what existing
    UI guards consume. Stable fstat/lstat observations reject concurrent edits
    rather than silently collecting a mixed snapshot.
    """
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), str(path)
    sha256 = hashlib.sha256()
    blob = hashlib.new(object_format) if object_format else None
    if blob:
        blob.update(b'blob ' + str(before.st_size).encode() + b'\0')
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), str(path)
        while chunk := stream.read(1024 * 1024):
            sha256.update(chunk)
            if blob:
                blob.update(chunk)
        after_fd = os.fstat(stream.fileno())
    after = path.lstat()
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size,
                              value.st_mtime_ns, value.st_ctime_ns, value.st_mode)
    assert identity(before) == identity(after_fd) == identity(after), str(path)
    return sha256.hexdigest(), blob.hexdigest() if blob else None, before.st_size


def tracked_bytes(root, state):
    tree = tracked_tree(state)
    files, oids, non_default_modes, total_bytes = {}, [], {}, 0
    for name in sorted(tree, key=lambda value: value.encode('utf-8')):
        expected_mode, expected_oid = tree[name]
        sha256, actual_oid, size = file_digests(root / name, state['objectFormat'])
        assert actual_oid == expected_oid, 'Actual bytes differ from HEAD blob: ' + name
        actual_mode = '100755' if (root / name).stat().st_mode & stat.S_IXUSR else '100644'
        assert actual_mode == expected_mode, 'Actual executable mode differs from HEAD: ' + name
        files[name] = sha256
        oids.append(expected_oid)
        if expected_mode != '100644':
            non_default_modes[name] = expected_mode
        total_bytes += size
    # OIDs follow sorted dataInputs keys, avoiding a second 32K-path map.
    return files, {'objectFormat': state['objectFormat'],
                   'pathOrder': 'dataInputs keys sorted by UTF-8 bytes',
                   'oids': oids, 'defaultMode': '100644',
                   'nonDefaultModes': non_default_modes, 'actualBytes': total_bytes,
                   'everyActualBlobMatchedHead': True}


def membership(names):
    ordered = sorted(names, key=lambda value: value.encode('utf-8'))
    return {'files': len(ordered), 'pathsNulSha256': digest(
        b''.join(name.encode('utf-8') + b'\0' for name in ordered))}


def directory_names(root, boundary):
    # os.walk follows its supplied root even with followlinks=False. Reject a
    # symlink at that boundary before traversal, then prove the resolved root
    # remains inside its expected checkout. Descendant symlink directories are
    # rejected separately below; no directory alias can widen the guard scope.
    root_stat = root.lstat()
    assert stat.S_ISDIR(root_stat.st_mode) and not root.is_symlink(), str(root)
    resolved_boundary = boundary.resolve(strict=True)
    assert root.resolve(strict=True).is_relative_to(resolved_boundary), str(root)
    names = set()
    for directory, directories, files in os.walk(root, followlinks=False):
        directory_path = Path(directory)
        directory_stat = directory_path.lstat()
        assert stat.S_ISDIR(directory_stat.st_mode) and not directory_path.is_symlink(), directory
        assert directory_path.resolve(strict=True).is_relative_to(resolved_boundary), directory
        directories[:] = sorted(directories)
        for name in directories:
            assert not (Path(directory) / name).is_symlink(), str(Path(directory) / name)
        names.update((Path(directory) / name).relative_to(root).as_posix() for name in files)
    return names


def data_scope_membership(data_inputs):
    result = {}
    for scope in ('assets', 'native', 'review'):
        actual = {scope + '/' + name for name in directory_names(D / scope, D)}
        expected = {name for name in data_inputs if name.startswith(scope + '/')}
        assert actual == expected, 'Formal D/' + scope + ' filesystem membership differs from tracked HEAD'
        result[scope] = membership(actual)
    return result


def tool_inventory():
    launch_paths = {'python': '/usr/bin/python3', 'node': '/usr/bin/node',
                    'firefox': '/usr/lib/firefox/firefox', 'git': '/usr/bin/git'}
    tools, files = {}, {}
    for name, launch in launch_paths.items():
        path = Path(launch)
        binary = path.resolve(strict=True)
        with binary.open('rb') as stream:
            header = stream.read(20)
        assert header[:6] == b'\x7fELF\x02\x01' and struct.unpack('<H', header[18:20])[0] == 183, str(binary)
        sha256, _, size = file_digests(binary)
        files[str(binary)] = sha256
        tools[name] = {'launchPath': launch, 'binaryPath': str(binary), 'sha256': sha256,
                       'bytes': size, 'elfMachine': 183,
                       'symlinkText': os.readlink(path) if path.is_symlink() else None}
        if name != 'firefox':
            tools[name]['version'] = subprocess.check_output([str(binary), '--version'], text=True).strip()
    # Firefox is never executed for a version query. Its installed ARM binary,
    # launcher wrapper and INI version/build evidence are all byte guarded.
    for name in ('/usr/bin/firefox', '/usr/bin/file', '/usr/bin/ps',
                 '/usr/lib/firefox/application.ini', '/usr/lib/firefox/platform.ini'):
        sha256, _, _ = file_digests(Path(name).resolve(strict=True))
        files[name] = sha256
    tools['firefox']['versionEvidence'] = '/usr/lib/firefox/application.ini'
    assert Path(sys.executable).resolve() == Path(tools['python']['binaryPath']), sys.executable
    return tools, files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--inputs-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert platform.machine() == 'aarch64'
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19 and sorted(os.sched_getaffinity(0)) == [0, 1]
    output = args.output.resolve()
    assert output.is_relative_to(A) and not output.is_relative_to(D) and not output.is_relative_to(C)
    assert output.parent.is_dir() and not output.exists(), str(output)
    inputs_path = args.inputs.resolve(strict=True)
    inputs, input_proof = held_json(inputs_path, output.parent)
    assert input_proof['sha256'] == args.inputs_sha256
    assert inputs['schema'] == 'stella.ui31-fresh-inventory-inputs.v1'
    references = inputs['references']
    roles = [ref['role'] for ref in references]
    for role in ('plan', 'publication', 'previousClosure', 'sourcePeer'):
        assert roles.count(role) == 1, role
    assert any(role.startswith('runtime:') for role in roles)
    evidence = {str(inputs_path): input_proof['sha256']}
    source_sha, _, _ = file_digests(Path(__file__).resolve())
    evidence[str(Path(__file__).resolve())] = source_sha
    for ref in references:
        path = Path(ref['path']).resolve(strict=True)
        assert path.is_relative_to(ROOT) and not path.is_relative_to(D) and not path.is_relative_to(C)
        sha256, _, _ = file_digests(path)
        assert sha256 == ref['sha256'], ref['role']
        assert str(path) not in evidence, str(path)
        evidence[str(path)] = sha256
    before_d, before_c = repository_state(D), repository_state(C)
    assert before_d['head'] == inputs['expectedDataHead'] and before_d['status'] == ''
    assert before_c['head'] == inputs['expectedSourceHead']
    assert before_c['status'] == inputs['expectedSourceStatus']
    data_inputs, data_blobs = tracked_bytes(D, before_d)
    source_files, source_blobs = tracked_bytes(C, before_c)
    assert len(source_files) == 312
    dist_names = directory_names(C / 'dist', C)
    dist_files = {name: file_digests(C / 'dist' / name)[0] for name in sorted(dist_names)}
    assert len(dist_files) == 234
    scopes = data_scope_membership(data_inputs)
    protected = {f'{kind}/scenes/{scene}.json': data_inputs[f'{kind}/scenes/{scene}.json']
                 for scene in PROTECTED_SCENES for kind in ('native', 'review')}
    tools, tool_files = tool_inventory()
    after_d, after_c = repository_state(D), repository_state(C)
    assert after_d == before_d and after_c == before_c, 'Repository state changed during collection'
    assert directory_names(C / 'dist', C) == dist_names, 'Dist membership changed during collection'
    assert data_scope_membership(data_inputs) == scopes
    # The single inventory is the only large persisted map. Runtime before/after
    # receipts reference it by path+SHA and record fresh verification summaries.
    # globalGuards deliberately excludes D: ALL D bytes live in dataInputs, and
    # the new owner core checks native/review membership against that full set.
    inventory = {
        'schema': 'stella.ui31-fresh-inventory.v1',
        'dataRoot': str(D), 'sourceRoot': str(C),
        'dataHead': before_d['head'], 'dataStatus': before_d['status'],
        'sourceHead': before_c['head'], 'sourceStatus': before_c['status'],
        'dataInputs': data_inputs, 'dataHeadBlobs': data_blobs,
        'protectedFirstThree': protected, 'globalGuards': {},
        'sourceFiles': source_files,
        'sourceHeadBlobs': {**source_blobs, 'pathOrder': 'sourceFiles keys sorted by UTF-8 bytes'},
        'distFiles': dist_files, 'toolFiles': tool_files, 'tools': tools,
        'sharedClosure': {}, 'evidenceGuards': evidence,
        'references': references, 'firstReadJsonProof': input_proof,
        'membership': {'dataTracked': membership(data_inputs),
                       'sourceTracked': membership(source_files), 'sourceDist': membership(dist_files),
                       'formalDataScopes': scopes},
        'allTrackedActualBytesMatchedHeadBlobs': True,
        'oldCaptureBytesRehashed': False, 'historicalFailed36551Reclassified': False,
        'collectorOnly': True, 'browserLaunched': False,
    }
    exclusive_json(output, inventory)
    sha256, _, size = file_digests(output)
    counts = {name: len(inventory[name]) for name in ('dataInputs', 'globalGuards',
              'protectedFirstThree', 'sourceFiles', 'distFiles', 'toolFiles')}
    print(json.dumps({'inventory': {'path': str(output), 'sha256': sha256, 'bytes': size},
                      'inventoryCounts': counts, 'dataHead': before_d['head'],
                      'sourceHead': before_c['head'], 'browserLaunched': False}))


if __name__ == '__main__':
    main()



