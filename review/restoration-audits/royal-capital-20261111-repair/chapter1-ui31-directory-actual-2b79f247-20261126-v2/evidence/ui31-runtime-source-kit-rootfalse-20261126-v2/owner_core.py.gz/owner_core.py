"""Static extraction of reviewed input/owned-process mechanics, no CLI.

The bind_context adapter comes from the reviewed v4 UI supervisor. This
preparation changes only native/review membership coverage to the fully hashed
dataInputs set; owned-process functions remain byte-identical to v4. They perform
no product/API work and have no automatic browser launch or temporary cleanup.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]

def bind_context(*, root, binding_value, output, inventory_reference, summary):
    # Explicitly supply the original functions' diagnostic context. This only
    # binds verifier/log sinks; no player, network, clock or process is created.
    global ROOT, binding, out, inventory_ref, binding_summary
    ROOT, binding, out = Path(root), binding_value, Path(output)
    inventory_ref, binding_summary = inventory_reference, summary

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def write_gzip(path, value):
    # Preserve complete large guard maps without duplicating plain multi-MB
    # JSON on the constrained rootfs. Compression never removes evidence rows.
    with path.open('xb') as stream:
        stream.write(gzip.compress(json.dumps(value, ensure_ascii=False).encode()))

def inputs(binding):
    data, source = Path(binding['dataRoot']), Path(binding['sourceRoot'])
    # NUL-delimited names preserve exact tracked membership without walking
    # unused ignored assets. Every admitted tracked file is hashed below.
    tracked = subprocess.check_output(['git', '-C', str(data), 'ls-files', '-z']).split(b'\0')
    assert tracked[-1] == b''
    assert sorted(tracked[:-1]) == sorted(os.fsencode(name) for name in binding['dataInputs']), 'Tracked data membership changed'
    return {'dataHead': git(data, 'rev-parse', 'HEAD'), 'dataStatus': git(data, 'status', '--short'),
            'dataInputs': {p: sha(data / p) for p in binding['dataInputs']},
            'protectedFirstThree': {p: sha(data / p) for p in binding['protectedFirstThree']},
            'resourceAndSourceGuards': {p: sha(ROOT / p) for p in binding['resourceAndSourceGuards']},
            'globalGuards': {p: sha(ROOT / p) for p in binding['globalGuards']},
            'toolFiles': {p: sha(p) for p in binding['toolFiles']},
            'kitGuards': {p: sha(p) for p in binding['kitGuards']},
            'sourceHead': git(source, 'rev-parse', 'HEAD'), 'sourceStatus': git(source, 'status', '--short'),
            'sourceFiles': {p: sha(source / p) for p in binding['source']['sourceFiles']},
            'distFiles': {p: sha(source / 'dist' / p) for p in binding['source']['distFiles']}}

def check_inputs(actual, binding):
    for key in ['dataHead', 'dataStatus', 'dataInputs', 'protectedFirstThree', 'resourceAndSourceGuards', 'globalGuards', 'toolFiles', 'kitGuards']:
        assert actual[key] == binding[key], key
    for key in ['sourceFiles', 'distFiles']:
        assert actual[key] == binding['source'][key], key
    assert actual['sourceHead'] == binding['source']['head']
    assert actual['sourceStatus'] == binding['source']['status']

def summarize_inputs(actual):
    # Every listed digest and actual membership is checked, but normal logs
    # retain only the immutable inventory reference and result. Preserve the
    # full original ACTUAL map in gzip only on an actual failed check.
    try:
        check_inputs(actual, binding)
        data, source = Path(binding['dataRoot']), Path(binding['sourceRoot'])
        for name in ['native', 'review']:
            assert {str(path.resolve()) for path in (data / name).rglob('*') if path.is_file()} <= {str((data / item).resolve()) for item in binding['dataInputs']}
        assert set(binding['source']['sourceFiles']) == {
            path for path in git(source, 'ls-files').splitlines() if (source / path).is_file()}
        assert set(binding['source']['distFiles']) == {
            str(path.relative_to(source / 'dist')) for path in (source / 'dist').rglob('*') if path.is_file()}
    except BaseException:
        original_traceback = traceback.format_exc()
        try:
            write_gzip(out / ('failed-inputs-' + str(time.time_ns()) + '.json.gz'), actual)
        except BaseException:
            print('FAILED_INPUT_ARCHIVE_ERROR ' + json.dumps({
                'originalTraceback': original_traceback, 'archiveTraceback': traceback.format_exc()}), flush=True)
        raise
    return {'inventory': inventory_ref, 'inventoryCounts': binding_summary['inventoryCounts'],
            'dataHead': actual['dataHead'], 'dataStatus': actual['dataStatus'],
            'sourceHead': actual['sourceHead'], 'sourceStatus': actual['sourceStatus'],
            'allListedDigestsFreshVerified': True, 'filesystemMembershipVerified': True,
            'actualCheckSummarySha256': hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest(),
            'largeGuardMapsPersisted': False}

def processes():
    return subprocess.check_output(['ps', '-eo', 'pid,ppid,pgid,comm,args'], text=True)

def members(group):
    result = []
    for line in processes().splitlines()[1:]:
        fields = line.strip().split(None, 4)
        if len(fields) >= 4 and int(fields[2]) == group:
            result.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                           'comm': fields[3], 'args': fields[4] if len(fields) > 4 else ''})
    return result

def stop(process):
    """Attempt only this Popen's newly created PGID, retaining every failure.

    A completed wait only reaps the launcher; it does not prove descendants
    exited. Conversely, SIGKILL is a request, not an exit receipt. The caller
    obtains a separate final PID/PGID inventory before retiring any profile.
    """
    result = {'pid': process.pid, 'pgid': process.pid, 'signals': [], 'errors': [],
              'lastGroupObservation': None}

    def signal_group(sig):
        try:
            os.killpg(process.pid, sig)
            result['signals'].append({'signal': int(sig), 'outcome': 'sent'})
        except ProcessLookupError:
            result['signals'].append({'signal': int(sig), 'outcome': 'group-not-found'})
        except Exception as error:
            result['errors'].append({'operation': 'killpg', 'signal': int(sig),
                                     'error': str(error), 'traceback': traceback.format_exc()})

    def observe_group():
        try:
            remaining = members(process.pid)
            result['lastGroupObservation'] = remaining
            return remaining
        except Exception as error:
            result['errors'].append({'operation': 'group-inventory', 'error': str(error),
                                     'traceback': traceback.format_exc()})
            result['lastGroupObservation'] = None
            return None

    # These are exclusively the process groups created with start_new_session.
    # Do not signal a discovered external browser or an escaped foreign group.
    signal_group(signal.SIGTERM)
    try:
        process.wait(timeout=12)
    except subprocess.TimeoutExpired:
        signal_group(signal.SIGKILL)
        try:
            process.wait(timeout=5)
        except Exception as error:
            result['errors'].append({'operation': 'wait-after-kill', 'error': str(error),
                                     'traceback': traceback.format_exc()})
    except Exception as error:
        result['errors'].append({'operation': 'wait-after-term', 'error': str(error),
                                 'traceback': traceback.format_exc()})

    remaining = observe_group()
    if remaining is None or remaining:
        signal_group(signal.SIGKILL)
        end = time.monotonic() + 5
        while time.monotonic() < end:
            remaining = observe_group()
            if remaining == [] or remaining is None:
                break
            time.sleep(.1)
    # Never translate an unknown inventory into an empty group. Even if this
    # function returns with survivors, final cleanup must preserve the profile.
    return result


def owned_inventory(owned):
    """Read one actual OS inventory for owned PIDs and their original PGIDs."""
    raw = processes()
    entries = []
    for line in raw.splitlines()[1:]:
        fields = line.strip().split(None, 4)
        if len(fields) >= 4:
            entries.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                            'comm': fields[3], 'args': fields[4] if len(fields) > 4 else ''})
    rows = []
    for name, process, _ in owned:
        rows.append({'kind': name, 'pid': process.pid, 'pgid': process.pid,
                     'exitCode': process.returncode,
                     'remainingOwnedPid': [row for row in entries if row['pid'] == process.pid],
                     'remainingGroupMembers': [row for row in entries if row['pgid'] == process.pid]})
    return raw, rows
