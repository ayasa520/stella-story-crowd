// Minimal caller of the separately sealed UI module. The canonical production
// page owns every API request and its normal boot; this driver never fetches a
// business endpoint, enters a scene, writes a field, prepares or plays a route.
import assert from 'node:assert/strict';
import {readFile,writeFile,realpath} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setTimeout as delay} from 'node:timers/promises';
import {sha,verifyInputs,expandInventory,parseHeldJson,readHeldJson} from './guards.mjs';
import {connect} from '../../stella-p30-firefox-20261120/bidi.mjs';
const output=process.env.STELLA_REVIEW_OUTPUT,releasePath=process.env.STELLA_RUNTIME_RELEASE_PATH;
assert.ok(output&&releasePath);
const releaseBytes=await readFile(releasePath);
const release=await parseHeldJson(releaseBytes,{path:releasePath,output,sha256:process.env.STELLA_RUNTIME_RELEASE_SHA256});
for(const flag of ['rootConfirmed','executionAuthorized','browserLaunchAuthorized','diagnosticInstrumentationAuthorized',
    'independentUi31StorageModuleAccepted','rootIndependentPreviousClosureApproved','deployedStudioApproved','budgetsApproved'])
  assert.equal(release[flag],true,flag);
assert.equal(release.browserOwner,'/root/ui_browser_owner');
assert.equal(process.env.STELLA_BROWSER_OWNER,release.browserOwner);
assert.equal(release.target,'https://stella-preview.jaoushingan.com/studio/');
assert.equal(release.module.sha256,'146cd5152f8ed47d990e1a63509442ba520e280b36705ea93aa7b9ceb877924c');
assert.equal(release.helper.sha256,'a7539a14ea582056b5d2759207b75d251cf85f49ee87f0977205f24673df760a');
assert.equal(release.modulePeer.sha256,'2fd27b66904e8fe06d9d76b593653d7f136fbad725e08c445c0d43255ba8c61c');
assert.equal(release.plan.sha256,'5817b5a9372144b7db7983baf45fe1050d7e18bfc5ae040abb442fda5d107d99');
// The new source dependency must be independently bound before any module import.
assert.equal(release.diagnosticStorage.sha256,'f204acbfee9fdbe10ce63fd0d42f4e26c959190b58b75dab1a1c26cc5c3fa7b0');
const root=new URL('../../../',import.meta.url).pathname;
for(const [name,digest]of Object.entries(release.runtimeBindings))
  assert.equal(sha(await readFile(resolve(root,name))),digest,name);
const refs=[release.module,release.helper,release.plan,release.modulePeer,release.previousCaseIndependentClosure,release.deployedGuardReceipt,release.diagnosticStorage];
for(const ref of refs)assert.equal(sha(await readFile(ref.path)),ref.sha256,ref.path);
// The approved helper ref must identify the module's actual relative import.
assert.equal(await realpath(release.helper.path),await realpath(new URL('./reference-fetch-scope.mjs',
  pathToFileURL(await realpath(release.module.path)))));
assert.equal(await realpath(release.diagnosticStorage.path),await realpath(new URL('./diagnostic-storage.mjs',
  pathToFileURL(await realpath(release.module.path)))));
const inventory=await readHeldJson(release.guardInventory.path,{output,sha256:release.guardInventory.sha256,bytes:release.guardInventory.bytes});
const binding=await expandInventory({inventory:release.guardInventory,inventoryCounts:release.inventoryCounts,
  dataRoot:inventory.dataRoot,sourceRoot:inventory.sourceRoot,dataHead:release.publishedHead,dataStatus:'',
  source:{head:release.sourceHead,status:release.sourceStatus},
  kitGuards:Object.fromEntries(Object.entries(release.runtimeBindings).map(([name,digest])=>[resolve(root,name),digest])),
  additionalGuards:{...release.additionalGuards,[releasePath]:sha(releaseBytes),
    [release.guardInventory.path]:release.guardInventory.sha256,...Object.fromEntries(refs.map(ref=>[ref.path,ref.sha256]))}},inventory);
assert.equal(await realpath(process.execPath),await realpath(release.tools.node.binaryPath));
assert.equal(sha(await readFile(process.execPath)),release.tools.node.sha256);
await verifyInputs(binding);
// Only now import the exact approved module. No dynamic source extraction,
// substitute response, private parser, fixture, Worker or auth token is used.
const {installDirectoryFlowObserver,runDirectorySweep,referenceFetchScope,referenceFetchRequiredEvents,
  referenceConsoleScope,referenceConsoleRequiredEvents,prepareDiagnosticArchive,
  assertDiagnosticArchiveBudget,writeDiagnosticArchive}=await import(pathToFileURL(release.module.path));
const plan=await readHeldJson(release.plan.path,{output,sha256:release.plan.sha256,bytes:release.plan.bytes});
assert.equal(plan.target,release.target);assert.equal(plan.inspectedSourceHead,release.sourceHead);
assert.equal(plan.budgets.totalMilliseconds,510000);assert.equal(plan.budgets.ownerWatchdogMilliseconds,570000);
// eventOrder records the actual callback interleaving across console, network,
// context and realm events. It references the unchanged raw arrays rather than
// copying payloads. No timestamp sort, source hook or page script is involved.
const subscribedEvents=[...new Set([...plan.requiredEvents,...referenceFetchRequiredEvents,...referenceConsoleRequiredEvents])];
const consoleEntries=[],networkEvents=[],eventOrder=[],exceptions=[],fatalFacts=[],hitches=[],ownerFailures=[];
const fatalProductNames=new Set(['STORY_PLAYER_ERROR','STORY_NORMAL_CLOCK_LISTENER_ERROR','STORY_NORMAL_CLOCK_REPORT_ERROR',
  'STORY_FX_ERROR','STORY_BACKGROUND_ERROR','STORY_PICTURE_ERROR','STORY_BGM_LOAD_FAILED']);
const allowedPosts=new Set(['/api/resolve','/api/commands/inspect','/api/commands/build','/api/project/open']);
let target,capabilities,driver,sessionRetired=false,firstFailure=null,sweepResult=null,lastDocument=null;
const secondaryFailures=[],failureExports=[];
const diagnostics=()=>({consoleEntries,networkEvents,exceptions,eventOrder});
const save=(name,value)=>writeFile(resolve(output,name),JSON.stringify(value)+'\n',{flag:'wx'});
async function saveGzip(name,value){
  return writeDiagnosticArchive(output,name,value,plan);
}
function healthy(boundary){
  assert.deepEqual(exceptions,[],'Original exceptions at '+boundary);
  const consoleScope=referenceConsoleScope(diagnostics(),new URL(release.target).origin,target?.context);
  assert.equal(consoleScope.summary.arrivalSequenceComplete,true,'Original arrival sequence unproven at '+boundary);
  assert.deepEqual(consoleScope.fatal,[],'Original console error without external realm provenance at '+boundary);
  // Keep every original fatalFacts row in exports. Only the same original
  // console object positively attributed by the shared pure classifier may be
  // diagnostic here; JavaScript and explicit product fatal names remain fatal.
  const external=new Set(consoleScope.externalReference);
  assert.deepEqual(fatalFacts.filter(row=>!external.has(row.params)),[],'Original fatal events at '+boundary);
  assert.deepEqual(ownerFailures,[],'Owner diagnostic failures at '+boundary);
  assert.deepEqual(referenceFetchScope(networkEvents,new URL(release.target).origin,target?.context).fatal,[],
    'Original network error at '+boundary);
  const failures=networkEvents.filter(e=>e.event==='network.responseCompleted'&&e.params.response.status>=400&&
    new URL(e.params.response.url).pathname!=='/favicon.ico');
  assert.deepEqual(failures,[],'Original HTTP failure at '+boundary);
  const mutations=networkEvents.filter(e=>e.event==='network.beforeRequestSent'&&
    new URL(e.params.request.url).origin===new URL(release.target).origin&&
    new URL(e.params.request.url).pathname.startsWith('/api/')&&e.params.request.method!=='GET'&&
    !allowedPosts.has(new URL(e.params.request.url).pathname));
  assert.deepEqual(mutations,[],'Unexpected canonical API mutation/prepare at '+boundary);
  assertDiagnosticArchiveBudget(prepareDiagnosticArchive(diagnostics(),'owner-final-diagnostics.json.gz',plan));
}
function retain(error,boundary){
  const fact={boundary,error:String(error),stack:error?.stack||'',epochMilliseconds:Date.now()};
  if(!firstFailure)firstFailure=fact;else secondaryFailures.push(fact);
}
async function evaluate(fn,arg){
  const reply=await driver.call('script.evaluate',{target,awaitPromise:true,
    expression:`(async()=>JSON.stringify(await (${fn})(${JSON.stringify(arg)})))()`});
  if(reply.type!=='success'){
    ownerFailures.push({operation:'original-script-evaluate',reply});
    throw Error(reply.exceptionDetails?.text||'Original Firefox evaluation failed');
  }
  return reply.result.type==='undefined'?null:parseHeldJson(reply.result.value,{path:'original-script-evaluate-reply',output});
}
async function exportFailure(error,boundary){
  // Keep the complete structured module attachment. String(error) alone loses
  // its raw-flow fallback when the module's own disk writes have failed.
  const packet={boundary,firstFailure,error:String(error),stack:error?.stack||'',
    sweepFailure:error?.sweepFailure??null,sweepExportErrors:error?.sweepExportErrors??null,
    sweepFallback:error?.sweepFallback??null,diagnostics:diagnostics(),fatalFacts,hitches,ownerFailures,
    lastDocument,secondaryFailures,exportErrors:[]};
  if(target&&!sessionRetired)try{
    packet.actualDocument=await evaluate(()=>({href:location.href,timeOrigin:performance.timeOrigin,
      state:window.reviewDirectorySweep?.snapshot()||null,observation:window.reviewDirectorySweep?.data()||null}));
  }catch(exportError){packet.exportErrors.push({operation:'actual-document',error:String(exportError),stack:exportError.stack});}
  try{
    packet.networkScope=referenceFetchScope(networkEvents,new URL(release.target).origin,target?.context).summary;
  }catch(scopeError){
    // Scope diagnostics must not replace the first error or skip full raw
    // sweepFallback export when an original row itself is malformed.
    packet.exportErrors.push({operation:'network-scope-summary',error:String(scopeError),stack:scopeError.stack});
  }
  try{
    packet.consoleScope=referenceConsoleScope(diagnostics(),new URL(release.target).origin,target?.context).summary;
  }catch(scopeError){
    packet.exportErrors.push({operation:'console-scope-summary',error:String(scopeError),stack:scopeError.stack});
  }
  failureExports.push(packet);
  try{const archive=await saveGzip('owner-failure-'+failureExports.length+'.json.gz',packet);
    console.error('OWNER_STRUCTURED_FAILURE_RETAINED',JSON.stringify({firstFailure,archive}));}
  catch(exportError){
    // The original driver log is an independent supervisor-owned sink. If the
    // archive write fails, emit the COMPLETE object here, never a shortened
    // string or a passing result. A budget error after both writes may cite
    // that complete archive instead. Output crossings retain facts and fail.
    const exportFact={operation:'owner-failure-archive',error:String(exportError),stack:exportError.stack};
    packet.exportErrors.push(exportFact);
    if(exportError.retainedDiagnosticArchive)
      console.error('OWNER_COMPLETE_BUDGET_CROSSING_ARCHIVE_RETAINED '+JSON.stringify({exportError:exportFact,
        archive:exportError.retainedDiagnosticArchive}));
    else console.error('OWNER_FULL_STRUCTURED_FAILURE '+JSON.stringify(packet));
    retain(exportError,'failure archive sink');
  }
}
try{
  driver=await connect(process.argv[2]);
  ({capabilities}=await driver.call('session.new',{capabilities:{}}));
  const {contexts}=await driver.call('browsingContext.getTree');target={context:contexts[0].context};
  driver.events((event,params)=>{
    if(event==='log.entryAdded'){
      eventOrder.push({event,index:consoleEntries.length});
      consoleEntries.push(params);
      if(params.type==='javascript')exceptions.push(params);
      const name=(params.text||'').split(/\s+/,1)[0];
      if(params.level==='error'||params.type==='javascript'||fatalProductNames.has(name))
        fatalFacts.push({event,params,reason:params.level==='error'?'original-console.error':
          params.type==='javascript'?'original-javascript-exception':'explicit-product-fatal'});
      if(name==='STORY_NORMAL_FRAME_HITCH')hitches.push({event,params});
    }else if(subscribedEvents.includes(event)){
      eventOrder.push({event,index:networkEvents.length});
      networkEvents.push({event,params});
    }
  });
  await driver.call('session.subscribe',{events:subscribedEvents,contexts:[target.context]});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:installDirectoryFlowObserver.toString()});
  await driver.call('browsingContext.setViewport',{context:target.context,viewport:{width:1600,height:1100},devicePixelRatio:1});
  await driver.call('browsingContext.navigate',{context:target.context,url:release.target,wait:'interactive'});
  // Normal app.start owns catalog, GET state?sceneId=10010001, editor setup and
  // its canonical read-only resolve/inspect traffic. No manual boot API, route,
  // localStorage, cookie, selection, before or form field is injected here.
  const deadline=Date.now()+45000;
  while(Date.now()<deadline){
    healthy('ordinary Studio boot');
    const state=await evaluate(()=>{
      const observer=window.reviewDirectorySweep,button=document.getElementById('workspaces'),
        bootComplete=document.getElementById('manageProjects');
      // Canonical app.start enables manageProjects only at its final success
      // boundary, after the real initial state/editor/resolve setup completes.
      if(!observer||!button||button.disabled||!bootComplete||bootComplete.disabled)return null;
      const state=observer.snapshot();
      return state.activeNode&&state.workspace&&!state.open&&state.playerHidden?state:null;
    });
    if(state){lastDocument=state;break;}
    await delay(75);
  }
  assert.ok(lastDocument,'Normal Studio boot did not reach a real active workspace; no alternate entry/retry');
  await save('ordinary-boot.json',{target:release.target,actual:lastDocument,
    originalApiRequests:networkEvents.filter(e=>e.event==='network.beforeRequestSent'&&
      new URL(e.params.request.url).pathname.startsWith('/api/')),
    originalUiBootOwnedByProduct:true,driverApiCalls:0});
  healthy('before module');
  // The module's tiny driver interface forwards the exact call once. This
  // owner boundary also rejects explicit info-level product fatal events
  // immediately before trusted input; it does not wrap any page method.
  const moduleDriver={call(method,params){
    if(method==='input.performActions')healthy('immediately before module BiDi input');
    return driver.call(method,params);
  }};
  sweepResult=await runDirectorySweep({driver:moduleDriver,target,evaluate,readDiagnostics:diagnostics,plan,
    approval:{rootConfirmed:release.rootConfirmed,executionAuthorized:release.executionAuthorized,
      browserOwner:release.browserOwner,expectedDataHead:release.publishedHead,expectedSourceHead:release.sourceHead},output});
  healthy('after module');
  const actual=await readHeldJson(resolve(output,'sweep.result.json'),{output});
  assert.equal(actual.all31ApiDomChecksPassed,true);assert.equal(actual.completed.length,31);
  assert.equal(actual.firstFailure,null);assert.deepEqual(actual.finalizationErrors,[]);
  assert.equal(actual.playerPreparedOrPlayed,false);assert.equal(actual.images,0);
  await save('module-completion.json',{sweepResult,completedSections:actual.completed.length,
    all31ApiDomChecksPassed:actual.all31ApiDomChecksPassed,hitCoverage:actual.actualEdgeMeasurements.hitCoverage,
    hitSamplingUnprovenEdges:actual.hitSamplingUnprovenEdges,networkScope:actual.networkScope,consoleScope:actual.consoleScope,
    pixelReviewPerformed:false,sourceAcceptance:false});
}catch(error){
  retain(error,'ordinary UI/module');await exportFailure(error,'ordinary UI/module');
}finally{
  // Even module export failures must not skip restoring its observer, ending
  // BiDi or closing the client. Each operation is independently attempted.
  if(target&&!sessionRetired)try{
    const cleanup=await evaluate(()=>window.reviewDirectorySweep?.stop()||null);
    await save('owner-observer-stop.json',cleanup);
  }catch(error){retain(error,'owner observer cleanup');await exportFailure(error,'owner observer cleanup');}
  if(driver)try{
    healthy('before session retirement');
  }catch(error){retain(error,'pre-retirement original diagnostics');await exportFailure(error,'pre-retirement');}
  if(driver)try{await driver.call('session.end');sessionRetired=true;}
  catch(error){retain(error,'session.end');await exportFailure(error,'session.end');}
  finally{try{driver.close();}catch(error){retain(error,'driver.close');}}
}
try{
  healthy('after session retirement');
  assert.equal(firstFailure,null,'First original/owner failure remains fatal');
  assert.equal(sessionRetired,true);assert.ok(sweepResult);
  await verifyInputs(binding);
  const finalDiagnostics=await saveGzip('owner-final-diagnostics.json.gz',{...diagnostics(),hitches,fatalFacts,
    ownerFailures,secondaryFailures,capabilities,sessionRetired,subscribedEvents,
    networkScope:referenceFetchScope(networkEvents,new URL(release.target).origin,target?.context).summary,
    consoleScope:referenceConsoleScope(diagnostics(),new URL(release.target).origin,target?.context).summary,originalRowsDropped:0});
  healthy('after final diagnostic export');
  const result=await readHeldJson(resolve(output,'sweep.result.json'),{output});
  await save('terminal-acceptance.json',{accepted:true,sessionRetired,completedSections:result.completed.length,
    all31ApiDomChecksPassed:result.all31ApiDomChecksPassed,hitCoverage:result.actualEdgeMeasurements.hitCoverage,
    hitSamplingUnprovenEdges:result.hitSamplingUnprovenEdges,finalDiagnostics,
    networkScope:referenceFetchScope(networkEvents,new URL(release.target).origin,target?.context).summary,
    consoleScope:referenceConsoleScope(diagnostics(),new URL(release.target).origin,target?.context).summary,
    captures:0,mediaCaptures:0,sourceAcceptance:false,pixelReviewPerformed:false,requiresRootIndependentOsClosure:true});
  healthy('after terminal receipt');
  console.log(JSON.stringify({terminalAccepted:true,completedSections:31,hitCoverage:result.actualEdgeMeasurements.hitCoverage,
    sessionRetired,captures:0,mediaCaptures:0,
    networkScope:referenceFetchScope(networkEvents,new URL(release.target).origin,target?.context).summary,
    consoleScope:referenceConsoleScope(diagnostics(),new URL(release.target).origin,target?.context).summary}));
}catch(error){
  retain(error,'terminal UI diagnostics');await exportFailure(error,'terminal UI diagnostics');
  process.exitCode=1;
}
