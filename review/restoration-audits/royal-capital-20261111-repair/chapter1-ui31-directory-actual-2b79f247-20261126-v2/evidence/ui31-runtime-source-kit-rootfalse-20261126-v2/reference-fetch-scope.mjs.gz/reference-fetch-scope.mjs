// Pure diagnostic classification, never a request/response or product hook.
// The future owner must retain these ORIGINAL lifecycle events in arrival order
// together with its unchanged network rows. No ID, URL query, timing or cause is
// seeded. Missing provenance always leaves a fetch error fatal.
export const referenceFetchRequiredEvents=Object.freeze([
  'browsingContext.contextCreated','browsingContext.navigationStarted','browsingContext.contextDestroyed'
]);

export function referenceFetchScope(events,productOrigin,topContext){
  if(!Array.isArray(events))throw Error('Original network/lifecycle event array unavailable');
  const contexts=new Map(),navigations=new Map(),documents=new Map(),requests=new Map();
  const fatal=[],externalReference=[],provenance=[];
  let rawFetchErrors=0,rawHttpErrors=0,sameOriginFetchErrors=0;
  const url=value=>{try{return new URL(value);}catch{return null;}};
  const product=url(productOrigin)?.origin,player='https://player.bilibili.com';
  const key=(context,id)=>typeof context==='string'&&context&&typeof id==='string'&&id?context+'\0'+id:null;
  const header=(request,name)=>{
    const matches=request?.headers?.filter(h=>h.name?.toLowerCase()===name)||[];
    return matches.length===1&&matches[0].value?.type==='string'?matches[0].value.value:null;
  };
  const mediaHost=u=>u?.protocol==='https:'&&!u.username&&!u.password&&!u.port&&
    /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+bilivideo\.com$/.test(u.hostname);
  const clear=context=>{
    contexts.delete(context);navigations.delete(context);documents.delete(context);
    if(context===topContext){contexts.clear();navigations.clear();documents.clear();}
  };
  for(let index=0;index<events.length;index++){
    const row=events[index],p=row.params??row,request=p.request,u=url(request?.url),context=p.context;
    if(row.event==='browsingContext.contextCreated'){
      clear(context);contexts.set(context,{parent:p.parent,index});
    }
    if(row.event==='browsingContext.contextDestroyed')clear(context);
    if(row.event==='browsingContext.navigationStarted'){
      // Even about:blank/data/cross-origin navigations invalidate the old
      // document. Network-only document tracking cannot prove this boundary.
      if(context===topContext){contexts.clear();documents.clear();navigations.clear();}
      const old=documents.get(context);
      if(old&&(old.navigation!==p.navigation||old.href!==p.url))documents.delete(context);
      navigations.set(context,{navigation:p.navigation,href:p.url,timestamp:p.timestamp,index});
    }
    if(row.event==='network.beforeRequestSent'){
      const id=key(context,request?.request);
      if(request?.destination==='iframe'||request?.destination==='document'){
        // A real document request replaces provenance even when it is NOT the
        // approved reference document. A response200 for the same request and
        // navigation is required before any media request can use this record.
        documents.set(context,{index,timestamp:p.timestamp,href:u?.href,
          requestId:request.request,navigation:p.navigation,createdIndex:contexts.get(context)?.index,
          reference:request.method==='GET'&&request.destination==='iframe'&&request.initiatorType==='iframe'&&
            u?.origin===player&&u.pathname==='/player.html'&&!u.username&&!u.password,
          completeIndex:null,completeTimestamp:null});
      }
      if(id)requests.set(id,{index,timestamp:p.timestamp,request,navigation:p.navigation,
        documentIndex:documents.get(context)?.index,createdIndex:contexts.get(context)?.index,
        navigationIndex:navigations.get(context)?.index});
    }
    if(row.event==='network.responseCompleted'){
      if(p.response?.status>=400)rawHttpErrors++;
      const doc=documents.get(context);
      if(doc&&doc.requestId===request?.request&&doc.navigation===p.navigation&&
          u?.href===doc.href&&p.response?.url===doc.href&&p.response.status===200){
        doc.completeIndex=index;doc.completeTimestamp=p.timestamp;
      }
    }
    if(row.event!=='network.fetchError')continue;
    rawFetchErrors++;
    // Same-origin Stella is tested FIRST and is never exempt, whatever
    // headers, context, error text or media-looking pathname accompany it.
    if(u&&u.origin===product){sameOriginFetchErrors++;fatal.push(row);continue;}
    const before=requests.get(key(context,request?.request)),doc=documents.get(context),
      created=contexts.get(context),nav=navigations.get(context);
    const range=header(request,'range'),origin=header(request,'origin'),refererText=header(request,'referer'),
      referer=url(refererText);
    const proven=Boolean(product)&&typeof topContext==='string'&&topContext&&
      created?.parent===topContext&&context!==topContext&&doc?.reference&&
      typeof doc.navigation==='string'&&doc.navigation&&nav?.navigation===doc.navigation&&nav.href===doc.href&&
      Number.isFinite(nav.timestamp)&&Number.isFinite(doc.timestamp)&&nav.timestamp<=doc.timestamp&&
      doc.completeIndex!==null&&Number.isFinite(doc.completeTimestamp)&&doc.timestamp<=doc.completeTimestamp&&
      before&&before.index>doc.completeIndex&&before.documentIndex===doc.index&&
      before.createdIndex===created.index&&doc.createdIndex===created.index&&before.navigationIndex===nav.index&&
      Number.isFinite(before.timestamp)&&Number.isFinite(p.timestamp)&&
      doc.completeTimestamp<=before.timestamp&&before.timestamp<=p.timestamp&&
      before.navigation===null&&p.navigation===null&&
      before.request.url===request.url&&before.request.method==='GET'&&request.method==='GET'&&
      mediaHost(u)&&u.pathname.endsWith('.m4s')&&
      typeof range==='string'&&/^bytes=\d+-\d*$/.test(range)&&header(before.request,'range')===range&&
      origin===player&&header(before.request,'origin')===origin&&
      referer?.origin===player&&!referer.username&&!referer.password&&header(before.request,'referer')===refererText&&
      p.errorText==='NS_BINDING_ABORTED'&&p.isBlocked===false;
    if(proven){
      externalReference.push(row);
      provenance.push({errorIndex:index,requestIndex:before.index,contextCreatedIndex:created.index,
        navigationIndex:nav.index,documentRequestIndex:doc.index,documentResponseIndex:doc.completeIndex,
        context,cancelCause:'unknown'});
    }else fatal.push(row);
  }
  return {fatal,externalReference,provenance,summary:{observationAvailable:true,
    rawFetchErrorCount:rawFetchErrors,rawHttpErrorCount:rawHttpErrors,sameOriginFetchErrorCount:sameOriginFetchErrors,
    externalReferenceErrorCount:externalReference.length,retainedExternalReferenceFetchErrors:externalReference.length,
    strictFetchErrorCount:fatal.length,allNetworkClean:rawFetchErrors===0&&rawHttpErrors===0,
    cancelCause:externalReference.length?'unknown':null,externalCancellationCause:externalReference.length?'unknown':null,
    externalReferenceProvenance:provenance,
    rawEventIndexBasis:'Caller original ordered network/lifecycle rows; every raw row remains in diagnostics',
    qualification:'Original rows retained; classification is not a cause, retry or all-network acceptance'}};
}

// Console attribution uses received-event ORDER, never cross-module timestamps.
// W3C realmCreated.params is RealmInfo (window: realm/origin/context/type);
// realmDestroyed.params contains realm only. Missing/later/invalid evidence is
// never invented from a stack URL or the word "bilibili" in a message.
export const referenceConsoleRequiredEvents=Object.freeze(['script.realmCreated','script.realmDestroyed']);

export function referenceConsoleScope(diagnostics,productOrigin,topContext){
  const {consoleEntries,networkEvents,eventOrder}=diagnostics??{};
  if(!Array.isArray(consoleEntries)||!Array.isArray(networkEvents))
    throw Error('Original console/network arrays unavailable');
  const errors=consoleEntries.filter(p=>p.level==='error'||p.type==='javascript');
  const fatal=[],externalReference=[],provenance=[];
  const url=value=>{try{return new URL(value);}catch{return null;}};
  const product=url(productOrigin)?.origin,player='https://player.bilibili.com';
  const script='https://s1.hdslb.com/bfs/seed/jinkela/short/user-fingerprint/bili-user-fingerprint.min.js';
  const signature='@bilibili/bili-user-fingerprint(report): report is not found';
  const header=(request,name)=>{
    const rows=request?.headers?.filter(h=>h.name?.toLowerCase()===name)||[];
    return rows.length===1&&rows[0].value?.type==='string'?rows[0].value.value:null;
  };
  // This compact journal references each original row exactly once. Its two
  // indexes advance independently, preserving the old raw-array evidence while
  // proving their interleaving without serializing every network payload twice.
  let ci=0,ni=0;
  const ordered=[];
  let complete=Array.isArray(eventOrder);
  for(const entry of complete?eventOrder:[]){
    if(!entry||typeof entry.event!=='string'){complete=false;break;}
    if(entry.event==='log.entryAdded'){
      if(entry.index!==ci||ci>=consoleEntries.length){complete=false;break;}
      ordered.push({event:entry.event,params:consoleEntries[ci++],rawIndex:entry.index});
    }else{
      const row=networkEvents[ni];
      if(entry.index!==ni||!row||row.event!==entry.event||!row.params){complete=false;break;}
      ordered.push({...row,rawIndex:ni++});
    }
  }
  complete=complete&&ci===consoleEntries.length&&ni===networkEvents.length;
  const contexts=new Map(),navs=new Map(),docs=new Map(),realms=new Map(),scripts=new Map();
  const clearDocument=context=>{
    navs.delete(context);docs.delete(context);scripts.delete(context);
    for(const [id,realm]of realms)if(realm.context===context)realms.delete(id);
  };
  const clearContext=context=>{
    if(context===topContext){contexts.clear();navs.clear();docs.clear();realms.clear();scripts.clear();}
    else{contexts.delete(context);clearDocument(context);}
  };
  if(!complete)fatal.push(...errors);
  else for(let arrivalIndex=0;arrivalIndex<ordered.length;arrivalIndex++){
    const row=ordered[arrivalIndex],p=row.params,context=p.context,request=p.request;
    const created=contexts.get(context);
    if(row.event==='browsingContext.contextCreated'){
      clearContext(context);contexts.set(context,{parent:p.parent,index:arrivalIndex});
    }else if(row.event==='browsingContext.contextDestroyed')clearContext(context);
    else if(row.event==='browsingContext.navigationStarted'){
      // A reused context ID is not a reused document or realm. Top navigation
      // also invalidates all previously observed children, even about:blank.
      if(context===topContext)clearContext(context);else clearDocument(context);
      navs.set(context,{id:p.navigation,href:p.url,index:arrivalIndex});
    }else if(row.event==='script.realmDestroyed')realms.delete(p.realm);
    else if(row.event==='script.realmCreated'){
      // Only the original unsandboxed window realm may identify this console.
      // Invalidate an earlier binding even if a replacement record is malformed.
      realms.delete(p.realm);
      if(p.type==='window'&&p.sandbox===undefined)
        for(const [id,previous]of realms)if(previous.context===context)realms.delete(id);
      const nav=navs.get(context),u=url(nav?.href);
      if(p.type==='window'&&p.sandbox===undefined&&typeof p.realm==='string'&&p.realm&&
          p.origin===player&&created?.parent===topContext&&context!==topContext&&
          u?.origin===player&&u.pathname==='/player.html'&&!u.username&&!u.password&&
          typeof nav.id==='string'&&nav.id)
        realms.set(p.realm,{context,origin:p.origin,index:arrivalIndex,
          createdIndex:created.index,navigationIndex:nav.index});
    }else if(row.event==='network.beforeRequestSent'){
      const nav=navs.get(context),u=url(request?.url);
      if(request?.destination==='iframe'||request?.destination==='document'){
        docs.delete(context);scripts.delete(context);
        if(created?.parent===topContext&&context!==topContext&&request.method==='GET'&&
            request.destination==='iframe'&&request.initiatorType==='iframe'&&
            u?.origin===player&&u.pathname==='/player.html'&&!u.username&&!u.password&&
            typeof request.request==='string'&&request.request&&typeof p.navigation==='string'&&p.navigation&&
            nav?.id===p.navigation&&nav.href===u.href)
          docs.set(context,{id:request.request,href:u.href,navigation:p.navigation,
            index:arrivalIndex,createdIndex:created.index,navigationIndex:nav.index,completeIndex:null});
      }else if(request?.url===script&&request.destination==='script'){
        scripts.delete(context);
        const doc=docs.get(context);
        if(request.method==='GET'&&typeof request.request==='string'&&request.request&&p.navigation===null&&
            doc?.completeIndex!==null&&doc?.completeIndex!==undefined&&
            header(request,'referer')===player+'/')
          scripts.set(context,{id:request.request,index:arrivalIndex,documentIndex:doc.index,completeIndex:null});
      }
    }else if(row.event==='network.responseCompleted'){
      const doc=docs.get(context),loaded=scripts.get(context);
      if(doc&&request?.request===doc.id&&request.method==='GET'&&p.navigation===doc.navigation&&
          request.url===doc.href&&p.response?.url===doc.href&&p.response.status===200)
        doc.completeIndex=arrivalIndex;
      if(loaded&&request?.request===loaded.id&&request.method==='GET'&&request.url===script&&
          request.destination==='script'&&p.navigation===null&&p.response?.url===script&&p.response.status===200&&
          header(request,'referer')===player+'/'&&doc?.index===loaded.documentIndex)
        loaded.completeIndex=arrivalIndex;
    }else if(row.event==='network.fetchError'){
      if(scripts.get(context)?.id===request?.request)scripts.delete(context);
      if(docs.get(context)?.id===request?.request){docs.delete(context);scripts.delete(context);}
    }else if(row.event==='log.entryAdded'&&(p.level==='error'||p.type==='javascript')){
      const source=p.source,child=contexts.get(source?.context),realm=realms.get(source?.realm),
        nav=navs.get(source?.context),doc=docs.get(source?.context),loaded=scripts.get(source?.context);
      // Product/top/unknown provenance is checked before the narrow known
      // external signature. A third-party script can also execute in Stella.
      const proven=Boolean(product)&&typeof topContext==='string'&&topContext&&
        source?.context!==topContext&&child?.parent===topContext&&
        realm?.context===source.context&&realm.origin===player&&realm.origin!==product&&
        realm.createdIndex===child.index&&realm.navigationIndex===nav?.index&&
        doc?.createdIndex===child.index&&doc.navigationIndex===nav?.index&&doc.navigation===nav?.id&&doc.href===nav?.href&&
        doc.completeIndex!==null&&doc.completeIndex<arrivalIndex&&
        loaded?.documentIndex===doc.index&&loaded.completeIndex!==null&&loaded.completeIndex<arrivalIndex&&
        realm.index<loaded.index&&loaded.index>doc.completeIndex&&
        p.type==='console'&&p.level==='error'&&p.method==='error'&&p.text===signature&&
        p.args?.length===1&&p.args[0].type==='string'&&p.args[0].value===signature&&
        Array.isArray(p.stackTrace?.callFrames)&&p.stackTrace.callFrames.length>0&&
        p.stackTrace.callFrames.every(frame=>frame.url===script);
      if(proven){
        externalReference.push(p);
        provenance.push({consoleIndex:row.rawIndex,consoleArrivalIndex:arrivalIndex,
          context:source.context,realm:source.realm,origin:realm.origin,contextCreatedArrivalIndex:child.index,
          navigationArrivalIndex:nav.index,documentRequestArrivalIndex:doc.index,
          documentResponseArrivalIndex:doc.completeIndex,realmCreatedArrivalIndex:realm.index,
          scriptRequestArrivalIndex:loaded.index,scriptResponseArrivalIndex:loaded.completeIndex,cause:'unknown'});
      }else fatal.push(p);
    }
  }
  return {fatal,externalReference,provenance,summary:{observationAvailable:true,arrivalSequenceComplete:complete,
    rawConsoleErrorCount:errors.length,rawJavaScriptExceptionCount:consoleEntries.filter(p=>p.type==='javascript').length,
    externalReferenceConsoleErrorCount:externalReference.length,strictConsoleErrorCount:fatal.length,
    allConsoleClean:errors.length===0,cause:externalReference.length?'unknown':null,
    externalReferenceProvenance:provenance,
    qualification:'Original rows retained; positive source attribution is not an error cause or retroactive acceptance'}};
}
