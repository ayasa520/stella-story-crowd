"""Rootfalse UI31 source preparation; no release or runtime authority is included.

A separately reviewed future release owns one headless Firefox only.

No API client, local server, Worker, recorder or automatic TemporaryDirectory is
created. The sole new work is ordinary production Studio navigation and the
separately reviewed31-section module. Original verifier/process functions are
referenced from the small byte-extracted owner_core, not from an executable CLI.
"""
import argparse
import base64
import errno
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
_UNBOUND_SHA256 = object()
def load(path, expected_sha256=_UNBOUND_SHA256, expected_bytes=None):
    # Hash and parse the SAME first-read bytes. A parse/proof failure preserves
    # that buffer plus the original decoder document/position and traceback;
    # it never rereads, repairs, normalizes or retries a malformed source.
    raw = Path(path).read_bytes()
    proof = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    try:
        if expected_sha256 is not _UNBOUND_SHA256:
            assert proof['sha256'] == expected_sha256, proof
        if expected_bytes is not None:
            assert proof['bytes'] == expected_bytes, proof
        return json.loads(raw)
    except BaseException as error:
        fact = {**proof, 'error': str(error), 'traceback': traceback.format_exc(),
                'doc': getattr(error, 'doc', None), 'pos': getattr(error, 'pos', None),
                'lineno': getattr(error, 'lineno', None), 'colno': getattr(error, 'colno', None)}
        try:
            sink = HERE / args.attempt
            sink.mkdir(exist_ok=True)
            stem = sink / ('json-first-read-' + str(time.time_ns()))
            with Path(str(stem) + '.raw.gz').open('xb') as stream:
                stream.write(gzip.compress(raw, compresslevel=1))
            with Path(str(stem) + '.failure.json.gz').open('xb') as stream:
                stream.write(gzip.compress(json.dumps(fact, ensure_ascii=False).encode(), compresslevel=1))
            print('JSON_FIRST_READ_FAILED ' + json.dumps({**proof, 'rawArchive': str(stem) + '.raw.gz',
                  'failureArchive': str(stem) + '.failure.json.gz', 'error': str(error)}), flush=True)
        except BaseException as archive_error:
            print('JSON_FIRST_READ_ARCHIVE_FAILED ' + json.dumps({**fact,
                  'rawBase64': base64.b64encode(raw).decode('ascii'),
                  'archiveError': str(archive_error), 'archiveTraceback': traceback.format_exc()}), flush=True)
        raise
# A Python signal handler runs between arbitrary bytecode instructions. It
# must NEVER raise in the Popen-return -> owned.append registration interval,
# or interrupt the independent cleanup attempts. Record flags only; ordinary
# cooperative boundaries below raise after the new PG is fully registered.
stop_requests = []
deferred_stop_signal = None
deferred_stop_boundary = None
class OwnerStopRequested(RuntimeError):
    pass
def defer_stop(signum, _frame):
    global deferred_stop_signal
    if deferred_stop_signal is None:
        deferred_stop_signal = signum
    stop_requests.append(signum)
def cooperate(boundary):
    global deferred_stop_boundary
    if deferred_stop_signal is not None:
        deferred_stop_boundary = boundary
        raise OwnerStopRequested('Deferred signal ' + str(deferred_stop_signal) + ' at ' + boundary)
signal.signal(signal.SIGTERM, defer_stop)
signal.signal(signal.SIGINT, defer_stop)

parser = argparse.ArgumentParser()
parser.add_argument('--release', required=True)
parser.add_argument('--release-sha256', required=True)
parser.add_argument('--attempt', required=True)
args = parser.parse_args()
assert re.fullmatch(r'attempt-[1-9][0-9]*', args.attempt)
release_path = Path(args.release).resolve()
assert not (HERE / args.attempt).exists(), 'Never reuse an earlier attempt'
release = load(release_path, args.release_sha256)
assert all(release.get(flag) is True for flag in ['rootConfirmed', 'executionAuthorized',
    'browserLaunchAuthorized', 'diagnosticInstrumentationAuthorized', 'independentUi31StorageModuleAccepted',
    'rootIndependentPreviousClosureApproved', 'deployedStudioApproved', 'budgetsApproved'])
assert release['browserOwner'] == os.environ.get('STELLA_BROWSER_OWNER') == '/root/ui_browser_owner'
assert release['attempt'] == args.attempt
assert release['target'] == 'https://stella-preview.jaoushingan.com/studio/'
assert release['maximumDriverSeconds'] == 570
assert release['moduleMaximumMilliseconds'] == 510000
assert release['expectedTotalOutputBytes'] == 16777216
assert os.getpriority(os.PRIO_PROCESS, 0) == 19 and sorted(os.sched_getaffinity(0)) == [0, 1]
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
bindings = release['runtimeBindings']
required = [HERE / 'run.py', HERE / 'play.mjs', HERE / 'owner_core.py',
    ROOT / 'artifacts/stella-p30-firefox-20261120/bidi.mjs',
    HERE / 'guards.mjs',
    Path(release['module']['path']), Path(release['helper']['path']), Path(release['diagnosticStorage']['path']), Path(release['plan']['path'])]
for path in required:
    assert bindings.get(str(path.relative_to(ROOT))) == sha(path), str(path)
for relative, expected in bindings.items():
    assert sha(ROOT / relative) == expected, relative
for ref in [release['module'], release['helper'], release['plan'], release['previousCaseIndependentClosure'],
            release['deployedGuardReceipt'], release['modulePeer'], release['diagnosticStorage']]:
    assert sha(ref['path']) == ref['sha256'], ref['path']
assert release['module']['sha256'] == '146cd5152f8ed47d990e1a63509442ba520e280b36705ea93aa7b9ceb877924c'
assert release['helper']['sha256'] == 'a7539a14ea582056b5d2759207b75d251cf85f49ee87f0977205f24673df760a'
# Bind the exact relative helper that this module will actually import.
assert Path(release['helper']['path']).resolve() == Path(release['module']['path']).resolve().parent / 'reference-fetch-scope.mjs'
assert release['plan']['sha256'] == '5817b5a9372144b7db7983baf45fe1050d7e18bfc5ae040abb442fda5d107d99'
assert release['modulePeer']['sha256'] == '2fd27b66904e8fe06d9d76b593653d7f136fbad725e08c445c0d43255ba8c61c'
assert release['diagnosticStorage']['sha256'] == 'f204acbfee9fdbe10ce63fd0d42f4e26c959190b58b75dab1a1c26cc5c3fa7b0'
assert Path(release['diagnosticStorage']['path']).resolve() == Path(release['module']['path']).resolve().parent / 'diagnostic-storage.mjs'
assert isinstance(release['workerVersion'], str) and release['workerVersion']
plan = load(release['plan']['path'], release['plan']['sha256'], release['plan'].get('bytes'))
assert release['sourceHead'] == plan['inspectedSourceHead']
assert plan['target'] == release['target'] and len(plan['sections']) == 31
assert plan['budgets']['totalMilliseconds'] == 510000
assert plan['budgets']['ownerWatchdogMilliseconds'] == 570000
inventory_ref = release['guardInventory']
inventory = load(inventory_ref['path'], inventory_ref['sha256'], inventory_ref.get('bytes'))
assert inventory['dataRoot'] == str((HERE.parent / 'data-checkout').resolve())
assert inventory['sourceRoot'] == str((ROOT / 'artifacts/stella-site-repair-source/.sites-checkout').resolve())
for name, count in release['inventoryCounts'].items():
    assert len(inventory[name]) == count
assert set(release['inventoryCounts']) == {'dataInputs', 'globalGuards', 'protectedFirstThree',
    'sourceFiles', 'distFiles', 'toolFiles'}
assert len(inventory['protectedFirstThree']) == 22
assert set(release['tools']) == {'python', 'node', 'firefox'}
for tool in release['tools'].values():
    assert sha(tool['binaryPath']) == tool['sha256'] == inventory['toolFiles'][tool['binaryPath']]
    assert Path(tool['launchPath']).resolve() == Path(tool['binaryPath']).resolve()
assert Path(sys.executable).resolve() == Path(release['tools']['python']['binaryPath']).resolve()
# Import this stdlib-only function library only AFTER its exact source binding.
# No source slicing/exec/AST extraction occurs at runtime.
spec = importlib.util.spec_from_file_location('stella_directory_owner_core', HERE / 'owner_core.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
binding_summary = {'inventoryCounts': release['inventoryCounts']}
binding = {'dataRoot': inventory['dataRoot'], 'sourceRoot': inventory['sourceRoot'],
    'dataHead': release['publishedHead'], 'dataStatus': '',
    'dataInputs': inventory['dataInputs'], 'protectedFirstThree': inventory['protectedFirstThree'],
    'globalGuards': inventory['globalGuards'], 'toolFiles': inventory['toolFiles'],
    'kitGuards': {str(ROOT / name): digest for name, digest in bindings.items()},
    'resourceAndSourceGuards': {**inventory['sharedClosure'], **inventory['evidenceGuards'],
        **release['additionalGuards'], str(release_path): args.release_sha256,
        **{ref['path']: ref['sha256'] for ref in [release['module'], release['helper'], release['plan'],
            release['modulePeer'], release['previousCaseIndependentClosure'], release['deployedGuardReceipt'], release['diagnosticStorage']]},
        inventory_ref['path']: inventory_ref['sha256']},
    'source': {'head': release['sourceHead'], 'status': release['sourceStatus'],
        'sourceFiles': inventory['sourceFiles'], 'distFiles': inventory['distFiles']},
    'budgets': {'expectedTotalOutputBytes': release['expectedTotalOutputBytes']}}
out = HERE / args.attempt
out.mkdir()  # Never reuse an old attempt or its authority/profile.
core.bind_context(root=ROOT, binding_value=binding, output=out,
                  inventory_reference=inventory_ref, summary=binding_summary)
write, inputs, check_inputs, summarize_inputs = core.write, core.inputs, core.check_inputs, core.summarize_inputs
processes, stop, owned_inventory = core.processes, core.stop, core.owned_inventory
write(out / 'release-binding.json', {'path': str(release_path), 'sha256': args.release_sha256,
    'inventory': inventory_ref, 'inventoryCounts': release['inventoryCounts'],
    'runtimeBindings': len(bindings), 'noLargeMapCopies': True})
owned, profile, before, address = [], None, None, None
browser_spawn_attempted = False
before_guards_verified = after_guards_verified = False
status = 1
handles = {'supervisorPid': os.getpid(), 'nice': 19, 'affinity': [0, 1],
    'browser': None, 'driver': None, 'server': None, 'xvfb': None, 'recorder': None, 'state': 'fresh-guards'}
try:
    cooperate('before fresh guard checks')
    before = inputs(binding)
    write(out / 'inputs-before.json', summarize_inputs(before))
    before_guards_verified = True
    cooperate('after complete before guards')
    free = shutil.disk_usage(ROOT).free
    write(out / 'disk-budget.json', {'availableBytes': free, 'outputCapBytes': 16777216, 'reserveBytes': 4194304})
    assert free >= 16777216 + 4194304, 'Insufficient fresh output reserve'
    raw = processes()
    (out / 'processes-before.txt').write_text(raw)
    assert not [line for line in raw.splitlines()[1:] if
        re.search(r'\b(?:firefox|chrome|chromium|Xvfb|ffmpeg)(?:\s|$)', line.split(None, 3)[-1])], 'Another test browser/media role is live'
    elf = subprocess.check_output(['file', release['tools']['firefox']['binaryPath']], text=True)
    assert 'ARM aarch64' in elf, elf
    write(out / 'browser-platform.json', {'path': release['tools']['firefox']['launchPath'],
        'fileOutput': elf, 'binarySha256': sha(release['tools']['firefox']['binaryPath'])})
    assert any(row.split()[1:3] == ['/dev/shm', 'tmpfs'] for row in Path('/proc/mounts').read_text().splitlines())
    cooperate('before private profile allocation')
    profile = Path(tempfile.mkdtemp(prefix='stella-directory-ui-qa-', dir='/dev/shm'))
    (profile / 'user.js').write_text('user_pref("browser.shell.checkDefaultBrowser",false);\nuser_pref("network.proxy.type",0);\n')
    with (profile / 'user.js').open('a') as preference:
        preference.write('user_pref("browser.cache.disk.parent_directory",' + json.dumps(str(profile / 'cache')) + ');\n')
    env = os.environ.copy()
    env.pop('STELLA_HOSTING', None); env.pop('STELLA_PRIVATE_OUTPUT', None)
    env.update(STELLA_REVIEW_OUTPUT=str(out), STELLA_RUNTIME_RELEASE_PATH=str(release_path),
        STELLA_RUNTIME_RELEASE_SHA256=args.release_sha256, XDG_CACHE_HOME=str(profile / 'cache'),
        GALLIUM_DRIVER='llvmpipe', LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='1', MESA_GLTHREAD='false',
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
    browser_log = (out / 'firefox.log').open('wb')
    cooperate('before browser spawn')
    browser_spawn_attempted = True
    browser = subprocess.Popen([release['tools']['firefox']['launchPath'], '--headless', '--no-remote',
        '--profile', str(profile), '--remote-debugging-port', '0', 'about:blank'],
        env=env, stdout=browser_log, stderr=subprocess.STDOUT, start_new_session=True)
    owned.append(('browser', browser, browser_log))
    handles['browser'] = {'pid': browser.pid, 'pgid': browser.pid, 'profile': str(profile)}
    cooperate('after minimal browser registration')
    write(out / 'handles.json', handles); print('HANDLES ' + json.dumps(handles), flush=True)
    end = time.monotonic() + 25
    while time.monotonic() < end and browser.poll() is None:
        cooperate('browser announcement poll')
        found = re.search(r'WebDriver BiDi listening on (ws://127.0.0.1:\d+)', (out / 'firefox.log').read_text())
        if found:
            address = found[1]
            break
        time.sleep(.1)
    assert address, 'Actual Firefox did not announce BiDi; preserve original log'
    driver_log = (out / 'driver.log').open('wb')
    cooperate('before driver spawn')
    driver = subprocess.Popen([release['tools']['node']['launchPath'], str(HERE / 'play.mjs'), address],
        env=env, stdout=driver_log, stderr=subprocess.STDOUT, start_new_session=True)
    owned.append(('driver', driver, driver_log))
    handles['driver'] = {'pid': driver.pid, 'pgid': driver.pid, 'bidi': address}
    cooperate('after minimal driver registration')
    handles['state'] = 'ordinary-ui'
    write(out / 'handles.json', handles); print('HANDLES ' + json.dumps(handles), flush=True)
    # Poll only this same owned process. The original overall570s watchdog is
    # unchanged; short waits let deferred TERM/INT reach centralized cleanup.
    driver_deadline = time.monotonic() + 570
    while True:
        cooperate('owned driver wait')
        remaining = driver_deadline - time.monotonic()
        if remaining <= 0:
            raise subprocess.TimeoutExpired(driver.args, 570)
        try:
            status = driver.wait(timeout=min(.25, remaining))
            break
        except subprocess.TimeoutExpired:
            continue
    cooperate('after driver terminal observation')
    if status == 0:
        terminal = load(out / 'terminal-acceptance.json')
        assert terminal['accepted'] is True and terminal['sessionRetired'] is True
        assert terminal['all31ApiDomChecksPassed'] is True and terminal['completedSections'] == 31
        assert terminal['captures'] == 0 and terminal['mediaCaptures'] == 0
finally:
    cleanup_errors, stop_results = [], []

    def report_error(operation, error):
        cleanup_errors.append({'operation': operation, 'error': str(error),
                               'traceback': traceback.format_exc()})

    def retain_json(name, value):
        # A failed diagnostic write must not skip another role or suppress the
        # final closure attempt. Original failures remain in the emitted receipt.
        try:
            write(out / name, value)
        except BaseException as error:
            report_error('write-' + name, error)

    active_error = sys.exc_info()[1]
    if active_error is not None:
        status = 1
        retain_json('supervisor-failure.json',
                    {'error': str(active_error), 'traceback': traceback.format_exc()})

    # Cleanup is centralized. Every owned role gets an independent attempt,
    # even if another wait/signal/inventory or log-close operation raises.
    for name, process, log in reversed(owned):
        try:
            result = stop(process)
            stop_results.append({'kind': name, **result})
            if result['errors']:
                cleanup_errors.extend({'kind': name, **item} for item in result['errors'])
        except BaseException as error:
            report_error('stop-' + name, error)
        finally:
            try:
                log.close()
            except BaseException as error:
                report_error('close-log-' + name, error)

    same = False
    try:
        after = inputs(binding)
        write(out / 'inputs-after.json', summarize_inputs(after))
        check_inputs(after, binding)
        after_guards_verified = True
        same = before is not None and before == after
        assert same
    except BaseException as error:
        report_error('input-guard-after', error)
        retain_json('input-guard-failure.json',
                    {'error': str(error), 'traceback': traceback.format_exc()})

    # Obtain the exit evidence after all stop attempts and resource hashing,
    # immediately before deciding the profile's fate. Missing OS evidence is
    # unknown, never an empty list; preserve the profile and fail in that case.
    inventory_raw, owned_rows, inventory_known = None, [], False
    try:
        inventory_raw, owned_rows = owned_inventory(owned)
        inventory_known = True
    except BaseException as error:
        report_error('final-owned-pid-pgid-inventory', error)
        owned_rows = [{'kind': name, 'pid': process.pid, 'pgid': process.pid,
                       'exitCode': process.returncode, 'remainingOwnedPid': None,
                       'remainingGroupMembers': None} for name, process, _ in owned]
    all_groups_empty = inventory_known and all(row['remainingGroupMembers'] == [] for row in owned_rows)
    all_pids_groups_empty = all_groups_empty and all(row['remainingOwnedPid'] == [] for row in owned_rows)
    # Group emptiness alone cannot identify an escaped listener. Check the
    # actual announced owned BiDi port without signalling any foreign PID.
    # An unknown endpoint after ANY browser spawn attempt is not evidence of
    # a closed port, even if the registered PID/PG has exited. Preserve the
    # profile for root review. Only never attempting a browser is vacuous.
    browser_registered = any(name == 'browser' for name, _, _ in owned)
    port_proof = {'address': address, 'browserSpawnAttempted': browser_spawn_attempted,
                  'browserRegistered': browser_registered,
                  'known': not browser_spawn_attempted, 'closed': not browser_spawn_attempted,
                  'reason': 'browser-never-spawned' if not browser_spawn_attempted else 'announcement-unavailable-unproven'}
    if address is not None:
        try:
            from urllib.parse import urlparse
            endpoint = urlparse(address)
            with socket.socket() as probe:
                probe.settimeout(.5)
                code = probe.connect_ex((endpoint.hostname, endpoint.port))
            port_proof = {'address': address, 'browserSpawnAttempted': browser_spawn_attempted,
                          'browserRegistered': browser_registered, 'connectEx': code, 'known': True,
                          'closed': code == errno.ECONNREFUSED}
        except BaseException as error:
            report_error('announced-bidi-port-proof', error)
            port_proof = {'address': address, 'browserSpawnAttempted': browser_spawn_attempted,
                          'browserRegistered': browser_registered, 'known': False, 'closed': False}
    all_owned_exit_proven = all_pids_groups_empty and port_proof['known'] and port_proof['closed']

    profile_cleanup = {'path': str(profile) if profile is not None else None,
                       'removed': False, 'retained': profile is not None,
                       'ownedPidPgidExitProven': all_pids_groups_empty,
                       'announcedPortProof': port_proof,
                       'escapedProcessReview': 'Root independent review is still required; no foreign group is signalled.'}
    if profile is None:
        profile_cleanup['reason'] = 'profile-not-created'
    elif all_owned_exit_proven:
        try:
            # This is the only profile deletion site. Successful SIGKILL/wait
            # alone cannot reach it; an actual empty owned-PID/PGID snapshot can.
            shutil.rmtree(profile)
            profile_cleanup.update(removed=True, retained=False, reason='removed-after-os-exit-proof')
        except BaseException as error:
            report_error('remove-proven-exited-profile', error)
            profile_cleanup['reason'] = 'removal-failed-after-os-exit-proof'
    else:
        profile_cleanup['reason'] = 'retained-owned-process-live-or-exit-unproven'

    if inventory_raw is not None:
        try:
            (out / 'processes-after.txt').write_text(inventory_raw)
        except BaseException as error:
            report_error('write-processes-after', error)
    output_bytes = sum(path.stat().st_size for path in out.rglob('*') if path.is_file())
    if output_bytes + 65536 > binding['budgets']['expectedTotalOutputBytes']:
        report_error('output-cap', RuntimeError('Complete original outputs exceed 16MiB; retained without truncation'))
    if stop_requests or not same or not all_owned_exit_proven or cleanup_errors:
        status = 1
    closure = {'owned': owned_rows, 'stopAttempts': stop_results,
               'osInventoryKnown': inventory_known, 'allOwnedGroupsEmpty': all_groups_empty,
               'allOwnedPidsAndGroupsEmpty': all_pids_groups_empty, 'announcedPortProof': port_proof,
               'inputsUnchanged': same, 'outputBytesBeforeFinalReceipts': output_bytes,
               'outputByteCap': binding['budgets']['expectedTotalOutputBytes'],
               'guardInventory': inventory_ref,
               'beforeGuardsVerified': before_guards_verified, 'afterGuardsVerified': after_guards_verified,
               'allGuardsCheckedWithoutMapCopies': before_guards_verified and after_guards_verified,
               'normalGuardSummariesUseInventoryReference': True,
               'failedActualGuardMapArchives': sorted(path.name for path in out.glob('failed-inputs-*.json.gz')),
               'deferredStopRequests': list(stop_requests), 'deferredStopBoundary': deferred_stop_boundary,
               'driverExitCode': next((process.returncode for name, process, _ in owned if name == 'driver'), None),
               'supervisorExitCode': status, 'cleanupErrors': cleanup_errors,
               'profileCleanup': profile_cleanup,
               'localServerStarted': False, 'recorderStarted': False, 'xvfbStarted': False, 'imageReviewStarted': False,
               'requiresIndependentClosureAfterSupervisorExit': True, 'supervisorPid': os.getpid()}
    # Try both final receipts independently. If either write fails the other
    # and stdout still carry the real cleanup errors; no role is skipped.
    handles['state'] = 'closed' if all_owned_exit_proven else 'cleanup-incomplete'
    handles['profileCleanup'] = profile_cleanup
    retain_json('handles.json', handles)
    if cleanup_errors:
        status = 1
        closure['supervisorExitCode'] = status
    retain_json('process-exit.json', closure)
    if cleanup_errors:
        status = 1
        closure['supervisorExitCode'] = status
    try:
        if stop_requests:
            status = 1
            closure['supervisorExitCode'] = status
            closure['deferredStopRequests'] = list(stop_requests)
        print('CLOSURE ' + json.dumps(closure), flush=True)
    except BaseException as error:
        status = 1
sys.exit(1 if stop_requests else status)
