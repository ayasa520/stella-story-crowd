// Passive observation and ordinary UI traversal only. The caller owns the sole
// browser, original BiDi event collectors, release checks and OS cleanup. This
// module deliberately has no launcher, connection, session or network client.
import assert from 'node:assert/strict';
import {appendFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {referenceFetchScope,referenceConsoleScope} from './reference-fetch-scope.mjs';
export {referenceFetchScope,referenceFetchRequiredEvents,referenceConsoleScope,referenceConsoleRequiredEvents} from './reference-fetch-scope.mjs';
import {prepareDiagnosticArchive,assertDiagnosticArchiveBudget,writeDiagnosticArchive} from './diagnostic-storage.mjs';
export {prepareDiagnosticArchive,assertDiagnosticArchiveBudget,writeDiagnosticArchive} from './diagnostic-storage.mjs';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');

// Install before the caller's one ordinary studio navigation. The original
// fetch receives the original arguments and its original promise is returned.
// Only a separate response clone is consumed; no request, response, console,
// program, player state, rendering method or clock is replaced or seeded.
export function installDirectoryFlowObserver() {
  if (window.reviewDirectorySweep) throw Error('Directory sweep observer already exists');
  const requests = [], flows = [], inputs = [], fields = [], errors = [];
  const pending = new Set(), originalFetch = window.fetch;
  let rawBytes = 0, stopped = false;
  const time = () => ({epoch: Date.now(), monotonic: performance.now()});
  const snapshot = () => ({
    ...time(), url: location.href,
    open: document.getElementById('workspaceDialog')?.open ?? false,
    navigationOpen: document.getElementById('directoryNavigator')?.open ?? false,
    flowOpen: document.getElementById('flowDialog')?.open ?? false,
    chapter: document.querySelector('#directorychapter .active')?.dataset.directoryId || '',
    section: document.querySelector('#directorysection .active')?.dataset.directoryId || '',
    activeNode: document.querySelector('#nodes .active[data-node]')?.dataset.node || '',
    workspace: document.getElementById('workspaceName')?.textContent || '',
    dirty: window.workbenchDirty ?? false, directoryDirty: window.directoryDirty ?? false,
    playerHidden: document.getElementById('storyPlayerPanel')?.hidden ?? true,
    directoryMessage: document.getElementById('directoryMessage')?.textContent || '',
    remembered: Object.keys(localStorage).filter(k => k.startsWith('stella-scene:')).sort()
      .map(k => [k, localStorage.getItem(k)])
  });
  const wrapper = function(...args) {
    let row;
    try {
      const request = args[0] instanceof Request ? args[0] : null;
      const url = new URL(request?.url || String(args[0]), location.href);
      if (url.origin === location.origin && url.pathname.startsWith('/api/')) {
        const method = String(args[1]?.method || request?.method || 'GET').toUpperCase();
        const meta = {index: requests.length, method, path: url.pathname, started: time()};
        requests.push(meta); // No auth bodies, cookies or request headers are read.
        if (url.pathname === '/api/directory/flow') {
          row = {...meta, index: flows.length, url: url.href,
            query: Object.fromEntries(url.searchParams), completed: false};
          flows.push(row);
        }
      }
    } catch (error) { errors.push({kind: 'request-observation', error: String(error)}); }
    const promise = originalFetch.apply(this, args);
    if (row) {
      const job = promise.then(async response => {
        try {
          row.status = response.status; row.headers = [...response.headers]; row.responseHead = time();
          const bytes = new Uint8Array(await response.clone().arrayBuffer());
          row.bytes = bytes.length; rawBytes += bytes.length;
          const digest = await crypto.subtle.digest('SHA-256', bytes);
          row.sha256 = [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
          let binary = '';
          for (let i = 0; i < bytes.length; i += 8192)
            binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
          row.rawBase64 = btoa(binary); // Lossless raw, including non-JSON/error bodies.
          if (rawBytes > 1048576) errors.push({kind: 'raw-budget', rawBytes});
        } catch (error) { row.observationError = String(error); }
        finally { row.completed = true; row.finished = time(); }
      }, error => { row.transportError = String(error); row.completed = true; row.finished = time(); });
      pending.add(job);
      job.finally(() => pending.delete(job)).catch(error => errors.push({kind: 'observer-job', error: String(error)}));
    }
    return promise;
  };
  const input = event => {
    const n = event.target.closest?.('button,summary');
    if (n) inputs.push({type: event.type, id: n.id, directoryId: n.dataset.directoryId || '',
      trusted: event.isTrusted, ...time()});
  };
  const field = event => {
    if (event.target.closest?.('#directoryForm,#flowDialog'))
      fields.push({type: event.type, id: event.target.id, trusted: event.isTrusted, ...time()});
  };
  window.fetch = wrapper;
  for (const type of ['pointerdown', 'click']) document.addEventListener(type, input, true);
  for (const type of ['input', 'change']) document.addEventListener(type, field, true);
  window.reviewDirectorySweep = {
    snapshot, data: () => ({requests, flows, inputs, fields, errors, rawBytes, pending: pending.size, stopped}),
    summary: () => ({requests, inputs, fields, errors, rawBytes, pending: pending.size, stopped}),
    stop() {
      if (!stopped) {
        if (window.fetch === wrapper) window.fetch = originalFetch;
        else errors.push({kind: 'fetch-identity-changed-before-cleanup'});
        for (const type of ['pointerdown', 'click']) document.removeEventListener(type, input, true);
        for (const type of ['input', 'change']) document.removeEventListener(type, field, true);
        stopped = true;
      }
      return {restoredOriginalFetch: window.fetch === originalFetch, pending: pending.size};
    }
  };
}

// This function reads browser-created SVG geometry, computed presentation and
// actual browser hit tests. Expected native/API pairs are validated separately;
// neither cloned JSON nor recomputed path formulas count as rendered evidence.
export function readDirectoryDom() {
  const root = document.querySelector('#directoryGraph svg.directory-map-canvas');
  const rect = n => { const r = n.getBoundingClientRect(); return [r.x, r.y, r.width, r.height]; };
  const polygon = n => n ? [...n.points].map(p => [p.x, p.y]) : [];
  const presented = n => {
    const s = getComputedStyle(n);
    return {display: s.display, visibility: s.visibility, opacity: s.opacity,
      stroke: s.stroke, strokeOpacity: s.strokeOpacity, strokeWidth: s.strokeWidth,
      pointerEvents: s.pointerEvents, checkVisibility: n.checkVisibility({opacityProperty: true, visibilityProperty: true})};
  };
  if (!root) return {missingSvg: true, state: window.reviewDirectorySweep.snapshot()};
  const viewport = root.closest('.directory-map-viewport'), vr = viewport.getBoundingClientRect();
  const cards = [...root.querySelectorAll('g.directory-map-card')].map(n => ({
    id: n.dataset.flowEntry, points: polygon(n.querySelector('polygon.map-card-base')), rect: rect(n)
  }));
  const portals = [...root.querySelectorAll('g.map-portal')].map(n => ({
    id: n.dataset.flowEdge, points: polygon(n.querySelector('polygon')), rect: rect(n), label: n.textContent
  }));
  const edges = [...root.querySelectorAll('g.directory-map-edge')].map(n => ({
    id: n.dataset.flowEdge, label: n.getAttribute('aria-label'),
    paths: [...n.querySelectorAll('path')].map(p => {
      const length = p.getTotalLength(), start = p.getPointAtLength(0), end = p.getPointAtLength(length);
      const m = p.getScreenCTM();
      const samples = m ? [.13, .27, .41, .59, .73, .87].map(t => {
        const a = p.getPointAtLength(length * t), s = new DOMPoint(a.x, a.y).matrixTransform(m);
        return [s.x, s.y, document.elementFromPoint(s.x, s.y)?.closest('[data-flow-edge]')?.dataset.flowEdge || ''];
      }) : [];
      return {class: p.getAttribute('class'), d: p.getAttribute('d'), length,
        start: [start.x, start.y], end: [end.x, end.y], rect: rect(p), presentation: presented(p), samples};
    })
  }));
  return {state: window.reviewDirectorySweep.snapshot(), title: document.getElementById('directoryGraphTitle').textContent,
    countText: document.getElementById('directoryMapCount').textContent, viewBox: root.getAttribute('viewBox'),
    transform: root.style.transform, viewport: [vr.x, vr.y, vr.width, vr.height],
    svgPresentation: presented(root), cards, portals, edges,
    counts: {cards: cards.length, edgeGroups: edges.length, portals: portals.length,
      lines: root.querySelectorAll('path.map-line').length,
      hits: root.querySelectorAll('path.map-line-hit').length,
      decorationPaths: root.querySelectorAll('path.map-end-rule,path.map-end-diamond').length,
      allPaths: root.querySelectorAll('path').length}};
}

const sorted = values => [...values].sort();
function distance(point, polygon) {
  let nearest = Infinity;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], dx = b[0] - a[0], dy = b[1] - a[1];
    const t = Math.max(0, Math.min(1, ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy) / (dx * dx + dy * dy || 1)));
    nearest = Math.min(nearest, Math.hypot(point[0] - a[0] - t * dx, point[1] - a[1] - t * dy));
  }
  return nearest;
}
function graphEntry(entries, sectionId, headSha) {
  for (let i = entries.length - 1; i >= 0; i--) {
    const entry = entries[i], args = entry.args?.map(a => a.value), text = entry.text || '';
    let raw;
    if (args?.[0] === 'STORY_DIRECTORY_GRAPH') raw = args[1];
    else if (text.startsWith('STORY_DIRECTORY_GRAPH ')) raw = text.slice('STORY_DIRECTORY_GRAPH '.length);
    if (typeof raw !== 'string') continue;
    try {
      const detail = JSON.parse(raw);
      if (detail.kind === 'scene' && detail.parent === 'section:' + sectionId && detail.headSha === headSha &&
          !String(detail.status).includes('读取中') && !String(detail.status).includes('读取失败'))
        return {consoleIndex: i, detail};
    } catch { /* The original console entry is retained intact in diagnostics. */ }
  }
  return null;
}

// The caller must supply original live BiDi console/network/exception arrays.
// Approval and input freeze remain caller responsibilities. Rootfalse plans do
// not grant execution, and this module never changes session ownership.
export async function runDirectorySweep({driver, target, evaluate, readDiagnostics, plan, approval, output}) {
  assert.equal(approval.rootConfirmed, true); assert.equal(approval.executionAuthorized, true);
  assert.equal(approval.browserOwner, '/root/ui_browser_owner');
  assert.match(approval.expectedDataHead, /^[0-9a-f]{40}$/);
  assert.equal(approval.expectedSourceHead, plan.inspectedSourceHead);
  assert.equal(plan.sections.length, 31); assert.equal(typeof readDiagnostics, 'function');
  assert.equal(new Set(plan.sections.map(s => s.id)).size, 31);
  assert.ok(plan.sections.every(s => Number.isSafeInteger(s.id) && !plan.excludedSectionIds.includes(s.id) &&
    s.sceneIds.every(Number.isSafeInteger) && s.loadedSceneIds.every(Number.isSafeInteger)));
  const file = name => resolve(output, name), actions = [], completed = [], flowJournal = new Map(), hitSamplingUnprovenEdges = [];
  const edgeMeasurements = [], sectionRecords = [], unjournaledFlowRecords = new Map(), finalizationErrors = [], additionalFailures = [];
  const started = Date.now(), stopAt = started + plan.budgets.totalMilliseconds;
  const safeBootPosts = new Set(['/api/resolve', '/api/commands/inspect', '/api/commands/build', '/api/project/open']);
  let stage = 'preconditions', firstFailure = null, initial, final, currentDom, cleanup, domBytes = 0, flowBytes = 0;
  let flowJournalReady = false, flowJournalBlocked = false, flowSequence = 0, drainBoundary = null;
  let diagnostics, observation, result, diagnosticStorage = null;
  const save = (name, value) => writeFile(file(name), JSON.stringify(value) + '\n', {flag: 'wx'});
  // The first observed failure is immutable in meaning. Independent cleanup or
  // evidence-export errors are accumulated without replacing its stage/stack.
  function retainFailure(error, boundary) {
    const fact = {stage: boundary, error: String(error), stack: error?.stack, code: error?.code ?? null,
      actualFlowIndex: error?.actualFlowIndex ?? null, actualRawSha256: error?.actualRawSha256 ?? null, epoch: Date.now()};
    if (!firstFailure) firstFailure = fact; else additionalFailures.push(fact);
  }
  function retainExportError(operation, error) {
    finalizationErrors.push({operation, error: String(error), stack: error?.stack, code: error?.code ?? null,
      retainedDiagnosticArchive: error?.retainedDiagnosticArchive ?? null});
    retainFailure(error, operation);
  }
  async function bestEffort(operation, task) {
    try { return await task(); }
    catch (error) { retainExportError(operation, error); return undefined; }
  }
  const state = () => evaluate(() => window.reviewDirectorySweep.snapshot());
  const observer = (full = false) => evaluate(full => full ? window.reviewDirectorySweep.data() : window.reviewDirectorySweep.summary(), full);
  const originalApiRequests = d => d.networkEvents.filter(e => e.event === 'network.beforeRequestSent')
    .map(e => (e.params ?? e).request).filter(r => r && new URL(r.url).origin === new URL(plan.target).origin &&
      new URL(r.url).pathname.startsWith('/api/'));
  const originalApiFailures = d => d.networkEvents.filter(e => e.event === 'network.responseCompleted')
    .map(e => (e.params ?? e).response).filter(r => r && new URL(r.url).origin === new URL(plan.target).origin &&
      new URL(r.url).pathname.startsWith('/api/') && r.status >= 400);
  function healthy() {
    assert.equal(firstFailure, null, 'An earlier failure forbids further ordinary UI input');
    assert.ok(Date.now() < stopAt, 'Sweep total time budget exhausted');
    const d = readDiagnostics();
    assert.ok(Array.isArray(d.consoleEntries) && Array.isArray(d.networkEvents) && Array.isArray(d.exceptions));
    assert.deepEqual(d.exceptions, [], 'Original JavaScript exception');
    const consoleScope=referenceConsoleScope(d,new URL(plan.target).origin,target.context);
    assert.equal(consoleScope.summary.arrivalSequenceComplete,true,'Original cross-event arrival sequence unproven');
    assert.deepEqual(consoleScope.fatal, [], 'Original console error without complete external realm provenance');
    assert.deepEqual(referenceFetchScope(d.networkEvents,new URL(plan.target).origin,target.context).fatal, [], 'Original network fetch error');
    assert.deepEqual(originalApiFailures(d), [], 'Original API HTTP error');
    assert.deepEqual(originalApiRequests(d).filter(r => String(r.method).toUpperCase() !== 'GET' &&
      !safeBootPosts.has(new URL(r.url).pathname)), [], 'Original network observed unexpected API mutation/prepare');
  }
  async function unwritten(s) {
    assert.equal(s.dirty, false); assert.equal(s.directoryDirty, false); assert.equal(s.flowOpen, false);
    assert.equal(s.playerHidden, true); assert.equal(s.activeNode, initial.activeNode); assert.equal(s.workspace, initial.workspace);
    assert.deepEqual(s.remembered, initial.remembered);
    const o = await observer(); assert.deepEqual(o.fields, []); assert.deepEqual(o.errors, []);
    assert.ok(o.inputs.every(x => x.trusted), 'Every observed pointer/click must be trusted');
    assert.deepEqual(o.requests.filter(r => r.method !== 'GET' && !safeBootPosts.has(r.path)), [], 'Unexpected API mutation/prepare');
  }
  async function wait(fn, arg, end) {
    while (Date.now() < Math.min(end, stopAt)) { healthy(); const value = await evaluate(fn, arg); if (value) return value; await delay(75); }
    throw Error('UI condition timeout at ' + stage);
  }
  async function click(selector, end) {
    healthy(); await unwritten(await state());
    assertDiagnosticArchiveBudget(prepareDiagnosticArchive(readDiagnostics(), 'sweep.diagnostics.json.gz', plan));
    const p = await wait(selector => {
      const n = document.querySelector(selector); if (!n || n.disabled || !n.checkVisibility()) return null;
      n.scrollIntoView({block: 'center'}); const r = n.getBoundingClientRect(); if (!r.width || !r.height) return null;
      const x = r.left + r.width / 2, y = r.top + r.height / 2;
      if (!n.contains(document.elementFromPoint(x, y))) return null;
      return {x: Math.round(x), y: Math.round(y)};
    }, selector, end);
    actions.push({stage, selector, point: p, epoch: Date.now()});
    await driver.call('input.performActions', {context: target.context, actions: [{type: 'pointer', id: 'mouse',
      parameters: {pointerType: 'mouse'}, actions: [{type: 'pointerMove', origin: 'viewport', ...p, duration: 0},
        {type: 'pointerDown', button: 0}, {type: 'pointerUp', button: 0}]}]});
  }
  async function navigation(open, end) {
    if ((await state()).navigationOpen !== open) await click('#directoryNavigationSummary', end);
    await wait(open => document.getElementById('directoryNavigator').open === open, open, end);
  }
  async function flushFlows(snapshot) {
    const o = snapshot || await observer(true);
    observation = o; // Retain the last full raw snapshot even if a later read/export fails.
    for (const r of o.flows) {
      const prior = flowJournal.get(r.index) || {};
      if ((r.completed && (prior.completeSequence || unjournaledFlowRecords.has(r.index + ':completion'))) ||
          (!r.completed && (!o.stopped || prior.partialSequence || unjournaledFlowRecords.has(r.index + ':partial')))) continue;
      const kind = r.completed ? 'completion' : 'partial', sequence = ++flowSequence;
      const bytes = typeof r.rawBase64 === 'string' ? Buffer.from(r.rawBase64, 'base64') : null;
      const losslessRawVerified = !!bytes && bytes.length === r.bytes && sha(bytes) === r.sha256;
      const record = {sequence, kind, flowIndex: r.index,
        followsPartialSequence: prior.partialSequence ?? unjournaledFlowRecords.get(r.index + ':partial')?.sequence ?? null,
        partialWasJournaled: !!prior.partialSequence, observedEpoch: Date.now(), losslessRawVerified, flow: r};
      // A partial is a different record from its later completion. Neither an
      // earlier partial nor a failed append can falsely certify complete raw.
      if (!flowJournalReady || flowJournalBlocked) { unjournaledFlowRecords.set(r.index + ':' + kind, record); continue; }
      const line = JSON.stringify(record) + '\n';
      try { await appendFile(file('sweep.flow-raw.jsonl'), line); }
      catch (error) {
        flowJournalBlocked = true; unjournaledFlowRecords.set(r.index + ':' + kind, record);
        retainExportError('flow-journal-append', error); throw error;
      }
      flowJournal.set(r.index, r.completed ? {...prior, completeSequence: sequence, losslessRawVerified} :
        {...prior, partialSequence: sequence});
      flowBytes += Buffer.byteLength(line);
      // Preserve the complete crossing row before reporting a budget failure.
      assert.ok(flowBytes <= plan.budgets.flowJournalBytes, 'Flow journal byte budget exceeded');
    }
  }
  try {
    stage = 'evidence-journal-create';
    await writeFile(file('sweep.flow-raw.jsonl'), '', {flag: 'wx'}); flowJournalReady = true;
    await writeFile(file('sweep.sections.jsonl'), '', {flag: 'wx'});
    stage = 'preconditions';
    initial = await state();
    assert.equal(new URL(initial.url).origin + new URL(initial.url).pathname, plan.target);
    assert.equal(initial.open, false); assert.ok(initial.activeNode && initial.workspace);
    await unwritten(initial); healthy();
    stage = 'open-directory'; const openingEnd = Date.now() + plan.budgets.sectionMilliseconds;
    await click('#workspaces', openingEnd);
    await wait(() => document.getElementById('workspaceDialog').open, null, openingEnd);
    await navigation(true, openingEnd);
    if ((await state()).chapter !== 'chapter:1') await click('#directorychapter [data-directory-id="chapter:1"]', openingEnd);
    for (const expected of plan.sections) {
      stage = 'section:' + expected.id; const end = Date.now() + plan.budgets.sectionMilliseconds;
      await navigation(true, end);
      await click('#directorysection [data-directory-id="section:' + expected.id + '"]', end);
      const raw = await wait(({id, head}) => {
        const o = window.reviewDirectorySweep.data();
        const rows = o.flows.filter(r => r.query.sectionId === String(id));
        return rows.find(r => r.completed && (r.transportError || r.observationError || r.status !== 200)) ||
          rows.find(r => r.query.sha === head && r.completed) || rows.filter(r => r.completed).at(-1) || null;
      }, {id: expected.id, head: approval.expectedDataHead}, end);
      await flushFlows(); // Raw bytes/status/headers precede any JSON interpretation.
      if (raw.transportError || raw.observationError || raw.status !== 200)
        throw Object.assign(Error('Original flow failure: ' + JSON.stringify({index: raw.index, status: raw.status,
          transportError: raw.transportError, observationError: raw.observationError})), {actualFlowIndex: raw.index});
      assert.equal(raw.query.sha, approval.expectedDataHead, 'Actual requested revision differs; never follow it automatically');
      const bytes = Buffer.from(raw.rawBase64, 'base64');
      assert.equal(bytes.length, raw.bytes); assert.equal(sha(bytes), raw.sha256);
      let api;
      try { api = JSON.parse(bytes.toString('utf8')); }
      catch (error) { error.actualFlowIndex = raw.index; error.actualRawSha256 = raw.sha256; throw error; }
      assert.equal(api.headSha, approval.expectedDataHead); assert.equal(api.sectionId, expected.id);
      assert.equal(raw.method, 'GET'); assert.equal(raw.query.sha, approval.expectedDataHead);
      const expectedPairs = sorted(expected.pairs.map(([s, t]) => 'scene:' + s + '>scene:' + t));
      assert.deepEqual(sorted(api.edges.map(e => e.source + '>' + e.target)), expectedPairs);
      assert.equal(api.coverage.sceneCount, expected.sceneIds.length);
      assert.deepEqual(sorted(api.coverage.loadedSceneIds), sorted(expected.loadedSceneIds));
      assert.deepEqual(sorted(api.coverage.missingScriptSceneIds), sorted(expected.missingScriptSceneIds));
      assert.deepEqual(api.coverage.missingChartSceneIds, []);
      assert.equal(api.coverage.knownInternalEdges, api.edges.filter(e => expected.sceneIds.includes(Number(e.target.replace(/^scene:/, '')))).length);
      let graph;
      while (!(graph = graphEntry(readDiagnostics().consoleEntries, expected.id, approval.expectedDataHead))) {
        healthy(); if (Date.now() >= end) throw Error('No original ready graph console for ' + expected.id); await delay(75);
      }
      await navigation(false, end); await click('#mapFit', end);
      await evaluate(() => new Promise(done => requestAnimationFrame(() => requestAnimationFrame(() => done(true)))));
      currentDom = await evaluate(readDirectoryDom);
      const measured = {sectionId: expected.id, apiEdges: api.edges.length,
        domEdges: currentDom.edges?.length ?? 0, sampledEdges: 0, positiveSampledEdges: 0};
      edgeMeasurements.push(measured);
      const failures = [], check = (condition, message) => { if (!condition) failures.push(message); };
      check(!currentDom.missingSvg, 'SVG absent');
      if (!currentDom.missingSvg) {
        check(currentDom.state.section === 'section:' + expected.id, 'Wrong selected section');
        check(currentDom.title === '本话各场景的流程', 'Wrong map layer');
        check(JSON.stringify(sorted(currentDom.cards.map(c => c.id))) === JSON.stringify(sorted(expected.sceneIds.map(id => 'scene:' + id))), 'Card IDs differ');
        check(JSON.stringify(sorted(currentDom.edges.map(e => e.id))) === JSON.stringify(sorted(api.edges.map(e => e.id))), 'API/DOM edge IDs differ');
        check(currentDom.counts.lines === api.edges.length && currentDom.counts.hits === api.edges.length, 'Actual line/hit count differs');
        const cards = new Map(currentDom.cards.map(c => [c.id, c])), portals = new Map(currentDom.portals.map(p => [p.id, p]));
        for (const edge of api.edges) {
          const actual = currentDom.edges.find(e => e.id === edge.id), source = cards.get(edge.source), target = cards.get(edge.target) || portals.get(edge.id);
          check(!!actual && !!source && !!target, 'Missing source/target/portal for ' + edge.id);
          if (!actual || !source || !target) continue;
          const line = actual.paths.filter(p => p.class === 'map-line'), hit = actual.paths.filter(p => p.class === 'map-line-hit');
          check(line.length === 1 && hit.length === 1, 'Path multiplicity ' + edge.id);
          if (line.length !== 1 || hit.length !== 1) continue;
          const p = line[0], h = hit[0], style = p.presentation;
          const startDistance = distance(p.start, source.points), endDistance = distance(p.end, target.points);
          actual.endpointEvidence = {source: edge.source, target: edge.target, targetIsPortal: !cards.has(edge.target), startDistance, endDistance};
          check(p.length > 0 && p.d === h.d, 'Zero/mismatched actual path ' + edge.id);
          check(startDistance <= .75 && endDistance <= .75, 'Path misses actual card/portal boundary ' + edge.id);
          check(style.checkVisibility && style.display !== 'none' && style.visibility === 'visible' && Number(style.opacity) > 0 &&
            Number(style.strokeOpacity) > 0 && parseFloat(style.strokeWidth) > 0 && style.stroke !== 'none' &&
            style.stroke !== 'transparent' && !/rgba\([^)]*,\s*0\)$/.test(style.stroke), 'Line not presented ' + edge.id);
          check(h.presentation.pointerEvents === 'stroke', 'Hit path pointer geometry differs ' + edge.id);
          // Finite samples can land on another legitimate overlapping stem or
          // card. Retain that uncertainty without inventing a missing edge or
          // stopping the remaining coverage as though a product error occurred.
          actual.hitSampleOwnsEdge = h.samples.some(s => s[2] === edge.id);
          measured.sampledEdges++; if (actual.hitSampleOwnsEdge) measured.positiveSampledEdges++;
          if (!actual.hitSampleOwnsEdge) hitSamplingUnprovenEdges.push({sectionId: expected.id, edgeId: edge.id});
        }
        const external = api.edges.filter(e => !cards.has(e.target));
        check(JSON.stringify(sorted(currentDom.portals.map(p => p.id))) === JSON.stringify(sorted(external.map(e => e.id))), 'Portal IDs differ');
      }
      const row = {sectionId: expected.id, flowIndex: raw.index, apiHeadSha: api.headSha, rawSha256: raw.sha256,
        apiEdges: api.edges.map(e => [e.id, e.source, e.target]), coverage: api.coverage, graph, dom: currentDom, measured, failures};
      sectionRecords.push(row);
      const line = JSON.stringify(row) + '\n';
      try { await appendFile(file('sweep.sections.jsonl'), line); }
      catch (error) { retainExportError('section-journal-append', error); throw error; }
      domBytes += Buffer.byteLength(line);
      assert.ok(domBytes <= plan.budgets.domJournalBytes, 'DOM journal byte budget exceeded');
      assert.deepEqual(failures, []); await unwritten(currentDom.state); completed.push(expected.id);
    }
    stage = 'ordinary-close'; await click('#closeWorkspace', Date.now() + plan.budgets.sectionMilliseconds);
    final = await state(); assert.equal(final.open, false); await unwritten(final); healthy();
  } catch (error) {
    retainFailure(error, stage);
    await bestEffort('failure-dom-read', async () => { currentDom = await evaluate(readDirectoryDom); });
  } finally {
    // Restoring instrumentation is cleanup, never another product input. Do not
    // retry a failed flow or continue selecting sections after any first error.
    await bestEffort('observer-stop', async () => { cleanup = await evaluate(() => window.reviewDirectorySweep.stop()); });
    await bestEffort('observer-drain', async () => {
      const deadlineEpoch = Date.now() + 2000;
      let snapshot, observedEpoch;
      do {
        snapshot = await observer(true); observedEpoch = Date.now();
        if ((!snapshot.pending && snapshot.flows.every(r => r.completed)) || observedEpoch >= deadlineEpoch) break;
        await delay(Math.min(50, Math.max(0, deadlineEpoch - observedEpoch)));
      } while (Date.now() <= deadlineEpoch);
      // This boundary is immutable. A later completion may supply additional
      // raw evidence but cannot convert a missed drain deadline into success.
      drainBoundary = {deadlineEpoch, observedEpoch, pending: snapshot.pending,
        unfinishedFlowIndexes: snapshot.flows.filter(r => !r.completed).map(r => r.index),
        completeObservedWithinDeadline: observedEpoch <= deadlineEpoch && !snapshot.pending && snapshot.flows.every(r => r.completed)};
      if (!drainBoundary.completeObservedWithinDeadline)
        retainFailure(Error('Original flow clones were not proven complete within the cleanup deadline'), 'observer-drain-deadline');
      await flushFlows(snapshot);
    });
    await bestEffort('original-diagnostic-read', async () => { diagnostics = readDiagnostics(); });
    await bestEffort('diagnostics-write', async () => {
      assert.ok(diagnostics && Array.isArray(diagnostics.consoleEntries) && Array.isArray(diagnostics.networkEvents) &&
        Array.isArray(diagnostics.exceptions), 'Original diagnostics snapshot is unavailable');
      try { diagnosticStorage = await writeDiagnosticArchive(output, 'sweep.diagnostics.json.gz', diagnostics, plan); }
      catch (error) { diagnosticStorage = error.retainedDiagnosticArchive ?? null; throw error; }
    });

    // Each feasible final observation/validation is independent of every disk
    // export. In particular a diagnostics write failure cannot skip late raw,
    // final form/readonly state or original exception/network validation.
    await bestEffort('final-observer-read', async () => { observation = await observer(true); });
    await bestEffort('late-flow-journal', () => flushFlows(observation));
    await bestEffort('final-state-read', async () => { final = await state(); });
    await bestEffort('final-readonly-validation', async () => { if (initial) await unwritten(final); });
    await bestEffort('final-original-diagnostic-validation', async () => {
      diagnostics = readDiagnostics();
      assert.deepEqual(diagnostics.exceptions, []); assert.deepEqual(originalApiFailures(diagnostics), []);
      const consoleScope=referenceConsoleScope(diagnostics,new URL(plan.target).origin,target.context);
      assert.equal(consoleScope.summary.arrivalSequenceComplete,true,'Original cross-event arrival sequence unproven');
      assert.deepEqual(consoleScope.fatal, []);
      assert.deepEqual(referenceFetchScope(diagnostics.networkEvents,new URL(plan.target).origin,target.context).fatal, []);
      assert.deepEqual(originalApiRequests(diagnostics).filter(r => String(r.method).toUpperCase() !== 'GET' &&
        !safeBootPosts.has(new URL(r.url).pathname)), []);
    });
    await bestEffort('final-raw-and-cleanup-validation', async () => {
      assert.ok(cleanup?.restoredOriginalFetch, 'Original fetch was not restored');
      assert.ok(drainBoundary?.completeObservedWithinDeadline, 'Drain deadline was missed or unproven');
      assert.ok(observation && !observation.pending, 'Final original clone state remains pending/unknown');
      assert.ok(observation.flows.every(r => r.completed && flowJournal.get(r.index)?.losslessRawVerified &&
        flowJournal.get(r.index)?.completeSequence), 'Not every flow has a complete lossless raw journal');
    });

    function buildResult() {
      const measured = edgeMeasurements.reduce((a, m) => ({apiEdges: a.apiEdges + m.apiEdges,
        domEdges: a.domEdges + m.domEdges, sampledEdges: a.sampledEdges + m.sampledEdges,
        positiveSampledEdges: a.positiveSampledEdges + m.positiveSampledEdges}),
      {apiEdges: 0, domEdges: 0, sampledEdges: 0, positiveSampledEdges: 0});
      const completeMeasuredCoverage = completed.length === plan.sections.length && edgeMeasurements.length === plan.sections.length &&
        edgeMeasurements.every(m => m.apiEdges === m.domEdges && m.sampledEdges === m.apiEdges);
      const hitCoverage = !completeMeasuredCoverage || firstFailure ? 'incomplete-or-failed' :
        !measured.sampledEdges ? 'no-edges-observed' : hitSamplingUnprovenEdges.length ? 'observed-unproven' : 'complete-positive';
      return {schema: 'stella.chapter1.directory-ui-sweep.v3', rootConfirmed: approval.rootConfirmed,
        expectedDataHead: approval.expectedDataHead, expectedSourceHead: approval.expectedSourceHead,
        completed, requested: plan.sections.map(s => s.id), all31ApiDomChecksPassed: completeMeasuredCoverage && !firstFailure,
        actualEdgeMeasurements: {sections: edgeMeasurements, totals: measured, completeMeasuredCoverage, hitCoverage},
        hitSamplingUnprovenEdges, allEdgesHavePositiveSampledHit: completeMeasuredCoverage && !firstFailure && measured.sampledEdges > 0 &&
          measured.positiveSampledEdges === measured.sampledEdges && hitSamplingUnprovenEdges.length === 0,
        firstFailure, additionalFailures, finalizationErrors, initial, final,
        currentFailureDom: firstFailure ? currentDom : null, actions, cleanup, drainBoundary,
        flowJournal: [...flowJournal].map(([index, record]) => ({index, ...record})),
        observer: observation && {...observation, flows: !Array.isArray(observation.flows) ? observation.flows : observation.flows.map(r => {
          const proof = flowJournal.get(r.index);
          if (!proof?.completeSequence || !proof.losslessRawVerified) return r;
          const {rawBase64, ...metadata} = r; return {...metadata, completeRawJournalSequence: proof.completeSequence};
        })},
        networkScope: Array.isArray(diagnostics?.networkEvents) ? referenceFetchScope(diagnostics.networkEvents,new URL(plan.target).origin,target.context).summary : {observationAvailable:false,allNetworkClean:null},
        consoleScope: diagnostics ? referenceConsoleScope(diagnostics,new URL(plan.target).origin,target.context).summary :
          {observationAvailable:false,arrivalSequenceComplete:false,allConsoleClean:null},
        journalBytes: {flowBytes, domBytes, diagnosticBytes: diagnosticStorage?.rawBytes ?? null,
          diagnosticStoredBytes: diagnosticStorage?.storedBytesIncludingIndex ?? null}, diagnosticStorage,
        durationMilliseconds: Date.now() - started, images: 0, sourceOrOriginalPayloadAcceptance: false,
        programOrResponseSubstitution: false, playerPreparedOrPlayed: false, rasterPixelsOrHumanVisualReviewPerformed: false,
        sessionAndOsCleanupOwnedByCaller: true};
    }
    result = buildResult();
    await bestEffort('result-write', () => save('sweep.result.json', result));
    // One independent new fallback path is best effort, not an overwrite or a
    // business retry. The complete in-memory packet is always attached to the
    // rejection below, even if every disk export fails. Caller must retain it
    // through its own supervisor log/sink before completing browser OS cleanup.
    if (firstFailure) {
      result = buildResult();
      await bestEffort('failure-fallback-write', () => writeDiagnosticArchive(output, 'sweep.failure-fallback.json.gz', {
        result, diagnostics, sections: sectionRecords, actualFlowObservation: observation,
        unjournaledFlowRecords: [...unjournaledFlowRecords.values()]}, plan));
      result = buildResult();
    }
  }
  if (firstFailure) throw Object.assign(Error('Directory sweep failed at ' + firstFailure.stage + ': ' + firstFailure.error), {
    sweepFailure: firstFailure, sweepExportErrors: finalizationErrors,
    sweepFallback: {result, diagnostics, sections: sectionRecords, actualFlowObservation: observation,
      unjournaledFlowRecords: [...unjournaledFlowRecords.values()]}});
  return {completed, hitSamplingUnprovenEdges, result: file('sweep.result.json')};
}
