# 共享 player package 登记：单文件条件候选

当前 D 的实际文件与 HEAD blob 均确认有五条 package 登记不符。候选只改 `assets/package.json` 的 11 个语义叶：五条 file record 各自的 `bytes` / `sha256`，以及按现有契约求和的顶层 `bytes`。其余 5,446 条记录、所有 `source` / `source_sha256`、catalog、原 payload、场景及 Rowdy 已封包均不改。

| record | 旧 bytes | 当前实际 bytes | 当前实际 SHA256 |
| --- | ---: | ---: | --- |
| player/animation.json | 833638 | 4908797 | a8d4ff6b24b9a545a0d20d5a234c7f4ed59afbee815fb3fafab81e3d1c74bd40 |
| player/effects.json | 136946 | 308927 | 5c3ffc320faaa098c48026910d1bea5dd61cc13b16518f6526184c6c2775fc22 |
| player/manifest.json | 2422301 | 2478697 | b7737a1db7820af433d070ed5f4731883760c5c74909b125fdf607c6ba5954a1 |
| player/motion_states.json | 344260 | 2015784 | e4c91d88fa8cbfd319f7c9caf2b2ca098112bf0b5a6c514573a507bdc318c582 |
| player/sound-blocks.json | 2246 | 3766 | 2fc11dd87ee19918c8c4a1400d4f748bfcdeb5951184cd0154be77ff28ec61ad |

Full / preview catalog 的 `player` 中 12 个显式 URL 已逐项核实际 bytes/SHA 与 HEAD blob。另七条 commands、lighting、player_config、preview_config、quake_clips、speaker_names_zh、transitions 的登记原本 exact。Subaru01 / Felt01 / Mimi01 / Ricardo01 的 controller 均指同一 animation，三份共享 animation / manifest / motion_states 都存在这四个 model。范围仅此共享引用，不声称扫过全 assets 或验证其所有递归媒体依赖。

旧 package 本身与 HEAD blob 一致，原顶层 `bytes=538769567` 也确实等于原 file record 的求和；问题是五条 record 未对应当前目标 bytes。候选 aggregate 为 `544746147`，增加 `5976580`。`package.json` 本身不在 `files`，不把 package 自己的序列化长度计入该 aggregate。候选仍有 5451 条记录。

`story_studio/crowd_assets.py:69–77` 的 `AssetWriter.record` 以目标文件计算 `bytes/sha256`，然后独立登记 source 原路径及其 SHA。`:328–365` 的 player 导出会选择/投影文档再写目标；`:427–430` 将 record bytes 求和。因此原 source 与公开目标的 hash 本可不同，不能将 source_sha 改成目标 SHA。本次五份 source 的当前实际 SHA 均仍等于登记的 source_sha；全部保留。animation 的 source 是 10,969,720 B / `d7fa5a74…`，与目标 JSON 语义相同且其 compact+newline 序列化正好等于当前目标；motion_states 也符合此等值关系。其余三份 source / target 语义不相同，仅记录观察，不从中推断历史变更原因。当前登记不符的历史成因仍 UNKNOWN。

`story_studio/recovery/native_resources.py:23–47` 核资源 key 与 metadata 文件存在，并不读取 package record SHA。因此这次发现说明登记与实际文件的差异，不证明脚本、模型或当前画面发生错误，也不签任何运行/演出通过。

`stage/assets/package.json` 是单文件候选，SHA `88eb356391485070f1a60e4d55be039fe58f1d7b64c085c54ffb900c93eafdb1`，1,972,953 B。完整 old/new 11 叶差异、12 URL 记录、实际 HEAD blob ID 与 source 观察在 report；输入守卫在 `input-guards.rootfalse.json`。检查前后 D 保持 `e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8` clean，C 保持 `6630ac70…` 及原 pycache 状态。最终 HEAD 留 null，全部执行/安装/运行接受标记 false。

现有 `A/apply-asset-plan.py:43–44` 必须在 `snapshots` 和 `writes` 同时取得 catalog.json，不能直接执行此单 package 候选。此包没有发明新安装器、没有添加 no-op catalog 写入；root 需另行选择并审查适用的 guarded metadata 安装入口。这里没有可执行安装命令。

已封 Rowdy 六文件候选与本包都以 package 原 SHA `47ca071b…` 为输入，不能将两个旧 stage 依次覆盖。若 root 先安装其中之一，第二个 transaction 必须基于当时真实 package 重新生成并绑定，保留第一项完整语义变化；原 Rowdy 包与其静审证据一律保留。未运行安装、业务 helper、网络、浏览器、媒体或转码，未写 D/C 或 Git。
