# Rowdy01 / Rowdy02 资源闭包独立静审

结论：本次静审未发现 must-fix。候选六文件资源增量可供 root 在 UI 冻结结束后重新绑定并审批；本报告不授权安装，也不接受任何剧情、身份选择、动作、表情或实播。

核对的 preparation receipt 为 `1375b651ef39a6b77169e61ac3a2f7c2f10a751cd8323661911d4762c22f2d0a`。receipt 全部 15 个 payload 的实际长度与 SHA 均匹配，合计 9,053,177 B；候选、原资源及所读 D/C 文件在本次末次读取时保持相同字节。独立证据列于 `evidence.rootfalse.json`，不是重跑作者 preparation 的输出。

实际 stage 恰为六文件、8,835,728 B：两模型各新增原 `ac.moc3`、`textures/texture_00.png`，共四 raw、2,176,700 B；另有 full `catalog.json` 和 `package.json`。当前四 raw 正式目标均不存在。stage 没有 native/review、preview、detail 或 player 索引文件。

Full catalog 只增加 `live2d/AC_rowdy01`、`live2d/AC_rowdy02` 两模型，`members` 与 `asset_members` 各增加同一组 52 个真实原成员映射；全部原有 key/value 保持。每模型原 descriptor 的递归 FileReferences 加 descriptor 本身恰 26 个成员，其中 23 个 motion；新增模型行逐字段等于现有 detail 投影，保留其 12 个 script motion、24 个 motion binding。三份现有 player 索引已有两模型及其 script state，preview catalog 现有两行的基础 URL/身份字段一致。

Package 恰新增 54 条：52 个原成员和两份既有生成 detail。原有 package 条目仅 `catalog.json` 的 bytes/SHA 更新，其余语义完整保留；其他顶层值保留，`bytes` 等于所有 file record 的总和（538,769,567 → 541,331,255 B）。52 个原成员均直接读现有 LIMEOS 原文件并与 overlay 实际目标比较；其 package `source`、`source_sha256` 精确对应这些原 bytes。两份 detail 只登记其实际 bytes/SHA，不编造原 detail 或历史生成收据。50 个既有原成员/detail 和四个 preview 均由 plan 的 54 条 reused locks 覆盖，实际 SHA 全匹配；六个 metadata locks 也全匹配。

允许的限量标准库 gzip 核对已实际完成：rowdy01 解压 296,128 B，SHA `7b7aeaff3b1c95e4db89a0f6a443a8c8f4be48a6efdeb66f061233f2fc5a35a1`；rowdy02 解压 322,240 B，SHA `776cba3821815aeadc813b12dcb41d7d9c9ed2c6742d42fcccd5a4c4cd85d94c`。两者均在 original-length+1 上限内读至 EOF/CRC 成功，且逐字节等于原 MOC 和 stage MOC。既有 WebP 只核实际 opaque SHA 与 RIFF/WEBP 容器长度；PNG 只核 signature/IHDR 的 1500×1500 尺寸。未解码图片，未证明 WebP 像素等价或历史编码来源。

现有契约锚点：`story_studio/crowd_assets.py:69–77` 的 bytes/SHA/source 记录、`:257–280` 的 model/detail/member 投影、`:407–465` 的 package 与引用校验，与候选结构一致。`apply-asset-plan.py:16–58` 接受同一 plan 字段，核 HEAD、metadata/reused locks、六个旧/新目标 bytes 后按 payload 先于 metadata 写入并回读。其 rootfalse 标记本身不是权限闸；实际 `expectedBaseHead:null` 也不是可执行绑定。后续仅由 root fresh 核 HEAD/所有 locks、审批独立 plan，再以现有脚本的两个原参数（approved-plan、installed-receipt）执行；本审未执行该脚本。

`native_resources.py:23–29,42–47` 要求显式模型存在于 full catalog 且 detail 文件存在；本增量补足这两项资源结构。C `lib/resources.ts:73–83,92–113,122–142,144–151` 已规定逻辑原 MOC/PNG 的 gzip/WebP preview、原质量与 404 fallback、by-path 映射；这是源码静态说明，没有 HTTP 或播放通过声明。

只读快照为 D `e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8`，检查前后 clean；C `6630ac70f17332efa031d021af00532d42307568`，检查前后仅原 `?? scripts/__pycache__/`。全部 root/installation/runtime/gameplay acceptance 标记保持 false；不改 D/C、旧包或任何 Git 状态，不执行业务、浏览器、网络、安装、转码或媒体工具。
