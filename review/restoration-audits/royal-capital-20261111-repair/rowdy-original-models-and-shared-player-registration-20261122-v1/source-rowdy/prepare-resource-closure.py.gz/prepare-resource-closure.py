"""Prepare only two additive model closures using existing package contracts.

Originals and the formal checkout are opened read-only. Missing original
payloads are copied exclusively into this new evidence stage. Existing motion,
detail, player-index and preview bytes are reused by exact hash; this does not
re-encode images, initialize Cubism, run an importer, or accept actor motion.
"""
from copy import deepcopy
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import struct

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout/assets'
C = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout'
OUT = Path(__file__).resolve().parent
STAGE = OUT / 'stage/assets'
ORIGINAL = ROOT / 'data/extracted_archives/limeos'
MODELS = ('rowdy01', 'rowdy02')
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}
assert not STAGE.exists()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return path.read_bytes()

def binding(path):
    raw = read(path)
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def emit(name, document):
    target = OUT / name
    with target.open('x', encoding='utf8') as stream:
        json.dump(document, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def encoded(document):
    # Match the existing crowd_assets.AssetWriter JSON representation. The
    # stage uses the actual existing detail and indices rather than rebuilding
    # the entire asset library or inventing original-generation provenance.
    return (json.dumps(document, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf8')

def copy_new(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as original, destination.open('xb') as target:
        shutil.copyfileobj(original, target, 1024 * 1024)
    assert read(destination) == read(source)

metadata_names = ('catalog.json', 'package.json', 'preview/catalog.json',
                  'player/motion_states.json', 'player/animation.json', 'player/manifest.json')
metadata_before = {name: binding(D / name) for name in metadata_names}
metadata = {name: json.loads(read(D / name)) for name in metadata_names}
base_catalog, base_package = metadata['catalog.json'], metadata['package.json']
catalog, package = deepcopy(base_catalog), deepcopy(base_package)
assert base_package['bytes'] == sum(row['bytes'] for row in base_package['files'].values())
assert base_package['files']['catalog.json']['sha256'] == metadata_before['catalog.json']['sha256']
assert metadata['preview/catalog.json'].get('model_members') == 'by-path'
changes, reused, sources, models, package_additions, new_members = [], {}, {}, [], {}, {}

for model in MODELS:
    native_id = 'live2d/AC_' + model
    prefix = 'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_' + model + '/'
    source_root = ORIGINAL / prefix
    target_root = D / 'models' / model
    descriptor_source = source_root / 'ac/ac.model3.json'
    descriptor_target = target_root / 'ac/ac.model3.json'
    descriptor_raw = read(descriptor_source)
    assert descriptor_raw == read(descriptor_target)
    descriptor = json.loads(descriptor_raw)
    assert descriptor['Version'] == 3
    assert native_id not in catalog['models']
    assert metadata['preview/catalog.json']['models'][native_id]['model_url'] == 'models/' + model + '/ac/ac.model3.json'
    detail_path = target_root / 'detail.json'
    detail_raw = read(detail_path)
    detail = json.loads(detail_raw)
    assert detail['id'] == model and detail['member'] == prefix + 'ac/ac.model3.json'
    assert detail['portrait'] == ''
    refs = []
    def references(value):
        if isinstance(value, str):
            refs.append(value)
        elif isinstance(value, dict):
            for item in value.values():
                references(item)
        elif isinstance(value, list):
            for item in value:
                references(item)
        elif value is not None:
            raise AssertionError(('Unexpected FileReferences leaf', value))
    references(descriptor['FileReferences'])
    assert len(refs) == len(set(refs))
    member_files = ['ac/ac.model3.json'] + ['ac/' + relative for relative in refs]
    assert len(member_files) == 26
    model_files, copied_missing = [], []
    for relative in member_files:
        source = (source_root / relative).resolve()
        assert source.is_relative_to(source_root.resolve()) and source.is_file()
        member = prefix + relative
        target_name = 'models/' + model + '/' + relative
        target = D / target_name
        original_binding = binding(source)
        sources[str(source)] = original_binding
        raw = read(source)
        existed = target.is_file()
        if existed:
            assert read(target) == raw, target_name
            reused[target_name] = sha(raw)
        else:
            assert relative in ('ac/ac.moc3', 'ac/textures/texture_00.png')
            stage_path = STAGE / target_name
            copy_new(source, stage_path)
            change = {'path': target_name, 'source': str(stage_path), 'bytes': len(raw),
                      'sha256': sha(raw), 'expectedSha256': None}
            changes.append(change)
            copied_missing.append(change)
        assert member not in catalog['members'] and member not in catalog['asset_members']
        catalog['members'][member] = target_name
        catalog['asset_members'][member] = target_name
        new_members[member] = target_name
        assert target_name not in package['files']
        package_row = {'bytes': len(raw), 'sha256': sha(raw),
                       'source': source.relative_to(ROOT).as_posix(), 'source_sha256': sha(raw)}
        package['files'][target_name] = package_row
        package_additions[target_name] = package_row
        model_files.append({'member': member, 'url': target_name, 'original': original_binding,
                            'DExistedBefore': existed, 'DByteExactBefore': existed,
                            'stageCopied': not existed, 'packageBefore': None})
    assert len(copied_missing) == 2
    detail_name = 'models/' + model + '/detail.json'
    assert detail_name not in package['files']
    reused[detail_name] = sha(detail_raw)
    # detail.json already exists and is complete. Register its actual bytes as
    # generated metadata without fabricating an original file or source hash.
    package_row = {'bytes': len(detail_raw), 'sha256': sha(detail_raw)}
    package['files'][detail_name] = package_row
    package_additions[detail_name] = package_row
    def projected(row):
        member = row['member']
        assert member.startswith(prefix) and member in new_members
        return dict(row, url=new_members[member])
    entry = dict(id=model, native_id=native_id, label=detail['name'],
                 model_url=new_members[detail['member']], member=detail['member'], detail_url=detail_name,
                 motions=[projected(row) for row in detail['motions']],
                 script_motions=[projected(row) for row in detail['script_motions']],
                 motion_bindings={token: projected(row) for token, row in detail['motion_bindings'].items()},
                 controller_url='player/animation.json')
    assert len(entry['motions']) == 23 and len(entry['script_motions']) == 12 and len(entry['motion_bindings']) == 24
    assert {row['member'] for row in detail['motions']} == {prefix + relative for relative in member_files if relative.endswith('.motion3.json')}
    states = metadata['player/motion_states.json']['models'][model]
    animation = metadata['player/animation.json']['models'][model]
    placement = metadata['player/manifest.json']['actors'][model]
    for row in detail['script_motions']:
        assert row['state'] in states['states'], (model, row['state'])
        assert any(row['state'] in layer['states'] for layer in animation['layers'])
    catalog['models'][native_id] = entry
    preview_checks = []
    for relative in ('ac/ac.moc3.gz', 'ac/textures/texture_00.webp'):
        preview_name = 'preview/models/' + model + '/' + relative
        path = D / preview_name
        item = binding(path)
        reused[preview_name] = item['sha256']
        preview_checks.append(item)
    moc_source = source_root / 'ac/ac.moc3'
    compressed = read(D / ('preview/models/' + model + '/ac/ac.moc3.gz'))
    original_moc = read(moc_source)
    assert compressed[:2] == b'\x1f\x8b'
    # This is standard-library decompression of an existing small gzip only.
    # Cap inflated bytes against the exact original size and verify EOF/CRC.
    with gzip.GzipFile(fileobj=io.BytesIO(compressed), mode='rb') as stream:
        inflated = stream.read(len(original_moc) + 1)
        assert len(inflated) == len(original_moc) and stream.read(1) == b''
    assert inflated == original_moc
    png = read(source_root / 'ac/textures/texture_00.png')
    assert png[:8] == b'\x89PNG\r\n\x1a\n' and png[12:16] == b'IHDR'
    png_width, png_height = struct.unpack_from('>II', png, 16)
    webp = read(D / ('preview/models/' + model + '/ac/textures/texture_00.webp'))
    assert webp[:4] == b'RIFF' and webp[8:12] == b'WEBP'
    assert struct.unpack_from('<I', webp, 4)[0] + 8 == len(webp)
    preview_row = metadata['preview/catalog.json']['models'][native_id]
    assert all(preview_row[k] == entry[k] for k in ('id','native_id','label','member','model_url','detail_url'))
    models.append({'model': model, 'native_id': native_id, 'originalPrefix': prefix,
                   'descriptorSource': binding(descriptor_source), 'descriptorD': binding(descriptor_target),
                   'descriptorByteExact': True, 'descriptorFileReferences': descriptor['FileReferences'],
                   'descriptorGroups': descriptor.get('Groups', []), 'memberFiles': model_files,
                   'detail': binding(detail_path), 'detailBeforeAndAfterUnchanged': True,
                   'motionCount': len(detail['motions']), 'scriptMotionCount': len(detail['script_motions']),
                   'bindingCount': len(detail['motion_bindings']),
                   'existingIndexCanonicalSHA256': {'motion_states': sha(encoded(states)), 'animation': sha(encoded(animation)), 'placement': sha(encoded(placement))},
                   'existingMotionStateNames': sorted(states['states']),
                   'allScriptMotionStatesPresentInCurrentIndices': True,
                   'newFullCatalogEntry': entry, 'unchangedPreviewCatalogEntry': preview_row,
                   'existingPreviewFiles': preview_checks,
                   'existingMocGzip': {'bytes': len(compressed), 'sha256': sha(compressed),
                      'inflatedBytes': len(inflated), 'inflatedSHA256': sha(inflated), 'byteExactOriginalMoc': True,
                      'newGzipEncodingPerformed': False},
                   'originalPNGHeaderDimensions': {'width': png_width, 'height': png_height},
                   'existingWebPContainerHeaderValid': True,
                   'webPPixelEquivalenceOrOriginalEncodeReceiptProven': False,
                   'preservation': 'Existing WebP/gzip/detail/descriptor/motions and player indices remain byte-for-byte unchanged.'})

# Verify the transaction is additive for every pre-existing catalog row, not
# merely the two model branches. Existing script data and other actors are not
# part of this stage. The preview picker already has both rows and stays intact.
for section, value in base_catalog.items():
    if isinstance(value, dict):
        assert all(catalog[section].get(key) == row for key, row in value.items())
    else:
        assert catalog[section] == value
assert set(catalog['models']) - set(base_catalog['models']) == {'live2d/AC_' + model for model in MODELS}
assert len(new_members) == 52 and len(package_additions) == 54 and len(changes) == 4
STAGE.mkdir(parents=True, exist_ok=True)
new_catalog_raw = encoded(catalog)
with (STAGE / 'catalog.json').open('xb') as stream:
    stream.write(new_catalog_raw)
package['files']['catalog.json'] = {'bytes': len(new_catalog_raw), 'sha256': sha(new_catalog_raw)}
package['files'] = dict(sorted(package['files'].items()))
package['bytes'] = sum(row['bytes'] for row in package['files'].values())
new_package_raw = encoded(package)
with (STAGE / 'package.json').open('xb') as stream:
    stream.write(new_package_raw)
for name in ('catalog.json','package.json'):
    raw = read(STAGE / name)
    changes.append({'path': name, 'source': str(STAGE / name), 'bytes': len(raw),
                    'sha256': sha(raw), 'expectedSha256': metadata_before[name]['sha256']})
assert len(changes) == 6
for name, row in base_package['files'].items():
    assert name == 'catalog.json' or package['files'][name] == row
assert set(package['files']) - set(base_package['files']) == set(package_additions)
for name, row in reused.items():
    assert sha(read(D / name)) == row
for name, row in metadata_before.items():
    assert binding(D / name) == row
for name, row in sources.items():
    assert binding(Path(name)) == row
# Every new descriptor reference resolves against either a copied stage file
# or an exactly hash-locked formal file. No all-library exporter or codec runs.
for model in models:
    for row in model['memberFiles']:
        selected = STAGE / row['url'] if (STAGE / row['url']).is_file() else D / row['url']
        assert selected.is_file() and sha(read(selected)) == row['original']['sha256']

plan = {'rootConfirmed': False, 'installationAuthorized': False, 'expectedBaseHead': None,
        'requiresFinalFreshRootBinding': True, 'target': str(D),
        'sourceMetadataLocks': {name: row['sha256'] for name,row in metadata_before.items()},
        'reusedPayloadLocks': reused, 'changes': changes,
        'scope': 'Four missing original MOC/PNG payloads plus additive full catalog/package registration only.',
        'actorFieldsChanged': False, 'runtimePlaybackAccepted': False}
emit('integration-plan.template.rootfalse.json', plan)
emit('resource-closure.rootfalse.json', {'rootConfirmed': False, 'dataHeadObservedFromParentOnly': 'e2c2b96b...',
     'sourceMetadataBefore': metadata_before, 'allSourceAndDHashesUnchanged': True, 'models': models,
     'newPackageFileRecords': package_additions, 'newArchiveMemberMappings': new_members,
     'rawOriginalCopies': changes[:4], 'changes': changes,
     'counts': {'fullCatalogModelsAdded': 2, 'archiveMembersAddedPerMap': 52, 'packageRecordsAdded': 54,
                'existingPackageRecordsChanged': ['catalog.json'], 'reusedPayloadLocks': len(reused),
                'missingRawPayloadsCopied': 4, 'DWriteCount': 0, 'CWriteCount': 0},
     'sourceProvenanceLimit': 'New source_sha256 records are fresh direct original-byte bindings. No historical extraction/transcode receipt is fabricated. Existing generated detail has bytes/hash only.',
     'scriptOrActionAcceptance': False, 'installableApproved': False})
emit('normal-path-and-cf-routing.rootfalse.json', {'rootConfirmed': False,
    'existingExporterContract': {'source': str(ROOT/'story_studio/crowd_assets.py'),
       'functions': ['AssetWriter.record','PilotAssetPackage.models','PilotAssetPackage.build','PilotAssetPackage.validate'],
       'schemaReused': True, 'wholeExporterExecuted': False},
    'existingInstaller': {'path': str(A/'apply-asset-plan.py'), 'schemaReused': True, 'executed': False,
       'argvTemplate': [str(ROOT/'.venv-video-ocr/bin/python'), '-B', str(A/'apply-asset-plan.py'),
          '<root-final-fresh-approved-plan.json>', '<root-installed-receipt.json>'],
       'requiredNextStep': 'Root rebinds expectedBaseHead and all source/reused locks after UI freeze ends, reviews exact six changes, then runs the existing installer; keep every other resource/script unchanged.'},
    'nativeGate': {'path': str(ROOT/'story_studio/recovery/native_resources.py'),
       'rule': 'Explicit live2d/AC_rowdy01 or02 requires full catalog models key and existing detail_url. Both rows currently absent; this stage adds exact model rows backed by complete descriptor children.'},
    'CF': {'source': str(C/'lib/resources.ts'),
       'catalog': 'Studio CF reads preview/catalog.json (already has both rows); full view reads catalog.json (both keys added).',
       'default': 'Model descriptor/detail URLs stay original JSON paths. Logical models/<id>/ac/ac.moc3 maps to existing preview/models/<id>/ac/ac.moc3.gz; PNG texture maps to existing WebP. Both have original fallback if preview404.',
       'original': 'quality=original fetches original MOC/PNG. Four original paths are absent before; stage supplies them.',
       'gzip': 'CF sends Content-Encoding gzip for accepting clients or standard DecompressionStream otherwise; existing gzip inflated bytes exactly match original MOC.',
       'model_members': 'Preview model_members=by-path resolves model archive members when that model is in preview catalog, without adding global preview aliases.',
       'frontEndChangeRequiredForThesePaths': False, 'actualHTTPOrGameplayTestPerformed': False,
       'webPProvenanceLimit': 'Existing WebP remains unchanged; its historical encoder receipt/pixel equivalence is not asserted.'},
    'preservation': {'D_C': 'read-only', 'previewCatalog': 'unchanged', 'indices': 'unchanged',
                     'otherModels': 'all old catalog entries/other package rows preserved',
                     'firstThreeSections': 'no native/review/script files in this stage'}})
print(json.dumps({'rootConfirmed': False, 'stage': str(STAGE), 'changes': len(changes),
                  'originalPayloadCopies': 4, 'copiedOriginalBytes': sum(row['bytes'] for row in changes[:4]),
                  'stageBytes': sum(row['bytes'] for row in changes), 'packageRecordsAdded':54,
                  'archiveMembersAddedPerMap':52, 'gzipByteExactBothModels':True, 'allSourceAndDHashesUnchanged':True,
                  'D_C_Modified':False, 'newCodecRun':False}))
