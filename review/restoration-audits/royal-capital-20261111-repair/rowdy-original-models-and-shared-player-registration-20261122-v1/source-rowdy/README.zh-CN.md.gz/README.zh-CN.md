# Rowdy01 / Rowdy02：最小资源闭包 stage

已实际完成只读核验和新增 A stage，原 preparation exit0、stderr0。共6个待安装文件，8,835,728字节：两模型缺失的4个原MOC/PNG共2,176,700字节，以及 additive full catalog/package。D/C、原图、旧证据均未改变，未运行正式安装器。

当前不是“预览不存在”：preview catalog已有两model行，MOC.gz和texture.webp都在。两份既有gzip经标准库限量解压，均与原MOC逐字节一致。D已有每模型descriptor、23个motion和detail，三份player索引也已有两model。它们全部复用并锁定原字节。

Full catalog新增2模型；members和asset_members各加52条真实原成员映射；package新增54条资源记录并更新catalog记录/bytes。detail、preview catalog、播放器索引无需改。此stage是六文件增量，必须覆盖到现有D才构成完整资源闭包。

既有WebP保持不变，不编造历史转码收据或像素等价。没有新编码、Unity解码、识图、浏览器、网络或游戏播放。资源注册不等于动作/表情/剧情验收。

Root结束UI冻结后，fresh绑定integration-plan.template.rootfalse.json中的expectedBaseHead及全部locks，复用现有apply-asset-plan.py正常注册；之后再走已独立审过的actor字段包。候选全为rootfalse，本包没有授权或执行正式写入。
