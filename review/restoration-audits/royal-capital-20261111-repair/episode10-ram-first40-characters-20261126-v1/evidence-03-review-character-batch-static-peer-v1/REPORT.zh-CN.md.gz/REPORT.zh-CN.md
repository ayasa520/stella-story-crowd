# Character batch prepare / review 独立静审

最终源码：`A/review-character-batch-v1.py`，14,922 B / 288 行，SHA256 `55623aa7d5349e1b71c3eb092a7e5a23955d39021bfdd75f0157c8f730e20ee4`。结论：本次发现的 M1 / M2 / M3 均已按最终源码静态关闭，未发现剩余 must-fix。完整初版及最终版均已阅读全文；只对最终同次原 bytes 使用 Python 内置 `compile`，没有执行 helper、导入业务模块、运行 stage/audit/apply 或新增测试。

初版实际 SHA 为 `283a3d54d4ef2ba1cb74222c7abadaae935d064fc30f874c928957ef0cc26ea9`。必须保留原发现，不能用修后结论倒签原版：

1. M1：初版先核 performance append，再将整个 `repairEvidence` 替回旧对象，会抹去其它 sibling 的额外改动。中间版 `29753e6f…` 已改为只 pop 已验证的 performance 尾项；按原缺席状态删空子 key / 父 key，父 key 删除前要求对象确为空。最终全 sidecar 比较仍能看见所有其它 evidence 变化。
2. M2：初版只处理 absolute path+SHA，真实 `scene10040043-last50…` 与 `scene10130003-last37…` 包的 packet / 同目录 JSON 引用全为相对路径、absolute 引用数为零；两 packet 自身分别有 164 / 336 个 relative path+SHA 对象。初版因此不能声明这些源 refs 已核。最终同时处理 absolute、明确 ROOT 前缀和 document-relative refs，禁止 relative `..`，全部参与原 SHA 校验和 A JSON 递归。历史漂移仅允许 manifest、ownership、catalog、package、本目标 native/review 六类明确路径，并要求声明 ancestor 的实际 Git blob 等于旧 SHA；原模型/图像/媒体和 outside-D 源不能被 fresh rebind。
3. M3：初版未拒绝 staged `recordings` / `directoryEntryUpdates`，而原 `native_install.py:146–173` 会把它们写入 library manifest。最终要求两数组均为空，并核 passed / rough / not-run，排除了额外 recording 与目录文字写入。

最终 prepare 逐 change 限制唯一 character 字段、完整 13 个 expected、同一 scene、唯一 array index，并核当前 scenarioId / uniq_id / stableKey / 13 字段原值；有 fullNativeRowBefore 时还核完整行。目标 current model catalog entry 必须等于显式 evidence-base ancestor 的模型 entry，detail 必须存在。候选 raw SHA 在 parse 前核对；原 source / peer / resource 参考按 path+SHA 追踪，允许历史 metadata rebinding 时记录 old/current SHA 和两 HEAD。递归源 JSON 的 `JSONDecodeError` 分支保留原 raw gzip 并抛出，不重试。

两原 business module 的实际 SHA 与源码 pinned 常量一致：native_repair `0efd16bc…`、native_install `6b819631…`；prepare 还将自身和原 observer 的实际 SHA 加入 source guards。review 再核这些 guards。因此后续 helper 改动不能沿用旧 prepare 获得同一 review 结论。

最终 review 对 staged native 只撤销被允许的 character 叶，再与当前完整 native 比较；其它字段、UID、数组顺序、branch 与未选行均保留在比较中。Sidecar 校验 exact performance append、只清 character unknown / performance issue，再做完整 inverse；全局 issues 的派生拼接与整份 sidecar 都核。Scene summary 从当前 entry 精确构造 nodeCount / reviewCounts / issues 及正常 draft 标记，整 entry 相等后才写 review 结果。它没有替代原 native_repair / native_install 的结构、ownership、资源及实际写入门禁。

独立只读成员检查确认，REFERENCE 的 285 路径恰为当前 140 native + 140 review + manifest / ownership / full catalog / package / preview catalog，缺项与多项均为 0；REFERENCE 中 protectedFirstThree 为 22。该检查是当前成员集合核对，没有执行 helper 的正式字节收集，也没有冒称本 peer 已验证所有 207 个候选的源图或实际业务结果。

后续 root 必须使用这份确切源码重新 prepare，在原 normal stage 后运行 review，再独立决定 apply；旧 prepare 不等于最终源码的 prepare。`--evidence-base` 应为 root 明示的真实 E2 ancestor `e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8`，不是无来源的历史值。源码只接受静态 character identity，完整入场、body / face / phase / timing / gameplay 仍未接受。此 peer 全为 rootfalse，不授权 apply；未写 D/C、旧包或 Git，未识图、浏览器、网络或媒体处理。
