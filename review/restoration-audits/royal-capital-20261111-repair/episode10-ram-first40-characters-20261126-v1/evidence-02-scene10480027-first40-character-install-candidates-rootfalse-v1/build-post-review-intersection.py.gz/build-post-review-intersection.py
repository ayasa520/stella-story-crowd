#!/usr/bin/env python3
"""Serialize the explicit intersection of two sealed static image reviews.

This is post-review reconciliation, not another independent visual review. The
primary and independent image packets remain immutable inputs. A model is emitted
only when both already-sealed per-row decisions name the same exact native model.
An unresolved peer variant always excludes the row, even if the primary named a
model that happens to be registered in D. All installation/root flags stay false.
"""

from __future__ import annotations

import ast
from collections import Counter
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

PROJECT = Path('/home/rikka/Projects/stella')
A = PROJECT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
OUT = Path(__file__).resolve().parent
PRIMARY = A / 'scene10480027-first53-static-identity-source-rootfalse-v1'
PEER = A / 'scene10480027-first53-independent-image-peer-v1'
TEMPLATE = A / 'episode10-scene54-27-characters-root-preparation-87482d95-v1/node-fields.root-approved.json'
E2 = 'e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8'
PRIMARY_RECEIPT = '2a91e2ec4b610bf0a72788aeaee1497f24d6775465e24ea26737562dea57b080'
PEER_RECEIPT = 'e916e069fc15856f9cd8249b3ab388d6592660356fd71ec47fb0d5318f394f09'


def read(path):
    return json.loads(Path(path).read_text())


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def bind(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def verify(binding):
    assert bind(binding['path']) == binding, binding['path']


def write(name, value):
    p = OUT / name
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return bind(p)


def dependency_names(descriptor):
    """Resolve only literal descriptor dependencies without loading a model.

    The original and D resource closure includes every FileReferences dependency,
    including motion JSON files. Hashing them proves file provenance/presence only;
    no motion token, animation state, MOC geometry or playback is accepted here.
    """
    refs = descriptor['FileReferences']
    names = []
    for key, value in refs.items():
        if isinstance(value, str):
            names.append((key, value))
        elif key == 'Textures':
            names.extend(('Texture', v) for v in value)
        elif key == 'Motions':
            for group in value.values():
                for item in group:
                    names.append(('Motion', item['File']))
                    if item.get('Sound'):
                        names.append(('Sound', item['Sound']))
        elif key == 'Expressions':
            names.extend(('Expression', v['File']) for v in value)
        else:
            assert value is None, (key, value)
    return list(dict.fromkeys(names))


def main():
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19
    assert set(os.sched_getaffinity(0)) <= {0, 1}
    observed_head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    assert observed_head == E2

    primary_receipt_binding = bind(PRIMARY / 'receipt.rootfalse.json')
    peer_receipt_binding = bind(PEER / 'receipt.rootfalse.json')
    assert primary_receipt_binding['sha256'] == PRIMARY_RECEIPT
    assert peer_receipt_binding['sha256'] == PEER_RECEIPT
    primary_seals = read(PRIMARY / 'files-index.rootfalse.json')['files']
    peer_seals = read(PEER / 'receipt.rootfalse.json')['payload']
    for seal in primary_seals + peer_seals:
        verify(seal)
    primary = read(PRIMARY / 'report.rootfalse.json')
    resources = read(PRIMARY / 'resources.rootfalse.json')['resources']
    peer_review = read(PEER / 'review.rootfalse.json')
    peer = read(PEER / 'coverage.rootfalse.json')
    assert primary['observedDHEADMetadataOnly'] == E2
    assert len(primary['rows']) == len(peer['rows']) == 53
    assert peer_review['independence']['primaryPerRowRecommendationsOrReportsRead'] is False

    native_path = D / 'native/scenes/10480027.json'
    review_path = D / 'review/scenes/10480027.json'
    catalog_path = D / 'assets/catalog.json'
    package_path = D / 'assets/package.json'
    manifest_path = D / 'manifest.json'
    ownership_path = D / 'review/native-restoration.json'
    preview_catalog_path = D / 'assets/preview/catalog.json'
    guard_paths = [native_path, review_path, catalog_path, package_path,
                   manifest_path, ownership_path, preview_catalog_path]
    current_files = [bind(p) for p in guard_paths]
    native = read(native_path)
    review = read(review_path)
    catalog = read(catalog_path)
    package = read(package_path)
    preview_catalog = read(preview_catalog_path)
    native_by_id = {r['scenario_id']: (i, r) for i, r in enumerate(native['scenario_list'])}
    resource_by_id = {r['nativeId']: r for r in resources}

    # Read the helper's declared field set as a literal AST value. Importing or
    # invoking native_repair/native_install would cross this task's execution
    # boundary, so compatibility is checked structurally and remains rootfalse.
    rough_path = PROJECT / 'story_studio/recovery/native_rough.py'
    rough_ast = ast.parse(rough_path.read_text())
    string_fields = next(ast.literal_eval(node.value) for node in rough_ast.body
                         if isinstance(node, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'STRING_FIELDS'
                                 for t in node.targets))
    assert len(string_fields) == 12
    expected_keys = string_fields | {'command'}
    template = read(TEMPLATE)
    assert template['schema'] == 'native_repair.node_fields'
    assert set(template['changes'][0]['expected']) == expected_keys

    intersections, excluded = [], []
    for offset, (p, q) in enumerate(zip(primary['rows'], peer['rows'])):
        sid = p['scenarioId']
        array_i, row = native_by_id[sid]
        rev = review['scenarios'][str(sid)]
        assert offset == p['candidateArrayOffset'] == q['candidateArrayOffset']
        assert sid == q['scenarioId']
        assert p['UID'] == q['UID'] == row['uniq_id']
        assert p['stableKey'] == q['stableKey'] == rev['stableKey']
        assert p['nativeArrayIndex'] == q['nativeArrayIndex'] == array_i
        assert digest(row) == p['fullNativeRowBeforeCanonicalSHA256'] == q['fullNativeRowCanonicalSHA256']
        assert digest(rev) == p['fullReviewRowBeforeCanonicalSHA256'] == q['fullReviewRowCanonicalSHA256']
        assert digest(row['branch_list']) == p['branchListCanonicalSHA256'] == q['branchListCanonicalSHA256']
        assert rev['sourceText'] == p['JPGuard'] == q['JapaneseGuard']
        assert row['msg_text'] == p['currentChineseGuard'] == q['ChineseGuard']
        assert p['source']['fullFrame'] == q['source']['fullFrame'] == q['freshOriginalFullFrame']
        assert p['source']['fullFrameSourceTimeSeconds'] == q['source']['fullFrameSourceTimeSeconds']
        verify(p['source']['fullFrame'])
        assert p['source']['fullFrameActuallyViewed'] is True and q['directFullFrameViewed'] is True
        assert row['character'] == row['character_image'] == ''
        primary_model = (p.get('candidate') or {}).get('character')
        peer_model = q.get('characterCandidate')
        if primary_model and primary_model == peer_model:
            assert not q['exactVariantAlternativesUnresolved']
            assert q['candidateOriginalResource']
            model_resource = resource_by_id[primary_model]
            assert q['candidateOriginalResource']['descriptor'] == model_resource['originalDescriptor']
            assert q['candidateOriginalResource']['opaqueMoc'] == model_resource['originalOpaqueMoc']
            assert q['candidateOriginalResource']['textures'] == model_resource['originalTextures']
            intersections.append((offset, p, q, row, rev, array_i))
        else:
            excluded.append({
                'candidateArrayOffset': offset, 'scenarioId': sid,
                'UID': row['uniq_id'], 'arrayIndex': array_i, 'stableKey': rev['stableKey'],
                'primaryCharacterRecommendation': primary_model,
                'peerCharacterRecommendation': peer_model,
                'peerExactVariantAlternativesUnresolved': q['exactVariantAlternativesUnresolved'],
                'peerUnknownReason': q['unknownReason'],
                'disposition': 'preserve_empty_excluded_from_node_fields',
                'reason': 'Primary recommendation is not supported as an exact model by the independent peer.' if primary_model else 'Both reviews leave the assignable exact identity unresolved.',
                'explicitDisagreement': primary_model is not None,
                'registrationCannotResolveDisagreement': True,
                'fullNativeRowBefore': row, 'fullReviewRowBefore': rev,
                'fullNativeRowCanonicalSHA256': digest(row),
                'fullReviewRowCanonicalSHA256': digest(rev),
                'branchListCanonicalSHA256': digest(row['branch_list']),
                'JPGuard': rev['sourceText'], 'currentChineseGuard': row['msg_text'],
                'fullSourceFrame': p['source']['fullFrame'],
                'sourceNominalSeconds': p['source']['fullFrameSourceTimeSeconds'],
                'rootConfirmed': False, 'installationAuthorized': False,
                'executionAuthorized': False,
            })
    assert len(intersections) == 40 and len(excluded) == 13
    assert {r['scenarioId'] for r in excluded} == {20, 22, 23, 25, 27, 28, 31, 34, 48, 49, 51, 56, 62}
    assert {r['scenarioId'] for r in excluded if r['explicitDisagreement']} == {20, 28, 48, 51}

    closure = []
    original_base = PROJECT / 'data/extracted_archives/limeos'
    for native_id in sorted({p['candidate']['character'] for _, p, *_ in intersections}):
        entry = catalog['models'][native_id]
        original_descriptor = original_base / entry['member']
        d_descriptor = D / 'assets' / entry['model_url']
        descriptor = read(original_descriptor)
        assert original_descriptor.read_bytes() == d_descriptor.read_bytes()
        assert dependency_names(descriptor) == dependency_names(read(d_descriptor))
        file_pairs = [('Descriptor', original_descriptor, d_descriptor)]
        file_pairs.extend((kind, original_descriptor.parent / name, d_descriptor.parent / name)
                          for kind, name in dependency_names(descriptor))
        dependencies = []
        for kind, original_file, d_file in file_pairs:
            orig, target = bind(original_file), bind(d_file)
            assert orig['sha256'] == target['sha256'] and orig['bytes'] == target['bytes']
            rel = str(d_file.relative_to(D / 'assets'))
            package_entry = package['files'][rel]
            assert package_entry['sha256'] == target['sha256']
            assert package_entry['bytes'] == target['bytes']
            assert package_entry['source_sha256'] == orig['sha256']
            dependencies.append({'kind': kind, 'original': orig, 'D': target,
                                 'packageRelativePath': rel, 'packageEntry': package_entry,
                                 'exactBytes': True})
        detail = D / 'assets' / entry['detail_url']
        positive = resource_by_id[native_id]
        peer_ref = next(r for r in peer_review['referenceCoverage']['directOriginalTextureViews']
                        if r['model'] == 'ac_' + entry['id'] and r['textureIndex'] == 0)
        assert peer_ref['texture'] == positive['originalTextures'][0]
        closure.append({
            'nativeId': native_id,
            'catalogJSONPointer': '/models/' + native_id.replace('/', '~1'),
            'catalogEntryCanonicalSHA256': digest(entry),
            'catalogMember': entry['member'], 'catalogModelURL': entry['model_url'],
            'detail': bind(detail),
            'previewCatalogEntryCanonicalSHA256': digest(preview_catalog['models'][native_id]),
            'originalModelDescriptorMocAndTextureMap': positive,
            'primaryPositiveTextureActuallyViewedInSealedReview': positive['originalTextures'][0],
            'independentPeerPositiveTextureActuallyViewedInSealedReview': peer_ref,
            'descriptorDependencyCount': len(dependencies), 'dependencies': dependencies,
            'allFilesPresentAndOriginalDPackageHashesAgree': True,
            'MocIsOpaqueHashOnly': True,
            'renderedOrMotionAccepted': False,
            'newAssetImportRequired': False,
        })
    assert len(closure) == 5
    closure_file = write('resource-closure.rootfalse.json', {
        'schema': 'stella.exact-five-model-resource-closure.rootfalse.v1',
        'rootConfirmed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'allBindingsReadOnly': True, 'resources': closure,
    })
    closure_i = {r['nativeId']: i for i, r in enumerate(closure)}
    guards = {
        'schema': 'stella.scene10480027.post-review-current-guards.rootfalse.v1',
        'rootConfirmed': False, 'executionAuthorized': False, 'installationAuthorized': False,
        'observedHEADMetadataOnly': E2, 'DWorkingTreeCleanAsserted': False,
        'files': current_files,
        'all115NativeIDsCanonicalSHA256': digest([(r['scenario_id'], r['uniq_id']) for r in native['scenario_list']]),
        'all115JPAndChinese': [{'scenarioId': r['scenario_id'], 'UID': r['uniq_id'],
                                'stableKey': review['scenarios'][str(r['scenario_id'])]['stableKey'],
                                'Japanese': review['scenarios'][str(r['scenario_id'])]['sourceText'],
                                'Chinese': r['msg_text'],
                                'branchListCanonicalSHA256': digest(r['branch_list'])}
                               for r in native['scenario_list']],
        'nativeStringFieldDeclaration': bind(rough_path),
        'STRING_FIELDS': sorted(string_fields), 'expectedKeys': sorted(expected_keys),
        'nativeRepairReadOnlyContractSource': bind(PROJECT / 'story_studio/recovery/native_repair.py'),
        'referencePacketReadOnlyShapeOnly': bind(TEMPLATE),
        'referencePacketApprovalFlagsWereNotInherited': True,
    }
    guard_file = write('current-row-and-scene-guards.rootfalse.json', guards)
    source_bindings = {
        'primaryReceipt': primary_receipt_binding,
        'primaryReport': bind(PRIMARY / 'report.rootfalse.json'),
        'primaryResources': bind(PRIMARY / 'resources.rootfalse.json'),
        'primaryFilesIndex': bind(PRIMARY / 'files-index.rootfalse.json'),
        'independentPeerReceipt': peer_receipt_binding,
        'independentPeerReview': bind(PEER / 'review.rootfalse.json'),
        'independentPeerCoverage': bind(PEER / 'coverage.rootfalse.json'),
        'independentPeerBindings': bind(PEER / 'bindings.rootfalse.json'),
    }
    changes = []
    for offset, p, q, row, rev, array_i in intersections:
        model = p['candidate']['character']
        after = copy.deepcopy(row)
        after['character'] = model
        expected = {key: copy.deepcopy(row[key]) for key in sorted(string_fields)}
        expected['command'] = copy.deepcopy(row['command'])
        assert set(expected) == expected_keys
        changes.append({
            'sceneId': 10480027, 'scenarioId': row['scenario_id'], 'UID': row['uniq_id'],
            'uniqueId': row['uniq_id'], 'arrayIndex': array_i, 'stableKey': rev['stableKey'],
            'candidateArrayOffset': offset,
            'rootConfirmed': False, 'rootReviewed': False,
            'executionAuthorized': False, 'installationAuthorized': False,
            'expected': expected, 'fields': {'character': model},
            'fullNativeRowBefore': row, 'fullReviewRowBefore': rev,
            'fullNativeRowBeforeCanonicalSHA256': digest(row),
            'fullNativeRowAfterCanonicalSHA256': digest(after),
            'fullReviewRowBeforeCanonicalSHA256': digest(rev),
            'branchListCanonicalSHA256': digest(row['branch_list']),
            'JPGuard': rev['sourceText'], 'JPGuardCanonicalSHA256': digest(rev['sourceText']),
            'currentChineseGuard': row['msg_text'], 'currentChineseGuardCanonicalSHA256': digest(row['msg_text']),
            'directImageReviewPerformedDuringThisPostReviewAssembly': False,
            'evidence': {
                'postReviewIntersectionOfSealedPerRowDecisions': True,
                'primaryReview': source_bindings['primaryReport'],
                'primaryReviewJSONPointer': f'/rows/{offset}',
                'independentPeerReview': source_bindings['independentPeerReview'],
                'independentPeerCoverage': source_bindings['independentPeerCoverage'],
                'independentPeerJSONPointer': f'/rows/{offset}',
                'sourceOriginalFullFrame': p['source']['fullFrame'],
                'sourceNominalCacheSeconds': p['source']['fullFrameSourceTimeSeconds'],
                'sourceRecordedInterval': p['source']['eventRangeSeconds'],
                'sourceIndexJSONPointer': p['source']['indexJSONPointer'],
                'sourceOriginalPTSNewlyEstablished': False,
                'sourceVideoSHA256InheritedNotRehashed': p['source']['originalRecordingSHA256InheritedFromBoundIndexNotRehashed'],
                'primarySourceFullFrameViewedInSealedReview': True,
                'independentPeerSourceFullFrameViewedInSealedReview': True,
                'primaryPositiveAndExclusionObservations': p['visualEvidence'],
                'independentPeerObservation': q['observed'],
                'independentPeerOcclusionOrLimit': q['occlusionOrLimit'],
                'exactModelAgreedByBoth': model,
                'positiveOriginalModelDescriptor': q['candidateOriginalResource']['descriptor'],
                'positiveOriginalModelOpaqueMoc': q['candidateOriginalResource']['opaqueMoc'],
                'positiveOriginalModelTextures': q['candidateOriginalResource']['textures'],
                'resourceClosure': closure_file,
                'resourceClosureJSONPointer': f'/resources/{closure_i[model]}',
                'identityAndImageOnly': True,
                'motionAccepted': False, 'expressionAccepted': False,
                'extraAccepted': False, 'geometryOrTimingAccepted': False,
                'audioVoiceAccepted': False, 'fullEntryAccepted': False,
                'fullSceneAccepted': False,
            },
        })
    node_fields = {
        'schema': 'native_repair.node_fields', 'version': 1,
        'status': 'post-review-explicit-40-exact-character-intersection-candidates-only',
        'rootConfirmed': False, 'rootReviewed': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'candidateOnly': True, 'baseSha': E2,
        'baseCommitMetadataObservedOnly': E2, 'DWorkingTreeCleanAsserted': False,
        'sceneId': 10480027, 'changes': changes,
        'requiredAssetImports': [], 'allowedFields': ['character'],
        'reviewChanges': {}, 'fullScenePerformanceAccepted': False,
        'sourceJapaneseAndCurrentChineseFullSceneGuard': guard_file,
        'currentNativeReviewCatalogFileGuards': current_files,
        'resourceClosure': closure_file,
        'normalSaveOrAPIPacketReady': False,
        'rootMustFreshRebindHEADOwnershipManifestFullGlobalAndNormalSaveBeforeApplying': True,
        'all13ExcludedRowsMustKeepTheirCurrentBlankForeground': [x['scenarioId'] for x in excluded],
        'notes': [
            'This assembly reconciles two sealed reviews and is not an independent image review.',
            'The four Pack rows are excluded because the peer cannot distinguish pack01 from pack_big01; D registration supplies no missing visual evidence.',
            'rootConfirmed is false in every change, so the existing native_repair helper must reject this unreleased candidate packet until root independently rebinds and authorizes a derived packet.',
            'No body, expression, layers, geometry, phase, timing, audio, full-entry, continuous-playback or whole-scene acceptance is implied.',
        ],
    }
    packet_file = write('node-fields.rootfalse.json', node_fields)
    exclusions_file = write('excluded13-and-disagreements.rootfalse.json', {
        'schema': 'stella.scene10480027.post-review-excluded13.rootfalse.v1',
        'rootConfirmed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'sourceBindings': source_bindings,
        'allExcludedRowsPreserveBothEmptyForegroundFields': True,
        'explicitDisagreementScenarioIds': [x['scenarioId'] for x in excluded if x['explicitDisagreement']],
        'rows': excluded,
    })
    input_file = write('sealed-input-bindings.rootfalse.json', {
        'schema': 'stella.scene10480027.post-review-sealed-inputs.rootfalse.v1',
        'rootConfirmed': False, 'executionAuthorized': False, 'installationAuthorized': False,
        'sourceBindings': source_bindings, 'primarySealsVerified': primary_seals,
        'peerSealsVerified': peer_seals, 'currentInputs': current_files,
    })

    # Validate the serialization without importing or invoking the repair helper.
    # These checks establish schema/guards only. Its root approval requirement is
    # deliberately unsatisfied, so this file is reviewable but cannot be installed.
    emitted = read(OUT / 'node-fields.rootfalse.json')
    assert len(emitted['changes']) == 40
    for change in emitted['changes']:
        assert set(change['fields']) == {'character'}
        assert set(change['expected']) == expected_keys
        assert all(isinstance(change['expected'][k], str) for k in string_fields)
        assert isinstance(change['expected']['command'], list) and len(change['expected']['command']) == 3
        assert all(isinstance(x, str) for x in change['expected']['command'])
        assert change['rootConfirmed'] is False
        after = copy.deepcopy(change['fullNativeRowBefore'])
        after.update(change['fields'])
        assert digest(after) == change['fullNativeRowAfterCanonicalSHA256']
    for seal in primary_seals + peer_seals:
        verify(seal)
    assert bind(PRIMARY / 'receipt.rootfalse.json') == primary_receipt_binding
    assert bind(PEER / 'receipt.rootfalse.json') == peer_receipt_binding
    assert [bind(p) for p in guard_paths] == current_files
    after_head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    assert after_head == E2
    receipt_file = write('receipt.rootfalse.json', {
        'schema': 'stella.scene10480027.first40.post-review-intersection.receipt.v1',
        'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'rootConfirmed': False, 'rootReviewed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'status': '40-character-only-intersection-candidates-13-preserved-4-explicit-pack-disagreements',
        'postReviewAssemblyNotIndependentImageReview': True,
        'sourceReviewScope': {'offset': 0, 'count': 53},
        'candidateCount': 40, 'preserveEmptyCount': 13,
        'modelCounts': dict(Counter(x['fields']['character'] for x in changes)),
        'packDisagreementScenarioIds': [20, 28, 48, 51],
        'expectedFieldCount': 13, 'STRING_FIELDCount': 12,
        'soleChangedField': 'character', 'requiredAssetImports': [],
        'originalModelClosures': len(closure),
        'modelDependencyFilePairs': sum(len(x['dependencies']) for x in closure),
        'all53CurrentRowAndJPZHAndBranchGuardsMatchBothSealedReviews': True,
        'all40SourceFullFrameRawHashesMatchBothSealedReviews': True,
        'sealedPrimaryAndPeerUnchanged': True,
        'DObservedHEADBeforeMetadataOnly': observed_head,
        'DObservedHEADAfterMetadataOnly': after_head,
        'DWorkingTreeCleanAsserted': False,
        'boundCurrentFilesUnchanged': True,
        'nativeRepairShapeCheckedByReadOnlySourceAndTemplate': True,
        'nativeRepairNativeInstallOrBusinessHelperExecuted': False,
        'browserMediaDecoderOrRendererExecuted': False,
        'D_CGitOrConfigurationMutated': False,
        'writesOnlyInsideNewOwnedOutputDirectory': True,
        'motionExpressionFullEntryTimingAudioWholeSceneAccepted': False,
        'wholeRestorationGoalComplete': False,
        'rootMustFreshRebindBeforeAnyInstall': True,
        'nice': 19, 'affinity': sorted(os.sched_getaffinity(0)),
        'packet': packet_file, 'resourceClosure': closure_file,
        'currentGuards': guard_file, 'exclusions': exclusions_file,
        'sealedInputs': input_file,
    })
    (OUT / 'README.txt').write_text(
        'Post-review explicit intersection, not an independent image review.\n'
        'node-fields.rootfalse.json follows native_repair.node_fields schema and guards all 12 STRING_FIELDS plus command.\n'
        '40 rows change character only; rootConfirmed/execution/installation stay false everywhere.\n'
        '13 rows preserve empty foreground, including explicit Pack disagreements at 20/28/48/51.\n'
        'Every candidate has full current native/review row guards, JP/Chinese/branch guards, original source-frame hash and exact-model positive references from both sealed reviews.\n'
        'Five complete original-to-D descriptor dependency closures are hashed; MOC is opaque, motions are not accepted.\n'
        'Only root may create a separately approved, freshly rebound installation packet. No business helper, browser, decoder, renderer, data write or Git mutation ran here.\n'
    )
    write('files-index.rootfalse.json', {
        'rootConfirmed': False, 'executionAuthorized': False, 'installationAuthorized': False,
        'files': [bind(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'files-index.rootfalse.json'],
    })
    print(json.dumps({'packet': packet_file, 'receipt': receipt_file,
                      'changes': 40, 'preserveEmpty': 13,
                      'resourceFilePairs': sum(len(x['dependencies']) for x in closure)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
