Post-review explicit intersection, not an independent image review.
node-fields.rootfalse.json follows native_repair.node_fields schema and guards all 12 STRING_FIELDS plus command.
40 rows change character only; rootConfirmed/execution/installation stay false everywhere.
13 rows preserve empty foreground, including explicit Pack disagreements at 20/28/48/51.
Every candidate has full current native/review row guards, JP/Chinese/branch guards, original source-frame hash and exact-model positive references from both sealed reviews.
Five complete original-to-D descriptor dependency closures are hashed; MOC is opaque, motions are not accepted.
Only root may create a separately approved, freshly rebound installation packet. No business helper, browser, decoder, renderer, data write or Git mutation ran here.
