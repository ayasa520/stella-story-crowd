scene10480027 candidate-array offsets 0..52 (first 53 of 106).
Read report.rootfalse.json for every complete guarded current row and its actually viewed full source frame.
44 character-only candidates are in character-only.packet.rootfalse.json; all approval/acceptance flags are false.
8 Emilia rows remain exact-resource unknown after actual emilia01/emilia02 atlas comparison.
node62 remains unknown: its existing full frame is already the selected-quote phase; one 1041.999 s full frame is the minimum proposed follow-up, not execution authorization.
No source images or global resource maps are copied. MOC blobs are opaque hashed provenance objects.
This is static identity evidence only. Full entry, body/face/layers, timing, audio/FX, routing and continuous playback remain unaccepted.
The full restoration goal remains active and unlimited under the first-three-episode standard.
