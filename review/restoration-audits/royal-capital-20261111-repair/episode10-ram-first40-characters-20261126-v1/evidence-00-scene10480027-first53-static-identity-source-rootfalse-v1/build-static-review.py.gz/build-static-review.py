#!/usr/bin/env python3
"""Write a bounded, read-only-input static identity audit.

The decisions below are manual observations made by the delegated image reviewer.
They must never be derived from the dialogue speaker or inherited character state.
This script only serializes those decisions and independently binds the existing
source images, complete current rows, and actual extracted resource bytes. It does
not decode video, render models, change D/C, or authorize installation.
"""

from __future__ import annotations

import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess


PROJECT = Path('/home/rikka/Projects/stella')
A = PROJECT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
OUT = Path(__file__).resolve().parent
RECOVERY = PROJECT / 'data/native_recovery/royal-capital-20261110'
ORIGINAL = PROJECT / 'data/extracted_archives/limeos'
CANDIDATES = A / 'chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json'
INDEX = RECOVERY / 'ocr/36/root-review/index.json'
NATIVE = D / 'native/scenes/10480027.json'
REVIEW = D / 'review/scenes/10480027.json'
CATALOG = D / 'assets/catalog.json'
PACKAGE = D / 'assets/package.json'
MANIFEST = D / 'manifest.json'
PREVIEW_CATALOG = D / 'assets/preview/catalog.json'


def read(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def binding(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return binding(path)


# Each entry is keyed by the actual guarded scenario UID's scenario component.
# Selection and ordering still come exclusively from the candidate array slice.
# None means that the source pixels do not establish a unique assignable resource.
OBSERVED = {
    4: 'subaru01', 5: 'felt01', 6: 'subaru01', 7: 'felt01',
    8: 'subaru01', 9: 'felt01', 10: 'subaru01', 11: 'felt01',
    12: 'felt01', 13: 'felt01', 14: 'subaru01', 15: 'subaru01',
    18: 'elsa01', 19: 'ram01', 20: 'pack01', 21: 'elsa01',
    22: None, 23: None, 24: 'elsa01', 25: None,
    26: 'elsa01', 27: None, 28: 'pack01', 29: 'elsa01',
    30: 'felt01', 31: None, 32: 'ram01', 33: 'elsa01',
    34: None, 35: 'subaru01', 36: 'elsa01', 37: 'ram01',
    38: 'subaru01', 39: 'elsa01', 40: 'subaru01', 41: 'elsa01',
    44: 'felt01', 45: 'ram01', 46: 'felt01', 47: 'ram01',
    48: 'pack01', 49: None, 50: 'ram01', 51: 'pack01',
    52: 'ram01', 53: 'elsa_nomantle01', 54: 'subaru01', 55: 'felt01',
    56: None, 57: 'elsa_nomantle01', 60: 'subaru01', 61: 'subaru01',
    62: None,
}

FEATURES = {
    'subaru01': {
        'positive': [
            'Visible upward-spiked hair and the white zip-front track jacket with dark shoulders and long sleeves, orange collar/trim, and N chest emblem match the inspected original subaru01 texture components.',
            'The jacket collar, chest emblem, and front zip are individually visible in this full source frame; the source has an actor body below the dialogue panel.',
        ],
        'negative': [
            'The inspected tshirt01 and tshirt02 original atlases have a plain dark torso without the white jacket front, orange standing collar, or chest emblem; both are excluded by the visible jacket.',
        ],
        'references': ['subaru01', 'subaru_tshirt01', 'subaru_tshirt02'],
    },
    'felt01': {
        'positive': [
            'Visible blond short hair with a large dark bow, red scarf with gold bars, open brown vest with light fur edging, and black bandeau match the inspected original felt01 atlas.',
            'The red scarf, dark bow, and brown vest are visible on the body in this full source frame, independently of the speaker label.',
        ],
        'negative': [
            'The inspected felt_dress01 atlas has a yellow/black formal bodice, frilled skirt, and white gloves; the source instead shows the scarf and open vest.',
            'The inspected felt_winter01 atlas has a blue checked scarf and dark winter torso; the source red scarf and brown open vest exclude it.',
        ],
        'references': ['felt01', 'felt_dress01', 'felt_winter01'],
    },
    'elsa01': {
        'positive': [
            'Visible side braid, flower hair ornament, feather/fur collar behind the shoulders, dark shoulder mantle, and gold circular clasp match the inspected original elsa01 atlas.',
            'The purple-edged open-front outfit and detached sleeves are consistent secondary details; the mantle, feather collar, clasp, and flower are the decisive visible variant features.',
        ],
        'negative': [
            'The inspected elsa_nomantle01 atlas has bare shoulder pieces and lacks the mantle, feather collar, gold clasp and flower present on this source actor; that variant is excluded.',
        ],
        'references': ['elsa01', 'elsa_nomantle01'],
    },
    'elsa_nomantle01': {
        'positive': [
            'Visible bare shoulders and upper chest, long side braid, purple-edged strapless open-front outfit and detached sleeves match the inspected original elsa_nomantle01 atlas.',
            'There is no mantle, feather/fur shoulder collar, gold neck clasp or hair flower on the fully visible source upper body.',
        ],
        'negative': [
            'The inspected elsa01 original atlas contains the conspicuous mantle, feather collar, gold circular clasp and flower absent from this source actor; the no-mantle variant is visually distinguished.',
        ],
        'references': ['elsa_nomantle01', 'elsa01'],
    },
    'ram01': {
        'positive': [
            'Visible pink bob with side-swept fringe, red eye, X-shaped hair clips and flower headband match the inspected original ram01 atlas.',
            'The black/white maid bodice, white ruffled collar and shoulder edges, narrow neck bow, and dark long sleeves are visible and match the original maid costume.',
        ],
        'negative': [
            'The inspected ram_hood01 atlas has a white/purple cloak torso and broad white/purple sleeves; the source has the dark maid bodice and ruffled white edges instead.',
            'The inspected ram_childhood01 atlas has a white/red kimono and pink obi, unlike the source black/white maid costume.',
        ],
        'references': ['ram01', 'ram_hood01', 'ram_childhood01'],
    },
    'pack01': {
        'positive': [
            'Visible small cat body, long upright tail, chest fur tuft, ear ring and purple cross-body satchel match the inspected original pack01 atlas.',
            'The exposed fur body and satchel are visible in the full frame; clothing or a human portrait is not being inferred from the speaker label.',
        ],
        'negative': [
            'The inspected pack_xmas01 atlas has a red fur-trimmed Santa outfit and holiday props; the source actor has exposed fur and the purple satchel, excluding that costume.',
        ],
        'references': ['pack01', 'pack_xmas01'],
    },
}

EMILIA_ROWS = {22, 23, 25, 27, 31, 34, 49, 56}
ATLASES_ACTUALLY_VIEWED = [
    'subaru01', 'felt01', 'elsa01', 'elsa_nomantle01',
    'emilia01', 'ram01', 'pack01', 'pack_xmas01',
    'subaru_tshirt01', 'subaru_tshirt02', 'emilia02', 'emilia_hood01',
    'felt_dress01', 'felt_winter01', 'ram_hood01', 'ram_childhood01',
]


def main():
    initial_affinity = sorted(os.sched_getaffinity(0))
    assert set(initial_affinity).issubset({0, 1}), initial_affinity
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19
    head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    all_candidates = read(CANDIDATES)
    selected_scene = next(s for s in all_candidates['scenes'] if s['sceneId'] == 10480027)
    selected = selected_scene['rows'][0:53]
    assert len(selected) == 53 and set(OBSERVED) == {r['scenarioId'] for r in selected}
    native = read(NATIVE)
    review = read(REVIEW)
    source_index = read(INDEX)
    catalog = read(CATALOG)
    package = read(PACKAGE)
    manifest = read(MANIFEST)
    preview_catalog = read(PREVIEW_CATALOG)
    native_rows = {row['scenario_id']: (i, row) for i, row in enumerate(native['scenario_list'])}
    events = {e['id']: (i, e) for i, e in enumerate(source_index['events'])}

    # Resources are compared as exact extracted byte objects. In particular, MOC
    # blobs remain opaque; matching hashes establish provenance, not runtime motion
    # or geometry. Only the small relevant package/catalog entries are copied.
    resources = []
    for model in ATLASES_ACTUALLY_VIEWED:
        native_id = 'live2d/AC_' + model
        member = f'LIMEOS/assets/downloadassets/assetbundle/models/ac/ac_{model}/ac/ac.model3.json'
        source_descriptor = ORIGINAL / member
        descriptor = read(source_descriptor)
        refs = descriptor['FileReferences']
        files = [source_descriptor, source_descriptor.parent / refs['Moc']]
        files.extend(source_descriptor.parent / name for name in refs['Textures'])
        resource = {
            'modelId': model, 'nativeId': native_id,
            'originalMember': member,
            'originalDescriptor': binding(files[0]),
            'originalOpaqueMoc': binding(files[1]),
            'originalTextures': [binding(p) for p in files[2:]],
            'texture00ActuallyViewed': True,
            'additionalTextureImagesActuallyViewed': False,
            'descriptorFileReferences': {k: v for k, v in refs.items() if k != 'Motions'},
            'MocParsedOrExecuted': False,
        }
        entry = catalog['models'].get(native_id)
        if entry:
            target_descriptor = D / 'assets' / entry['model_url']
            target_refs = read(target_descriptor)['FileReferences']
            target_files = [target_descriptor, target_descriptor.parent / target_refs['Moc']]
            target_files.extend(target_descriptor.parent / name for name in target_refs['Textures'])
            resource['D'] = {
                'catalogJSONPointer': '/models/' + native_id.replace('~', '~0').replace('/', '~1'),
                'catalogEntrySHA256': digest(entry),
                'catalogSubset': {k: entry.get(k) for k in ['id', 'native_id', 'label', 'model_url', 'member', 'detail_url']},
                'descriptor': binding(target_files[0]),
                'opaqueMoc': binding(target_files[1]),
                'textures': [binding(p) for p in target_files[2:]],
                'descriptorExactToOriginal': files[0].read_bytes() == target_files[0].read_bytes(),
                'MocExactToOriginal': files[1].read_bytes() == target_files[1].read_bytes(),
                'textureFilesExactToOriginal': len(files) == len(target_files) and all(p.read_bytes() == q.read_bytes() for p, q in zip(files[2:], target_files[2:])),
                'relevantPackageEntries': {str(p.relative_to(D / 'assets')): package['files'].get(str(p.relative_to(D / 'assets'))) for p in target_files},
                'previewCatalogEntrySHA256': digest(preview_catalog['models'][native_id]) if native_id in preview_catalog['models'] else None,
            }
            assert resource['D']['descriptorExactToOriginal']
            assert resource['D']['MocExactToOriginal']
            assert resource['D']['textureFilesExactToOriginal']
        else:
            resource['D'] = None
            resource['notRegisteredInDReason'] = 'The current catalog has no native ID entry; no alternate resource installation is proposed.'
        resources.append(resource)

    resource_file = write('resources.rootfalse.json', {
        'schema': 'stella.static-original-to-D-resource-opaque-map.rootfalse.v1',
        'rootConfirmed': False, 'installationAuthorized': False,
        'executionAuthorized': False, 'acceptance': False,
        'MocIsOpaqueByteProvenanceOnly': True,
        'resourceCount': len(resources), 'resources': resources,
    })

    rows, packet_rows = [], []
    viewed_frames = []
    for offset, candidate_row in enumerate(selected):
        sid = candidate_row['scenarioId']
        native_i, current = native_rows[sid]
        current_review = review['scenarios'][str(sid)]
        assert current['uniq_id'] == candidate_row['UID']
        assert current_review['stableKey'] == candidate_row['stableKey']
        assert current_review['sourceText'] == candidate_row['sourceText']
        assert current['character'] == '' and current['character_image'] == ''
        recording = current_review['recordings'][0]
        event_i, event = events[recording['ocrEventId']]
        assert event['source_video'] == recording['sourceVideo']
        assert event['source_sha256'] == recording['sourceSha256']
        assert event['crop'] == recording['frame']
        frame = binding(event['frame'])
        viewed_frames.append(frame)
        model = OBSERVED[sid]
        result = {
            'candidateArrayOffset': offset, 'sceneId': 10480027,
            'scenarioId': sid, 'UID': current['uniq_id'],
            'nativeArrayIndex': native_i, 'stableKey': current_review['stableKey'],
            'fullNativeRowBefore': current,
            'fullNativeRowBeforeCanonicalSHA256': digest(current),
            'branchListCanonicalSHA256': digest(current['branch_list']),
            'fullReviewRowBefore': current_review,
            'fullReviewRowBeforeCanonicalSHA256': digest(current_review),
            'JPGuard': current_review['sourceText'],
            'JPGuardCanonicalSHA256': digest(current_review['sourceText']),
            'currentChineseGuard': current['msg_text'],
            'currentChineseGuardCanonicalSHA256': digest(current['msg_text']),
            'currentReviewChineseGuard': current_review.get('translation'),
            'source': {
                'recording': recording,
                'indexJSONPointer': f'/events/{event_i}',
                'eventId': event['id'],
                'eventSourceText': event['text'],
                'eventRangeSeconds': [event['start'], event['end']],
                'fullFrame': frame,
                'fullFrameActuallyViewed': True,
                'fullFrameSourceTimeSeconds': event['source_frame_time'],
                'timePrecision': 'Existing sampled source_index source_frame_time, recorded to 0.001 s; original media PTS and a frame-accurate boundary were not freshly established.',
                'timeChosenFromIndexNotFilenameArithmetic': True,
                'originalRecordingSHA256InheritedFromBoundIndexNotRehashed': event['source_sha256'],
                'isFullOriginalFrameNotDialogueCrop': True,
            },
            'speakerLabelUsedAsIdentityProof': False,
            'choicePortraitUsedAsIdentityProof': False,
            'bodyFaceExtraLayersGeometryTimingAudioOrWholeSceneAccepted': False,
            'fullEntryHoldExitReviewed': False,
            'reviewIssuesAndDraftStatusMustRemain': True,
        }
        if model:
            evidence = copy.deepcopy(FEATURES[model])
            result.update({
                'disposition': 'static_character_only_candidate',
                'candidate': {'character': 'live2d/AC_' + model},
                'visualEvidence': evidence,
                'characterImageCandidate': None,
            })
            if sid == 30:
                result['visualEvidence']['limitations'] = ['This sampled full frame is visibly darkened during a transition. The blond hair/dark bow, red scarf, black bandeau and brown vest remain visible; only static identity is proposed. No transition phase or timing is accepted.']
            if sid in {28, 51}:
                result['visualEvidence']['limitations'] = ['A bright cyan circular FX overlaps the actor torso. Cat head/ears, long tail, fur and satchel remain visible. The FX resource and its timing are not accepted.']
            after = copy.deepcopy(current)
            after['character'] = 'live2d/AC_' + model
            packet_rows.append({
                'candidateArrayOffset': offset, 'sceneId': 10480027,
                'scenarioId': sid, 'UID': current['uniq_id'],
                'nativeArrayIndex': native_i, 'stableKey': current_review['stableKey'],
                'fullNativeRowBefore': current,
                'fullNativeRowBeforeCanonicalSHA256': digest(current),
                'fullNativeRowAfterCanonicalSHA256': digest(after),
                'fullReviewRowBeforeCanonicalSHA256': digest(current_review),
                'branchListCanonicalSHA256': digest(current['branch_list']),
                'JPGuard': current_review['sourceText'],
                'currentChineseGuard': current['msg_text'],
                'fields': {'character': 'live2d/AC_' + model},
                'evidenceReportJSONPointer': f'/rows/{offset}',
            })
        elif sid in EMILIA_ROWS:
            result.update({
                'disposition': 'unknown_exact_model_variant', 'candidate': None,
                'visibleIdentity': 'Silver-haired girl in the white/purple original costume with braid/white hair flower, purple eyes and green diamond pendant. This visual observation is independent of the dialogue speaker label.',
                'visualEvidence': {
                    'positive': ['White/purple fitted bodice, long pale hair, braided headband, white flower and green pendant agree with the actual emilia01 and emilia02 source texture references.'],
                    'negative': ['Neither this source still nor the inspected shared costume portions provides a reliable positive exclusion of emilia02. The descriptors, MOC hashes and texture hashes are distinct, but that byte difference is not a visible identity test.'],
                    'references': ['emilia01', 'emilia02', 'emilia_hood01'],
                    'remainingAmbiguity': 'emilia01 versus emilia02; emilia02 has additional atlas elements not visibly established in these stills. No installable character field is proposed from chronology, names or D registration.',
                    'hoodReferenceLimit': 'Only original hood texture00 was viewed; its second texture was not viewed, so no complete hood-variant rejection is claimed.',
                },
                'minimumAdditionalEvidence': 'An original resource assignment for this recorded route, or a source interval showing a variant-specific feature with a properly bound comparison reference. More of the same shared costume still alone would not resolve the ambiguity.',
            })
        else:
            assert sid == 62
            result.update({
                'disposition': 'unknown_dialogue_actor_due_to_selected_quote_phase',
                'candidate': None,
                'visibleIdentity': 'No actor body is visible in the reviewed 1051.499 s full frame. It shows the dialogue prompt and selected Ram-directed quote over a blurred background.',
                'visualEvidence': {
                    'positive': [], 'negative': ['Speaker name and the selected Ram quote are text/UI evidence and cannot supply the blank character field.'],
                    'references': [],
                },
                'preserveExistingBlank': True,
                'noActorInThisSampleDoesNotProveWholeDialogueBlank': True,
                'minimumAdditionalEvidence': {
                    'sourceVideo': event['source_video'],
                    'inheritedSourceVideoSHA256': event['source_sha256'],
                    'targetSeconds': 1041.999,
                    'justification': 'One un-cropped full frame from the final prompt sample before choice_left first appears at 1042.999 s; current bound frame is already a selected-quote phase.',
                    'minimumFrameCount': 1,
                    'freshDecodeOrExecutionAuthorized': False,
                },
            })
        rows.append(result)

    inputs = [CANDIDATES, INDEX, NATIVE, REVIEW, CATALOG, PACKAGE, MANIFEST, PREVIEW_CATALOG,
              RECOVERY / 'ocr/36/coarse-1hz/manifest.json',
              RECOVERY / 'ocr/36/dialogue-completion-2hz/manifest.json']
    input_bindings = [binding(p) for p in inputs]
    scene_manifest = next(s for s in manifest['scenes'] if s['id'] == 10480027)
    recording_manifest = next(r for r in manifest['recordings'] if r['id'] == 'bili-capital-36')
    report = {
        'schema': 'stella.scene10480027.first53-static-source-identity.rootfalse.v1',
        'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reviewer': '/root/scene27_identity_first53',
        'rootConfirmed': False, 'acceptance': False,
        'installationAuthorized': False, 'executionAuthorized': False,
        'observedDHEADMetadataOnly': head,
        'DWorkingTreeCleanAsserted': False,
        'candidateArraySlice': {'sceneId': 10480027, 'offset': 0, 'count': 53, 'totalSceneCandidates': selected_scene['candidateRows']},
        'scope': 'Static visual identity only. Source stills do not accept body, face, layers, geometry, voice, BGM, FX, timing, routes or whole-scene/whole-goal restoration.',
        'goalStillActiveUnlimited': True,
        'firstThreeManuallyAcceptedEpisodesRemainTheWholeGoalStandard': True,
        'identityContextFromCurrentEvidenceNotSceneNumberInference': {
            'manifestScene': {k: scene_manifest.get(k) for k in ['id', 'chapterId', 'sectionId', 'title', 'titleJa', 'source', 'nativeIdentifierOrigins']},
            'sectionDirectoryEntry': manifest['studioDirectory']['entries']['section:1048'],
            'sceneDirectoryEntry': manifest['studioDirectory']['entries']['scene:10480027'],
            'recordingManifest': recording_manifest,
            'route': '本編：ラムVer. / 共同作戦, as explicitly recorded in the current directory metadata and recording title.',
            'sourceRowAlignment': 'Each full frame is looked up by the current review row ocrEventId and exact crop/sourceVideo/sourceSha guards in the existing index; visible JP prompt is checked against the candidate row. IDs are authored reconstruction guards, not newly proven original native IDs.',
            'sourceIndex': binding(INDEX),
        },
        'inputs': input_bindings,
        'resources': resource_file,
        'coverage': {
            'candidateRows': 53, 'fullSourceFramesActuallyViewed': 53,
            'distinctExistingFullSourceImagesActuallyViewed': len({x['sha256'] for x in viewed_frames}),
            'originalNativeTexture00AtlasesActuallyViewed': len(ATLASES_ACTUALLY_VIEWED),
            'staticCharacterOnlyCandidates': len(packet_rows),
            'unknownExactEmiliaVariant': len(EMILIA_ROWS),
            'unknownDueToSelectedQuotePhase': 1,
            'characterImageCandidates': 0,
            'fullEntryPerformanceAccepted': False,
            'sourceVideoDecodeOrNewModelRenderPerformed': False,
        },
        'rows': rows,
        'formalD_CGitConfigurationOrOldEvidenceWrites': False,
        'allApprovalFlagsRemainFalse': True,
        'execution': {'nice': os.getpriority(os.PRIO_PROCESS, 0), 'affinity': initial_affinity, 'onlySerializerAndHashingExecuted': True},
    }
    report_file = write('report.rootfalse.json', report)
    packet_file = write('character-only.packet.rootfalse.json', {
        'schema': 'stella.scene10480027.first53-character-candidates.rootfalse.v1',
        'rootConfirmed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'observedDHEADMetadataOnly': head,
        'DWorkingTreeCleanAsserted': False,
        'native': binding(NATIVE), 'review': binding(REVIEW),
        'report': report_file, 'resources': resource_file,
        'allowedFields': ['character'], 'reviewChanges': {},
        'otherFieldsAndBranchesAndJPAndChineseMustRemainExact': True,
        'requiresFreshRootRebindAndIndependentReviewBeforeAnyInstall': True,
        'candidateRows': len(packet_rows), 'rows': packet_rows,
        'unknownRowsExcluded': [row['scenarioId'] for row in rows if row['candidate'] is None],
    })
    index_file = write('inputs-index.rootfalse.json', {
        'rootConfirmed': False, 'executionAuthorized': False,
        'installationAuthorized': False, 'acceptance': False,
        'files': input_bindings, 'sourceFullFramesActuallyViewed': viewed_frames,
        'resourceSubsetsOnly': resource_file,
        'globalCatalogAndPackageWereReadOnlyNoFullMapCopied': True,
    })
    # Re-read only the bound inputs after serialization to detect concurrent
    # changes. A changed unrelated repository HEAD is metadata, not a D-clean
    # check; row and file guards remain the actual installation prerequisites.
    post_bindings = [binding(p) for p in inputs]
    assert post_bindings == input_bindings
    assert len(packet_rows) == 44 and len(rows) - len(packet_rows) == 9
    assert {r['scenarioId'] for r in rows if r['candidate'] is None} == EMILIA_ROWS | {62}
    assert all(set(r['fields']) == {'character'} for r in packet_rows)
    post_head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    receipt = {
        'schema': 'stella.scene10480027.first53-static-receipt.rootfalse.v1',
        'rootConfirmed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'reviewer': '/root/scene27_identity_first53',
        'status': '53-full-source-stills-reviewed-44-character-only-candidates-9-explicit-unknowns',
        'observedHEADBeforeMetadataOnly': head,
        'observedHEADAfterMetadataOnly': post_head,
        'DWorkingTreeCleanAsserted': False,
        'boundInputFilesUnchangedDuringSerializer': True,
        'targetRowCount': 53, 'candidateRowCount': len(packet_rows),
        'unknownRowCount': len(rows) - len(packet_rows),
        'originalSourceFullImagesActuallyViewed': 53,
        'originalTexture00AtlasesActuallyViewed': 16,
        'rootViewedImages': False,
        'browserFFmpegMediaDecodeInstallGitOrConfigMutationPerformed': False,
        'writesOnlyInsideNewOwnedOutputDirectory': True,
        'report': report_file, 'packet': packet_file,
        'resourceMapping': resource_file, 'inputIndex': index_file,
        'nice': 19, 'cpuAffinity': initial_affinity,
        'wholeRestorationGoalComplete': False,
    }
    receipt_file = write('receipt.rootfalse.json', receipt)
    (OUT / 'README.txt').write_text(
        'scene10480027 candidate-array offsets 0..52 (first 53 of 106).\n'
        'Read report.rootfalse.json for every complete guarded current row and its actually viewed full source frame.\n'
        '44 character-only candidates are in character-only.packet.rootfalse.json; all approval/acceptance flags are false.\n'
        '8 Emilia rows remain exact-resource unknown after actual emilia01/emilia02 atlas comparison.\n'
        'node62 remains unknown: its existing full frame is already the selected-quote phase; one 1041.999 s full frame is the minimum proposed follow-up, not execution authorization.\n'
        'No source images or global resource maps are copied. MOC blobs are opaque hashed provenance objects.\n'
        'This is static identity evidence only. Full entry, body/face/layers, timing, audio/FX, routing and continuous playback remain unaccepted.\n'
        'The full restoration goal remains active and unlimited under the first-three-episode standard.\n'
    )
    write('files-index.rootfalse.json', {
        'rootConfirmed': False, 'acceptance': False,
        'executionAuthorized': False, 'installationAuthorized': False,
        'files': [binding(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'files-index.rootfalse.json'],
    })
    print(json.dumps({'report': report_file, 'receipt': receipt_file,
                      'candidateCount': len(packet_rows), 'unknownCount': len(rows) - len(packet_rows)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
