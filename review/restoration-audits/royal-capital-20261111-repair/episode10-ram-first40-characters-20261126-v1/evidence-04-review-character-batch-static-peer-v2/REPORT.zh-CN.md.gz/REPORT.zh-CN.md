# Character batch v2：仅格式示例递归边界静审

结论：v2 最小差异静审无 must-fix。绑定 `review-character-batch-v2.py` 15,407 B，SHA `bbb2731351557114496aec19e1c950f361b7ab458ddaf694e4d9b7693449e8c7`。旧 v1 `55623aa7…` 和旧 peer 均保留；本次不重跑 prepare，不执行源码、业务、测试或安装。

相对 v1 只有两处差异：新增 `CONTRACT_EXAMPLE` 精确常量，指向 `episode10-scene54-27-characters-root-preparation-87482d95-v1/node-fields.root-approved.json`；递归 enqueue 条件新增 `ref != CONTRACT_EXAMPLE` 及解释其角色的英文注释。没有 basename、目录或模式范围豁免。

已独立读取 Ram 候选的 `current-row-and-scene-guards.rootfalse.json`（44,736 B，SHA `99c0b37738208f9728c262cf1448702039a4bdabc1d34895d70c6bf498539a5b`）：`/referencePacketReadOnlyShapeOnly` 明示该精确文件，`referencePacketApprovalFlagsWereNotInherited` 为 true。原 assembly 源 `build-post-review-intersection.py:270–271` 以这两个字段写出其格式参考角色。实际示例文件 93,980 B / SHA `122919316f610b5a84b1d52709825792af9e014e82109bd0c7a5be7fb7e8da70` 与该 sealed ref 完全相同；其 27 项 change 属于 scene10450054，而非当前 Ram scene10480027 的来源。

v2 例外发生在 `actual_raw` SHA 校验和 `guards[str(ref)] = actual` 之后：示例原 bytes 仍被守卫，只不把它内部旧 Julius source graph 递归解释为本次视觉证据。所有其它 relative / absolute source refs、原图和模型仍走原递归与原 SHA，历史 D rebinding 白名单、ancestor Git blob 校验、285 / 22 守卫、两 pinned business 模块、自身 / observer guard、M1 inverse 与 M3 空数组门均逐字节沿用 v1。完整 GNU diff 和静态精确重建结果随 receipt 附存。

root 提供的原 v2 prepare session36531 / exit1 / handle05fb9f 失败保留；本 peer 没有重跑或把它重分类为通过。此次结论只支持已明确 shape-only 的这个文件角色，不接受其旧视觉来源、不授 root approval、不代替原 normal stage/audit/apply。root 后续新 prepare 的真实输出、原门禁与 apply 决定仍独立进行。未写 D/C、旧包或 Git，无浏览器、网络、媒体或图片读取。
