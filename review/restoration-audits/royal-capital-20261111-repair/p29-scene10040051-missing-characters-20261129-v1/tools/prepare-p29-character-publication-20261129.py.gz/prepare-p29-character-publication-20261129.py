"""Build a compact audit plan for one already saved, independently checked scene.

This module never applies a scene, changes Git, or launches a browser. The
existing archive writer and commit verifier consume its exact saved-file set.
Image payloads and model assets stay in their existing locations; only reviewed
metadata and the actual saved-verification inputs are archived once.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
D = A / 'data-checkout'
p = argparse.ArgumentParser()
p.add_argument('--scene', type=int, required=True)
p.add_argument('--parent', required=True)
p.add_argument('--count', type=int, required=True)
args = p.parse_args()
assert args.scene in (10040051, 10040052, 10040053)
assert subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip() == args.parent
out = A / f'p29-scene{args.scene}-normal-character-root-preparation-20261129-v1'
candidate = A / f'p29-scene{args.scene}-combined-character-root-candidate-20261129-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


proof = json.loads((out / 'root-saved-verification.json').read_bytes())
assert proof['parentHead'] == args.parent and proof['exactNativeLeafChanges'] == args.count
assert proof['completeNativeRowsOtherFieldsBranchesAndOrderExact'] and proof['all22ProtectedExact']
files = [(q, 'candidate/' + str(q.relative_to(candidate)))
         for q in candidate.rglob('*') if q.is_file()]
for leaf in ('preflight.root-approved.json', 'node-fields.root-approved.json',
             'stage.root-review.json', 'root-saved-verification.json', 'apply.original.stdout.log'):
    files.append((out / leaf, 'normal-save/' + leaf))
files.extend((q, 'normal-save/saved-inputs/' + q.name)
             for q in (out / 'saved-verification-inputs-v1').iterdir() if q.is_file())
for operation in ('stage', 'install-audit', 'install-apply'):
    folder = A / f'p29-scene{args.scene}-{operation}-observer-20261129-v1'
    files.extend((q, operation + '/' + q.name) for q in folder.iterdir() if q.is_file())
files.append((Path(__file__).resolve(), 'tools/' + Path(__file__).name))
entries = []
for source, destination in files:
    assert source.stat().st_size < 8 * 1024 * 1024
    encoding = 'identity' if source.suffix == '.gz' else 'gzip'
    entries.append(dict(source=str(source), sourceBytes=source.stat().st_size,
        sourceSHA256=sha(source), destination=destination + ('' if encoding == 'identity' else '.gz'),
        encoding=encoding))
assert len({row['destination'] for row in entries}) == len(entries)
plan = dict(rootConfirmed=True, archiveAuthorized=True, dataRoot=str(D), expectedHead=args.parent,
    savedDataFiles=proof['savedFiles'],
    targetRelativeDirectory=f'review/restoration-audits/royal-capital-20261111-repair/p29-scene{args.scene}-missing-characters-20261129-v1',
    originalRunStatus='Normal stage, full stage review, install audit, single apply and complete saved verification exited0.',
    entries=entries,
    readme=f'# P29 scene{args.scene}: restore {args.count} missing character bindings\n\n'
        'Two independent visual reviews bind each exact original dialogue panel to the visible costume and original model resources. '
        'Only previously empty character fields are changed. Full native rows, identifiers, branches and order, reviewed sidecars, '
        'manifest and ownership are verified;281 other formal guards and22 protected files remain unchanged.\n\n'
        'These are static character identities. Motion, face, full entry, timing and saved continuous playback remain unaccepted. '
        'Unknown/no-foreground/occluded rows stay explicit. Retained original controls or original atlas/MOC/prefab structure are '
        'used as documented; missing historical raw controls are not claimed fresh. Source images are not duplicated here.\n')
target = out / 'archive-plan.root-approved.json'
with target.open('x') as stream:
    stream.write(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
(out / 'commit-message.txt').write_text(
    f'Restore {args.count} missing character bindings in P29 scene {args.scene}\n\n'
    'Use independent original-panel and costume/model evidence. Preserve all\n'
    'other fields, routes and source ordering; record normal save verification.\n')
print(json.dumps(dict(plan=str(target), sha256=sha(target), entries=len(entries),
                     sourceBytes=sum(row['sourceBytes'] for row in entries))))
