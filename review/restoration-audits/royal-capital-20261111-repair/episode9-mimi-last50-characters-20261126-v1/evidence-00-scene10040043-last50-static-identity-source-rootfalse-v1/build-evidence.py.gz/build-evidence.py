#!/usr/bin/env python3
"""Build this bounded, read-only source audit; never import or install a repair."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import struct

ROOT = Path("/home/rikka/Projects/stella")
A = ROOT / "artifacts/stella-script-continuation-20261121"
D = A / "data-checkout"
OUT = A / "scene10040043-last50-static-identity-source-rootfalse-v1"
INDEX = ROOT / "data/native_recovery/royal-capital-20261110/ocr/31/root-review/index.json"
CANDIDATES = A / "chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json"
MASTER = ROOT / "data/story_directory/device-snapshot/Adv.d"
NATIVE = D / "native/scenes/10040043.json"
REVIEW = D / "review/scenes/10040043.json"
CATALOG = D / "assets/catalog.json"
MANIFEST = D / "manifest.json"
KNOWN_HEAD_METADATA = "e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    # Explicit canonicalization lets the sole formal writer independently rebind
    # an entire row, including branch arrays and unknown fields. No key or array
    # is discarded merely because this audit proposes only one scalar field.
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()

def relative(path):
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)

def file_binding(path):
    data = path.read_bytes()
    return {"path": relative(path), "bytes": len(data), "sha256": sha(data)}

def json_read(path):
    return json.loads(path.read_text())

def image_dimensions_without_pixel_decode(path):
    # Read only structural PNG/JPEG headers. Images were already directly viewed
    # by the delegated reviewer; this function does not decode a video or render,
    # crop, resize, copy, or reinterpret any original image.
    b = path.read_bytes()
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return list(struct.unpack(">II", b[16:24]))
    if b[:2] != b"\xff\xd8":
        raise ValueError(f"Unsupported existing image header: {path}")
    i = 2
    while i < len(b):
        if b[i] != 255:
            i += 1
            continue
        while i < len(b) and b[i] == 255:
            i += 1
        marker = b[i]
        i += 1
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            continue
        length = int.from_bytes(b[i:i + 2], "big")
        if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                      0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            return [int.from_bytes(b[i + 5:i + 7], "big"),
                    int.from_bytes(b[i + 3:i + 5], "big")]
        i += length
    raise ValueError(f"No image dimensions found: {path}")

def write_json(name, value):
    # Generated outputs are confined to this new evidence directory. All D
    # inputs and all historical evidence remain read-only throughout this run.
    path = OUT / name
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return file_binding(path)

created = datetime.datetime.now(datetime.timezone.utc).isoformat()
inputs = {
    "candidateList": file_binding(CANDIDATES),
    "nativeSceneSnapshot": file_binding(NATIVE),
    "reviewSceneSnapshot": file_binding(REVIEW),
    "originalFrameIndex": file_binding(INDEX),
    "originalDirectoryMaster": file_binding(MASTER),
    "manifestSnapshot": file_binding(MANIFEST),
    "catalogSnapshot": file_binding(CATALOG),
    "manualVisualVerdicts": file_binding(OUT / "manual-visual-verdicts.json"),
}
native = json_read(NATIVE)
review = json_read(REVIEW)
catalog = json_read(CATALOG)
manifest = json_read(MANIFEST)
candidates = next(s for s in json_read(CANDIDATES)["scenes"] if s["sceneId"] == 10040043)
selected = candidates["rows"][50:100]
assert len(selected) == 50
verdicts = json_read(OUT / "manual-visual-verdicts.json")["verdicts"]
assert [v["node"] for v in verdicts] == [r["scenarioId"] for r in selected]
by_node = {r["scenario_id"]: r for r in native["scenario_list"]}
events = {e["id"]: e for e in json_read(INDEX)["events"]}
recording = next(r for r in manifest["recordings"] if r["id"] == "bili-capital-31")
scene_manifest = next(s for s in manifest["scenes"] if s["id"] == 10040043)
master = json.loads(gzip.decompress(MASTER.read_bytes()))
master_group = next(g for g in master["AdventureScene"]
                    if any(s["id"] == 10040043 for s in g["scene_list"]))
master_scene = next(s for s in master_group["scene_list"] if s["id"] == 10040043)
section_group = next(g for g in master["AdventureSection"]
                     if any(s["id"] == 1004 for s in g.get("section_list", [])))
master_section = next(s for s in section_group["section_list"] if s["id"] == 1004)
assert master_group["section_id"] == 1004
assert section_group["chapter_id"] == 1
assert scene_manifest["sectionId"] == 1004
source = {
    "chapter": {"id": 1, "title": "第1章　王都的一日篇"},
    "section": {"id": 1004, "name": master_section["name"],
                "description": master_section["desc"]},
    "scene": {"id": 10040043, "titleJa": master_scene["name"],
              "titleZh": scene_manifest["title"],
              "nativeMaster": master_scene},
    "route": master_scene["route_name"],
    "associationBasis": "Direct original Adv.d scene group section_id=1004, section group chapter_id=1; D manifest scene metadata; review sceneSegments and per-row recording/sourceText anchors. Not inferred from ID magnitude or recording ordering.",
    "recording": recording,
    "sceneSegments": review["sceneSegments"],
    "sourceVideoHashedReadProbedOrDecodedHere": False,
    "sourceVideoSHAIsInheritedMetadata": True,
    "sourceVideoStatBytes": Path(recording["localPath"]).stat().st_size,
    "literalOriginalScenarioCSVRecovered": False,
    "expectedOriginalJPJSONPathChecked": "data/localization/ja-originals/main/rezelos-2020-scene-10040043.json",
    "expectedOriginalJPJSONPresent": (ROOT / "data/localization/ja-originals/main/rezelos-2020-scene-10040043.json").exists(),
    "originalScenarioIdsRecovered": False,
    "nativeIdOrigin": "authored",
}
limits = {
    "staticCostumeIdentityCandidateOnly": True,
    "rootConfirmed": False,
    "installationAuthorized": False,
    "executionAuthorized": False,
    "motionAccepted": False,
    "bodyActionAccepted": False,
    "faceAccepted": False,
    "extraLayerAccepted": False,
    "completeEntryAccepted": False,
    "completeEntryHoldExitAccepted": False,
    "geometryAccepted": False,
    "positionAccepted": False,
    "phaseAccepted": False,
    "timingAccepted": False,
    "voiceAccepted": False,
    "textAccepted": False,
    "normalSavedPlaybackAccepted": False,
    "wholeSceneAccepted": False,
    "wholeRouteAccepted": False,
    "fullRestorationAccepted": False,
}

# These are the reviewer's manual observations of the original model atlases and
# the source stills. They describe costume identity only: visible posed hands,
# eye states, expressions, and arm arrangements never become motion/face tokens.
features = {
    "subaru01": {
        "source": ["Short swept spiky dark hair.", "Black long-sleeved zip jacket with pale front panels, orange shoulder piping and orange-lined standing collar.", "Small dark/orange N-shaped mark on the left chest and a dark undershirt."],
        "atlas": ["The original atlas contains the same pale zip-front torso with N-shaped chest mark.", "Separate dark sleeves have orange cuff/edge pieces; the dark spiky hair and orange collar pieces match the source costume."],
        "variantBasis": "The long black sleeves, zipped pale torso, orange collar and chest mark identify AC_subaru01's visible costume. A bare short-sleeved T-shirt costume is not the costume seen in these stills; no assignment comes from the speaker label.",
    },
    "felt01": {
        "source": ["Short blonde hair, braided crown section and a large black bow at the back/top.", "Red neck scarf with two pale diagonal bars, black bandeau and exposed midriff.", "Short brown vest with dark round buttons/cross-stitch panel, brown gloves and pale fur cuffs."],
        "atlas": ["The original atlas has the matching black bow and blonde braid/hair pieces.", "Its red scarf includes the same pale diagonal bars; the bandeau torso, brown cross-stitched vest, glove and pale cuff pieces match the still."],
        "variantBasis": "The scarf, bandeau, exposed abdomen, brown sleeveless vest and black bow directly identify AC_felt01's costume rather than relying on the displayed name.",
    },
    "mimi01": {
        "source": ["Small orange-haired cat-eared character with two short front braids and gold bell fasteners.", "White robe/cape with orange border, red neck bow and two large pale chest pom-poms.", "Thin orange-and-pale tail; most stills also show a brown staff head at the left edge."],
        "atlas": ["The original atlas includes orange triangular ears, orange braids with gold bells and the thin banded tail.", "White/orange cape and sleeve pieces, red bow, two pom-poms and brown zig-zag staff head match the original stills."],
        "variantBasis": "The white/orange robe, red bow, bell-tied braids and pom-poms directly identify AC_mimi01's costume; the displayed speaker glyph is not used.",
    },
    "ricardo01": {
        "source": ["Large brown canine-faced figure with tall pointed ears, high swept crest and two hanging side locks tied with red rings.", "Bare muscular chest/abdomen with a pointed dark V-shaped fur patch and pale flank patches.", "Black diagonal chest strap, red/black patterned shoulder plate and pale waist wrap."],
        "atlas": ["The original atlas contains the same canine muzzle, pointed ears, crest/mane and red-ringed side-lock pieces.", "Its bare torso has the same pointed chest fur silhouette and pale side patches; the long black strap, red/black shoulder motif and pale waist wrap match."],
        "variantBasis": "The bare furred torso, diagonal strap and red/black shoulder plate directly identify AC_ricardo01's costume; no audio or speaker-name inference is used.",
    },
}

resources = {}
for model in sorted({v["id"] for v in verdicts}):
    native_id = "live2d/AC_" + model
    entry = catalog["models"][native_id]
    original_descriptor = ROOT / "data/extracted_archives/limeos" / entry["member"]
    packaged_descriptor = D / "assets" / entry["model_url"]
    desc = json_read(original_descriptor)
    refs = desc["FileReferences"]
    names = [("descriptor", original_descriptor, packaged_descriptor),
             ("MOC", original_descriptor.parent / refs["Moc"],
              packaged_descriptor.parent / refs["Moc"])]
    names += [("texture", original_descriptor.parent / texture,
               packaged_descriptor.parent / texture) for texture in refs["Textures"]]
    pairs = []
    for kind, original, packaged in names:
        ob, pb = file_binding(original), file_binding(packaged)
        assert ob["sha256"] == pb["sha256"] and ob["bytes"] == pb["bytes"]
        pair = {"kind": kind, "original": ob, "D": pb, "opaqueBytesEqual": True,
                "originalPixelsDirectlyViewed": kind == "texture",
                "DTextureSeparatePixelReview": False,
                "DTextureAttributionBasis": "Original and D exact bytes equality; original full atlas directly viewed." if kind == "texture" else "Opaque byte binding only; not visual animation evidence."}
        if kind == "texture":
            pair["dimensions"] = image_dimensions_without_pixel_decode(original)
        pairs.append(pair)
    resources[native_id] = {
        "catalogEntryCanonicalSHA256": sha(canonical(entry)),
        "catalogIdentity": {k: entry[k] for k in ("id", "native_id", "label", "model_url", "member", "detail_url")},
        "descriptorReferences": {"Moc": refs["Moc"], "Textures": refs["Textures"]},
        "payloadPairs": pairs,
        "visibleCostumeBasis": features[model],
        "newModelRenderExecuted": False,
        "motionOrFaceTokenDerived": False,
    }

time_precision = {
    "source": "Existing root-review/index.json event.time and source_frame_time, linked by exact per-row ocrEventId and recording hash; JPEG is the existing full original recording frame.",
    "reportedSecondsDecimalResolution": 0.001,
    "videoPTSIndependentlyMeasuredHere": False,
    "nativePTSForCachedJPEG": None,
    "frameAccurateNativeBoundaryClaimed": False,
    "meaning": "Legacy index-reported source frame/seek position only. Decimal formatting does not establish native PTS accuracy, authored card start, duration, phase or timing.",
    "fpsMetadata": 30.000095904402492,
    "fpsMetadataSource": "data/native_recovery/royal-capital-20261110/ocr/31/coarse-1hz/manifest.json",
}
rows = []
for offset, (candidate, verdict) in enumerate(zip(selected, verdicts), 50):
    node = candidate["scenarioId"]
    row = by_node[node]
    rr = review["scenarios"][str(node)]
    assert row["uniq_id"] == candidate["UID"]
    assert rr["stableKey"] == candidate["stableKey"]
    assert rr["sourceText"] == candidate["sourceText"]
    assert row["character"] == row["character_image"] == ""
    rec = rr["recordings"][0]
    event = events[rec["ocrEventId"]]
    assert event["source_sha256"] == recording["localSha256"]
    assert event["source_video"] == recording["localPath"]
    assert event["frame"] != rec["frame"]
    frame = Path(event["frame"])
    native_id = "live2d/AC_" + verdict["id"]
    source_features = list(features[verdict["id"]]["source"])
    if node == 105:
        source_features[-1] = "Thin orange-and-pale tail is visible; the raised-sleeve still does not show the staff head."
    rows.append({
        "candidateArrayOffset": offset, "scenarioId": node,
        "UID": row["uniq_id"], "stableKey": rr["stableKey"],
        "nativeArrayIndex": native["scenario_list"].index(row),
        "fullCurrentNativeRowSnapshot": row,
        "fullCurrentNativeRowCanonicalSHA256": sha(canonical(row)),
        "fullCurrentReviewRowSnapshot": rr,
        "fullCurrentReviewRowCanonicalSHA256": sha(canonical(rr)),
        "guards": {
            "characterBefore": "", "characterImageBefore": "",
            "sourceSpeakerJa": rr.get("sourceSpeaker"),
            "sourceTextJa": rr["sourceText"],
            "translationZh": rr.get("translation"),
            "nativeSpeaker": row.get("msg_character"),
            "nativeTextZh": row.get("msg_text"),
            "unknownFieldsMustBePreserved": rr.get("unknownFields", []),
            "pendingTextIssueMustBePreserved": any(i.get("code") == "text_review_pending" for i in rr.get("issues", [])),
            "originalScenarioIdRemainsUnknown": True,
            "nativeBranchesCanonicalSHA256": sha(canonical(row["branch_list"])),
            "reviewBranchesCanonicalSHA256": sha(canonical(rr.get("branches", []))),
        },
        "sourceAnchor": {
            "recordingId": rec["recordingId"], "segmentId": rec["segmentId"],
            "rowRecordingIntervalSeconds": [rec["start"], rec["end"]],
            "rowSourceAnchorSeconds": rec.get("sourceAnchorSeconds"),
            "ocrEventId": rec["ocrEventId"],
            "eventId": event["id"],
            "eventIntervalSeconds": [event["start"], event["end"]],
            "eventReportedTimeSeconds": event["time"],
            "eventReportedSourceFrameTimeSeconds": event.get("source_frame_time"),
            "legacyFrameIndex": event["frame_index"],
            "precisionRef": "timePrecision",
            "sourceVideoPath": recording["localPath"],
            "sourceVideoSHA256Inherited": recording["localSha256"],
        },
        "directFullFrameReview": {
            **file_binding(frame),
            "dimensions": image_dimensions_without_pixel_decode(frame),
            "directlyViewed": True,
            "viewer": "tools.view_image",
            "reviewer": "/root/scene43_identity_last50",
            "fullOriginalFrame": True,
            "subtitleCropUsedAsIdentityEvidence": False,
            "speakerLabelUsedAsIdentityEvidence": False,
            "choicePortraitUsedAsIdentityEvidence": False,
            "completeEntrySequenceReviewed": False,
            "foregroundObservation": "One clear costumed character in the original full frame; no CG foreground.",
            "visibleIdentityFeatures": source_features,
            "matchingOriginalAtlasResource": native_id,
            "atlasAndPayloadEvidenceRef": "resources/" + native_id,
        },
        "identityDecision": {
            "status": "single-field-character-candidate-for-root-freshbind",
            "candidate": {"field": "character", "before": "", "value": native_id},
            "characterImageCandidate": None,
            "visibleIdentitySupported": True,
            "originallyNoCharacter": False,
            "unknown": False,
            "rootConfirmed": False,
        },
        "minimalExtractionRequirement": None,
        "limits": limits,
    })
counts = {}
for r in rows:
    key = r["identityDecision"]["candidate"]["value"]
    counts[key] = counts.get(key, 0) + 1

packet = {
    "schema": "stella.scene10040043.last50.static-identity-source-review.v1",
    "createdUTC": created, "reviewer": "/root/scene43_identity_last50",
    "status": "fifty-static-character-only-candidates-await-root-freshbind",
    "knownDataHeadMetadataOnly": KNOWN_HEAD_METADATA,
    "headReadOrVerifiedHere": False,
    "DWorktreeCleanClaimed": False,
    "rootFreshBindRequired": True,
    "selection": {"sceneId": 10040043, "candidateRowsInScene": 100,
                  "offset": 50, "count": 50, "arrayOrderUsed": True,
                  "notScenarioIdRangeSelection": True,
                  "nodeIds": [r["scenarioId"] for r in rows]},
    "inputBindings": inputs, "sourceIdentity": source,
    "timePrecision": time_precision,
    "resources": resources, "rows": rows,
    "summary": {"rows": 50, "characterCandidates": 50, "characterImageCandidates": 0,
                "originallyNoCharacterFindings": 0, "unknown": 0,
                "missingFullframes": 0, "resourceCounts": counts,
                "fullframesDirectlyViewed": 50, "originalAtlasesDirectlyViewed": 4,
                "textPendingRowsPreserved": sum(r["guards"]["pendingTextIssueMustBePreserved"] for r in rows)},
    "limits": limits,
    "preservation": {"noDOrCOrGitMutation": True,
                     "oldEvidenceUnchanged": True,
                     "allPendingTextAndUnknownOriginalCSVClaimsRetained": True,
                     "allBranchesRetainedAsExactSnapshots": True,
                     "largeImagesCopied": False,
                     "completeInventoryProduced": False},
}
packet_binding = write_json("static-identity-review.rootfalse.json", packet)
assert file_binding(NATIVE) == inputs["nativeSceneSnapshot"]
assert file_binding(REVIEW) == inputs["reviewSceneSnapshot"]
receipt = {
    "schema": "stella.static-identity-evidence-receipt.rootfalse.v1",
    "createdUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "rootConfirmed": False, "installationAuthorized": False, "executionAuthorized": False,
    "knownDataHeadMetadataOnly": KNOWN_HEAD_METADATA,
    "DWorktreeCleanClaimed": False, "rootFreshBindRequired": True,
    "scope": "scene10040043 candidate array offset50/count50, static identity only",
    "output": packet_binding,
    "manualVerdicts": inputs["manualVisualVerdicts"],
    "builder": file_binding(OUT / "build-evidence.py"),
    "summary": packet["summary"],
    "readOnlyNativeAndReviewSnapshotStableDuringBuild": True,
    "offlineBuilderExecuted": True,
    "executionEnvironment": {"nice": os.getpriority(os.PRIO_PROCESS, 0),
                             "cpuAffinity": sorted(os.sched_getaffinity(0))},
    "checks": {"fiftyRowsHaveUIDStableKeyAndFullNativeReviewGuards": True,
               "fiftyOriginalFullframesDirectlyViewed": True,
               "fourOriginalAtlasesDirectlyViewed": True,
               "originalAndDDescriptorMOCTexturesOpaqueByteEqual": True,
               "allProposalsAreCharacterSingleScalar": True,
               "noSpeakerOrSubtitleCropOrChoicePortraitIdentityInference": True,
               "noBrowserFFmpegVideoAudioDecodeInstallAPIBuildTestsOrGit": True,
               "noFormalDataWebsiteOrOldEvidenceWritten": True},
    "limits": limits,
}
write_json("receipt.rootfalse.json", receipt)
print(json.dumps({"outputDirectory": str(OUT), "summary": packet["summary"],
                  "packet": packet_binding, "receipt": file_binding(OUT / "receipt.rootfalse.json")},
                 ensure_ascii=False, indent=2))

