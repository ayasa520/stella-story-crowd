# Original PlayAnim → SetMotion forwarding

The exact previously unopened boundary is now read: **PlayAnim**,
Assembly-CSharp token `0x600187c`, native VA/file offset
`0x1dead08..0x1deadac`, **164 original instruction bytes**. Its verified table
slot is VA `0x2ebc4b0`, file offset `0x2ebb4b0`. Raw SHA-256:
`be85418217ab8a5710aea5ffd6f806db1c7e314cccccf4aa0401c296af79e836`.
The complete disassembly, actual argv/exit record, metadata parameters and
fresh source hashes are retained. No other new instruction body was read.

Metadata flags `0x91` prove PlayAnim is static. Its parameters and register
dataflow are:

| Declared parameter | Entry register | Saved by instruction | Valid-path forwarding |
|---|---|---|---|
| model_path: string | x0 | x20 at0x1dead28 | x0=x20 at0x1dead84 |
| l2d_name: string | x1 | x21 at0x1dead24 | Only the IsNullOrEmpty gate; not forwarded |
| motion_list: string[] | x2 | x19 at0x1dead20 | x1=x19 at0x1dead88 |

At `0x1dead50` the exact mscorlib String.IsNullOrEmpty method
(`0x6000a90`, VA `0x1eefbb0`) receives **l2d_name**. If that result is true,
motion_list is null, or its array length is zero, the function returns through
`0x1dead9c..0x1deada8`. It performs no SetMotion call on those paths.

Otherwise `0x1dead98` tail-branches to the exactly mapped static **SetMotion**,
token `0x6001880`, VA `0x1deadac`, whose two declared parameters are
model_path:string and motion_list:string[]. The model path and the **same
original array pointer** are passed unchanged. PlayAnim does not concatenate
l2d_name into a path, select array elements, filter empty tokens, reorder the
array, or assign body/face/extra slots. Thus an already-supplied nonempty array
containing an empty element and a face/extra token is not rewritten by this
boundary. This does not prove how PlayMotion constructed or chose that array.

Layer/trigger selection remains in the previously bound downstream code:
SetMotion's saved caller windows test each current token for emptiness, call
GetLayerName and GetTriggerName, then dispatch a nonempty trigger. The prior
GetLayerName content classification and the separate type9/name predicate
receipt remain applicable within their stated controller/instance conditions.
This packet does not read SetMotion again or extend those claims to active
weights, transition timing, blending or visible Animator state.

## Empty inputs are distinct boundaries

- **Whole PlayMotion motion string empty:** prior evidence branches out before
  this helper and writes the exact empty literal to observed static-fields
  base+0x8. This packet does not prove that field's native identity or exclusive
  state effects. Metadata declares `m_previous_motion_hash:string`, but field
  declaration order is not field-offset proof. It is not labelled a queue, nor
  claimed to clear body/face/extra/Animator state.
- **PlayAnim array null/empty or l2d_name empty:** this newly read body returns
  without tail-calling SetMotion.
- **A nonempty array containing an empty token:** PlayAnim forwards that same
  array; the previously retained SetMotion token-empty gate handles the token.

Consequently **“whole empty motion only clears a queue” is not established**.
The one newly closed fact is the exact PlayAnim→SetMotion argument boundary.
Newline selection, actor-index association and PlayMotion→PlayAnim argument
setup remain outside this new body. No phase or temporal sequence is inferred.

This source-only result is bound to the prior motion receipt
`b8c71d3715552c026a88c93729860ed9d8933ea972a13a172e30d3ac487c94a5`
and predicate receipt
`4171e0db1d1207f954fe03024553e89f0bb3d5176e2823c1200ab39d962ac78c`.
All original/prior inputs have fresh before/after hashes. The collector records
repeated header/table lookup I/O separately from the single new164-byte code
span; no other instruction span was extracted. The work used nice19/CPU0,1
and the installed static objdump. No game ELF execution, browser, network,
image/media, D/C/Git access or mutation, live Animator inspection, CSV recovery,
or dependency installation occurred.
