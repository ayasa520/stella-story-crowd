"""Read the one already located original PlayAnim boundary as inert ELF data.

Fresh metadata ownership, static flags, module header/table and actual PT_LOAD
mapping prove the token-to-file selection. Only this exact instruction body is
extracted. Direct calls are named by their own verified module pointer table;
field declarations are not promoted into native field-offset evidence.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import sys

ROOT = Path('/home/rikka/Projects/stella')
OUT = Path(__file__).resolve().parent
A = OUT.parent
MOTION = A / 'original-mimi-motion-token-semantics-20261127-v1'
PREDICATE = A / 'original-mimi-trigger-predicate-20261127-v1'
LOGS = Path('/home/rikka/.local/state/stella-migration-20261112/pre-tar-update/files/logs')
sys.path.insert(0, str(ROOT))
from lost_in_memories.tools.metadata import Metadata
assert os.getpriority(os.PRIO_PROCESS, 0) >= 19
assert os.sched_getaffinity(0) == {0, 1}

def witness(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}

previous = json.loads((MOTION / 'motion-bodies-and-bindings.original.json').read_bytes())
paths = [Path(r['path']) for r in previous['allInputsBefore'][:5]] + [
    MOTION / 'receipt.rootfalse.json', MOTION / 'report.rootfalse.json',
    MOTION / 'motion-bodies-and-bindings.original.json',
    MOTION / 'play-empty-guard.disassembly.selected.txt',
    MOTION / 'play-empty-key-store.disassembly.selected.txt',
    PREDICATE / 'receipt.rootfalse.json', PREDICATE / 'report.rootfalse.json']
before = [witness(path) for path in paths]
assert before[:5] == previous['allInputsBefore'][:5]
assert before[5]['sha256'] == 'b8c71d3715552c026a88c93729860ed9d8933ea972a13a172e30d3ac487c94a5'
assert before[10]['sha256'] == '4171e0db1d1207f954fe03024553e89f0bb3d5176e2823c1200ab39d962ac78c'
receipt = json.loads((MOTION / 'receipt.rootfalse.json').read_bytes())
retained = {r['path']: r for r in receipt['files']}
assert all(row == retained[row['path']] for row in before[6:10])
metadata = Metadata((LOGS / 'metadata-decrypted.dat').read_bytes(),
    json.loads((ROOT / 'lost_in_memories/config/metadata_layout.json').read_bytes()),
    json.loads((LOGS / 'metadata-types.json').read_bytes()))
ELF = ROOT / 'data/libil2cpp-offline.so'
fd = os.open(ELF, os.O_RDONLY)
reads = 0
def pread(offset, count):
    global reads
    assert 0 <= count <= 300000 and 0 <= offset and offset + count <= 49492360
    value = os.pread(fd, count, offset)
    assert len(value) == count
    reads += count
    return value
try:
    header = pread(0, 64)
    assert header[:7] == b'\x7fELF\x02\x01\x01' and struct.unpack_from('<HH', header, 16) == (3, 183)
    phoff = struct.unpack_from('<Q', header, 32)[0]
    phsize, phcount = struct.unpack_from('<HH', header, 54)
    assert phsize == 56 and 0 < phcount <= 32
    headers = pread(phoff, phsize * phcount)
    segments = [struct.unpack_from('<IIQQQQQQ', headers, i * phsize) for i in range(phcount)]
    def offset(va, count):
        choices = [s for s in segments if s[0] == 1 and s[3] <= va and va + count <= s[3] + s[5]]
        assert len(choices) == 1
        return choices[0][2] + va - choices[0][3]
    def read_va(va, count):
        return pread(offset(va, count), count)
    modules, tables = [], {}
    for old in previous['verifiedModulesAndQualifiedWitnesses']:
        if old['name'] not in ('Assembly-CSharp.dll', 'mscorlib.dll'):
            continue
        image = list(struct.unpack_from('<10i', metadata.data, old['imageRecordOffset']))
        assert image == old['imageRecord'] and metadata.string(image[0]) == old['name']
        name_va, count, table = struct.unpack('<QQQ', read_va(int(old['codeGenModuleVA'], 16), 24))
        assert read_va(name_va, 64).split(b'\0', 1)[0].decode() == old['name']
        assert count == old['count'] and table == int(old['methodTableVA'], 16)
        assert offset(table, count * 8) == int(old['methodTableFileOffset'], 16)
        tables[old['name']] = struct.unpack('<' + 'Q' * count, read_va(table, count * 8))
        modules.append(old)
    owner = metadata.declaration(7144, True)
    assert owner['name'] == 'Stella.Live2DMotion.Motion'
    method_start = metadata.integer(metadata.definition_offset(owner['index']) + 40)
    def details(index, ordinal, method):
        start = metadata.integer(metadata.definition_offset(index) + 40)
        at = metadata.layout['methods_offset'] + (start + ordinal) * 32
        pstart, ptable = metadata.integer(at + 12), struct.unpack_from('<I', metadata.data, 228)[0]
        params = []
        for n in range(method['parameter_count']):
            name, token, typ = struct.unpack_from('<III', metadata.data, ptable + (pstart + n) * 12)
            assert token >> 24 == 8
            params.append({'name': metadata.string(name), 'type': metadata.type_name(typ), 'token': hex(token)})
        flags = metadata.short(at + 24)
        return {**method, 'parameters': params, 'flags': hex(flags), 'static': bool(flags & 0x10)}
    ordinal, method = next((i, m) for i, m in enumerate(owner['methods']) if m['token'] == '0x600187c')
    target = details(owner['index'], ordinal, method)
    assert target['static'] and target['name'] == 'PlayAnim'
    pointers = tables['Assembly-CSharp.dll']
    rid = int(method['token'], 16) & 0xffffff
    slot = int(modules[0]['methodTableVA'], 16) + (rid - 1) * 8
    start = pointers[rid - 1]
    stop = min(p for p in pointers if p > start)
    assert (start, stop, stop - start) == (0x1dead08, 0x1deadac, 164)
    body = read_va(start, stop - start)
    with (OUT / 'playanim.body.original.bin').open('xb') as stream:
        stream.write(body)
    argv = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=2s', '15s',
        '/usr/bin/prlimit', '--as=536870912', '--fsize=1048576', '--',
        '/usr/bin/llvm-objdump', '--no-show-raw-insn', '--disassemble',
        '--start-address=' + hex(start), '--stop-address=' + hex(stop), str(ELF)]
    process = subprocess.run(argv, capture_output=True, timeout=18)
    assert process.returncode == 0 and not process.stderr
    for name, data in [('playanim.disassembly.original.stdout.txt', process.stdout),
                       ('playanim.disassembly.original.stderr.log', process.stderr)]:
        with (OUT / name).open('xb') as stream:
            stream.write(data)
    observed = {int(value, 16) for value in re.findall(rb'\b(?:bl|b)\s+(0x[0-9a-f]+)', process.stdout)}
    matches = []
    for module in modules:
        wanted = {0x06000000 | (i + 1): va for i, va in enumerate(tables[module['name']]) if va in observed}
        image = module['imageRecord']
        for index in range(image[2], image[2] + image[3]):
            at = metadata.definition_offset(index)
            first = metadata.integer(at + 40)
            for n in range(metadata.short(at + 68)):
                tok = metadata.integer(metadata.layout['methods_offset'] + (first + n) * 32 + 20)
                if tok in wanted:
                    declaration = metadata.declaration(index, True)
                    matches.append({'module': module['name'], 'owner': declaration['name'], 'ownerTypeIndex': index,
                        **details(index, n, declaration['methods'][n]), 'VA': hex(wanted[tok])})
    result = {'schema': 'stella.original-playanim-forwarding-body.v1', 'rootConfirmed': False,
        'originalELFExecuted': False, 'browserNetworkAPIMediaUsed': False, 'DCOrGitWritesPerformed': False,
        'target': {'owner': owner['name'], 'ownerTypeIndex': owner['index'], **target,
            'slotVA': hex(slot), 'slotFileOffset': hex(offset(slot, 8)), 'bodyVA': hex(start),
            'bodyFileOffset': hex(offset(start, len(body))), 'stopVA': hex(stop), 'bodyBytes': len(body),
            'bodySHA256': hashlib.sha256(body).hexdigest()},
        'exactDirectCallMatches': matches, 'motionFieldsDeclarationOnly': owner['fields'],
        'disassembly': {'argv': argv, 'exitCode': process.returncode, 'stdoutBytes': len(process.stdout),
            'stdoutSHA256': hashlib.sha256(process.stdout).hexdigest(), 'stderrBytes': len(process.stderr)},
        'newOriginalInstructionBytesExtracted': len(body), 'otherNewInstructionBodiesRead': 0,
        'ELFBytesReadExcludingHashPasses': reads, 'nice': 19, 'cpuAffinity': [0, 1]}
finally:
    os.close(fd)
after = [witness(path) for path in paths]
assert before == after
result.update({'allInputsBefore': before, 'allInputsAfter': after, 'allInputsUnchanged': True})
with (OUT / 'body-and-direct-bindings.original.json').open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'target': result['target'], 'exactDirectCallMatches': matches,
                  'motionFieldsDeclarationOnly': owner['fields'], 'allInputsUnchanged': True}, indent=2))
