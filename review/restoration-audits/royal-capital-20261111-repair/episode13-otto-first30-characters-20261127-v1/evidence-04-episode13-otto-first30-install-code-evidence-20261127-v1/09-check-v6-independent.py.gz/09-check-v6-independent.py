"""Repeat the independent V5 counterexamples against the separately sealed V6.

This derives an in-memory harness from the preserved peer harness; it never
edits V5, V6, the old observations, or any source candidate. Only policy and
the exact walker AST execute. Full helper CLIs and business gates never run.
"""
import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import tempfile

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
OUT = Path(__file__).parent
RUN = OUT / 'v6-checks'
RUN.mkdir()
old_harness = OUT / 'check-policy-independent.py'
before = old_harness.read_text()
after = before


def replace_once(old, new):
    global after
    assert after.count(old) == 1, old
    after = after.replace(old, new)


replace_once("V5 = A / 'review-explicit-visual-field-batch-v5.py'", "V5 = A / 'review-explicit-visual-field-batch-v6.py'")
replace_once("assert digest(raw5) == 'e4f5fffa0396606987bf78bc3d0d0ea6eddebc1a1e3e010e6c832489836581b2'",
             "assert digest(raw5) == '66fb2f166a1b3f1e5d76a37159cb940bcf2188c96313084818e53af13adb2394'")
replace_once("'direct_evidence_references', 'GuardOnlyReferenceRoles']",
             "'direct_evidence_references', 'actual_evidence_reference_closure', 'GuardOnlyReferenceRoles']")
replace_once('args=SimpleNamespace(read_log=str(CAPTURE)))',
             'args=SimpleNamespace(read_log=str(CAPTURE)), CONTRACT_EXAMPLE=CONTRACT)')
replace_once('guards=dict(roles.manifest_guard),',
             'guards={**roles.manifest_guard, **roles.evidence_guards},')
replace_once("    bypass = policy(fixture_decision, candidate=fixture_candidate, source_packet=fixture_packet)\n    bypass_result = expect('Role policy must preserve corrupted descendant detection', True,\n                          lambda: run_actual_walk(bypass))",
             "    def attempt_bad_descendant():\n        roles = policy(fixture_decision, candidate=fixture_candidate, source_packet=fixture_packet)\n        return run_actual_walk(roles)\n    bypass_result = expect('Role policy must preserve corrupted descendant detection', True,\n                          attempt_bad_descendant)")
replace_once("helpersOrBusinessOrGitBrowserApiExecuted=False,",
             "fullHelperCliPrepareReviewBusinessGitBrowserApiExecuted=False, isolatedPolicyAndExactWalkerAstExecuted=True,")
after = after.replace('exactV5SHA256', 'exactV6SHA256').replace('checks.v5.rootfalse.json', 'checks.v6.rootfalse.json')
(RUN / 'harness-transformation.diff').write_text(''.join(difflib.unified_diff(
    before.splitlines(True), after.splitlines(True), fromfile='independent-v5-harness', tofile='independent-v6-harness')))
ns = dict(__file__=str(RUN / 'in-memory-independent-harness.py'), __name__='independent_v6_policy_check')
exec(compile(after, str(RUN / 'in-memory-independent-harness.py'), 'exec'), ns)
result_path = RUN / 'checks.v6.rootfalse.json'
result = json.loads(result_path.read_bytes())
assert result['safetyFailures'] == 0 and not result['findings']
assert result['checksPassed'] == 14

# Verify that the added closure read path preserves the actual held input and
# exception document on parse failure; a later successful read is not a retry.
policy_namespace = ns['namespace']
capture = ns['CAPTURE']
additional = []
with tempfile.TemporaryDirectory(prefix='v6-closure-capture-peer-', dir=A) as temporary:
    temporary = Path(temporary)
    for mode in ['malformed-json', 'wrong-sealed-digest']:
        candidate = temporary / mode / 'candidate' / 'packet.json'
        candidate.parent.mkdir(parents=True)
        evidence = temporary / mode / 'evidence' / 'source.json'
        evidence.parent.mkdir()
        raw = b'{"unclosed":' if mode == 'malformed-json' else b'{"valid": true}'
        evidence.write_bytes(raw)
        declared = hashlib.sha256(raw).hexdigest() if mode == 'malformed-json' else '0' * 64
        packet = dict(changes=[dict(evidence=dict(source=dict(path=str(evidence), sha256=declared)))])
        candidate.write_text(json.dumps(packet))
        schema = temporary / mode / 'schema' / 'example.json'
        schema.parent.mkdir()
        schema.write_text('{}')
        manifest = temporary / mode / 'role.json'
        decision = dict(schema='stella.root-reference-roles.v1', rootConfirmed=True, rootReviewed=True,
            candidate=dict(path=str(candidate), sha256=hashlib.sha256(candidate.read_bytes()).hexdigest()),
            guardOnlyReferences=[dict(path=str(schema), sha256=hashlib.sha256(schema.read_bytes()).hexdigest(),
                role='guard-only-shape-contract', reason='Synthetic schema fixture', rootConfirmed=True)])
        manifest.write_text(json.dumps(decision))
        expected_error = json.JSONDecodeError if mode == 'malformed-json' else ValueError
        try:
            policy_namespace['GuardOnlyReferenceRoles'](str(manifest),
                hashlib.sha256(manifest.read_bytes()).hexdigest(), candidate,
                hashlib.sha256(candidate.read_bytes()).hexdigest(), packet)
        except expected_error as error:
            number = policy_namespace['READ_NUMBER']
            stem = capture / f'{number:03d}'
            fact = json.loads(stem.with_suffix('.json').read_bytes())
            held = gzip.decompress(stem.with_suffix('.raw.gz').read_bytes())
            assert held == raw and fact['sha256'] == hashlib.sha256(raw).hexdigest()
            if mode == 'malformed-json':
                assert gzip.decompress(stem.with_suffix('.exception-doc.gz').read_bytes()) == error.doc.encode('utf-8', 'surrogatepass')
            else:
                assert fact['errorType'] == 'ReferenceRoleDigestMismatch' and fact['parsed'] is False
            additional.append(dict(name=mode, expectedFailurePreserved=True, heldBytesExact=True,
                                   actualInputSHA256=fact['sha256'], originalErrorType=type(error).__name__))
        else:
            raise AssertionError('Invalid closure input unexpectedly accepted: ' + mode)

assert hashlib.sha256((A / 'review-explicit-visual-field-batch-v5.py').read_bytes()).hexdigest() == 'e4f5fffa0396606987bf78bc3d0d0ea6eddebc1a1e3e010e6c832489836581b2'
assert hashlib.sha256((A / 'review-explicit-visual-field-batch-v6.py').read_bytes()).hexdigest() == '66fb2f166a1b3f1e5d76a37159cb940bcf2188c96313084818e53af13adb2394'
final = dict(schema='stella.reference-roles.independent-v6-additional-checks.v1',
    sourceSHA256='66fb2f166a1b3f1e5d76a37159cb940bcf2188c96313084818e53af13adb2394',
    baseIndependentChecks=14, additionalChecks=additional, mustFix=[],
    originalV5FaultEvidencePreserved=True, syntheticApprovalsDeleted=True,
    fullHelperCliPrepareReviewBusinessGitBrowserApiOrImageExecuted=False,
    isolatedPolicyAndExactWalkerAstExecuted=True,
    originalIndependentHarnessSHA256=hashlib.sha256(before.encode()).hexdigest(),
    transformedIndependentHarnessSHA256=hashlib.sha256(after.encode()).hexdigest())
(RUN / 'additional-checks.v6.rootfalse.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(dict(independentChecksPassed=16, mustFix=[], output=str(RUN))))
