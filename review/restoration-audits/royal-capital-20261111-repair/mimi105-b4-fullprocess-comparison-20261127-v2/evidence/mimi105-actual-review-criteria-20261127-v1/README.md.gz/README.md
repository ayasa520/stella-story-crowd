# Mimi 105 actual-video review criteria — source only

No actual video has been provided to this review. Root must confirm OS closure before local image review. The original126-frame source verdict is unchanged.

| Source frame / PTS(s) | Required complete-process comparison |
| --- | --- |
|0000 /803.321|104 Felt held margin and real exit into105.|
|0009–0010 /803.621–803.654|Mimi fades in with open eyes and lower arms.|
|0014 /803.787|Both hands raised while eyes remain open.|
|0027 /804.221|Arms remain raised as eyes narrow.|
|0030 /804.321|Broad closed-eye smile with hands still raised.|
|0090 /806.321|Sustained raised-arm/closed-smile hold; inspect the whole loop and mouth changes.|
|0108 /806.921;0112 /807.054|Mimi fades, then is absent. These are witnesses, not newly fixed exact boundaries.|
|0115–0125 /807.154–807.487|106 Felt enters and becomes clear; no Mimi layer leaks.|

Review all four B1F0/B1F1/B2F0/B2F1 cases against the full process. B1F0 is an open-eye control; do not select another case merely because its token sounds correct. Compare bilateral arm/hand geometry, eye order, maintained state, ordinary exit and successor together. A matching still or loop endpoint cannot pass a case.

Hold adequacy uses an actual original resting-state/no-blend checkpoint followed by at least4 Normal actor seconds. Do not substitute wall delay, add Wait, alter speed or force a renderer pose. Preserve frame-hitch evidence; missing critical frames make the affected criterion inconclusive.

`criteria.rootfalse.json` contains exact source report/receipt/input hashes, inherited landmark hashes, four-case matrix and review prerequisites. No body, face, mouth driver, timing, audio, saved playback or whole-scene acceptance is issued here.
