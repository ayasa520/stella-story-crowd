This independent review reads closed B4 artifacts with Node only, at nice19,
CPU0,1 and a 256 MiB Node heap limit. The final technical result is in
technical-review.rootfalse.json: 42 recorded-contract checks passed. This is
not body, face, native-phase, pixel, pacing, or whole-scene acceptance.

byte-diff.rootfalse.json records the one completed first-buffer observation.
The saved original raw and current B1F0 result are byte-identical and parse in
Node. The original Python exception.doc differs at six bytes, UTF-8 offsets
[944274,944280), replaced by NUL; the first codepoint offset943932 matches the
original exception position. The original Python failure is preserved, never
retried or reclassified. The operation, moment and mechanism remain unknown.

review.rootfalse.json is retained unchanged. Its byte-audit phase completed;
its subsequent technical phase stopped because this reviewer mistakenly used
runtime-context dataRoot/sourceRoot fields as frozen-binding fields and used
the older root-closure schema. Those are reviewer assumptions, not product
failures. The technical continuation used the actual inventory roots/current
closure schema, reading closed results independently. It did not reread or
rerun the original failure gzip/doc observation or the Python reader.

All four original received-program hashes, 104->105->106 ready boundaries,
trusted ready advances, actual settled Actor holds of at least four seconds,
controller states, archived decoded-clip hashes and guarded motion-source
bindings were checked. The canonical pure motion decoder was not executed by
this reviewer. Video was not decoded and no images were viewed.

Firefox stderr retains unsupported GL_EXT_shader_texture_lod shader messages
and WebGL context-lost warnings. Owner/BiDi fatal collectors are empty and the
attached-actor probe reports no loss, but the stderr messages do not identify
their canvas or event time. Their cause and visual consequence are unresolved.
Normal hitches and observer/copy overhead are also retained, not erased.

The root's exact independent closure records full input verification and owned
OS/port/display/profile retirement, with explicit unreadable-foreign-process
environment limits. No new OS, memory, browser, API or player sampling occurred.
All original artifacts, D/C and Git remain unchanged. Full original-source and
actual-media review is still required before accepting any body/face choice.
