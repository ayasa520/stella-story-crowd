"""Retire explicit used files while preserving live repositories and evidence.

This helper never discovers deletion candidates. The caller must supply a
reviewed file manifest, with an immutable lstat identity for every object.
Migration backups live outside the project, so their two exact historical
roots are allowed explicitly; user state and live Codex sessions are excluded.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
OUT = Path(__file__).resolve().parent
MIGRATION = Path('/home/rikka/.local/state/stella-migration-20261112')
ALLOWED = (ROOT, MIGRATION / 'source-x86', MIGRATION / 'pre-tar-update/files')
PROTECTED = (A / 'data-checkout', ROOT / 'story_crowd_data',
             ROOT / 'artifacts/stella-site-repair-source/.sites-checkout',
             ROOT / '.venv-video-ocr', ROOT / 'data/extracted_archives')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size,
            s.st_mtime_ns, s.st_nlink, s.st_blocks * 512]


def save(path, value):
    raw = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(gzip.compress(raw, mtime=0) if path.suffix == '.gz' else raw)


def available():
    s = os.statvfs(ROOT)
    return s.f_bavail * s.f_frsize


def snapshot():
    result = {}
    for name, base in [('root', ROOT), ('data', A / 'data-checkout'),
                       ('canonical', PROTECTED[2]), ('legacy', ROOT / 'story_crowd')]:
        def git(*args):
            return subprocess.check_output(['git', '-C', str(base), *args])
        result[name] = {'head': git('rev-parse', 'HEAD').decode().strip(),
                        'trackedStatus': git('status', '--porcelain', '-uno').decode(),
                        'diffSHA256': hashlib.sha256(git('diff', '--binary', 'HEAD')).hexdigest()}
    return result


def main():
    plan_path = Path(sys.argv[1])
    batch = sys.argv[2]
    assert batch.isalnum()
    plan = json.loads(plan_path.read_bytes())
    assert plan['rootReviewed'] is True and plan['entries']
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19
    assert sorted(os.sched_getaffinity(0)) == [0, 1]
    baseline = snapshot()
    assert baseline['data']['trackedStatus'] == ''
    tracked = {str(ROOT / p) for p in subprocess.check_output(
        ['git', '-C', str(ROOT), 'ls-files', '-z']).decode().split('\0') if p}
    paths = {row['path'] for row in plan['entries']}
    assert len(paths) == len(plan['entries'])
    retained = {row['path']: digest(Path(row['path'])) for row in plan.get('retained', [])}
    assert all(retained[row['path']] == row['sha256']
               for row in plan.get('retained', []))
    assert not (paths & retained.keys())
    # Validate every entry before any unlink. Directory symlinks and hardlinks
    # are rejected so the manifest cannot escape scope or exaggerate disk gains.
    for row in plan['entries']:
        path = Path(row['path'])
        assert path.is_absolute() and path.parent.resolve() == path.parent
        assert any(path.is_relative_to(base) for base in ALLOWED)
        assert not any(path.is_relative_to(base) for base in PROTECTED)
        assert '.git' not in path.parts and str(path) not in tracked
        value = identity(path)
        assert value == row['identity'] and value[5] == 1, str(path)
        assert stat.S_ISREG(value[2]) or stat.S_ISLNK(value[2])
        if row.get('sha256'):
            assert digest(path) == row['sha256'], str(path)
        if row.get('keep'):
            keep = Path(row['keep'])
            assert str(keep) not in paths and keep.is_file()
            assert keep.stat().st_size == value[3]
            assert digest(keep) == row['sha256'], str(keep)
    # Check readable process descriptors and memory maps. These observations do
    # not claim visibility into inaccessible processes; they protect this user's
    # active work without terminating unrelated applications.
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fds = list((proc / 'fd').iterdir())
        except OSError:
            continue
        for fd in fds:
            try:
                target = os.readlink(fd)
            except OSError:
                continue
            assert target not in paths, (proc.name, target)
        try:
            maps = (proc / 'maps').read_text()
        except OSError:
            continue
        for line in maps.splitlines():
            fields = line.split(None, 5)
            if len(fields) == 6:
                assert fields[5] not in paths, (proc.name, fields[5])
    free_before = available()
    save(OUT / f'{batch}-retirement-manifest.json.gz',
         {'plan': plan, 'planSHA256': digest(plan_path), 'before': baseline,
          'retainedSHA256': retained, 'readableOpenFilesChecked': True})
    deleted = []
    try:
        for row in plan['entries']:
            path = Path(row['path'])
            assert identity(path) == row['identity'], str(path)
            path.unlink()
            deleted.append(str(path))
    except BaseException:
        save(OUT / f'{batch}-partial.json', {'deleted': deleted})
        raise
    assert all(not os.path.lexists(p) for p in paths)
    for name in sorted(plan.get('pruneEmptyDirectories', []),
                       key=lambda p: len(Path(p).parts), reverse=True):
        path = Path(name)
        assert any(path.is_relative_to(base) for base in ALLOWED)
        assert not any(path.is_relative_to(base) for base in PROTECTED)
        try:
            path.rmdir()
        except OSError:
            pass
    assert snapshot() == baseline
    assert all(digest(Path(p)) == sha for p, sha in retained.items())
    groups = {}
    for row in plan['entries']:
        group = groups.setdefault(row['category'], {'files': 0, 'allocatedBytes': 0})
        group['files'] += 1
        group['allocatedBytes'] += row['identity'][6]
    report = {'status': 'deleted_and_verified', 'deletedFiles': len(deleted),
              'releasedFileAllocationBytes': sum(row['identity'][6] for row in plan['entries']),
              'availableBefore': free_before, 'availableAfter': available(), 'groups': groups,
              'trackedRepositoriesAndDirtyWorkUnchanged': True,
              'retainedHashesVerified': len(retained), 'payloadBackupCreated': False}
    save(OUT / f'{batch}-receipt.json', report)
    print(json.dumps(report))


if __name__ == '__main__':
    main()
