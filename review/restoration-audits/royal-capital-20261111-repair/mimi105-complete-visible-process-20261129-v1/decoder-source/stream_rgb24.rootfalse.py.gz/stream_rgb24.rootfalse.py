"""ROOTFALSE proposal: one explicitly released decoder, bounded native PNGs.

The module is never imported by the metadata audit. Running it requires a NEW
root release bound to this exact source/plan and a new output directory. Raw RGB
crosses stdout once and is never persisted. Native PNGs/contact sheets stay in
pending directories until complete count/EOF/checksum/timestamp gates succeed.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import importlib.util
import json
import os
import re
import signal
import stat
import struct
import subprocess
import sys
import threading
import time
import traceback
import zlib

A = Path('/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121')
WIDTH, HEIGHT, FRAME_BYTES = 500, 1000, 1500000
MAX_FRAMES, MAX_OUTPUT = 600, 256 * 1024 * 1024
MEDIA_LIMIT, MAX_STDERR = MAX_OUTPUT - 4 * 1024 * 1024, 2 * 1024 * 1024
CELL_W, CELL_H, COLS, ROWS = 100, 216, 4, 3
SHEET_W, SHEET_H = CELL_W * COLS, CELL_H * ROWS
FONT = ['111101101101111', '010110010010111', '111001111100111',
        '111001111001111', '101101111001001', '111100111001111',
        '111100111101111', '111001001001001', '111101111101111',
        '111101111001111']


def sha_file(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def observer_event(value):
    """Persist to the caller-owned observer, with a separate-file fallback.

    The original caller must exclusively open both complete capture files
    before exec. Tool display is not a durable sink. Sink errors are returned
    as facts, never raised over the primary exception this event describes.
    """
    errors = []
    for name, stream in [('stderr', sys.stderr), ('stdout-fallback', sys.stdout)]:
        try:
            # A successful fallback also preserves the prior sink failure;
            # returning that error only to an unwinding caller would lose it.
            event = dict(value, observerSink=name, priorObserverSinkErrors=list(errors))
            stream.write(json.dumps(event) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
            return dict(durable=True, sink=name, sinkErrors=errors)
        except BaseException:
            errors.append(dict(sink=name, traceback=traceback.format_exc()))
    return dict(durable=False, sinkErrors=errors)


def held_json(path, expected):
    # The expected SHA and parser see the same held bytes. A first failure is
    # emitted losslessly to the invoking CLI's stderr, never repaired/retried.
    raw = Path(path).read_bytes()
    fact = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    assert len(raw) <= 1024 * 1024 and re.fullmatch('[a-f0-9]{64}', expected)
    assert fact['sha256'] == expected, fact
    try:
        return json.loads(raw), fact
    except json.JSONDecodeError as error:
        observer_event(dict(held=fact, rawBase64=base64.b64encode(raw).decode(),
            exceptionDoc=error.doc, pos=error.pos, line=error.lineno, column=error.colno,
            traceback=traceback.format_exc()))
        raise


class Output:
    """Reserve every chunk before write; leave 4MiB for complete diagnostics.

    Only native PNG/contact data use the smaller media allowance. This accounts
    conservatively for block rounding plus directories as well as logical bytes.
    It is specific to this material folder, not a project-wide output registry.
    """
    def __init__(self, root):
        self.root, self.sizes, self.lock = root, {}, threading.Lock()
        self.block = os.statvfs(root).f_frsize

    def append(self, stream, raw, media=False):
        with self.lock:
            key = str(Path(stream.name).relative_to(self.root))
            sizes = {**self.sizes, key: self.sizes.get(key, 0) + len(raw)}
            allocated = sum(((n + self.block - 1) // self.block) * self.block for n in sizes.values()) + 65536
            limit = MEDIA_LIMIT if media else MAX_OUTPUT
            assert sum(sizes.values()) <= limit and allocated <= limit, ('Output cap before write', key, allocated, limit)
            stream.write(raw)
            self.sizes = sizes

    def json(self, name, value, durable=False):
        raw = (json.dumps(value, indent=2) + '\n').encode()
        assert len(raw) <= 1024 * 1024
        with (self.root / name).open('xb') as stream:
            self.append(stream, raw)
            if durable:
                stream.flush()
                os.fsync(stream.fileno())


def native_png(path, pixels, width, height, output):
    # Encode lossless RGB8 PNG row-by-row. No full PNG or second native RGB
    # frame is buffered. IDAT fragments are at most 64KiB and checked pre-write.
    with path.open('xb') as stream:
        digest = hashlib.sha256()
        written = 0
        file_limit = width * height * 3 + height + 65536
        def emit(raw):
            nonlocal written
            assert written + len(raw) <= file_limit, 'PNG byte cap before write'
            output.append(stream, raw, media=True)
            digest.update(raw)
            written += len(raw)
        def chunk(kind, data):
            assert len(data) <= 65536
            emit(struct.pack('>I', len(data)) + kind)
            emit(data)
            emit(struct.pack('>I', zlib.crc32(data, zlib.crc32(kind)) & 0xffffffff))
        emit(b'\x89PNG\r\n\x1a\n')
        chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
        compressor = zlib.compressobj(3)
        view = memoryview(pixels)
        for row in range(height):
            encoded = compressor.compress(b'\x00' + view[row * width * 3:(row + 1) * width * 3].tobytes())
            for start in range(0, len(encoded), 65536):
                chunk(b'IDAT', encoded[start:start + 65536])
        encoded = compressor.flush()
        for start in range(0, len(encoded), 65536):
            chunk(b'IDAT', encoded[start:start + 65536])
        chunk(b'IEND', b'')
        stream.flush()
        os.fsync(stream.fileno())
    assert path.stat().st_size <= width * height * 3 + height + 65536
    return dict(bytes=path.stat().st_size, sha256=digest.hexdigest())


def contact_cell(canvas, frame, cell, ordinal, milliseconds):
    # Contacts alone use a fixed nearest-neighbor spatial sample, never temporal
    # interpolation. The full 500x1000 native PNG remains the review authority.
    ox, oy = (cell % COLS) * CELL_W, (cell // COLS) * CELL_H
    view = memoryview(frame)
    for y in range(200):
        for x in range(100):
            source = ((y * 5) * WIDTH + x * 5) * 3
            target = ((oy + y) * SHEET_W + ox + x) * 3
            canvas[target:target + 3] = view[source:source + 3]
    # Label format is ordinal:MKVmilliseconds, explicitly documented in index.
    label = f'{ordinal:04d}:{milliseconds:05d}'
    for index, char in enumerate(label):
        glyph = '000010000010000' if char == ':' else FONT[int(char)]
        for point, bit in enumerate(glyph):
            if bit == '1':
                x, y = ox + 2 + index * 5 + point % 3, oy + 204 + point // 3
                where = (y * SHEET_W + x) * 3
                canvas[where:where + 3] = b'\xff\xff\xff'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--release', required=True)
    parser.add_argument('--release-sha256', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    # First-read errors can precede the material directory. Both observer
    # descriptors must already be independent regular files at this point.
    # O_EXCL/no-clobber is a caller obligation, explicitly bound below and in
    # the plan; it cannot be recovered from descriptor flags after opening.
    observer_fds = {name: os.fstat(fd) for name, fd in [('stdout', 1), ('stderr', 2)]}
    assert all(stat.S_ISREG(value.st_mode) for value in observer_fds.values())
    assert (observer_fds['stdout'].st_dev, observer_fds['stdout'].st_ino) != (observer_fds['stderr'].st_dev, observer_fds['stderr'].st_ino)
    release, release_ref = held_json(args.release, args.release_sha256)
    assert release['rootConfirmed'] is True and release['pixelDecoderAuthorized'] is True
    assert release['nativePNGAndContactsAuthorized'] is True
    assert release['singleOriginalDecoder'] is True
    assert release['planSHA256'] == args.plan_sha256
    observer = release['durableObserverCapture']
    for field in ['noClobberExclusiveOpen', 'openedBeforeProcessStart',
                  'completeUntruncatedStdoutAndStderr', 'originalExitAndHashesAfterTerminal']:
        assert observer[field] is True, field
    for name in ['stdout', 'stderr']:
        linked = os.stat(observer[name + 'Path'], follow_symlinks=False)
        assert stat.S_ISREG(linked.st_mode)
        assert (linked.st_dev, linked.st_ino) == (observer_fds[name].st_dev, observer_fds[name].st_ino)
    plan, plan_ref = held_json(args.plan, args.plan_sha256)
    assert plan['rootConfirmed'] is False and plan['pixelDecoderAuthorized'] is False
    assert plan['maximumOutputBytes'] == MAX_OUTPUT and plan['maximumFrames'] == MAX_FRAMES
    assert plan['durableObserverContract']['required'] is True
    assert sorted(os.sched_getaffinity(0)) == [0, 1] and os.getpriority(os.PRIO_PROCESS, 0) == 19
    assert sha_file(__file__) == plan['code']['decoder']['sha256']
    # The fragment parser is pure metadata code and is imported only after
    # its exact release-bound bytes have been verified, never by name alone.
    parser_ref = plan['code']['showinfoParser']
    assert Path(parser_ref['path']).stat().st_size == parser_ref['bytes']
    assert sha_file(parser_ref['path']) == parser_ref['sha256']
    parser_spec = importlib.util.spec_from_file_location('stella_rgb_showinfo_fragments', parser_ref['path'])
    metadata_parser = importlib.util.module_from_spec(parser_spec)
    parser_spec.loader.exec_module(metadata_parser)
    out = Path(args.out).resolve()
    assert str(out) == release['outputDirectory'] and out.parent == A
    assert out.name.startswith('mimi105-v5-lossless-material-') and not out.exists()
    for value in plan['inputs'].values():
        assert Path(value['path']).stat().st_size == value['bytes']
        assert sha_file(value['path']) == value['sha256'], value['path']
    tool = plan['ffmpeg']
    assert Path(tool['launchPath']).resolve() == Path(tool['binaryPath'])
    assert sha_file(tool['binaryPath']) == tool['sha256']
    meta, metadata_ref = held_json(plan['inputs']['metadataAnalysis']['path'], plan['inputs']['metadataAnalysis']['sha256'])
    assert meta['offsetFitted'] is False and meta['addedOffset'] == [0, 1]
    assert meta['mismatchOrdinals'] == [] and meta['sps']['reducedProgressiveFramePeriod'] == [1, 32]
    expected = meta['frames']
    assert len(expected) == plan['expectedFrames'] == 471 and len(expected) <= MAX_FRAMES
    assert [row['ordinal'] for row in expected] == list(range(len(expected)))
    out.mkdir()
    pending, contacts = out / 'pending-native', out / 'pending-contacts'
    pending.mkdir(); contacts.mkdir()
    output = Output(out)
    output.json('inputs-before.json', dict(plan=plan_ref, release=release_ref, metadata=metadata_ref))
    assert os.statvfs(out).f_bavail * os.statvfs(out).f_frsize > MAX_OUTPUT + 512 * 1024 * 1024
    argv = [tool['launchPath'], '-nostdin', '-hide_banner', '-loglevel', 'info',
            '-threads', '1', '-filter_threads', '1', '-filter_complex_threads', '1',
            '-copyts', '-noautorotate', '-i', plan['inputs']['sourceMKV']['path'], '-map', '0:v:0', '-an', '-sn', '-dn',
            '-vf', 'format=rgb24,showinfo', '-fps_mode', 'passthrough', '-c:v', 'rawvideo',
            '-pix_fmt', 'rgb24', '-threads', '1', '-f', 'rawvideo', 'pipe:1']
    output.json('decoder.command.json', dict(argv=argv, singleOriginalInvocation=True,
        stdoutRawRGBPersisted=False, expectedFrameBytes=FRAME_BYTES, twoNativeFrameBytes=2 * FRAME_BYTES))
    child, stderr_thread, timer = None, None, None
    stderr_errors, timed_out = [], []
    cleanup_errors, failure_sink_errors = [], []
    execution_phase_closed, published_paths = False, []
    raw_stderr_state = dict(bytes=0, eof=False, flushedAndFsynced=False)
    frame_rows, sheet_rows = [], []
    start = time.monotonic()

    def kill_owned(stage='owned-decoder-stop'):
        # Poll/kill errors are opaque cleanup facts, not replacement primary
        # exceptions or evidence that the process/group has disappeared.
        try:
            if child is not None and child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass  # A subsequent wait still has to establish leader termination.
        except BaseException:
            cleanup_errors.append(dict(stage=stage, traceback=traceback.format_exc()))

    def stop_watchdog():
        if timer is not None:
            timer.cancel()
            timer.join(timeout=10)
            assert not timer.is_alive(), 'Watchdog cancellation/join unproven'

    def wait_child():
        if child is not None:
            return child.wait(timeout=10)

    def join_stderr():
        if stderr_thread is not None:
            stderr_thread.join(timeout=10)
            assert not stderr_thread.is_alive(), 'Original stderr reader join timed out'

    def cleanup_attempt(stage, operation):
        try:
            return operation()
        except BaseException:
            cleanup_errors.append(dict(stage=stage, traceback=traceback.format_exc()))
            return None

    def watchdog():
        timed_out.append(True)
        kill_owned('watchdog-stop')

    def read_stderr():
        # This thread has exactly one responsibility: preserve complete raw
        # bytes under the existing cap, through real stderr EOF. FFmpeg log
        # calls may interleave across newlines, so no frame parsing occurs here.
        count = 0
        try:
            with (out / 'decoder.original.stderr.log').open('xb') as stream:
                while True:
                    raw = os.read(child.stderr.fileno(), 16384)
                    if not raw:
                        break
                    count += len(raw)
                    if count > MAX_STDERR:
                        # Preserve the complete observed crossing chunk before
                        # stopping the only decoder; no silent truncation/pass.
                        output.json('stderr-bound-crossing.json', dict(bytesBefore=count - len(raw),
                            rawBase64=base64.b64encode(raw).decode(), bound=MAX_STDERR))
                        raise AssertionError('Decoder stderr2MiB bound crossed')
                    output.append(stream, raw)
                    raw_stderr_state['bytes'] = count
                stream.flush()
                os.fsync(stream.fileno())
                raw_stderr_state.update(eof=True, flushedAndFsynced=True)
        except BaseException:
            stderr_errors.append(traceback.format_exc())
            kill_owned('stderr-reader-stop')

    try:
        child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 bufsize=0, start_new_session=True)
        output.json('decoder.started.json', dict(pid=child.pid, pgid=child.pid, monotonicSeconds=start))
        stderr_thread = threading.Thread(target=read_stderr, daemon=True)
        stderr_thread.start()
        timer = threading.Timer(plan['decoderWallSeconds'], watchdog)
        timer.start()
        # Backpressure is automatic: no next RGB frame is read until checks,
        # pending native PNG and contact-cell operations for this frame finish.
        frame = bytearray(FRAME_BYTES)
        canvas = bytearray(SHEET_W * SHEET_H * 3)
        assert len(frame) + len(canvas) < 2 * FRAME_BYTES
        for n, expected_row in enumerate(expected):
            cursor = 0
            while cursor < FRAME_BYTES:
                got = child.stdout.readinto(memoryview(frame)[cursor:])
                if not got:
                    output.json('stdout-short-frame.json', dict(ordinal=n, bytes=cursor,
                        partialSHA256=hashlib.sha256(memoryview(frame)[:cursor]).hexdigest()))
                    raise AssertionError('EOF before complete expected RGB frame')
                cursor += got
            assert not stderr_errors and not timed_out
            checksum = f'{zlib.adler32(frame, 0) & 0xffffffff:08X}'
            record = dict(ordinal=n, preEncoderPTS=expected_row['preEncoderPTS'],
                encoderTick=expected_row['encoderTick'], packetPTS=expected_row['packetPTS'],
                packetDTS=expected_row['packetDTS'], decodedShowinfoDeferredUntilFullStderrEOF=True,
                expectedPreEncoderAdler32=expected_row['preEncoderRGBAdler32'],
                decodedRawAdler32=checksum,
                decodedRawRGBSHA256=hashlib.sha256(frame).hexdigest())
            with (out / 'frames.observations.jsonl').open('ab') as stream:
                output.append(stream, (json.dumps(record) + '\n').encode())
            # Strong pixel gate BEFORE any pending PNG write. The independent
            # decoded showinfo/PTS gate follows complete log EOF below; it is
            # deferred, never removed or allowed to publish partially checked data.
            assert checksum == expected_row['preEncoderRGBAdler32'], record
            filename = f'{n:06d}.png'
            png = native_png(pending / filename, frame, WIDTH, HEIGHT, output)
            record['nativePNG'] = dict(path='frames/' + filename, **png)
            frame_rows.append(record)
            cell = n % (COLS * ROWS)
            contact_cell(canvas, frame, cell, n, expected_row['packetPTS'])
            if cell == COLS * ROWS - 1 or n == len(expected) - 1:
                first = n - cell
                name = f'{first:06d}-{n:06d}.png'
                sheet = native_png(contacts / name, canvas, SHEET_W, SHEET_H, output)
                sheet_rows.append(dict(path='contacts/' + name, ordinals=[first, n],
                    dimensions=[SHEET_W, SHEET_H], columns=COLS, rows=ROWS,
                    label='ordinal:packetPTS_milliseconds', **sheet))
                # Reset in small chunks: a second complete contact canvas plus
                # the current native frame would exceed the two-frame bound.
                for offset in range(0, len(canvas), 65536):
                    count = min(65536, len(canvas) - offset)
                    canvas[offset:offset + count] = bytes(count)
        assert child.stdout.read(1) == b'', 'Additional decoded pixels after471expectedframes'
        child.stdout.close()
        code = wait_child()
        join_stderr()
        assert code == 0 and len(frame_rows) == len(expected)
        assert raw_stderr_state['eof'] and raw_stderr_state['flushedAndFsynced'] and not stderr_errors
        # Child/consumer/log have now actually ended. Parse this SAME held raw
        # buffer by explicit n-start spans, preserving every original byte and
        # warning. Required fields are unique; missing/duplicate/ambiguous data
        # is fatal. No line repair, reordering, or manufactured concatenation.
        stderr_path = out / 'decoder.original.stderr.log'
        stderr_raw = stderr_path.read_bytes()
        stderr_ref = dict(path=str(stderr_path), bytes=len(stderr_raw), sha256=hashlib.sha256(stderr_raw).hexdigest())
        assert len(stderr_raw) == raw_stderr_state['bytes'] <= MAX_STDERR
        decoded_showinfo = metadata_parser.parse_showinfo(stderr_raw, len(expected))
        assert decoded_showinfo['rawSHA256'] == stderr_ref['sha256']
        for n, (event, record, expected_row) in enumerate(zip(decoded_showinfo['frames'], frame_rows, expected)):
            assert event['ordinal'] == record['ordinal'] == n
            assert event['pts'] == record['packetPTS'] == expected_row['packetPTS'], (n, event, record)
            assert event['checksum'] == record['decodedRawAdler32'] == expected_row['preEncoderRGBAdler32'], (n, event, record)
            record.update(decodedPTS=event['pts'], decodedTimeBase=event['timeBase'],
                decodedShowinfoAdler32=event['checksum'], decodedShowinfoRecordIndex=n,
                decodedShowinfoVerifiedAfterFullStderrEOF=True)
        output.json('decoded-showinfo-records.rootfalse.json', dict(rootConfirmed=False,
            rawStderr=stderr_ref, fullLog=decoded_showinfo, all471ThreeAdlerAndPTSChecksPassed=True), durable=True)
        showinfo_ledger = out / 'decoded-showinfo-records.rootfalse.json'
        showinfo_ledger_ref = dict(path=showinfo_ledger.name, bytes=showinfo_ledger.stat().st_size,
                                  sha256=sha_file(showinfo_ledger))
        for value in plan['inputs'].values():
            assert sha_file(value['path']) == value['sha256'], value['path']
        # The 180s decoder budget covers consumption/native+contact staging,
        # true EOF, child reaping, complete stderr fragment validation, all
        # three checksum/PTS gates and immutable after-hashes.
        # Cancel AND join its thread before the final timeout decision. It can
        # no longer fire between that decision and the publication below.
        execution_phase_end = time.monotonic()
        stop_watchdog()
        assert not stderr_errors and not timed_out and not cleanup_errors
        assert execution_phase_end - start <= plan['decoderWallSeconds'], 'Decoder execution-phase wall bound crossed'
        assert child.returncode == 0 and not stderr_thread.is_alive()
        execution_phase_closed = True
        # Publish only after complete stream EOF, original exit0 and late log
        # checks; all native pixels came from the same single decoder pass.
        pending.rename(out / 'frames')
        published_paths.append('frames')
        contacts.rename(out / 'contacts')
        published_paths.append('contacts')
        output.json('index.rootfalse.json', dict(schema='stella.mimi105-v5.same-pass-rgb-material.v1',
            rootConfirmed=False, formalAcceptance=False, motionAccepted=False, bodyAccepted=False,
            faceAccepted=False, sourcePhaseAccepted=False, originalDecoderExitCode=code, decoderInvocations=1,
            completeEOFCount=len(frame_rows), timeBridgeFromMetadataVerified=True,
            allOrdinalPTSAndThreeAdlerChecksAgree=True,
            decodedShowinfoLedger=showinfo_ledger_ref, rawStderrState=raw_stderr_state,
            original32bitChecksumCollisionLimit=True, originalRawCryptographicEqualityProven=False,
            rawRGBSaved=False, nativeDimensions=[WIDTH, HEIGHT], nativeFormat='RGB8PNG',
            contactSpatialSample='nearest native sample every5pixels; never a temporal sample',
            frames=frame_rows, contacts=sheet_rows, plan=plan_ref, release=release_ref))
        output.json('decoder.terminal.json', dict(originalExitCode=code,
            pid=child.pid, pgid=child.pid, ownedLeaderReaped=True,
            elapsedSeconds=time.monotonic() - start, frameCount=len(frame_rows),
            decoderExecutionPhaseWallSeconds=execution_phase_end - start,
            decoderExecutionPhaseWallScope='spawn through consumer/staging/EOF/reap/full-stderr-fragment-and-three-Adler-PTS-gates/after-hashes, before publication',
            outputLogicalBytes=sum(output.sizes.values()), metadataAndSourceAfterExact=True))
        print(json.dumps(dict(status='CHECKSUM_AND_TIMING_VERIFIED_MATERIAL_ROOTFALSE', output=str(out), frames=len(frame_rows))))
    except BaseException as primary_error:
        original_traceback = traceback.format_exc()
        primary = dict(rootConfirmed=False, formalAcceptance=False,
            errorType=type(primary_error).__name__, error=str(primary_error),
            originalErrorTraceback=original_traceback,
            returnCodeObservedBeforeCleanup=child.returncode if child is not None else None,
            completedFrameCount=len(frame_rows), publishedPaths=list(published_paths))
        # Persist the original failure BEFORE any wait/join/signal can fail.
        # The regular-file observer is independent of this material sink and
        # is the durable fallback when this bounded filesystem write fails.
        try:
            output.json('primary-error.rootfalse.json', primary, durable=True)
        except BaseException:
            failure_sink_errors.append(dict(stage='primary-error-file', traceback=traceback.format_exc()))
        first_observer = observer_event(dict(operation='primary-error', primary=primary,
            failureSinkErrors=list(failure_sink_errors)))
        failure_sink_errors.extend(first_observer['sinkErrors'])
        cleanup_attempt('watchdog-cancel-join', stop_watchdog)
        cleanup_attempt('signal-owned-child', lambda: kill_owned('failure-stop'))
        cleanup_attempt('child-wait', wait_child)
        cleanup_attempt('stderr-join', join_stderr)
        failure = dict(rootConfirmed=False, formalAcceptance=False, primary=primary,
            stderrReaderErrors=stderr_errors, cleanupErrors=list(cleanup_errors),
            rawStderrState=dict(raw_stderr_state),
            failureSinkErrors=list(failure_sink_errors), watchdogTriggered=bool(timed_out),
            originalDecoderExitCode=child.returncode if child is not None else None,
            ownedLeaderReaped=child is not None and child.returncode is not None,
            stderrReaderJoined=stderr_thread is None or not stderr_thread.is_alive(),
            watchdogJoined=timer is None or not timer.is_alive(),
            groupAbsenceProven=False, independentRootClosureStillRequired=True,
            publishedPaths=list(published_paths), partialPendingFilesPreserved=True, noRetry=True)
        try:
            output.json('failure.rootfalse.json', failure, durable=True)
        except BaseException:
            failure_sink_errors.append(dict(stage='cleanup-failure-file', traceback=traceback.format_exc()))
        observer_event(dict(operation='cleanup-after-primary', failure=failure,
                            finalFailureSinkErrors=list(failure_sink_errors)))
        # Bare raise retains the original exception and traceback, even when
        # cleanup or a failure sink failed. Never turn opaque cleanup into PASS.
        raise
    finally:
        # A failed cleanup gets one bounded final attempt, recorded separately.
        # Every operation/sink is guarded: finally cannot mask a primary error.
        # The success path already proved child/reader/watchdog termination
        # before publication and therefore needs no speculative cleanup here.
        if not execution_phase_closed:
            cleanup_attempt('finally-watchdog-cancel-join', stop_watchdog)
            cleanup_attempt('finally-signal-child', lambda: kill_owned('finally-stop'))
            cleanup_attempt('finally-child-wait', wait_child)
            cleanup_attempt('finally-stderr-join', join_stderr)
            final_fact = dict(operation='finally-cleanup', cleanupErrors=list(cleanup_errors),
                failureSinkErrors=list(failure_sink_errors),
                originalDecoderExitCode=child.returncode if child is not None else None,
                ownedLeaderReaped=child is not None and child.returncode is not None,
                stderrReaderJoined=stderr_thread is None or not stderr_thread.is_alive(),
                watchdogJoined=timer is None or not timer.is_alive(), groupAbsenceProven=False)
            try:
                output.json('finally-cleanup.rootfalse.json', final_fact, durable=True)
            except BaseException:
                failure_sink_errors.append(dict(stage='finally-cleanup-file', traceback=traceback.format_exc()))
            observer_event(dict(**final_fact, finalFailureSinkErrors=list(failure_sink_errors)))


if __name__ == '__main__':
    main()
