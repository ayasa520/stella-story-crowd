"""Pure bounded metadata parser. No decoder, file writes, or import-time work.

FFmpeg may interleave another log call between showinfo's n/type fragment and
checksum fragment. A newline is therefore not an atomic frame record. We keep
the original bytes and identify each record from its explicit showinfo n-start
to the next n-start. Every required field must occur exactly once in that raw
span; ambiguity is a failure, never resolved by selecting first/last or joining
rewritten log lines. Offsets always address the original byte buffer.
"""
import base64
import hashlib
import re

PREFIX = rb'\[Parsed_showinfo_\d+ @ 0x[0-9a-fA-F]+\]'
START = re.compile(rb'(' + PREFIX + rb')\s+n:\s*(\d+)\b')
WARNING = re.compile(rb'Application provided invalid, non monotonically increasing dts to muxer in stream 0:[^\r\n]*')


class ShowinfoMetadataError(ValueError):
    pass


def unique_field(raw, start, end, name, pattern):
    matches = list(re.finditer(pattern, raw[start:end]))
    if len(matches) != 1:
        raise ShowinfoMetadataError(dict(field=name, recordByteSpan=[start, end],
                                        occurrences=len(matches)))
    match = matches[0]
    return match.groups(), dict(matchByteSpan=[start + match.start(), start + match.end()],
        valueByteSpans=[[start + match.start(i), start + match.end(i)] for i in range(1, len(match.groups()) + 1)])


def parse_showinfo(raw, expected_count):
    assert isinstance(raw, bytes) and len(raw) <= 2 * 1024 * 1024
    assert type(expected_count) is int and 0 < expected_count <= 600
    starts = list(START.finditer(raw))
    if len(starts) != expected_count:
        raise ShowinfoMetadataError(dict(expectedRecordCount=expected_count, actualRecordStarts=len(starts)))
    prefixes = {match.group(1) for match in starts}
    if len(prefixes) != 1:
        raise ShowinfoMetadataError('More than one showinfo instance; ownership ambiguous')
    prefix = starts[0].group(1)
    config_pattern = re.escape(prefix) + rb'\s+config in time_base:\s*(\d+)/(\d+),\s*frame_rate:\s*(\d+)/(\d+)'
    values, config_offsets = unique_field(raw, 0, starts[0].start(), 'config', config_pattern)
    numerator, denominator, rate_numerator, rate_denominator = map(int, values)
    if [numerator, denominator] != [1, 1000]:
        raise ShowinfoMetadataError(dict(decodedTimeBase=[numerator, denominator]))
    frames = []
    for ordinal, marker in enumerate(starts):
        start = marker.start()
        end = starts[ordinal + 1].start() if ordinal + 1 < len(starts) else len(raw)
        if int(marker.group(2)) != ordinal:
            raise ShowinfoMetadataError(dict(expectedOrdinal=ordinal, actualOrdinal=int(marker.group(2)), byteSpan=[start, end]))
        pts, pts_offsets = unique_field(raw, start, end, 'pts', rb'(?<![A-Za-z0-9_])pts:\s*(-?\d+)\b')
        fmt, fmt_offsets = unique_field(raw, start, end, 'fmt', rb'(?<![A-Za-z0-9_])fmt:\s*([A-Za-z0-9_]+)\b')
        dims, dims_offsets = unique_field(raw, start, end, 'dimensions', rb'(?<![A-Za-z0-9_])s:\s*(\d+)x(\d+)\b')
        checksum, checksum_offsets = unique_field(raw, start, end, 'checksum', rb'(?<![A-Za-z0-9_])checksum:\s*([0-9A-Fa-f]{8})\b')
        plane, plane_offsets = unique_field(raw, start, end, 'plane_checksum', rb'(?<![A-Za-z0-9_])plane_checksum:\[\s*([0-9A-Fa-f]{8})\s*\]')
        if fmt[0] != b'rgb24' or list(map(int, dims)) != [500, 1000]:
            raise ShowinfoMetadataError(dict(ordinal=ordinal, format=fmt[0].decode('ascii'), dimensions=list(map(int, dims))))
        if int(checksum[0], 16) != int(plane[0], 16):
            raise ShowinfoMetadataError(dict(ordinal=ordinal, wholeChecksum=checksum[0].decode('ascii'), planeChecksum=plane[0].decode('ascii')))
        prefix_spans = [[start + m.start(), start + m.end()] for m in re.finditer(re.escape(prefix), raw[start:end])]
        frames.append(dict(ordinal=ordinal, recordByteSpan=[start, end],
            ordinalValueByteSpan=list(marker.span(2)), showinfoPrefixByteSpans=prefix_spans,
            pts=int(pts[0]), timeBase=[1, 1000], format='rgb24', dimensions=[500, 1000],
            checksum=checksum[0].decode('ascii'), planeChecksum=plane[0].decode('ascii'),
            fields=dict(pts=pts_offsets, format=fmt_offsets, dimensions=dims_offsets,
                        checksum=checksum_offsets, planeChecksum=plane_offsets)))
    warnings = [dict(byteSpan=list(match.span()), rawBase64=base64.b64encode(match.group()).decode('ascii'))
                for match in WARNING.finditer(raw)]
    return dict(schema='stella.unchanged-stderr.showinfo-record-fragments.v1',
        rawBytes=len(raw), rawSHA256=hashlib.sha256(raw).hexdigest(),
        rawBufferRewritten=False, linesConcatenatedOrRepaired=False,
        frameCount=len(frames), showinfoInstance=prefix.decode('ascii'),
        config=dict(timeBase=[numerator, denominator], advertisedFrameRate=[rate_numerator, rate_denominator], fields=config_offsets),
        frames=frames, rawMuxerWarningCount=len(warnings), rawMuxerWarnings=warnings,
        warningDisposition='Preserved original bytes/spans, not deleted or treated as a substitute for actual exit/count/CRC gates.')
