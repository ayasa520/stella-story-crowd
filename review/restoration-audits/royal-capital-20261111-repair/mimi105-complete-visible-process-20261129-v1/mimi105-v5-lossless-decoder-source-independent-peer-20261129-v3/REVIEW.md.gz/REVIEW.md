# Independent source review — v3 RGB decoder

Verdict: **source peer pass** for one separately released invocation. No code
change is required before that invocation. This is not a decoder execution,
pixel-losslessness result, image review, motion acceptance or field installation.

Reviewed source: `stream_rgb24.rootfalse.py`, SHA-256
`da3f9020e822a69e820a389beeb19f53dec08221b9a76ba9d049e747249f287a`;
parser `showinfo_fragments.py`, SHA-256
`77c04024cbb6f0f4c06f39fac675ee26e03fe972ec030a91f0af3516d92aaa0e`.

- The stderr thread (lines 284–309) only preserves bounded original bytes and
  reports real EOF/fsync. It does not parse newline fragments or discard muxer
  warnings. A crossing chunk is separately recorded before failure.
- The native consumer (lines 324–365) reads each full RGB24 frame, verifies its
  initial-zero Adler against the original pre-encoder value before staging PNGs,
  and rejects extra stdout bytes after the 471 expected frames.
- Complete stdout EOF, child exit 0, reader join and stderr EOF/fsync are checked
  before parsing the held raw stderr (lines 365–380). The parser uses original
  explicit n-start byte spans and requires unique fields and one showinfo
  instance. It does not repair, concatenate or rewrite lines.
- The final per-ordinal comparison (lines 381–387) requires decoded showinfo PTS
  to equal the exact packet PTS, and decoded showinfo/raw/pre-encoder Adler to
  agree. The immutable metadata contains all 471 ordinals and exactly 50 adjacent
  duplicate PTS. The same existing argv retains copyts, RGB24, passthrough and
  single-thread decoder/filter/encoder limits.
- Input after-hashes, watchdog cancel-and-join, timeout/error checks and child/
  reader termination all precede directory/index publication (lines 393–421).
  The 256 MiB hard output cap, 4 MiB diagnostic reserve, 600-frame maximum and
  180-second execution-phase bound remain active; their sufficiency is not
  promised by source review.
- Original exceptions are captured before guarded cleanup, independent observer
  sinks preserve failures, and bare raise retains the primary traceback (lines
  429–489). Cleanup failures remain separate facts. An independent OS/group
  closure remains necessary after the future actual invocation.

Actual work performed here: 27 fresh referenced-file/tool hash checks, compile
of the two source files without importing/executing the decoder, AST inspection
of the single Popen/argv path, and one import of the pure parser followed by one
parse of the retained 59,743-byte failed stderr. All 151 complete metadata
records and their original field/warning byte spans exactly match the prior
validation, all 151 PTS/pre-encoder Adler values agree, and all 31 warnings remain
present. Record 150 checksum is `8D116236` at raw byte span `[59577,59585)`.

The original CLI exit 1/FFmpeg -9 remains a failed run. Its 138 completed raw
consumer frames do not extend to 151 merely because the parser recovers 151
metadata records. Full 471-frame same-pass output, real EOF, original exit 0,
all three checks and actual process closure still require new runtime evidence.
No FFmpeg, ffprobe, browser, image generation, image view or formal checkout/Git
mutation occurred during this review. Existing sealed v3 files are unchanged.
