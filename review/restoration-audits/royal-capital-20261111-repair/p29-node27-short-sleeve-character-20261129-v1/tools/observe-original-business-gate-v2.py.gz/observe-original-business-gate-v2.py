"""Observe the unchanged normal business gate, including its actual failed bytes.

The previous observer retained JSONDecodeError.doc but not the raw argument of
the failed json.loads call. A fresh disk read is a different observation. This
observer walks the original traceback to retain that exact live argument and
the business frame's filename, without rereading, repairing, or retrying it.
The module, parser and original exception are left unchanged.
"""
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import sys
import traceback

module, directory, *forwarded = sys.argv[1:]
assert module in {'story_studio.recovery.native_repair', 'story_studio.recovery.native_install'}
out = Path(directory).resolve()
out.mkdir()
sys.argv = [module, *forwarded]
(out / 'runtime.json').write_text(json.dumps({
    'executable': sys.executable, 'version': sys.version,
    'module': module, 'argv': forwarded, 'parserReplaced': False,
}, indent=2) + '\n')
try:
    runpy.run_module(module, run_name='__main__')
except BaseException as error:
    fact = {'errorType': type(error).__name__, 'message': str(error),
            'traceback': traceback.format_exc(), 'automaticRetry': False,
            'parserReplaced': False, 'originalFailureReRaised': True}
    if isinstance(error, json.JSONDecodeError):
        raw_doc = error.doc.encode('utf-8', 'surrogatepass')
        (out / 'original-exception-doc.txt.gz').write_bytes(gzip.compress(raw_doc, mtime=0))
        fact.update(position=error.pos, line=error.lineno, column=error.colno,
                    exceptionDocSHA256=hashlib.sha256(raw_doc).hexdigest())
        frames = []
        trace = error.__traceback__
        while trace is not None:
            frame = trace.tb_frame
            local = frame.f_locals
            info = {'file': frame.f_code.co_filename, 'function': frame.f_code.co_name,
                    'line': trace.tb_lineno}
            for key in ('name', 'kind', 'identity'):
                value = local.get(key)
                if isinstance(value, (str, int)):
                    info[key] = value
            for key in ('s', 'raw'):
                value = local.get(key)
                if isinstance(value, bytes):
                    leaf = f'frame-{len(frames):02}-{key}.bin.gz'
                    (out / leaf).write_bytes(gzip.compress(value, mtime=0))
                    info[key] = {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest(),
                                 'archive': leaf, 'sameAsExceptionDocBytes': value == raw_doc}
            frames.append(info)
            trace = trace.tb_next
        fact['originalTracebackInputs'] = frames
    (out / 'failure.json').write_text(json.dumps(fact, indent=2) + '\n')
    raise
