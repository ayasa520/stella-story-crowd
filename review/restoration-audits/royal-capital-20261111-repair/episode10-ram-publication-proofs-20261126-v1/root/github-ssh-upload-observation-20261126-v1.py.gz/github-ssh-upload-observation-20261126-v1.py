"""Keep the existing SSH route and upload pacing with a longer liveness window.

Two2026-11-26 attempts ended in OpenSSH's unresponsive-server timeout before a
remote ACK, after about4.1MiB and3.1MiB of producer progress. The cause remains
unknown. This command-local observation allows twelve unanswered10-second
probes instead of three, within the unchanged900-second owner deadline. It
does not disable host-key checks, reconnect, replay stdin, change credentials,
rewrite a remote, or change global/repository configuration.
"""
import os
from pathlib import Path
import sys

ROOT = Path('/home/rikka/Projects/stella')
sys.path.insert(0, str(ROOT / 'data/native_recovery/royal-capital-20261110/repair-20261111'))
import github_ssh_route_v1 as route
import github_ssh_paced_v3 as paced

route.RESOLVERS = (
    'https://cloudflare-dns.com/dns-query?name=ssh.github.com&type=A',
    'https://dns.google/resolve?name=ssh.github.com&type=A',
)
arguments = sys.argv[1:]
command = route.ssh_command(arguments)
if '-G' not in arguments and any(v in ('github.com', 'git@github.com') for v in arguments):
    # OpenSSH uses the first value supplied for each option. Place this
    # bounded observation before the old count while retaining all other args.
    command[1:1] = ['-oUpdateHostKeys=no', '-oServerAliveCountMax=12']
if '-G' not in arguments and any('git-receive-pack' in v for v in arguments):
    raise SystemExit(paced.paced_command(command))
os.execv(command[0], command)
