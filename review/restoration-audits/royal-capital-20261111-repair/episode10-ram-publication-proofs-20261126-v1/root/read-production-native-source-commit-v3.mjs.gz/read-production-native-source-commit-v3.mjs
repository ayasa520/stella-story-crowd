// Compare the live main API with immutable, committed native/review blobs.
// A later local stage or installation must not change what an earlier
// publication is checked against. This reader captures each HTTP body once
// before parsing and retains original errors; it never retries or edits data.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {gzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const A=path.dirname(fileURLToPath(import.meta.url));
const D=path.join(A,'data-checkout');
const [head,sceneText,name]=process.argv.slice(2);
assert.match(head,/^[a-f0-9]{40}$/);
assert.match(sceneText,/^\d+(,\d+)*$/);
assert.match(name,/^[a-z0-9-]+$/);
const scenes=sceneText.split(',').map(Number);
assert.ok(scenes.length>=1&&scenes.length<=3&&new Set(scenes).size===scenes.length);
assert.equal(execFileSync('/usr/bin/git',['-C',D,'rev-parse',head+'^{commit}'],{encoding:'utf8'}).trim(),head);
const out=path.join(A,name);fs.mkdirSync(out);
const hash=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const save=(name,j)=>fs.writeFileSync(path.join(out,name),JSON.stringify(j,null,2)+'\n',{flag:'wx'});
const results=[];
for(const scene of scenes){
  const url='https://stella-preview.jaoushingan.com/api/native/source?sceneId='+scene;
  const fact={scene,url,method:'GET',expectedHead:head,automaticRetries:0,startedUTC:new Date().toISOString()};
  try{
    const response=await fetch(url,{signal:AbortSignal.timeout(60000)});
    const raw=Buffer.from(await response.arrayBuffer());
    Object.assign(fact,{status:response.status,bytes:raw.length,sha256:hash(raw),headers:Object.fromEntries(response.headers)});
    fs.writeFileSync(path.join(out,scene+'.response.json.gz'),gzipSync(raw,{level:6}),{flag:'wx'});
    save(scene+'.transport.json',fact);
    assert.equal(response.status,200);assert.ok(raw.length<=4*1024*1024);
    const value=JSON.parse(raw.toString('utf8'));
    assert.equal(value.headSha,head);
    const native=execFileSync('/usr/bin/git',['-C',D,'show',head+':native/scenes/'+scene+'.json'],{maxBuffer:8*1024*1024});
    const review=execFileSync('/usr/bin/git',['-C',D,'show',head+':review/scenes/'+scene+'.json'],{maxBuffer:8*1024*1024});
    assert.deepEqual(value.document,JSON.parse(native));assert.deepEqual(value.review,JSON.parse(review));
    Object.assign(fact,{observedHead:value.headSha,completeCommittedNativeAndReviewExact:true,
      nativeFileSHA256:hash(native),reviewFileSHA256:hash(review),continuousPlaybackAccepted:false});
    save(scene+'.verified.json',fact);results.push(fact);
  }catch(error){save(scene+'.failure.json',{...fact,error:String(error),stack:error.stack,cause:'unknown',originalRawBodyRetained:fs.existsSync(path.join(out,scene+'.response.json.gz'))});throw error;}
}
save('receipt.json',{rootConfirmed:true,expectedHead:head,allWholeCommittedDocumentsExact:true,results,retries:0,gameplayAccepted:false});
console.log(JSON.stringify({output:out,expectedHead:head,requests:results.length,allWholeCommittedDocumentsExact:true}));
