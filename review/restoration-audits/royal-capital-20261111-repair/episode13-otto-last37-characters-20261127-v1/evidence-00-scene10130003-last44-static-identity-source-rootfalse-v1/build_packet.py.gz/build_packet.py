"""Bind a bounded delegated still-image review to immutable source bytes.

This is an evidence writer, not a native-script installer. It snapshots exactly
the assigned candidate slice and selected model dependencies, and refuses to
overwrite output files. MOC payloads are treated as opaque bytes: hash equality
establishes a resource correspondence, never animation, topology or geometry.
"""

from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zlib

from PIL import Image


ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
HERE = Path(__file__).resolve().parent
EXPECTED_HEAD = 'e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8'
REVIEWER = '/root/scene03_identity_last44'
OCR = ROOT / 'data/native_recovery/royal-capital-20261110/ocr/40'
LIMEOS = ROOT / 'data/extracted_archives/limeos'
MODEL_ROOT = LIMEOS / 'LIMEOS/assets/downloadassets/assetbundle/models/ac'
POSITIVE_MODELS = ['rowdy01', 'rowdy02', 'citizen_beast01', 'otto01', 'subaru01']
NEGATIVE_MODELS = ['poorman01', 'ton01', 'kan01', 'chin01', 'otto_prison01',
                   'subaru_tshirt01', 'subaru_tshirt02', 'subaru_butler01']
ROW_MODELS = {
    49: 'rowdy01', 50: 'subaru01', 51: 'otto01', 52: 'rowdy01',
    53: 'rowdy02', 54: 'citizen_beast01', 55: 'otto01', 56: 'subaru01',
    57: 'otto01', 58: 'subaru01', 59: 'rowdy01', 60: 'otto01',
    61: 'subaru01', 62: 'subaru01', 63: 'subaru01', 64: 'otto01',
    65: 'subaru01', 66: 'rowdy01', 67: 'otto01', 68: 'rowdy02',
    **{n: 'subaru01' for n in range(70, 94)},
}
DESCRIPTIONS = {
    'rowdy01': {
        'positive': 'Short spiked dark red-brown hair, pointed beard, muscular bare arms, dark sleeveless lace-up chest garment and gray-white ragged trim on the open dark vest. These same assembled pieces are visible in the original rowdy01 texture atlas.',
        'negative': 'poorman01 has plain brown hair, torn blue cloth and gray sleeves; ton01 has dark braided hair, a pale long sleeveless shirt and green cloth; neither has this pointed beard or fur-edged open vest. rowdy02 is bald with a dark headband and a broad light-gray torso.',
        'comparedAgainst': ['poorman01', 'ton01', 'rowdy02'],
    },
    'rowdy02': {
        'positive': 'Bald crown, wide purple-dark headband tied at the left, broad light-gray sleeveless torso and dark open waistcoat. The visible headband, exposed head, belly shape and waistcoat pieces agree with the original rowdy02 atlas.',
        'negative': 'ton01 has purple braided hair, green cloth, bandaged arms and a yellow waist sash; rowdy01 has spiked brown hair, pointed beard and gray-white vest edging. The source foreground has neither alternative outfit.',
        'comparedAgainst': ['ton01', 'rowdy01'],
    },
    'citizen_beast01': {
        'positive': 'Gray fur and large triangular ears with pink interiors, green eyes, blue-violet tunic, pale blue scarf and diagonal brown strap with a rectangular gold buckle agree with the directly inspected citizen_beast01 texture.',
        'negative': 'kan01 is a human figure with bowl-cut brown hair, red-purple long clothing and bow; chin01 has blue hair with pink streaks and a gray sleeveless outfit. Neither contains the gray fur, large ears and blue scarf shown in this full frame.',
        'comparedAgainst': ['kan01', 'chin01'],
    },
    'otto01': {
        'positive': 'Gray layered hair, blue-violet eyes, broad green merchant hat with gold curved linework and white feather, green cloak, red neck bow and green-yellow triangular chest trim agree with original otto01 atlas pieces.',
        'negative': 'otto_prison01 shares gray hair but has a black-white striped shirt and no green merchant hat, feather or cloak; the source frame visibly contains the merchant outfit.',
        'comparedAgainst': ['otto_prison01'],
    },
    'subaru01': {
        'positive': 'Short spiked dark hair, orange stand collar and shoulder trim, black sleeves and light gray-white zip-front tracksuit torso with a two-tone N emblem agree with the directly inspected original subaru01 atlas.',
        'negative': 'subaru_tshirt01 and subaru_tshirt02 show plain dark short-sleeved shirts without the orange collar or light zip-front N torso; subaru_butler01 has a black formal coat, brown waistcoat and white collar. All differ visibly from this tracksuit.',
        'comparedAgainst': ['subaru_tshirt01', 'subaru_tshirt02', 'subaru_butler01'],
    },
}


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def file_record(path, picture=False):
    record = {'path': str(path), 'exists': path.is_file()}
    if not record['exists']:
        return record
    payload = path.read_bytes()
    record.update(bytes=len(payload), sha256=sha(payload))
    if picture:
        with Image.open(path) as image:
            record.update(dimensions=list(image.size), format=image.format)
    return record


def canonical_sha(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':')).encode('utf-8'))


def write_once(name, value):
    with (HERE / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    assert os.getpriority(os.PRIO_PROCESS, 0) == 19
    assert sorted(os.sched_getaffinity(0)) == [0, 1]
    head = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == EXPECTED_HEAD
    paths = {
        'candidateScan': A / 'chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json',
        'nativeScene': D / 'native/scenes/10130003.json',
        'reviewScene': D / 'review/scenes/10130003.json',
        'manifest': D / 'manifest.json',
        'catalog': D / 'assets/catalog.json',
        'previewCatalog': D / 'assets/preview/catalog.json',
        'assetPackage': D / 'assets/package.json',
        'sourceFrameIndex': OCR / 'root-review/index.json',
        'sourceManifest': OCR / 'coarse-1hz/manifest.json',
        'extractionManifest': ROOT / 'data/extracted_archives/limeos-manifest.json',
        'originalPlayerManifest': ROOT / 'data/story_player/extracted/manifest.json',
        'dataPlayerManifest': D / 'assets/player/manifest.json',
    }
    raw = {key: path.read_bytes() for key, path in paths.items()}
    docs = {key: json.loads(value) for key, value in raw.items()}
    candidates = next(s for s in docs['candidateScan']['scenes'] if s['sceneId'] == 10130003)['rows'][44:88]
    assert len(candidates) == 44
    native_rows = {r['scenario_id']: r for r in docs['nativeScene']['scenario_list']}
    review_rows = docs['reviewScene']['scenarios']
    events = {e['id']: e for e in docs['sourceFrameIndex']['events']}
    catalog = docs['catalog']
    preview = docs['previewCatalog']
    package = docs['assetPackage']['files']
    extraction = {e['path']: e for e in docs['extractionManifest']['entries']}
    local_overrides = docs['extractionManifest'].get('local_overrides', [])

    # Store only the selected resource records, not the multi-thousand-row maps.
    resources = {}
    for model in POSITIVE_MODELS + NEGATIVE_MODELS:
        original_dir = MODEL_ROOT / ('ac_' + model) / 'ac'
        descriptor = json.loads((original_dir / 'ac.model3.json').read_text())
        reference = descriptor['FileReferences']
        rels = ['ac.model3.json', reference['Moc'], *reference['Textures']]
        records = []
        for relative in rels:
            original = original_dir / relative
            data_relative = 'models/' + model + '/ac/' + relative
            target = D / 'assets' / data_relative
            member = original.relative_to(LIMEOS).as_posix()
            original_bytes = original.read_bytes()
            item = {
                'role': 'descriptor' if relative.endswith('.json') else ('opaqueMOC' if relative.endswith('.moc3') else 'texture'),
                'original': file_record(original, relative.endswith('.png')),
                'data': file_record(target, relative.endswith('.png')),
                'byteIdenticalWhenDataExists': original_bytes == target.read_bytes() if target.exists() else None,
                'member': member,
                'dataMembersEntry': catalog['members'].get(member),
                'dataAssetMembersEntry': catalog['asset_members'].get(member),
                'dataPackageEntry': package.get(data_relative),
                'selectedExtractionEntry': extraction.get(member),
                'crc32MatchesExtraction': f'{zlib.crc32(original_bytes):08x}' == extraction[member]['crc32'],
                'sourceLocalOverrides': [o for o in local_overrides if o.get('asset') == str(original.relative_to(ROOT))],
            }
            if relative.endswith('.png'):
                item['original']['directlyViewed'] = True
                compressed = D / 'assets/preview' / Path(data_relative).with_suffix('.webp')
                item['compressedDataTexture'] = file_record(compressed, True)
                item['compressedTextureByteIdentityClaimed'] = False
                item['compressedTextureVisualAcceptance'] = False
            if relative.endswith('.moc3'):
                compressed = D / 'assets/preview' / (data_relative + '.gz')
                item['compressedDataMOC'] = file_record(compressed)
                item['gzipDecodedByteIdenticalToOriginal'] = gzip.decompress(compressed.read_bytes()) == original_bytes if compressed.exists() else None
                item['MOCMeaningOrTopologyDecoded'] = False
            records.append(item)
        native_id = 'live2d/AC_' + model
        original_actor = docs['originalPlayerManifest']['actors'].get(model)
        data_actor = docs['dataPlayerManifest']['actors'].get(model)
        resources[model] = {
            'nativeId': native_id,
            'use': 'positiveIdentityReference' if model in POSITIVE_MODELS else 'negativeVariantReference',
            'originalDescriptorReference': {'Moc': reference['Moc'], 'Textures': reference['Textures'], 'Physics': reference.get('Physics')},
            'fullDataCatalogEntryPresent': native_id in catalog['models'],
            'previewCatalogEntry': preview['models'].get(native_id),
            'fullCatalogIdentityFields': {k: v for k, v in catalog['models'].get(native_id, {}).items() if k not in ('motions', 'script_motions', 'motion_bindings')},
            'files': records,
            'playerActorRecordByteSemanticEquality': original_actor == data_actor,
            'playerActorSource': original_actor.get('source') if original_actor else None,
            'playerGeometryAccepted': False,
            'staticVisibleComparison': DESCRIPTIONS.get(model),
        }

    rows = []
    for ordinal, candidate in enumerate(candidates, 44):
        sid = candidate['scenarioId']
        current = native_rows[sid]
        review = review_rows[str(sid)]
        assert current['uniq_id'] == candidate['UID']
        assert review['stableKey'] == candidate['stableKey']
        assert review['sourceText'] == candidate['sourceText']
        assert current['msg_text'] == review['translation']
        assert current['scenario_type'] == 2 and current['character'] == '' and current['character_image'] == ''
        recording = candidate['recordings'][0]
        event = events[recording['ocrEventId']]
        frame = file_record(Path(event['frame']), True)
        assert frame['dimensions'] == [480, 856]
        # A reviewed dialogue can merge a fading-panel event without rewriting
        # the older OCR extraction index. Preserve both intervals verbatim. A
        # mismatch is logged evidence, not permission to normalize timestamps.
        index_interval = [event['start'], event['end']]
        current_interval = [recording['start'], recording['end']]
        frame.update(directlyViewed=True, reviewer=REVIEWER,
                     sourceIndexEventId=event['id'], indexedSourceFrameSeconds=event['source_frame_time'],
                     indexedFrameNumber=event['frame_index'],
                     sourceIndexInterval=index_interval, currentReviewInterval=current_interval,
                     indexIntervalMatchesCurrentReview=index_interval == current_interval,
                     precision='Existing index seconds are copied verbatim (millisecond decimal here); no fresh decoder PTS or frame-exact native event boundary was measured.')
        model = ROW_MODELS[sid]
        decision = 'candidate_static_character_identity'
        fields = {'character': 'live2d/AC_' + model}
        observations = ['A full-size foreground actor is visible in this original full frame.']
        if sid == 52:
            observations.append('This frame is dimmed, but the red-brown spiked hair, pointed beard, fur-edged vest and lace-up dark chest remain visible. Brightness phase, expression and action are not assigned.')
        if sid == 82:
            decision = 'withheld_overlay_mapping_unknown_keep_empty'
            fields = {}
            observations = [
                'At 823.998 seconds the source has a mind-map/choice overlay and a large central Subaru tracksuit actor, plus separate small choice portraits. The central actor, rather than any small portrait, supports only the observed visible model candidate subaru01.',
                'The existing 819.998-second full frame also shows the large tracksuit actor behind choice UI. At 827.998 seconds the selected quote remains over a blurred background and no large foreground actor is visible.',
                'Keep the formal character and character_image fields empty in this package: the exact underlying CARD field versus choice-layer binding is withheld for root review. Do not use a small choice portrait as a substitute source actor.',
            ]
        all_available = resources[model]['fullDataCatalogEntryPresent'] and all(f['data']['exists'] for f in resources[model]['files'])
        row = {
            'candidateOrdinalZeroBased': ordinal,
            'candidateNumberOneBased': ordinal + 1,
            'sceneId': 10130003, 'scenarioId': sid, 'UID': candidate['UID'],
            'stableKey': candidate['stableKey'], 'nativeIdentifierOrigin': review.get('nativeIdOrigin'),
            'currentCompleteNativeRow': current,
            'currentCompleteReviewRow': review,
            'currentNativeRowCanonicalSha256': canonical_sha(current),
            'currentReviewRowCanonicalSha256': canonical_sha(review),
            'guard': {'character': current['character'], 'character_image': current['character_image'],
                      'sourceTextJa': review['sourceText'], 'sourceTextJaUtf8Sha256': sha(review['sourceText'].encode()),
                      'currentTextZh': current['msg_text'], 'currentTextZhUtf8Sha256': sha(current['msg_text'].encode()),
                      'speakerMetadataOnly': current['msg_character'], 'stableKey': review['stableKey'],
                      'UID': current['uniq_id'], 'scenarioType': current['scenario_type']},
            'sourceRecordingAnchor': recording,
            'fullOriginalFrame': frame,
            'identity': {'decision': decision, 'observedVisibleModelCandidate': 'live2d/AC_' + model,
                         'fields': fields, 'positiveVisibleBasis': DESCRIPTIONS[model]['positive'],
                         'negativeVisibleBasis': DESCRIPTIONS[model]['negative'],
                         'comparedAgainstOriginalVariants': DESCRIPTIONS[model]['comparedAgainst'],
                         'resourceBindingKey': model, 'resourcesCompleteInFullDataCatalog': all_available,
                         'resourceIntegrationRequired': not all_available, 'observations': observations,
                         'sourceSpeakerUsedAsModelProof': False, 'cropUsedAsForegroundProof': False,
                         'choiceSmallPortraitUsedAsForegroundProof': False},
            'rootConfirmed': False, 'installationApproved': False, 'executionApproved': False,
            'bodyAccepted': False, 'faceAccepted': False, 'phaseAccepted': False,
            'timingAccepted': False, 'audioAccepted': False, 'wholeSceneAccepted': False,
        }
        rows.append(row)

    def event_frame(event_id):
        event = events[event_id]
        record = file_record(Path(event['frame']), True)
        record.update(directlyViewed=True, indexedSourceFrameSeconds=event['source_frame_time'], eventId=event_id)
        return record

    title_frame = file_record(OCR / 'root-review/frames/cc01f9d67b5f-014340.jpg', True)
    title_frame.update(directlyViewed=True, sourceAnchorSeconds=476.999,
                       indexedSourceFrameSeconds=477.999, sourceIndexEventIds=['merged-0130', 'merged-0131'],
                       visibleJapaneseTitle='IFルート：オットー / 悪い予感はよく当たる',
                       precision='Title anchor from review/scenes metadata, not a newly measured frame PTS.')
    manifest = docs['manifest']
    recording = next(r for r in manifest['recordings'] if r['id'] == 'bili-capital-40')
    source_video = Path(recording['ocrSources'][0]['path'])
    video_bindings = {'OCRSource': file_record(source_video), 'localRecording': file_record(Path(recording['localPath']))}
    assert video_bindings['OCRSource']['sha256'] == recording['ocrSources'][0]['sha256']
    assert video_bindings['localRecording']['sha256'] == recording['localSha256']
    binding = {
        'chapter': {'id': 1, 'title': '第1章　王都的一日篇'},
        'section': next(s for c in manifest['chapters'] for s in c['sections'] if 10130003 in s['sceneIds']),
        'scene': {'id': 10130003, 'titleZh': '坏预感总会应验', 'titleJa': '悪い予感はよく当たる',
                  'identifierOrigin': 'authored reconstruction; not asserted as recovered original native row identifiers'},
        'recordingMetadata': recording,
        'reviewSceneSegments': docs['reviewScene']['sceneSegments'],
        'sourceTitleFullFrame': title_frame,
        'sourceVideoByteBindings': video_bindings,
        'routeEvidence': {'route': 'IFルート：オットー',
                          'choice82': {'promptJa': review_rows['82']['sourceText'],
                                       'observedSelectedSide': 'right', 'observedRightLabelJa': 'お金を払う',
                                       'observedSelectedQuoteJa': '何とか、金で問題解決できないか？',
                                       'fullOriginalFrames': [event_frame('merged-0245'), event_frame('merged-0247')],
                                       'unobservedLeftExitPreserved': True},
                          'identificationBasis': 'Manifest/review recording identities, directly viewed IF Otto source title, Japanese dialogue sequence and the observed right money choice; never inferred from scene/part numbering.'},
        'originalJapaneseScenarioFileAvailableForThisScene': False,
        'JapaneseGuardProvenance': 'Current reconstructed review sourceText and fixed recording anchors; not claimed to be an original game scenario_list.'
    }
    for key, path in paths.items():
        assert path.read_bytes() == raw[key], 'A bound input changed during review assembly: ' + key
    metadata_after = subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD'], text=True).strip()
    assert metadata_after == head
    input_records = {key: {'path': str(path), 'bytes': len(raw[key]), 'sha256': sha(raw[key])} for key, path in paths.items()}
    common = {'rootConfirmed': False, 'executionApproved': False, 'installationApproved': False,
              'bodyAccepted': False, 'faceAccepted': False, 'phaseAccepted': False,
              'timingAccepted': False, 'audioAccepted': False, 'wholeSceneAccepted': False,
              'fullRestorationGoalComplete': False}
    write_once('rows.json', {'schema': 'stella.delegated-static-identity-rows.v1', **common,
                             'reviewer': REVIEWER, 'slice': {'offset': 44, 'count': 44, 'order': 'candidate rows array'}, 'rows': rows})
    write_once('resource-bindings.json', {'schema': 'stella.selected-model-static-reference-bindings.v1',
                                         **common, 'MOCPolicy': 'Opaque bytes only; no body/face/topology/geometry conclusion.', 'models': resources})
    write_once('source-route-binding.json', {'schema': 'stella.source-route-binding.v1', **common, **binding})
    write_once('receipt.json', {
        'schema': 'stella.delegated-static-identity-receipt.v1', **common,
        'createdUtc': datetime.now(timezone.utc).isoformat(), 'reviewer': REVIEWER,
        'dataHeadMetadataBefore': head, 'dataHeadMetadataAfter': metadata_after,
        'dataCleanAsserted': False, 'dataHeadMeaning': 'Metadata only. No git status or repository-wide cleanliness acceptance.',
        'boundInputs': input_records, 'boundInputsUnchangedDuringAssembly': True,
        'counts': {'assignedRows': 44, 'directlyViewedAssignedFullFrames': 44,
                   'additionalDirectlyViewedSourceFullFrames': 3,
                   'directlyViewedOriginalModelTextureAtlases': 13,
                   'singleCharacterFieldCandidates': 43, 'withheldKeepEmpty': 1,
                   'candidateModels': dict(Counter(r['identity']['observedVisibleModelCandidate'] for r in rows if r['identity']['fields'])),
                   'candidateRowsRequiringResourceIntegration': sum(r['identity']['resourceIntegrationRequired'] for r in rows if r['identity']['fields'])},
        'missingFullFrames': [], 'minimalAdditionalExtractionRequired': [],
        'sourceIndexIntervalDifferences': [
            {'scenarioId': r['scenarioId'], 'sourceIndexInterval': r['fullOriginalFrame']['sourceIndexInterval'],
             'currentReviewInterval': r['fullOriginalFrame']['currentReviewInterval']}
            for r in rows if not r['fullOriginalFrame']['indexIntervalMatchesCurrentReview']
        ],
        'permissions': {'root': False, 'execution': False, 'installation': False,
                        'browser': False, 'ffmpeg': False, 'newMedia': False, 'formalDataWrite': False,
                        'canonicalSourceWrite': False, 'gitMutation': False},
        'activities': {'browserStarted': False, 'ffmpegRun': False, 'newMediaExtracted': False,
                       'installedSoftware': False, 'formalDataChanged': False, 'canonicalSourceChanged': False,
                       'oldEvidenceModified': False, 'gitCommittedOrPushed': False,
                       'mediaCopied': False, 'completeLargeMapsCopied': False},
        'runtime': {'nice': os.getpriority(os.PRIO_PROCESS, 0), 'cpus': sorted(os.sched_getaffinity(0))},
        'goal': 'All recording-covered chapters/routes retain the first-three-episode full restoration acceptance standard. This packet signs static identity observations only.',
        'limitations': ['No complete entry/action sequence is reviewed by this still-image packet.',
                        'Native row IDs are authored reconstruction metadata; Japanese original sourceText is guarded without claiming a recovered game script.',
                        'Row82 stays empty pending root overlay-to-CARD binding review.',
                        'rowdy01/rowdy02 descriptors and compressed previews exist, but full catalog, package entries and uncompressed MOC/PNG are incomplete; six candidates cannot be treated as complete resource registration.'],
    })
    artifacts = {p.name: file_record(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != 'artifact-hashes.json'}
    write_once('artifact-hashes.json', {'schema': 'stella.small-evidence-artifact-hashes.v1', 'files': artifacts})
    print(json.dumps({'output': str(HERE), 'rows': 44, 'characterCandidates': 43, 'withheld': 1,
                      'resourceIntegrationRows': 6, 'files': len(artifacts) + 1}, ensure_ascii=False))


if __name__ == '__main__':
    main()
