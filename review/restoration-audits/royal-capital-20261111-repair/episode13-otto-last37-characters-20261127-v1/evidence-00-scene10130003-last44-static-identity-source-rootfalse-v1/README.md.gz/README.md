# Scene 10130003, candidate rows 44–87: static identity evidence

Delegated reviewer: `/root/scene03_identity_last44`. Data HEAD is metadata only:
`e2c2b96bb8b9b5636a3fd4f73234f66d864cddd8`. Repository cleanliness is not asserted.

The reviewed source title reads `IFルート：オットー / 悪い予感はよく当たる`.
Manifest and recording evidence place it in chapter 1, episode 13, recording
`bili-capital-40`, `13-IF奥托「从零开始的异世界商贩」`. The observed choice is
the right `お金を払う` exit; the unrecorded left exit remains unresolved.

All 44 assigned original full frames and 13 original model texture atlases were
actually viewed. Three additional original full frames establish the route title
and choice context. No new frame, thumbnail, crop or media was created or copied.

| Candidate model | Rows | Limitation |
| --- | ---: | --- |
| `live2d/AC_subaru01` | 30 | Ordinary source full frames show the gray-white, black and orange tracksuit. |
| `live2d/AC_otto01` | 6 | Merchant hat, white feather, green cloak and red bow are visible. |
| `live2d/AC_rowdy01` | 4 | Nodes 49, 52, 59, 66 require complete resource registration. Node 52 is dimmed but identifiable. |
| `live2d/AC_rowdy02` | 2 | Nodes 53, 68 require complete resource registration. |
| `live2d/AC_citizen_beast01` | 1 | Gray fur, large ears, blue scarf and buckled diagonal strap are visible. |

Node 82 is withheld and remains empty. Its large central tracksuit actor is
recorded as a visible candidate, separately from the small choice portraits, but
this package does not decide the underlying CARD versus choice-layer binding.
The later selected-quote frame shows no large actor. No choice portrait is used
as a substitute for source foreground evidence.

`rows.json` contains each UID, stable key, complete native/review rows, Japanese
and Chinese text guards, source frame bytes/SHA-256 and copied index times.
`resource-bindings.json` binds only selected original/D descriptor, opaque MOC
and texture records. Both rowdy descriptors and compressed previews exist in D;
full catalog/package records and uncompressed MOC/PNG do not. Gzip-decoded MOC
bytes match their original source bytes for all five positive models.

`assembly-diagnostic.json` records the sole old-index/current-review interval
difference: node 61 ends at 736.498 in the extraction index and 737.498 in current
review metadata after a fading-panel merge. Neither input was changed. Source
index seconds are not newly measured decoder PTS or native phase boundaries.

Root, execution and installation approval remain false. Body, face, phase,
timing, audio and whole-scene acceptance remain false. D, C, old evidence and Git
were not modified. The full recording-covered restoration goal remains active.

The final package file hashes are in `artifact-hashes.json`.
