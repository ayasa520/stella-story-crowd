"""Bind one future published ordinary41field save without changing its content.

This is deliberately unreleased. Only a hash-bound root preparation release
permits the future Git/file reads and new private output files. No importer,
API, listener, browser, decoder or model state is started by this helper.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = HERE.parent / 'data-checkout'
SOURCE = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout'
ROUTE = HERE.parent / 'episode11-scene10110003-save-playback-plan-20261121-v1/route.rootfalse.json'
SOURCE_PACKET = HERE.parent / 'episode11-gap-audit-20261121-v1/scene10110003-node-fields.rootfalse.json'
MINIMUM_GLOBAL = HERE.parent / 'episode6-rom13-runtime-full-guard-supplement-v1.json'

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()

def write(name, value):
    with (HERE / name).open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

parser = argparse.ArgumentParser()
parser.add_argument('--root-inputs', required=True)
parser.add_argument('--root-inputs-sha256', required=True)
args = parser.parse_args()
release_path = Path(args.root_inputs).resolve()
assert sha(release_path) == args.root_inputs_sha256
release = load(release_path)
assert release['rootConfirmed'] is True and release['preparationAuthorized'] is True
assert release['browserLaunchAuthorized'] is False
assert re.fullmatch('[0-9a-f]{40}', release['publishedHead'] or '')
assert git(DATA, 'rev-parse', 'HEAD') == release['publishedHead']
assert git(DATA, 'status', '--short') == '', 'Only the committed/published ordinary save may be bound'
assert git(SOURCE, 'rev-parse', 'HEAD') == release['sourceHead']
assert git(SOURCE, 'status', '--short') == release['sourceStatus']
assert git(SOURCE, 'diff', '--name-only', 'HEAD') == ''
assert isinstance(release['browserOwner'], str) and release['browserOwner'].startswith('/root/')
assert sha(SOURCE / 'dist/server/index.js') == release['expectedDistServerSha256']
for kind, key in [('native', 'expectedNativeSha256'), ('review', 'expectedReviewSha256')]:
    assert sha(DATA / f'{kind}/scenes/10110003.json') == release[key]

packet_ref = release['approvedPacket']
assert sha(packet_ref['path']) == packet_ref['sha256']
packet = load(packet_ref['path'])
assert packet['rootConfirmed'] is True and len(packet['changes']) == 41
assert sha(SOURCE_PACKET) == 'da2fce7ffff8cbf520b7bb59a60b51448d8518eb87a17a810a42ec89a98c64a3'
source_packet, original_route = load(SOURCE_PACKET), load(ROUTE)
assert [(c['sceneId'], c['scenarioId'], c['stableKey'], c['fields']) for c in packet['changes']] == [
    (c['sceneId'], c['scenarioId'], c['stableKey'], c['fields']) for c in source_packet['changes']]
assert all(c['rootConfirmed'] is True for c in packet['changes'])
assert release['postapplyAndPublicationGuards'], 'A proposed or failed stage is not a saved/publication result'
guards = {str(release_path): sha(release_path), packet_ref['path']: packet_ref['sha256'],
          str(SOURCE_PACKET): sha(SOURCE_PACKET), str(ROUTE): sha(ROUTE), str(MINIMUM_GLOBAL): sha(MINIMUM_GLOBAL)}
guards.update(release['postapplyAndPublicationGuards'])
guards.update(release['additionalEvidenceGuards'])
global_ref = release['globalGuardSnapshot']
assert sha(global_ref['path']) == global_ref['sha256']
guards[global_ref['path']] = global_ref['sha256']
global_guards = load(global_ref['path'])['guards']
assert set(load(MINIMUM_GLOBAL)['guards']) <= set(global_guards), 'The original complete950 guard set is a minimum'
for path, expected in {**guards, **global_guards}.items():
    assert sha(ROOT / path) == expected, path

native = load(DATA / 'native/scenes/10110003.json')
review = load(DATA / 'review/scenes/10110003.json')
manifest = load(DATA / 'manifest.json')
rows = {row['scenario_id']: row for row in native['scenario_list']}
assert list(rows) == list(range(1, 47)) and len(native['scenario_list']) == 46
for change in packet['changes']:
    row = rows[change['scenarioId']]
    assert review['scenarios'][str(change['scenarioId'])]['stableKey'] == change['stableKey']
    for key, value in change['expected'].items():
        assert row[key] == change['fields'].get(key, value), (change['scenarioId'], key)
assert {key: sum(key in c['fields'] for c in packet['changes']) for key in ('character', 'bg_picture')} == {
    'character': 40, 'bg_picture': 1}
models = sorted({re.fullmatch(r'live2d/AC_([A-Za-z0-9_]+)', c['fields']['character'])[1]
                 for c in packet['changes'] if 'character' in c['fields']})
assert models == ['felt01', 'rom01', 'subaru01']
steps = []
for original in original_route['steps']:
    scenario = original['scenarioId']
    row = rows[scenario]
    assert row['uniq_id'] == original['uniqId']
    assert review['scenarios'][str(scenario)]['stableKey'] == original['stableKey']
    assert row['character'] == original['expectedCharacterAfterSave']
    assert row['bg_picture'] == original['expectedExplicitBgAfterSave']
    branch = next(b for b in row['branch_list'] if b['branch_id'] == original['recordedBranchId'])
    assert branch['transition_list'] == [original['nextNativeTransition']]
    uid = review['scenarios'][str(scenario)].get('studioNodeId') or row['uniq_id']
    assert original['id'] == f'node:10110003:{uid}'
    steps.append({'id': original['id'], 'scenario': scenario, 'native': row,
                  'expectedModel': row['character'].removeprefix('live2d/AC_') if row['character'] else '',
                  'branchId': branch['branch_id'], 'expectedTransition': branch['transition_list'][0],
                  'expectedEffectiveBackground': original['expectedScriptBackgroundAfterSave'],
                  'expectedBackgroundProvider': original['expectedScriptBackgroundProviderAfterSave'],
                  'kind': original['kind'], 'capture': True})
for item in original_route['unknownBranches']:
    branch = next(b for b in rows[item['scenarioId']]['branch_list'] if b['branch_id'] == item['branchId'])
    assert branch['transition_list'] == []
assert rows[45]['video'] == 'adv_dive01_out' and rows[46]['bg_music'] == 'bgm_btl_adv_win01'
assert steps[-1]['expectedTransition'] == original_route['finish']['nativeTransition']
assert steps[-1]['expectedTransition']['next_scenario_label'] == 'FINISH'

# Freeze the entire compiled/source guard and all importer batch files, not
# only currently fetched model URLs. Current ownership adds a new batch, so
# global guard membership must grow instead of truncating to a historical950.
paths = {'manifest.json', 'review/native-restoration.json', 'assets/catalog.json',
         'assets/package.json', 'assets/preview/catalog.json'}
paths.update(s[key] for s in manifest['scenes'] for key in ('path', 'reviewPath'))
paths.update(str(p.relative_to(DATA)) for p in (DATA / 'review/restoration-batches').glob('*.json'))
for model in models:
    for pattern in [f'assets/models/{model}/**/*', f'assets/preview/models/{model}/**/*',
                    f'assets/portraits/{model}.*', f'assets/preview/portraits/{model}.*']:
        paths.update(str(p.relative_to(DATA)) for p in DATA.glob(pattern) if p.is_file())
for pattern in ['assets/player/**/*', 'assets/backgrounds/*', 'assets/preview/backgrounds/*',
                'assets/music/*', 'assets/preview/music/*', 'assets/thumbnails/**/*',
                'assets/preview/thumbnails/**/*', 'assets/movies/adv_dive01_out.*',
                'assets/preview/movies/adv_dive01_out.*']:
    paths.update(str(p.relative_to(DATA)) for p in DATA.glob(pattern) if p.is_file())
for path in paths:
    if path.startswith(('native/', 'review/restoration-batches/')) or path in (
            'manifest.json', 'review/native-restoration.json', 'assets/catalog.json', 'assets/package.json'):
        assert str((DATA / path).relative_to(ROOT)) in global_guards, path
protected = load(HERE.parent / 'p42-six-visual-saved-runtime-v1/input-binding.json')['protectedFirstThree']
assert len(protected) == 22 and {p: sha(DATA / p) for p in protected} == protected
source_files = {p: sha(SOURCE / p) for p in sorted(git(SOURCE, 'ls-files').splitlines()) if (SOURCE / p).is_file()}
dist_files = {str(p.relative_to(SOURCE / 'dist')): sha(p) for p in sorted((SOURCE / 'dist').rglob('*')) if p.is_file()}
readiness_path = HERE.parent / 'episode5-silent54-saved-runtime-v2/input-binding.json'
readiness = load(readiness_path)
guards[str(readiness_path)] = sha(readiness_path)
# Reuse the already accepted stable segment only while the actual native title
# projection is byte-identical. A newly changed clip needs a new review rather
# than silently inheriting this historical screenshot window.
assert source_files['public/player/native-title.json'] == readiness['source']['sourceFiles']['public/player/native-title.json']
plan = {'schema': 'stella.scene10110003.saved-plan.v1', 'rootConfirmed': False,
        'sceneId': 10110003, 'sectionId': 'section:1011', 'start': steps[0]['id'],
        'steps': steps, 'sceneRows': 46, 'models': models,
        'allLibraryNodes': sum(len(load(DATA / s['path'])['scenario_list']) for s in manifest['scenes']),
        'recordedChoices': original_route['recordedChoices'], 'unknownBranches': original_route['unknownBranches'],
        'finish': original_route['finish'], 'forbiddenEnterPrefix': 'node:10120001:',
        'captureFormat': {'type': 'image/jpeg', 'quality': .9, 'viewport': {'width': 440, 'height': 900},
                          'count': 46, 'maximumCaptureBytes': 7000000},
        'captureReadiness': readiness['captureReadiness'],
        'acceptanceScope': 'Saved forty actor identities, explicit BG27 and one continuous recorded1–46 route with45internal edges+461 section-FINISH. No body/face/extra/tint/geometry/timing/FX/audio, unknown branches or whole scene/episode/goal acceptance.'}
write('capture-plan.json', plan)
write('input-binding.json', {'schema': 'stella.scene10110003.saved-inputs.v1', 'rootConfirmed': False,
      'dataRoot': str(DATA), 'sourceRoot': str(SOURCE), 'dataHead': release['publishedHead'], 'dataStatus': '',
      'revision': release['publishedHead'], 'revisionMeaning': 'Actual published ordinary Git commit',
      'dataInputs': {p: sha(DATA / p) for p in sorted(paths)}, 'protectedFirstThree': protected,
      'resourceAndSourceGuards': guards, 'globalGuards': global_guards, 'browserOwner': release['browserOwner'],
      'source': {'head': release['sourceHead'], 'status': release['sourceStatus'],
                 'sourceFiles': source_files, 'distFiles': dist_files},
      'planSha256': sha(HERE / 'capture-plan.json'), 'browserOrServerStarted': False})
print(json.dumps({'status': 'frozen-not-executed', 'dataHead': release['publishedHead'],
                  'sourceHead': release['sourceHead'], 'nodes': 46, 'models': models,
                  'dataInputs': len(paths), 'globalGuards': len(global_guards)}))
