// Ordinary saved-player input only. The complete program is returned by the
// real API and passed unchanged to its existing load protocol. Passive probes
// observe display ownership and GL submissions; they supply no actor, route,
// initial state, background, animation clock or replacement renderer.
import assert from 'node:assert/strict';
import {readFile,writeFile,appendFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {connect} from '../../stella-p30-firefox-20261120/bidi.mjs';
import {installRenderProbe} from '../../stella-p30-firefox-20261120/render-probe.mjs';
import {installEndingObserver} from '../episode5-silent54-saved-runtime-v2/ending-observer.mjs';
import {installCaptureReadiness} from '../episode5-silent54-saved-runtime-v2/capture-readiness.mjs';
const here=new URL('./',import.meta.url),origin='http://127.0.0.1:5198';
const output=process.env.STELLA_REVIEW_OUTPUT;assert.ok(output);
const load=async name=>JSON.parse(await readFile(new URL(name,here),'utf8'));
const plan=await load('capture-plan.json'),binding=await load('input-binding.json');
const offlinePrepare=await load('normal-prepare-receipt.json'),route=await load('normal-prepare-route-check.json');
assert.equal(offlinePrepare.status,200);
const driver=await connect(process.argv[2]);
const traces=[],records=[],errors=[],http=[],played=[],captures=[],actions=[],eventWrites=[];
let target,stage='connect',capabilities,prepared,panelConfig,totalCaptureBytes=0;
const save=async(name,value)=>writeFile(resolve(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
async function evaluate(fn,arg){
  const reply=await driver.call('script.evaluate',{target,awaitPromise:true,
    expression:`(async()=>JSON.stringify(await (${fn})(${JSON.stringify(arg)})))()`});
  if(reply.type!=='success')throw Error(reply.exceptionDetails?.text||'Firefox evaluation failed');
  return reply.result.type==='undefined'?null:JSON.parse(reply.result.value);
}
async function snapshot(){return evaluate(()=>{
  const geometry=id=>{const e=document.getElementById(id);return e.dataset.backgroundGeometry?JSON.parse(e.dataset.backgroundGeometry):null;};
  const panel=document.getElementById('subtitles'),actor=document.getElementById('actor'),quote=document.getElementById('choiceCanvas');
  return {epochMilliseconds:Date.now(),performanceMilliseconds:performance.now(),body:{...document.body.dataset},
    status:document.getElementById('status').textContent,accessibleText:document.getElementById('accessibleText').textContent,
    background:geometry('card'),backdrop:geometry('backdrop'),
    choiceGeometry:document.getElementById('viewport').dataset.choiceGeometry||null,
    actor:{visible:actor.checkVisibility({opacityProperty:true,visibilityProperty:true}),width:actor.width,height:actor.height},
    pictureHidden:document.getElementById('picture').hidden,
    card:{opacity:getComputedStyle(document.getElementById('cardMotion')).opacity},
    panel:{hidden:panel.hidden,opacity:getComputedStyle(panel).opacity,translate:getComputedStyle(panel).translate},
    choiceSurface:{hidden:quote.hidden,visible:quote.checkVisibility({opacityProperty:true,visibilityProperty:true}),
      opacity:getComputedStyle(quote).opacity,width:quote.width,height:quote.height},
    choices:[...document.querySelectorAll('#choices button')].map(e=>({edge:e.dataset.edge,text:e.textContent,
      disabled:e.disabled,selected:e.getAttribute('aria-pressed')})),advanceDisabled:document.getElementById('advance').disabled,
    render:window.reviewRenderProbe.snapshot(),observer:window.reviewEndingObserver.snapshot(),
    movie:{hidden:document.getElementById('movie').hidden,visible:document.getElementById('movie').checkVisibility({opacityProperty:true,visibilityProperty:true}),
      currentTime:document.getElementById('movie').currentTime,duration:Number.isFinite(document.getElementById('movie').duration)?document.getElementById('movie').duration:null,
      ended:document.getElementById('movie').ended,seeking:document.getElementById('movie').seeking,readyState:document.getElementById('movie').readyState,
      playbackRate:document.getElementById('movie').playbackRate,presentation:document.getElementById('movie').dataset.moviePresentation,
      fit:getComputedStyle(document.getElementById('movie')).objectFit,resource:document.getElementById('movie').currentSrc},
    titleLabel:document.querySelector('#storyFlow .native-title-content')?.getAttribute('aria-label')||''};
});}
async function click(selector){
  const point=await evaluate(selector=>{
    const e=document.querySelector(selector);if(!e||e.disabled||!e.checkVisibility())return null;
    e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();
    return {x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)};
  },selector);assert.ok(point,'Visible enabled ordinary control '+selector);
  actions.push({selector,before:await snapshot()});
  await driver.call('input.performActions',{context:target.context,actions:[{type:'pointer',id:'mouse',parameters:{pointerType:'mouse'},
    actions:[{type:'pointerMove',origin:'viewport',...point,duration:0},{type:'pointerDown',button:0},{type:'pointerUp',button:0}]}]});
  actions.at(-1).afterEpochMilliseconds=Date.now();
}
async function waitFor(fn,arg,timeout=45000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(errors.length)throw Error(errors.at(-1));
    const value=await evaluate(fn,arg);if(value)return value;
    for(const selector of ['#movieContinue','#voiceContinue']){
      const blocked=await evaluate(selector=>{const e=document.querySelector(selector);return e&&!e.hidden&&!e.disabled&&e.checkVisibility();},selector);
      if(blocked)await click(selector);
    }
    await delay(70);
  }
  throw Error('Ordinary player condition timed out at '+stage);
}
function parsed(prefix){return traces.filter(line=>line.startsWith(prefix)).map(line=>JSON.parse(line.slice(prefix.length)));}
async function waitTrace(test,timeout=15000){
  const end=Date.now()+timeout;
  while(Date.now()<end){if(errors.length)throw Error(errors.at(-1));const value=test();if(value)return value;await delay(50);}
  throw Error('Actual player event timed out at '+stage);
}
async function panelReady(step,node){
  const group=!node.speaker?panelConfig.player.panels.narration:node.character_image?panelConfig.player.panels.picture:panelConfig.player.panels.dialogue;
  const profile=panelConfig.transitions.panel_entries?.[group];
  if(!profile){assert.equal(parsed('STORY_PANEL_IN_START ').filter(e=>e.node===step.id).length,0);return {group,profile:null};}
  // Match the owning node/group/token rather than treating ENTER, ready phase
  // or an arbitrary elapsed delay as evidence that its panel became visible.
  const owner=await waitTrace(()=>parsed('STORY_PANEL_IN_START ').filter(e=>e.node===step.id).at(-1));
  assert.equal(owner.group,group);
  const complete=await waitTrace(()=>{
    assert.ok(!parsed('STORY_PANEL_IN_CANCELLED ').some(e=>e.group===group&&e.token===owner.token),'Owned panel cancelled');
    return parsed('STORY_PANEL_IN_COMPLETE ').find(e=>e.node===step.id&&e.group===group&&e.token===owner.token);
  });
  return {group,profile,owner,complete};
}
async function actorReady(step){
  assert.equal(traces.filter(e=>e.startsWith('STORY_DISPLAY_COMMIT '+step.id+' ')).at(-1),
    'STORY_DISPLAY_COMMIT '+step.id+' actor '+step.expectedModel);
  const before=await evaluate(()=>window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor'));
  assert.ok(before?.attached&&!before.lost);
  // Positive new draw submissions belong to the attached actor canvas. A
  // stale Subaru screenshot, an ENTER event or a scratch GL context cannot
  // satisfy Rom's gate. Actual pixels are reviewed independently after exit.
  return waitFor(draws=>{
    const e=window.reviewRenderProbe.snapshot().contexts.find(e=>e.canvas==='actor');
    return e?.attached&&!e.lost&&e.draws>draws+3&&document.getElementById('actor')
      .checkVisibility({opacityProperty:true,visibilityProperty:true})&&e;
  },before.draws,10000);
}

async function capture(step,gate=null){
  assert.ok(captures.length<46,'At most46 original JPEGs');
  const beforeReadiness=gate?await waitFor(({method,args})=>{
    const value=window.reviewCaptureReadiness[method](args);return value.ready?value:null;
  },gate,20000):null;
  const before=await snapshot();
  const shot=await driver.call('browsingContext.captureScreenshot',{context:target.context,origin:'viewport',
    format:{type:'image/jpeg',quality:plan.captureFormat.quality}});
  const bytes=Buffer.from(shot.data,'base64'),file='episode11-scene10110003-'+String(step.scenario).padStart(2,'0')+'.jpg';
  totalCaptureBytes+=bytes.length;assert.ok(totalCaptureBytes<=plan.captureFormat.maximumCaptureBytes);
  await writeFile(resolve(output,file),bytes,{flag:'wx'});
  const after=await snapshot();
  assert.equal(before.body.node,step.id);assert.equal(after.body.node,step.id);
  const afterReadiness=gate?await evaluate(({method,args})=>window.reviewCaptureReadiness[method](args),gate):null;
  if(gate){
    assert.ok(afterReadiness.ready,'Capture stays within its actual native title segment');
    assert.equal(beforeReadiness.generation,afterReadiness.generation);
    assert.equal(beforeReadiness.startSequence,afterReadiness.startSequence);
  }
  captures.push({scenario:step.scenario,file,bytes:bytes.length,
    sha256:createHash('sha256').update(bytes).digest('hex'),model:step.expectedModel,
    kind:step.kind,before,after,beforeReadiness,afterReadiness});
}
async function background(step){
  const scriptBackground=await waitTrace(()=>parsed('STORY_SCRIPT_BACKGROUND ').filter(e=>e.node===step.id).at(-1));
  const expected=route.nodes.find(e=>e.node.id===step.id);
  assert.equal(scriptBackground.effective,expected.expectedEffectiveBackground);
  return {scriptBackground,expected};
}
async function mediaEnded(step){
  const ended=await waitFor(id=>window.reviewMediaEvents.findLast(e=>e.node===id&&e.event==='ended'),step.id,45000);
  assert.equal(ended.trusted,true);assert.equal(ended.playbackRate,1);assert.equal(ended.seeking,false);
  assert.ok(Number.isFinite(ended.duration)&&ended.duration>0);
  assert.ok(Math.abs(ended.currentTime-ended.duration)<.001);
  assert.equal(ended.played.length,1);assert.equal(ended.played[0][0],0);
  assert.ok(Math.abs(ended.played[0][1]-ended.duration)<.001);
  const events=await evaluate(id=>window.reviewMediaEvents.filter(e=>e.node===id),step.id);
  assert.equal(events.filter(e=>e.event==='ended').length,1);
  assert.ok(events.every(e=>e.playbackRate===1&&!e.seeking&&!['seeking','seeked','error'].includes(e.event)));
  assert.ok(events.some(e=>e.event==='play')&&events.some(e=>e.event==='playing'));
  return {ended,events};
}
try{
  ({capabilities}=await driver.call('session.new',{capabilities:{}}));
  const {contexts}=await driver.call('browsingContext.getTree');target={context:contexts[0].context};
  driver.events((event,value)=>{
    if(event==='log.entryAdded'){
      const line=value.text||'';
      if(value.type==='javascript'||line.startsWith('STORY_PLAYER_ERROR'))errors.push(line);
      if(/^(?:STORY_|STELLA_|MODEL_|PREVIEW_|VOICE_)/.test(line)){
        traces.push(line);const row={sequence:traces.length-1,eventEpochMilliseconds:value.timestamp,observedEpochMilliseconds:Date.now(),line};
        records.push(row);eventWrites.push(appendFile(resolve(output,'events.jsonl'),JSON.stringify(row)+'\n')
          .catch(error=>errors.push(String(error))));
      }
    }
    if(event==='network.responseCompleted'){
      const url=new URL(value.response.url);
      if(url.origin===origin){const row={url:url.href,status:value.response.status,mimeType:value.response.mimeType,
        observedEpochMilliseconds:Date.now()};http.push(row);
        if(row.status>=400&&url.pathname!=='/favicon.ico')errors.push('HTTP '+row.status+' '+row.url);}
    }
  });
  await driver.call('session.subscribe',{events:['log.entryAdded','network.responseCompleted'],contexts:[target.context]});
  for(const fn of [installRenderProbe,installEndingObserver,installCaptureReadiness])
    await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:fn.toString()});
  await driver.call('script.addPreloadScript',{contexts:[target.context],functionDeclaration:(()=>{
    window.reviewTrustedInputs=[];window.reviewMediaEvents=[];
    document.addEventListener('click',event=>{const e=event.target.closest('button');if(e)window.reviewTrustedInputs.push({
      button:e.id,edge:e.dataset.edge,trusted:event.isTrusted,node:document.body.dataset.node,phase:document.body.dataset.phase,
      epochMilliseconds:Date.now(),performanceMilliseconds:performance.now()});},true);
    document.addEventListener('DOMContentLoaded',()=>{
      const video=document.getElementById('movie');
      for(const name of ['loadstart','loadedmetadata','loadeddata','canplay','play','playing','pause','waiting','stalled','ended',
        'seeking','seeked','ratechange','volumechange','timeupdate','error'])
        video.addEventListener(name,event=>window.reviewMediaEvents.push({event:name,node:document.body.dataset.node,
          trusted:event.isTrusted,eventTimestamp:event.timeStamp,epochMilliseconds:Date.now(),performanceMilliseconds:performance.now(),
          resource:video.currentSrc,currentTime:video.currentTime,duration:Number.isFinite(video.duration)?video.duration:null,
          playbackRate:video.playbackRate,seeking:video.seeking,ended:video.ended,paused:video.paused,muted:video.muted,volume:video.volume,
          played:Array.from({length:video.played.length},(_,i)=>[video.played.start(i),video.played.end(i)])}));
    },{once:true});
  }).toString()});
  await driver.call('browsingContext.setViewport',{context:target.context,viewport:plan.captureFormat.viewport,devicePixelRatio:1});
  stage='normal-setup';
  await driver.call('browsingContext.navigate',{context:target.context,url:origin+'/player/player.html?assetRevision='+binding.revision,wait:'interactive'});
  await waitFor(()=>window.reviewReady===true);
  await evaluate(()=>window.reviewEndingObserver.attachClock());
  await evaluate(()=>window.reviewEndingObserver.beginCase('episode11-scene10110003',{scope:'Saved identities/background/recorded route only'}));
  assert.equal(await evaluate(()=>document.getElementById('language').value),'zh');
  assert.equal(await evaluate(()=>document.getElementById('auto').getAttribute('aria-pressed')),'false');
  panelConfig=await evaluate(async()=>({player:await(await fetch('/player/player_config.json')).json(),
    transitions:await(await fetch('/player-assets/transitions.json')).json()}));
  stage='ordinary-saved-prepare';
  const actual=await evaluate(async({id,revision,expectedProgramSha256})=>{
    const response=await fetch('/api/player/prepare',{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({id,baseSha:revision,choices:{}})});
    const raw=await response.text();
    if(!response.ok)return {status:response.status,raw};
    const program=JSON.parse(raw),digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(program)));
    const programSha256=[...new Uint8Array(digest)].map(e=>e.toString(16).padStart(2,'0')).join('');
    if(programSha256!==expectedProgramSha256)return {status:response.status,raw,programSha256,loaded:false};
    window.postMessage({type:'stella-player-load',program},location.origin);
    return {status:response.status,raw,programSha256,loaded:true};
  },{id:plan.start,revision:binding.revision,expectedProgramSha256:offlinePrepare.programSha256});
  await writeFile(resolve(output,'normal-http-prepare.json.gz'),gzipSync(actual.raw),{flag:'wx'});
  assert.equal(actual.status,200);assert.equal(actual.loaded,true);assert.equal(actual.programSha256,offlinePrepare.programSha256);
  prepared=JSON.parse(actual.raw);assert.equal(prepared.start,plan.start);assert.equal(prepared.headSha,binding.revision);
  assert.equal(prepared.nodes.length,plan.allLibraryNodes);
  assert.equal(prepared.nodes.filter(e=>e.scene_id==='scene:10110003').length,46);
  for(const [index,step]of plan.steps.entries()){
    stage='node-'+step.scenario;
    await waitTrace(()=>traces.find(line=>line.startsWith('STORY_PLAYER_ENTER '+step.id+' ')),45000);
    const node=prepared.nodes.find(e=>e.id===step.id);assert.equal(node.model,step.expectedModel);
    if(node.kind==='title'){
      const decision=await waitTrace(()=>parsed('STORY_NATIVE_INTERVAL_DECISION ').find(e=>e.node===step.id));
      if(decision.show){
        await waitFor(id=>document.body.dataset.node===id&&document.body.dataset.phase==='chart',step.id);
        await click('#storyFlow footer button');
      }
      // TitleProc resolves its script background only after the optional
      // chart is released by its real continue button. Waiting for this log
      // before that input would deadlock an ordinary opening title.
      const bg=await background(step);
      const args={node:step.id,caseName:'episode11-scene10110003',...{
        referenceWidth:plan.captureReadiness.referenceWidth,stableStart:plan.captureReadiness.titleStableStart,
        stableEnd:plan.captureReadiness.titleStableEnd}};
      // The existing title helper observes its actual Normal clip and glyph
      // canvases. It does not hold the title, write time or delay its edge.
      await capture(step,{method:'title',args});
      const state=captures.at(-1).after;
      assert.equal(state.background?.resource||'',bg.expected.expectedDisplayBackground);
      assert.equal(state.backdrop?.resource||'',bg.expected.expectedDisplayBackground);
      const complete=await waitTrace(()=>parsed('STORY_NATIVE_TITLE_ENTRY ').find(e=>e.node===step.id&&e.stage==='completed'),20000);
      assert.equal(complete.durationMilliseconds,2500);
      played.push({scenario:step.scenario,id:step.id,kind:node.kind,titleDecision:decision,titleComplete:complete,...bg,state});
      continue; // TitleProc owns11 and461 automatically; no Advance race.
    }
    const bg=await background(step);
    if(node.kind==='movie'){
      const metadata=await waitTrace(()=>parsed('STORY_PLAYER_MOVIE ').find(e=>e.node===step.id),30000);
      assert.equal(metadata.resource,'adv_dive01_out');assert.equal(metadata.presentation,'door');
      assert.equal(metadata.fit,panelConfig.player.movies.door_fit);
      // Capture one naturally decoded middle interval, then wait for its real
      // browser ended event. No seeking, pause, rate edit or synthetic ended.
      const middle=await waitFor(id=>{
        const video=document.getElementById('movie'),card=document.getElementById('cardMotion');
        return document.body.dataset.node===id&&document.body.dataset.phase==='movie'&&video.readyState>=2&&
          Number.isFinite(video.duration)&&video.currentTime>=video.duration/3&&video.currentTime<video.duration*.8&&
          !video.ended&&!video.seeking&&video.playbackRate===1&&
          video.checkVisibility({opacityProperty:true,visibilityProperty:true})&&Number(getComputedStyle(card).opacity)>=.99&&
          {currentTime:video.currentTime,duration:video.duration,epochMilliseconds:Date.now()};
      },step.id,30000);
      await capture(step);
      const state=captures.at(-1).after;
      assert.equal(state.background?.resource,bg.expected.expectedDisplayBackground);
      assert.equal(state.backdrop?.resource,bg.expected.expectedDisplayBackground);
      assert.equal(state.movie.presentation,'door');assert.equal(state.body.phase,'movie');
      assert.equal(state.movie.ended,false);assert.ok(state.movie.currentTime<state.movie.duration*.9);
      assert.ok(traces.some(e=>e.startsWith('STORY_DISPLAY_COMMIT '+step.id+' movie ')));
      const natural=await mediaEnded(step);
      // The saved movie has empty text and command[2]: Wait,500 then CardOut.
      // Canonical afterText briefly sets ready, then automatically advances
      // its empty card after CardOut. That existing lifecycle owns451. Waiting
      // for a stable45-ready surface or clicking Advance here can instead hit
      // the automatically entered46 title. Keep the original commands, wait
      // for the actual451 event, and let the next loop observe ENTER46.
      const automaticMovieTransition=await waitTrace(()=>parsed('STORY_PLAYER_TRANSITION ')
        .find(e=>e.edge===route.edges[index].id),15000);
      assert.equal(automaticMovieTransition.target,plan.steps[index+1].id);
      assert.deepEqual(automaticMovieTransition.native,step.expectedTransition);
      assert.equal(actions.filter(e=>e.selector==='#advance'&&e.before.body.node===step.id).length,0);
      played.push({scenario:step.scenario,id:step.id,kind:node.kind,metadata,middle,natural,...bg,state,
        automaticMovieTransitionOwnsNext:true,automaticMovieTransition,noAdvanceInputForMovie:true});
      continue;
    }
    // Let every typewriter finish naturally. No input is issued from a sampled
    // text phase; an asynchronous click must never turn into an unintended edge.
    const choice=plan.recordedChoices.find(e=>e.scenarioId===step.scenario),wanted=choice?'choice':'ready';
    await waitFor(({id,wanted})=>document.body.dataset.node===id&&document.body.dataset.phase===wanted,{id:step.id,wanted});
    const panel=await panelReady(step,node);
    const visible=await waitFor(id=>{
      const card=document.getElementById('cardMotion'),panel=document.getElementById('subtitles'),a=getComputedStyle(card),p=getComputedStyle(panel);
      return document.body.dataset.node===id&&Number(a.opacity)>=.99&&Number(p.opacity)>=.99&&p.translate==='none'&&
        card.checkVisibility({opacityProperty:true,visibilityProperty:true})&&panel.checkVisibility({opacityProperty:true,visibilityProperty:true})&&
        {cardAlpha:a.opacity,panelAlpha:p.opacity,panelTranslate:p.translate,epochMilliseconds:Date.now()};
    },step.id);
    let render=null;
    if(step.expectedModel)render=await actorReady(step);
    else assert.ok(traces.filter(e=>e.startsWith('STORY_DISPLAY_COMMIT '+step.id+' ')).at(-1)
      ?.startsWith('STORY_DISPLAY_COMMIT '+step.id+' empty '));
    let state=await snapshot(),selected=null;
    assert.equal(state.background?.resource,bg.expected.expectedDisplayBackground);
    assert.equal(state.backdrop?.resource,bg.expected.expectedDisplayBackground);
    assert.equal(state.pictureHidden,true);
    // The shared GL canvas can remain attached/DOM-visible while Pixi hides
    // its model. Empty/movie display commits, rather than canvas visibility,
    // identify those nodes; actual absence is left to delegated pixel review.
    if(step.expectedModel)assert.equal(state.actor.visible,true);
    assert.ok(state.accessibleText.includes(step.native.msg_text));
    assert.equal(state.render.losses.filter(e=>e.canvas==='actor'||e.attached).length,0);
    if(choice){
      const missing=route.unknown.find(e=>e.source===step.id);assert.ok(missing);
      assert.ok(state.choices.find(e=>e.edge===missing.id)?.text.includes('未恢复'));
      assert.equal(state.advanceDisabled,true,'No default choice confirmation');
      const edge=route.edges[index];assert.equal(edge.label_translation,choice.label);assert.equal(edge.available,true);
      await click('#choices button[data-edge='+JSON.stringify(edge.id)+']');
      await waitFor(edge=>document.body.dataset.phase==='choice'&&!document.getElementById('advance').disabled&&
        [...document.querySelectorAll('#choices button')].some(e=>e.dataset.edge===edge&&e.getAttribute('aria-pressed')==='true'),edge.id);
      const quote=await waitTrace(()=>parsed('STORY_CHOICE_QUOTE ').filter(e=>e.edge===edge.id).at(-1));
      assert.equal(quote.language,'zh');
      const choiceGeometry=await waitFor(()=>{
        const raw=document.getElementById('viewport').dataset.choiceGeometry,value=raw&&JSON.parse(raw);
        return value?.pressed&&value.touch===1&&value;
      });
      render=await actorReady(step);state=await snapshot();
      assert.ok(state.accessibleText.includes(step.native.branch_list.find(e=>e.branch_id===choice.branchId).msg_quote));
      assert.equal(state.choiceSurface.visible,true);
      selected={edge,quote,choiceGeometry,state};
    }
    await capture(step);
    played.push({scenario:step.scenario,id:step.id,kind:node.kind,model:step.expectedModel,panel,visible,render,...bg,state,selected});
    await click('#advance');
    if(played.length%5===0)console.error('PLAYED '+played.length+'/46');
  }
  stage='section-complete';
  await waitFor(()=>document.body.dataset.phase==='complete',null,25000);
  const enters=traces.filter(line=>line.startsWith('STORY_PLAYER_ENTER ')).map(line=>line.split(' ')[1]);
  assert.deepEqual(enters,plan.steps.map(e=>e.id));
  assert.ok(!enters.some(e=>e.startsWith(plan.forbiddenEnterPrefix)));
  const transitions=parsed('STORY_PLAYER_TRANSITION ');assert.equal(transitions.length,46);
  for(const [index,event]of transitions.entries()){
    assert.equal(event.edge,route.edges[index].id);assert.deepEqual(event.native,plan.steps[index].expectedTransition);
    if(index<45){assert.equal(event.target,plan.steps[index+1].id);assert.equal(event.action,'continue');}
    else assert.equal(event.action,'section');
  }
  const completion=traces.filter(e=>e.startsWith('STORY_PLAYER_SECTION_COMPLETE '+plan.sectionId+' '));
  assert.equal(completion.length,1);
  assert.equal(played.length,46);assert.equal(captures.length,46);assert.equal(captures.filter(c=>c.model).length,40);
  const trustedInputs=await evaluate(()=>window.reviewTrustedInputs);assert.ok(trustedInputs.every(e=>e.trusted));
  const chosen=trustedInputs.filter(e=>e.edge);assert.deepEqual(chosen.map(e=>e.edge),plan.recordedChoices.map(c=>route.edges[c.scenarioId-1].id));
  const terminal=route.edges.at(-1);assert.equal(terminal.flow_action,'section');
  const finalState=await snapshot();assert.equal(finalState.body.phase,'complete');
  const endDecision=parsed('STORY_NATIVE_INTERVAL_DECISION ').find(e=>e.node===plan.steps.at(-1).id);
  const bgmCommand=await waitTrace(()=>parsed('STORY_BGM_COMMAND ').findLast(e=>e.resource==='bgm_btl_adv_win01'&&e.key===plan.steps.at(-1).id+':'+endDecision.generation));
  const bgmPlay=await waitTrace(()=>parsed('STORY_BGM_PLAY ').findLast(e=>e.resource==='bgm_btl_adv_win01'));
  assert.equal(bgmCommand.restart,false);assert.equal(bgmCommand.fade,1);
  assert.ok(bgmPlay.samples>0&&bgmPlay.sampleRate>0);
  const providerEvents=(await readFile(resolve(output,'provider-events.jsonl'),'utf8')).trim().split('\n').map(e=>JSON.parse(e));
  const modelDelivery={};
  for(const model of plan.models){
    const members=providerEvents.filter(e=>new RegExp('^assets/(?:preview/)?models/'+model+'/').test(e.relative));
    const definition=members.find(e=>e.relative.endsWith('/ac.model3.json')),moc=members.find(e=>e.relative.endsWith('.moc3')),
      texture=members.find(e=>e.relative.includes('/textures/'));
    assert.ok(definition&&moc&&texture,'Actual saved definition/MOC/texture '+model);
    modelDelivery[model]={definition,moc,texture,members};
  }
  const observer=await evaluate(()=>window.reviewEndingObserver.finish());
  assert.equal(observer.droppedRecords,0);assert.deepEqual(observer.observerErrors,[]);assert.deepEqual(errors,[]);
  await save('provider-proof.json',{modelDelivery,controller:providerEvents.filter(e=>e.relative==='assets/player/animation.json'),
    movie:providerEvents.filter(e=>e.relative.endsWith('/adv_dive01_out.mp4')),
    music:providerEvents.filter(e=>e.relative.includes('bgm_btl_adv_win01'))});
  await save('image-manifest.json',{format:'original-browser-viewport-jpeg',captures:captures.map(({scenario,file,bytes,sha256,model,kind})=>
    ({scenario,file,bytes,sha256,model,kind})),count:46,totalCaptureBytes,requiresIndependentClosureBeforeReview:true});
  await writeFile(resolve(output,'observer.json.gz'),gzipSync(JSON.stringify(observer)),{flag:'wx'});
  await save('result.json',{browser:capabilities.browserName,version:capabilities.browserVersion,
    prepared:{start:prepared.start,headSha:prepared.headSha,programSha256:actual.programSha256,before:prepared.before},
    played,captures,totalCaptureBytes,enters,transitions,finalState,actions,trustedInputs,panelConfig,traces,records,errors,http,modelDelivery,
    bgm:{command:bgmCommand,play:bgmPlay},completion,
    terminal:{edge:terminal,executed:true,destinationEntered:false},scope:plan.acceptanceScope,revision:binding.revision});
  console.log(JSON.stringify({entered:46,internalTransitions:45,sectionFinish:1,captures:46,totalCaptureBytes,errors}));
}catch(error){
  let state;try{state=await snapshot();}catch(e){state={observationFailure:String(e)};}
  let observer;try{observer=await evaluate(()=>window.reviewEndingObserver.finish());}catch(e){observer={observationFailure:String(e)};}
  await save('failure.json',{stage,error:String(error),stack:error.stack,played,captures,totalCaptureBytes,state,observer,traces,records,errors,http,actions});
  console.error(JSON.stringify({stage,error:String(error),played:played.length,captures:captures.length}));process.exitCode=1;
}finally{
  await Promise.all(eventWrites);await driver.call('session.end').catch(error=>console.error('SESSION_END '+String(error)));driver.close();
}
