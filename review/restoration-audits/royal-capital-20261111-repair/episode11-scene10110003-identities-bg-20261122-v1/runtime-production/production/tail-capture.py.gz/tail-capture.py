"""One root-released bounded log subscription and one ordinary POST replay.

Only new private artifacts are written. Existing browser/server processes are
neither started nor stopped. A literal readiness message emitted after Wrangler
observes WebSocket.OPEN gates the replay; timeout or CLI failure does not retry.
Raw CLI streams stay private, while the summary exposes only redacted selected
application/stack lines. Source logging can omit a stack; never invent one.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback
from urllib.parse import urlsplit, urlunsplit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CLI = ROOT / 'artifacts/stella-site-repair-source/.sites-checkout/node_modules/wrangler/wrangler-dist/cli.js'
HEAD = 'debef87397ac10976e6fad96b1d14b28297cd754'
TAG = 'episode11-prepare-tail-v1-attempt-1'
READY = 'Connected to stella-preview, waiting for logs...'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def processes():
    return subprocess.check_output(['ps', '-eo', 'pid,ppid,pgid,sid,comm'], text=True)


def group_members(pgid):
    return [line for line in processes().splitlines()[1:]
            if len(line.split()) >= 5 and int(line.split()[2]) == pgid]


def stop_owned(process, hard_deadline):
    # Signal only a new owned group. In particular, the already live browser
    # and its local server are unrelated to these diagnostic process groups.
    for sig, grace in [(signal.SIGINT, 4), (signal.SIGTERM, 2), (signal.SIGKILL, .5)]:
        if not group_members(process.pid):
            break
        try:
            os.killpg(process.pid, sig)
        except ProcessLookupError:
            break
        deadline = min(hard_deadline, time.monotonic() + grace)
        while group_members(process.pid) and time.monotonic() < deadline:
            process.poll()
            time.sleep(.05)
    process.poll()


def redact(text):
    # Raw evidence is unchanged. Only a separate shareable summary is redacted;
    # drop URL credentials/queries and common credential forms before exposing
    # application error text, which may contain an upstream body fragment.
    text = re.sub(r'\x1b\[[0-9;?]*[A-Za-z]', '', text)
    def safe_url(match):
        try:
            value = urlsplit(match[0])
            return urlunsplit((value.scheme, value.hostname or '', value.path, '', ''))
        except ValueError:
            return '[URL_REDACTED]'
    text = re.sub(r'https?://[^\s<>"\']+', safe_url, text)
    text = re.sub(r'(?i)(bearer|oauth_token|refresh_token|api[_-]?key|secret|authorization)\s*[:= ]+\S+', r'\1 [REDACTED]', text)
    text = re.sub(r'\b(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)\b', '[REDACTED]', text)
    return re.sub(r'[A-Za-z0-9_+/=-]{32,}', lambda m: m[0] if m[0] in {
        HEAD, '9d39252bde3b57983fe9a1e9c563f891bb781622'} else '[LONG_VALUE_REDACTED]', text)


parser = argparse.ArgumentParser()
parser.add_argument('--release', required=True)
parser.add_argument('--release-sha256', required=True)
parser.add_argument('--attempt', required=True)
args = parser.parse_args()
assert args.attempt == 'attempt-1'
release_path = Path(args.release).resolve()
assert sha(release_path) == args.release_sha256
release = json.loads(release_path.read_text())
assert all(release[name] is True for name in ['rootConfirmed', 'executionAuthorized', 'tailAuthorized', 'singlePOSTReplayAuthorized'])
assert release['browserLaunchAuthorized'] is False
assert release['expectedHead'] == HEAD and release['diagnosticTag'] == TAG
assert release['sourceHead'] == '9d39252bde3b57983fe9a1e9c563f891bb781622'
assert release['maximumTailLifetimeSeconds'] == 50
assert os.getpriority(os.PRIO_PROCESS, 0) == 19 and sorted(os.sched_getaffinity(0)) == [0, 1]
assert release['guards']
for name in ['capture.py', 'replay.mjs', 'wrangler.tail.json', 'README.md']:
    relative = str((HERE / name).relative_to(ROOT))
    assert release['runtimeBindings'][relative] == sha(HERE / name), relative


def check_guards():
    for group in ['guards', 'runtimeBindings']:
        for path, digest in release[group].items():
            assert sha(ROOT / path) == digest, path


check_guards()
failure_http = ROOT / release['originalHTTPReceipt']
original = json.loads(failure_http.read_text())['records']
failed = original[-1]
assert failed['method'] == 'POST' and failed['status'] == 500 and failed['decodedResponseBytes'] == 84
assert failed['headers']['cf-ray'] == 'a5e0f8c0dae6f3db-SJC'
assert failed['request'] == {'id': 'node:10110003:1011000300001', 'baseSha': HEAD, 'choices': {}}
assert str(CLI.relative_to(ROOT)) in release['guards']
assert str(failure_http.relative_to(ROOT)) in release['guards']
for path in [
        'artifacts/stella-site-repair-source/.sites-checkout/lib/server.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/app/api/[...path]/route.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/lib/studio-api.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/lib/repository.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/lib/resources.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/lib/studio-native.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/lib/studio-state.ts',
        'artifacts/stella-site-repair-source/.sites-checkout/node_modules/wrangler/package.json',
        'artifacts/stella-script-continuation-20261121/data-checkout/native/scenes/10110003.json',
        'artifacts/stella-script-continuation-20261121/data-checkout/review/scenes/10110003.json',
        'artifacts/stella-script-continuation-20261121/data-checkout/manifest.json',
        'artifacts/stella-script-continuation-20261121/data-checkout/review/native-restoration.json',
        'artifacts/stella-script-continuation-20261121/episode11-production-readback-rootfalse-v1/attempt-1/failure.json',
        'artifacts/stella-script-continuation-20261121/episode11-production-readback-rootfalse-v1/attempt-1/normal-saved-player-prepare.response.gz']:
    assert path in release['guards'], path
os.umask(0o077)
out = HERE / args.attempt
out.mkdir()
write(out / 'release-binding.json', {'path': str(release_path), 'sha256': sha(release_path)})
write(out / 'replay-request.json', failed['request'])
(out / 'processes-before.txt').write_text(processes())
owned, handles, streams = [], {}, []
ready = replayed = False
status = 1
started = None
try:
    env = os.environ.copy()
    env.update(CI='true', NO_COLOR='1', FORCE_COLOR='0', WRANGLER_SEND_METRICS='false',
               WRANGLER_WRITE_LOGS='false', WRANGLER_CACHE_DIR=str(out / 'cache'),
               WRANGLER_LOG_PATH=str(out / 'private-wrangler-log'),
               STELLA_TAIL_OUTPUT=str(out), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    command = ['node', '--no-warnings', '--experimental-vm-modules', str(CLI), 'tail', 'stella-preview',
               '--config', str(HERE / 'wrangler.tail.json'), '--format', 'pretty', '--method', 'POST',
               '--header', 'x-stella-diagnostic:' + TAG]
    write(out / 'tail-command.json', {'argv': command, 'cwd': str(out), 'credentialValuesRecorded': False,
          'maximumTailLifetimeSeconds': 50, 'readyDeadlineSeconds': 15, 'POSTDeadlineMilliseconds': 20000,
          'cleanupBeginsBySeconds': 43, 'statusFilter': None, 'samplingRateOptionOmitted': True})
    stdout = (out / 'tail.stdout.private.log').open('xb', buffering=0)
    stderr = (out / 'tail.stderr.private.log').open('xb', buffering=0)
    streams += [stdout, stderr]
    started = time.monotonic()
    tail = subprocess.Popen(command, cwd=out, env=env, stdin=subprocess.DEVNULL,
                            stdout=stdout, stderr=stderr, start_new_session=True)
    owned.append(('tail', tail))
    handles['tail'] = {'pid': tail.pid, 'pgid': tail.pid}
    write(out / 'handles.json', handles)
    print('HANDLES ' + json.dumps(handles), flush=True)
    while time.monotonic() < started + 15 and tail.poll() is None:
        # Inspect only the literal marker; never forward arbitrary CLI output
        # or auth diagnostics to the model/user during connection setup.
        if READY.encode() in (out / 'tail.stdout.private.log').read_bytes():
            ready = True
            break
        time.sleep(.1)
    assert ready and tail.poll() is None, 'Tail did not reach actual OPEN readiness; no POST sent'
    write(out / 'tail-ready.json', {'actualReadyMarker': READY, 'ready': True,
          'elapsedSeconds': time.monotonic() - started, 'UTC': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    print('TAIL_READY true', flush=True)
    replay_log = (out / 'replay.private.log').open('xb')
    streams.append(replay_log)
    replay = subprocess.Popen(['node', str(HERE / 'replay.mjs')], cwd=out, env=env,
                              stdin=subprocess.DEVNULL, stdout=replay_log, stderr=subprocess.STDOUT, start_new_session=True)
    owned.append(('replay', replay))
    replayed = True
    handles['replay'] = {'pid': replay.pid, 'pgid': replay.pid}
    write(out / 'replay-handles.json', handles)
    print('HANDLES ' + json.dumps(handles), flush=True)
    replay.wait(timeout=max(.1, started + 36 - time.monotonic()))
    assert replay.returncode == 0, 'One POST transport/recording failed; exact bytes retained'
    until = min(started + 43, time.monotonic() + 8)
    while time.monotonic() < until and tail.poll() is None:
        time.sleep(.1)
    status = 0
except BaseException as error:
    write(out / 'failure.json', {'error': redact(str(error)), 'traceback': redact(traceback.format_exc()),
          'tailReady': ready, 'POSTReplayStarted': replayed, 'automaticRetries': 0})
finally:
    hard_deadline = (started + 50) if started is not None else time.monotonic()
    for _, process in reversed(owned):
        stop_owned(process, hard_deadline)
    for stream in streams:
        stream.close()
    capture_seconds = time.monotonic() - started if started is not None else 0
    remaining = [{'role': role, 'pid': process.pid, 'pgid': process.pid, 'exitCode': process.poll(),
                  'remaining': group_members(process.pid)} for role, process in owned]
    guard_error = None
    try:
        check_guards()
    except Exception as error:
        guard_error = str(error)
        status = 1
    if any(row['remaining'] for row in remaining) or capture_seconds > 50:
        status = 1
    (out / 'processes-after.txt').write_text(processes())
    write(out / 'process-exit.json', {'owned': remaining, 'allOwnedGroupsEmpty': all(not row['remaining'] for row in remaining),
          'tailReady': ready, 'POSTReplayStarted': replayed, 'automaticRetries': 0, 'captureSeconds': capture_seconds,
          'maximumSeconds': 50, 'inputsUnchanged': guard_error is None, 'guardError': guard_error,
          'existingBrowserOrServerTouched': False, 'browserStarted': False, 'serverStarted': False, 'exitCode': status})
    selected = []
    for filename in ['tail.stdout.private.log', 'tail.stderr.private.log']:
        if not (out / filename).exists():
            continue
        for number, line in enumerate((out / filename).read_text(errors='replace').splitlines(), 1):
            if any(marker in line for marker in ['STELLA_REQUEST_FAILED', 'STELLA_ASSET_CATALOG_READ',
                   'STELLA_GITHUB_BLOB_BATCH_FAILED', 'GITHUB_REQUEST_FAILED', 'STELLA_PUBLIC_SOURCE',
                   'POST https://stella-preview.jaoushingan.com/api/player/prepare']) or re.match(r'^\s+at\s', line):
                selected.append({'file': filename, 'lineNumber': number, 'redactedPrintedText': redact(line)})
    write(out / 'safe-summary.json', {'tailReady': ready, 'POSTReplayStarted': replayed, 'selectedPrintedLines': selected,
          'rawStreamsPreservedUnchanged': True, 'rawFormat': 'Actual Wrangler pretty stdout/stderr, not full WebSocket JSON',
          'sourceCatchLogsMessageOnly': True, 'stackOrUpstreamPathNotInvented': True,
          'missingStackOrPathIsNotProofOfCause': True, 'existingBrowserOrServerTouched': False})
    print('CLOSURE ' + json.dumps({'exitCode': status, 'tailReady': ready, 'POSTReplayStarted': replayed,
          'captureSeconds': capture_seconds, 'allOwnedGroupsEmpty': all(not row['remaining'] for row in remaining),
          'inputsUnchanged': guard_error is None}), flush=True)
sys.exit(status)
