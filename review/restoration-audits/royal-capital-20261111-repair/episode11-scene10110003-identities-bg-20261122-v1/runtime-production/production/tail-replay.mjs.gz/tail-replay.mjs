// One ordinary replay after the supervisor has observed Wrangler OPEN. Do not
// repeat the successful GET, retry a POST, call resolve, or seed program state.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const output=process.env.STELLA_TAIL_OUTPUT;assert.ok(output);
const ready=JSON.parse(await readFile(resolve(output,'tail-ready.json'),'utf8'));assert.equal(ready.ready,true);
const request=JSON.parse(await readFile(resolve(output,'replay-request.json'),'utf8'));
assert.deepEqual(request,{id:'node:10110003:1011000300001',baseSha:'debef87397ac10976e6fad96b1d14b28297cd754',choices:{}});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const row={method:'POST',url:'https://stella-preview.jaoushingan.com/api/player/prepare',request,
 diagnosticHeader:'x-stella-diagnostic:episode11-prepare-tail-v1-attempt-1',startedUTC:new Date().toISOString(),
 deadlineMilliseconds:20000,retries:0,status:null,headers:null,bodyComplete:false};
const chunks=[];
try{
 const response=await fetch(row.url,{method:'POST',redirect:'manual',credentials:'omit',headers:{
  accept:'application/json','content-type':'application/json','accept-encoding':'identity',
  origin:'https://stella-preview.jaoushingan.com',
  'user-agent':'Mozilla/5.0 (X11; Linux aarch64; rv:159.0) Gecko/20100101 Firefox/159.0',
  'x-stella-diagnostic':'episode11-prepare-tail-v1-attempt-1'},body:JSON.stringify(request),signal:AbortSignal.timeout(20000)});
 row.status=response.status;row.statusText=response.statusText;row.headers=Object.fromEntries(response.headers.entries());
 if(response.body)for await(const chunk of response.body)chunks.push(Buffer.from(chunk));
 row.bodyComplete=true;
}catch(error){
 row.transportError={name:error.name,message:error.message,cause:error.cause?{name:error.cause.name,message:error.cause.message,code:error.cause.code}:null};
 process.exitCode=1;
}finally{
 const raw=Buffer.concat(chunks),compressed=gzipSync(raw);assert.ok(gunzipSync(compressed).equals(raw));
 row.bodyBytes=raw.length;row.bodySha256=sha(raw);row.gzipFile='single-replay.response.gz';
 row.gzipSha256=sha(compressed);row.finishedUTC=new Date().toISOString();
 await writeFile(resolve(output,row.gzipFile),compressed,{flag:'wx',mode:0o600});
 await writeFile(resolve(output,'single-replay-http.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx',mode:0o600});
 console.log(JSON.stringify({status:row.status,bodyBytes:raw.length,bodySha256:row.bodySha256,
  cfRay:row.headers?.['cf-ray']??null,bodyComplete:row.bodyComplete,retries:0}));
}
