"""Build a bounded, immutable browser resource package for the crowd pilot.

This exporter reads the existing extraction and authored scene references. It
does not run recognition, modify a Studio project, or publish anything. Native
script resource names remain the catalog keys; browser URLs are a separate
projection so preview encodings cannot become accidental game script fields.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import logging
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
import wave

from live2d_workbench.catalog import PairingCatalog
from .media import StoryMediaCatalog
from .motions import StoryMotionCatalog
from .paths import DEFAULT_STUDIO_CONFIG, load_studio_configuration


PILOT_SCENES = ("10010020", "10010001", "10010016", "10140002", "10140003")
MAXIMUM_FILE_BYTES = 100_000_000


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def relative_source(path: Path, root: Path) -> str:
    """Provenance must not publish the local user's absolute home directory."""
    return path.resolve().relative_to(root.resolve()).as_posix()


class AssetWriter:
    """Own output boundaries, atomic publication, and the package file index."""

    def __init__(self, output: Path, root: Path):
        self.output, self.root = output.resolve(), root.resolve()
        if self.output == self.root or self.output.is_relative_to(self.root / "data"):
            raise ValueError("Asset output must not replace the source or runtime data")
        self.output.mkdir(parents=True, exist_ok=True)
        self.files: dict[str, dict] = {}
        self.members: dict[str, str] = {}

    def target(self, name: str) -> Path:
        path = (self.output / name).resolve()
        if not path.is_relative_to(self.output) or path == self.output:
            raise ValueError("Asset output path escapes its package: " + name)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def record(self, name: str, source: Path | None = None, **details):
        path = self.target(name)
        size = path.stat().st_size
        if not 0 < size < MAXIMUM_FILE_BYTES:
            raise ValueError(f"Invalid public asset size: {name} ({size} bytes)")
        row = dict(bytes=size, sha256=sha256(path), **details)
        if source is not None:
            row.update(source=relative_source(source, self.root), source_sha256=sha256(source))
        self.files[name] = row
        return name

    def copy(self, source: Path, name: str, member: str | None = None):
        target = self.target(name)
        # Existing generated assets can be reused on an interrupted build.
        # The source digest is the identity, not a timestamp or a stale cache
        # hint. Originals are opened read-only and never changed in place.
        if not target.is_file() or sha256(target) != sha256(source):
            with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as temporary:
                temporary_path = Path(temporary.name)
                with source.open("rb") as stream:
                    shutil.copyfileobj(stream, temporary, 1024 * 1024)
            os.replace(temporary_path, target)
        self.record(name, source)
        if member is not None:
            self.members[member] = name
        return name

    def json(self, name: str, document, source: Path | None = None):
        target = self.target(name)
        payload = (json.dumps(document, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
        with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as temporary:
            temporary.write(payload)
            temporary_path = Path(temporary.name)
        os.replace(temporary_path, target)
        return self.record(name, source)

    def existing_references(self, document, directory: Path):
        """Find only manifest-named extracted files, never copy a resource tree.

        Resource manifests also contain diagnostic source paths. Resolve each
        candidate below the extraction directory and require an actual file,
        which excludes native archives, absolute paths, and unrelated data.
        """
        if isinstance(document, dict):
            for value in document.values():
                yield from self.existing_references(value, directory)
        elif isinstance(document, list):
            for value in document:
                yield from self.existing_references(value, directory)
        elif isinstance(document, str):
            path = (directory / document).resolve()
            if path.is_relative_to(directory.resolve()) and path.is_file():
                yield path.relative_to(directory).as_posix()


class PilotReferences:
    """Collect resource identities from the selected authored scenes only."""

    def __init__(self, project: dict, scene_ids: tuple[str, ...], *, include_candidates=False,
                 full_directory=False, include_evidence=False):
        self.scene_ids = scene_ids
        videos = {row["id"]: row for row in project["videos"]
                  if row["workspace_scene"].removeprefix("scene:") in scene_ids}
        represented = {row["workspace_scene"].removeprefix("scene:") for row in videos.values()}
        if represented != set(scene_ids):
            raise ValueError("Pilot scenes missing recordings: " + str(set(scene_ids) - represented))
        self.nodes = [row for row in project["nodes"]
                      if row["video_id"] in videos and row["review_state"] != "excluded"]
        self.models = {row["model"] for row in self.nodes if row["model"]}
        self.models.update(actor["model"] for row in self.nodes for actor in row.get("actors", []))
        self.backgrounds = {row["bg_picture"] for row in self.nodes if row["bg_picture"]}
        self.music = {row["bg_music"].split(",", 1)[0] for row in self.nodes if row["bg_music"]}
        self.pictures = {row["character_image"] for row in self.nodes if row["character_image"]}
        self.movies = {row["movie_resource"] for row in self.nodes if row["movie_resource"]}
        self.banks = {row["bank"] for row in self.nodes if row["bank"]}
        if include_candidates:
            # Suggestions remain unapplied review evidence. Package only their
            # referenced resources so a reviewer can inspect and choose them
            # online without silently replacing the authored selection.
            for node in self.nodes:
                for kind in ("model", "body", "face", "cast"):
                    self.models.update(row["model"] for row in node["candidates"].get(kind, []) if row.get("model"))
                self.backgrounds.update(row["id"] for row in node["candidates"].get("background", []) if row.get("id"))
                self.music.update(row["id"] for row in node["candidates"].get("bgm", []) if row.get("id"))
                self.banks.update(row["bank"] for row in node["candidates"].get("voice", []) if row.get("bank"))
        blocks = [block for row in self.nodes for block in row["command"]]
        self.sounds = self.command_resources(blocks, ("SE", "StopSE"))
        self.effects = self.command_resources(blocks, ("PlayFX", "FX"))
        entries = {row["id"]: row for row in project["directory"]["entries"]}
        self.sections = {entries["scene:" + scene]["parent"].removeprefix("section:")
                         for scene in scene_ids}
        self.thumbnail_ids = {"scene": set(scene_ids), "section": self.sections}
        if full_directory:
            self.thumbnail_ids = {kind: {row["native_id"] for row in entries.values() if row["kind"] == kind}
                                  for kind in ("scene", "section")}
        self.evidence_nodes = self.nodes if include_evidence else []

    @staticmethod
    def command_resources(blocks, commands):
        names = "|".join(re.escape(command) for command in commands)
        pattern = re.compile(r'(?:^|\n|<BR>)(?:' + names + r'),\s*"([^"]+)"')
        return {match.group(1) for block in blocks for match in pattern.finditer(block)}


class MusicPreviewExporter:
    """Make bounded web previews while preserving ACB waveform timing metadata."""

    def __init__(self, writer: AssetWriter, bitrate: str):
        if not re.fullmatch(r"[1-9][0-9]{1,2}k", bitrate):
            raise ValueError("Expected an explicit audio bitrate, for example 128k")
        self.writer, self.bitrate = writer, bitrate

    @staticmethod
    def decoded_frames(path: Path, channels: int):
        # Container duration can include Opus pre-skip. Count decoded PCM
        # instead so an encoder delay cannot silently move the intro or put a
        # native loop endpoint outside the waveform used by Web Audio.
        process = subprocess.Popen(["ffmpeg", "-v", "error", "-threads", "1", "-i", str(path),
                                    "-f", "s16le", "-acodec", "pcm_s16le", "-"],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        count = 0
        assert process.stdout is not None
        for chunk in iter(lambda: process.stdout.read(1024 * 1024), b""):
            count += len(chunk)
        error = process.stderr.read().decode() if process.stderr is not None else ""
        if process.wait() != 0:
            raise RuntimeError("Preview decode failed: " + error)
        if count % (2 * channels):
            raise ValueError("Decoded preview does not contain complete PCM frames")
        return count // (2 * channels)

    def export(self, resource: str, source: Path, native: dict):
        with wave.open(str(source)) as stream:
            channels = stream.getnchannels()
            if stream.getframerate() != native["sample_rate"] or stream.getnframes() < native["samples"]:
                raise ValueError("Native waveform does not fit its decoded source: " + resource)
        target_name = "music/" + resource + ".opus"
        target = self.writer.target(target_name)
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".opus", delete=False) as temporary:
            temporary_path = Path(temporary.name)
        try:
            # Trim in the original sample domain before the Opus resampler.
            # The extracted WAV has extra loop repetitions and a decoder fade;
            # those are preview artifacts, not part of the native waveform.
            # Keep both decoding/filtering and encoding bounded. Asset builds
            # run alongside recording review and must not create an implicit
            # worker pool merely because the source codec permits threading.
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-threads", "1", "-filter_threads", "1",
                            "-i", str(source), "-map", "0:a:0",
                            "-af", f"atrim=end_sample={native['samples']},asetpts=PTS-STARTPTS",
                            "-ar", "48000", "-ac", str(channels), "-c:a", "libopus",
                            "-b:a", self.bitrate, "-vbr", "on", "-threads", "1", "-map_metadata", "-1",
                            str(temporary_path)], check=True)
            frames = self.decoded_frames(temporary_path, channels)
            duration = frames / 48000
            expected_duration = native["samples"] / native["sample_rate"]
            if abs(duration - expected_duration) > 1 / 48000 + 1e-8:
                raise ValueError("Encoded preview changed native duration: " + resource)
            if native["loop"] and not 0 <= native["loop_start"] < native["loop_end"] <= duration + 1 / 48000:
                raise ValueError("Native loop is outside encoded preview: " + resource)
            os.replace(temporary_path, target)
        finally:
            temporary_path.unlink(missing_ok=True)
        preview = dict(codec="opus", sample_rate=48000, decoded_samples=frames,
                       channels=channels, duration=duration, bitrate=self.bitrate)
        self.writer.record(target_name, source, transform=dict(kind="native_waveform_opus", **preview))
        metadata_url = self.writer.json("music/" + resource + ".json", native)
        logging.info("CROWD_ASSET_MUSIC id=%s native_samples=%d decoded_samples=%d bytes=%d",
                     resource, native["samples"], frames, target.stat().st_size)
        return dict(label=resource, url=target_name, metadata_url=metadata_url,
                    metadata=native, preview=preview)


class PilotAssetPackage:
    """Coordinate independent model, media, audio and player exporters."""

    def __init__(self, root: Path, config: dict, project: dict, writer: AssetWriter,
                 references: PilotReferences, bitrate: str):
        self.root, self.config, self.writer, self.refs = root, config, writer, references
        self.catalog = PairingCatalog(root / config["pairing_config"])
        self.media = StoryMediaCatalog(self.catalog, config["media"])
        self.motions = StoryMotionCatalog(self.catalog, config["motion_names"], config["semantics"]["motion_layers"])
        self.music_exporter = MusicPreviewExporter(writer, bitrate)
        self.project_revision = project["revision"]

    def copied_member(self, member: str, name: str):
        return self.writer.copy(self.catalog.archive.path(member), name, member)

    def models(self):
        rows = {}
        for model in sorted(self.refs.models):
            detail = self.motions.detail(model)
            prefix = self.catalog.layout["models"] + "ac_" + model + "/"
            for member in sorted(self.catalog.members):
                if member.startswith(prefix):
                    self.copied_member(member, "models/" + model + "/" + member.removeprefix(prefix))

            def projected(row):
                return dict(row, url=self.writer.members[row["member"]])

            native_id = "live2d/AC_" + model
            detail_url = self.writer.json("models/" + model + "/detail.json", detail)
            row = dict(id=model, native_id=native_id, label=detail["name"],
                       model_url=self.writer.members[detail["member"]], member=detail["member"],
                       detail_url=detail_url,
                       motions=[projected(motion) for motion in detail["motions"]],
                       script_motions=[projected(motion) for motion in detail["script_motions"]],
                       motion_bindings={token: projected(motion) for token, motion in detail["motion_bindings"].items()},
                       controller_url="player/animation.json")
            if detail["portrait"]:
                row["portrait_url"] = self.copied_member(detail["portrait"],
                                                         "portraits/" + model + Path(detail["portrait"]).suffix)
            rows[native_id] = row
        return rows

    def media_rows(self, identities, catalog, directory):
        rows = {}
        for identity in sorted(identities):
            item = catalog[identity]
            member = item if isinstance(item, str) else item["member"]
            url = self.copied_member(member, directory + "/" + PurePosixPath(member).name)
            rows[identity] = dict(label=identity, url=url, member=member)
            if directory in ("backgrounds", "pictures"):
                rows[identity]["thumbnail_url"] = url
        return rows

    def voices(self):
        banks = {}
        for bank in sorted(self.refs.banks):
            rows = []
            for row in sorted(self.catalog.voices(bank), key=lambda item: item["cue"]):
                url = self.copied_member(row["member"], "voices/" + bank + "/" + row["cue"] + ".wav")
                rows.append(dict(row, url=url))
            detail_url = self.writer.json("voices/" + bank + "/index.json", rows)
            banks[bank] = dict(cues=rows, detail_url=detail_url)
        return banks

    def music(self):
        rows = {}
        for identity in sorted(self.refs.music):
            member = self.media.music[identity]["member"]
            rows[identity] = self.music_exporter.export(identity, self.catalog.archive.path(member),
                                                       self.media.music_metadata(identity))
            # Existing callers can still resolve an archive member to the
            # preview URL. Native script values remain the dictionary keys.
            self.writer.members[member] = rows[identity]["url"]
        return rows

    def sounds(self):
        rows = {row["cue"]: row for row in self.media.sound_effects}
        result = {}
        for identity in sorted(self.refs.sounds):
            row = deepcopy(rows[identity])
            if row.get("preview_error"):
                raise ValueError("Selected sound cannot be prepared: " + identity + ": " + row["preview_error"])
            row["url"] = self.copied_member(row["member"], "sounds/" + PurePosixPath(row["member"]).name)
            result[identity] = row
        return result

    def player(self, sounds):
        source = (self.root / self.config["player_assets"]).resolve()
        documents = {name: read_json(source / name) for name in
                     ("manifest.json", "animation.json", "lighting.json", "effects.json", "transitions.json", "sound-blocks.json")}
        documents["manifest.json"]["actors"] = {model: documents["manifest.json"]["actors"][model]
                                                  for model in sorted(self.refs.models)}
        documents["animation.json"]["models"] = {model: documents["animation.json"]["models"][model]
                                                   for model in sorted(self.refs.models)}
        documents["effects.json"]["resources"] = {identity: documents["effects.json"]["resources"][identity]
                                                   for identity in sorted(self.refs.effects)}
        # Item cutins use a logical /cutin URL in the desktop manifest. Those
        # are not files relative to the extracted player directory, so they
        # need an explicit catalog-owned resource projection for the website.
        # Native PlayFX command names are left intact in every game script.
        for resource in documents["effects.json"]["resources"].values():
            texture = resource.get("texture", "")
            if isinstance(texture, str) and texture.startswith("/cutin/"):
                identity = texture.removeprefix("/cutin/")
                member = self.media.cutins[identity]
                member = member if isinstance(member, str) else member["member"]
                name = self.copied_member(member, "cutins/" + PurePosixPath(member).name)
                resource["texture"] = "/resource/" + name
        waves = {wave_id for row in sounds.values() for key in ("block_program", "sequence_program")
                 for wave_id in row.get(key, {}).get("waves", {})}
        documents["sound-blocks.json"]["waves"] = {identity: documents["sound-blocks.json"]["waves"][identity]
                                                    for identity in sorted(waves, key=int)}
        for name, document in documents.items():
            self.writer.json("player/" + name, document, source / name)
        files = set().union(*(set(self.writer.existing_references(document, source))
                              for document in documents.values()))
        for name in sorted(files):
            self.writer.copy(source / name, "player/" + name)

        motion_source = self.root / self.catalog.config["motion_index"]
        motion_index = read_json(motion_source)
        motion_index["models"] = {model: motion_index["models"][model] for model in sorted(self.refs.models)}
        self.writer.json("player/motion_states.json", motion_index, motion_source)
        ui = self.root / "story_studio/ui"
        configuration = read_json(ui / "player_config.json")
        configuration.update(manifest="manifest.json", asset_root="./", speaker_translations="speaker_names_zh.json",
                             viewer_config="preview_config.json", animation_manifest="animation.json",
                             lighting_manifest="lighting.json")
        self.writer.json("player/player_config.json", configuration, ui / "player_config.json")
        for name in ("speaker_names_zh.json", "quake_clips.json"):
            self.writer.copy(ui / name, "player/" + name)
        self.writer.copy(self.root / "live2d_workbench/ui/preview_config.json", "player/preview_config.json")
        self.writer.copy(self.root / "story_studio/config/commands.json", "player/commands.json")
        # Each resource document keeps its existing local file references.
        # A web loader resolves those against that document's URL. This avoids
        # embedding a deployment hostname, and makes the package usable from
        # both a public asset host and a same-origin static route.
        return dict(manifest_url="player/manifest.json", animation_url="player/animation.json",
                    motion_states_url="player/motion_states.json", lighting_url="player/lighting.json",
                    effects_url="player/effects.json", transitions_url="player/transitions.json",
                    sound_blocks_url="player/sound-blocks.json", config_url="player/player_config.json",
                    preview_config_url="player/preview_config.json", commands_url="player/commands.json",
                    quake_url="player/quake_clips.json", speaker_names_url="player/speaker_names_zh.json",
                    relative_references="Resolve relative filenames against the containing JSON document URL")

    def thumbnails(self):
        result = {"scene": {}, "section": {}}
        for kind, identities in self.refs.thumbnail_ids.items():
            for identity in sorted(identities):
                member = self.media.directory_thumbnails[kind].get(identity)
                if not member:
                    logging.info("CROWD_THUMBNAIL_UNAVAILABLE kind=%s id=%s", kind, identity)
                    continue
                result[kind][identity] = self.copied_member(member, "thumbnails/" + kind + "/" + identity + ".png")
        return result

    def evidence(self):
        from .crowd_import import evidence_frame
        result = {}
        for node in self.refs.evidence_nodes:
            name = evidence_frame(node, self.root)
            if name:
                result[node["id"]] = self.writer.copy(Path(node["frame"]), name)
        return result

    def build(self, project_digest):
        result = dict(schema_version=1, url_base="All catalog URLs are relative to this catalog.json",
                      scenes=list(self.refs.scene_ids), source_project_revision=self.project_revision,
                      source_project_sha256=project_digest)
        logging.info("CROWD_ASSET_STAGE models=%d", len(self.refs.models))
        result["models"] = self.models()
        result["backgrounds"] = self.media_rows(self.refs.backgrounds, self.media.backgrounds, "backgrounds")
        result["pictures"] = self.media_rows(self.refs.pictures, self.media.pictures, "pictures")
        result["movies"] = self.media_rows(self.refs.movies, self.media.movies, "movies")
        logging.info("CROWD_ASSET_STAGE voices=%d", len(self.refs.banks))
        result["voices"] = self.voices()
        result["music"] = self.music()
        result["sound_effects"] = self.sounds()
        result["player"] = self.player(result["sound_effects"])
        result["thumbnails"] = self.thumbnails()
        result["evidence"] = self.evidence()
        result["members"] = dict(sorted(self.writer.members.items()))
        result["asset_members"] = result["members"]
        self.writer.json("catalog.json", result)
        self.validate(result)
        package = dict(schema_version=1, catalog="catalog.json", source_project_sha256=project_digest,
                       files=dict(sorted(self.writer.files.items())),
                       bytes=sum(row["bytes"] for row in self.writer.files.values()))
        self.writer.json("package.json", package)
        return result, package

    def validate(self, catalog):
        def walk(document):
            if isinstance(document, dict):
                for key, value in document.items():
                    if (key == "url" or key.endswith("_url")) and isinstance(value, str):
                        if value not in self.writer.files:
                            raise ValueError("Catalog URL is not in the package: " + value)
                    walk(value)
            elif isinstance(document, list):
                for value in document:
                    walk(value)

        walk(catalog)
        for model in catalog["models"].values():
            path = self.writer.target(model["model_url"])
            document = read_json(path)

            def check_reference(value):
                if isinstance(value, dict):
                    for item in value.values():
                        check_reference(item)
                elif isinstance(value, list):
                    for item in value:
                        check_reference(item)
                elif isinstance(value, str):
                    target = (path.parent / value).resolve()
                    if not target.is_relative_to(self.writer.output) or not target.is_file():
                        raise ValueError("Model reference is missing: " + value)

            check_reference(document["FileReferences"])
        for member, url in catalog["members"].items():
            if url not in self.writer.files:
                raise ValueError("Archive member has no packaged asset: " + member)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_STUDIO_CONFIG)
    parser.add_argument("--project", type=Path, default=Path("data/story_studio/project.json"))
    parser.add_argument("--output", type=Path, default=Path("story_crowd_data/assets"))
    parser.add_argument("--scene", action="append", dest="scenes")
    parser.add_argument("--music-bitrate", default="128k")
    parser.add_argument("--include-candidates", action="store_true")
    parser.add_argument("--full-directory", action="store_true")
    parser.add_argument("--include-evidence", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    root, config = load_studio_configuration(args.config)
    project_path = args.project if args.project.is_absolute() else root / args.project
    project_digest = sha256(project_path)
    project = read_json(project_path)
    output = args.output if args.output.is_absolute() else root / args.output
    writer = AssetWriter(output, root)
    refs = PilotReferences(project, tuple(args.scenes or PILOT_SCENES), include_candidates=args.include_candidates,
                           full_directory=args.full_directory, include_evidence=args.include_evidence)
    package = PilotAssetPackage(root, config, project, writer, refs, args.music_bitrate)
    try:
        catalog, index = package.build(project_digest)
        if sha256(project_path) != project_digest:
            raise ValueError("The project changed during asset packaging; rebuild against its new revision")
        print(json.dumps(dict(output=str(output), files=len(index["files"]), bytes=index["bytes"],
                              models=len(catalog["models"]), banks=len(catalog["voices"]),
                              voice_cues=sum(len(bank["cues"]) for bank in catalog["voices"].values()),
                              source_project_revision=project["revision"]), ensure_ascii=False))
    finally:
        package.catalog.close()


if __name__ == "__main__":
    main()
