# P32 ADV_still_004 additive resource stage

Prepared with the existing `story_studio.crowd_assets.AssetWriter` under this artifact directory only. No installer, native repair, browser, image decoding, OCR, D/C write, Git commit, or push was executed by this task.

Review `integration-plan.peer-reviewed.rootfalse.json` (SHA-256 `5cb86178a3426adee17b78086c10f1d15311d848583230bc91fb8f5f5e46287a`). Its expected base is `c90086d9b1a63caac72e829b295188914a4c4e54`. All root/install/execution flags remain false. `integration-plan.rootfalse.json` and `preparation-proof.rootfalse.json` record the pre-peer preparation; their pending peer status is historical. `source-peer-and-final-guards.rootfalse.json` binds the later independent acceptance without changing their bytes or the three staged files.

The independent review is `../p32-node74-cg004-independent-identity-rootfalse-20261127-v1/review.rootfalse.json`, SHA-256 `999bc262ecf8a6d2f7977daf1abba87d9fdb9ac4d1cdd9aeca5736b7ace47de7`. It accepts ADV_still_004 artwork resource identity from the original PNG, existing preview, and existing source frames. It does not accept a native row binding, loading behavior, crop, wipe, phase, timing, door, ending, or complete scene.

## Exact staged transaction

| Relative target under D/assets | Bytes | SHA-256 |
| --- | ---: | --- |
| pictures/ADV_still_004.png | 1,404,098 | f3ce1748b1f899a312094ce05db53908767c6672287bc74bb61812c15dcbe079 |
| catalog.json | 4,666,292 | f3c6909b51e85e57fea9354bb50f1077e65ba77762a07cf183f0f47d4552dbe2 |
| package.json | 1,994,023 | 85c78376761e9fe46f8532e7a53dee04b24206b379c60fc99915fe19a6a39002 |

Total staged physical bytes: 8,064,413. The PNG is the exact viewable original, 1536 x 2048 RGBA. The tracked 1536 x 2048 WebP is reused in place: 158,848 bytes, SHA-256 `ccca72b7ee3aed37cbf09451c242d991661a4713ff927390c34c60883a333201`, Git blob `cbe319fb8a0d9bf58b9abd0a3e428a648d7d496f`. No WebP is staged or reencoded; `assets/preview/catalog.json` remains byte-exact.

The main catalog adds only `pictures.ADV_still_004` and the corresponding `members` / `asset_members` entries. Removing those three additions restores the entire previous catalog object. All 18 old top-level sections and all old section entries were checked exactly. The new picture points to the existing WebP. Package metadata adds the exact original PNG and existing WebP records, and updates only the old `catalog.json` self-record. Every other old package record and other top-level field is unchanged. Package payload accounting is 547,307,835 -> 548,871,240 bytes, delta 1,563,405 = 1,404,098 + 158,848 + 459 catalog bytes. JSON whitespace reduction accounts for the smaller physical package metadata file; it is not a payload removal.

`preparation-proof.rootfalse.json` contains per-section equality, package totals, tool hashes, and the initial clean D / metadata / native / review guards. The peer addendum rechecked the same staged bytes and c900 metadata after peer review. This is a snapshot, not permission to reuse an obsolete HEAD. If D advances, root must prepare and inspect a fresh guarded derivative.

## Existing installation interface for root review

The existing helper is `/home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121/apply-asset-plan.py`, 3,500 bytes, SHA-256 `ff5ef8fa4a20ac5d5f222be7164b8bc961cafda5a4fc1cbeed235efb0322feb2`.

```sh
nice -n 19 taskset -c 0,1 /usr/bin/python -B \
  /home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121/apply-asset-plan.py \
  ROOT_APPROVED_PLAN_ABSOLUTE_PATH NEW_ROOT_RECEIPT_ABSOLUTE_PATH
```

There are exactly two positional arguments. The helper checks the HEAD, current metadata hashes, reused payload, old catalog entries, staged bytes, and readback; it writes payload before metadata. It does not enforce root flags itself. Root must review and explicitly authorize a new plan derivative with fresh guards before calling it. This task has not called it.

## Separate native field step

After normal resource installation, verification, commit, push, and exact ACK, derive a fresh one-leaf packet for `10470047` / node `74` / UID `1047004700074` / array index `73` / stable `s10470047-p32-at0922`. The existing source-only packet is `../p32-cg004-source-candidate-c90086d9-20261127-v1/node-fields.source-only.rootfalse.json`, SHA-256 `5cdff87b71c42658a5675a58b0756036eaa567ba08370ec4d77d79a0ab850b84`. Its nonempty `requiredAssetImports` remains intact until actual registration is published. Do not run that old packet directly.

Existing `review-explicit-visual-field-batch-v7.py` supports `--field character_image --count 1`; SHA-256 `019eace6abb930e91bff315a8761594142ff9e6155999c5aee3a2fde59f04e15`. A fresh packet must preserve all 13 current expected fields, the complete native row, JA / ZH text, UID, stable key, row count and complete 74-row order. The previous full native SHA is `c5bd179c665f72579416480a1999c119aa7221112561df956c04b015522cb21e`, review SHA `caed0d9a479882d411ba7edae41fa02ebcb4af0102ad64057e56345005b9bdde`. Branch 741 stays unresolved. No crop/wipe/phase/door/ending change is included.
