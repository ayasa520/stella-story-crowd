# Fresh P32 node 74 CG field candidate

The immutable input is `node-fields.rootfalse.json`, SHA-256 `658db8111212d525686f9714524644ee819b5cef7bc970ec8c82b73e5e2f200d`. Both metadata and resource evidence epochs are actual commit `e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5`. This is one rootfalse proposal: scene 10470047, scenario 74, arrayIndex 73, UID 1047004700074, stable `s10470047-p32-at0922`; change only blank `character_image` to `ADV_still_004`. JA `―おわり―` and ZH `——完——` are exact current sidecar/native values.

All 13 expected fields, the entire native row, full 74-element scenario ID order and full UID order were captured from the clean e572 checkout. Complete native bytes are also exact against c900. The explicit fresh sorted/compact UTF-8 scenario-array encoding and digest are recorded in `fresh-target-resource-guards.rootfalse.json`. An initial assertion against the historical guard's differently serialized array digest stopped before any new artifact directory existed. That old digest had no encoding declaration and was not reused; actual native bytes, complete target row, 74 IDs and 74 UIDs remained exact. This preparation issue is retained in the fresh guards.

`requiredAssetImports` is empty only after reading the real current catalog, both member mappings, package records, registered original PNG, existing WebP, and exact e572 Git blobs. The resource package's total byte accounting was recomputed. The independent art review `999bc262ecf8a6d2f7977daf1abba87d9fdb9ac4d1cdd9aeca5736b7ace47de7` remains art identity only. The normal resource install receipt is the real `../p32-cg004-assets-root-preparation-c90086d9-20261127-v1/install-receipt.json`, SHA-256 `6a0724fa8d25c9a2bc376ef86174f76a1ba1bbc73ceb57640f6dafd3eb2ea339`. Its postproof establishes exit 0, exact three resource writes, 283 other formal guards, and all 22 protected files. The local resource ACK records exact e572 main with return code 0; it was read without an external request.

The primary comparison document remains historical c900 evidence. Its bytes are still exact at e572. The new packet does not reinterpret that primary document as a fresh whole-scene acceptance. Plan paths and hashes are scalar `normalResourcePlanPath` / `normalResourcePlanSHA256`, so the v7 walker will not interpret logical plan change names as file references. Sealed refs use only actual files. The read-only reference check followed the existing v7 path/SHA reference syntax, without importing or invoking v7, native repair, installation or any business helper.

## Existing root preparation interface

`../review-explicit-visual-field-batch-v7.py` is unchanged, SHA-256 `019eace6abb930e91bff315a8761594142ff9e6155999c5aee3a2fde59f04e15`. Root may review the candidate and then run its normal preparation with fresh exact HEAD/clean guards. This task has not run it and has not authorized native changes.

```sh
nice -n 19 taskset -c 0,1 /usr/bin/python -B \
  /home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121/review-explicit-visual-field-batch-v7.py prepare \
  --candidate /home/rikka/Projects/stella/artifacts/stella-script-continuation-20261121/p32-node74-cg004-v7-input-e572f6da-20261127-v1/node-fields.rootfalse.json \
  --candidate-sha256 658db8111212d525686f9714524644ee819b5cef7bc970ec8c82b73e5e2f200d \
  --preparation NEW_ROOT_PREPARATION_ABSOLUTE_PATH \
  --evidence-base e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5 \
  --resource-evidence-base e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5 \
  --field character_image --count 1 --read-log NEW_ROOT_READ_LOG_ABSOLUTE_PATH
```

Both output directories must be new and A-owned; preparation must be an immediate child of A as required by the existing helper. Root must recheck the full 74-row order and complete current native/review row alongside the helper's 285 formal guards and 22 protected files. Branch 741 remains empty/pending; no wipe, crop, phase, timing, door, ending, motion, expression, or other field is accepted. Root must separately accept the intended current native binding; the art peer did not accept it.

## Existing production GET paths, source-inspected only

From canonical `app/resource/[...path]/route.ts`, `app/picture/[id]/route.ts`, and `lib/resources.ts`:

- Original PNG: `/resource/pictures/ADV_still_004.png?revision=e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5&quality=original` (1,404,098 bytes; `f3ce1748b1f899a312094ce05db53908767c6672287bc74bb61812c15dcbe079`).
- Existing WebP: `/resource/preview/pictures/ADV_still_004.webp?revision=e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5&quality=original` (158,848 bytes; `ccca72b7ee3aed37cbf09451c242d991661a4713ff927390c34c60883a333201`).
- Normal alias: `/picture/ADV_still_004?revision=e572f6da527f4e3fe3e6c61fbcadf98a4a21bec5` (Cloudflare defaults to preview).

`RAW_BASE` is `https://raw.githubusercontent.com/ayasa520/stella-story-crowd`; all three read the same pinned resource revision. No production request, browser, image interpretation, OCR, decode, D/C mutation, commit, or push was performed by this packet task.
