"""Independently close the one startup-logged runtime after its real terminal.

The owner receipt is only an input to this check, not proof of OS absence.
Re-read every frozen input through the existing full verifier and inspect
current PIDs, process groups, readable descendant markers, ports, the actual
assigned X display, and private state. Never signal unrelated processes or
claim unreadable foreign environments were inspected.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
from urllib.parse import urlparse

parser = argparse.ArgumentParser()
parser.add_argument('--original-session', type=int, required=True)
parser.add_argument('--original-exit-code', type=int, required=True)
parser.add_argument('--terminal-chunk', required=True)
args = parser.parse_args()
O = Path(__file__).resolve().parent
A = O.parent
B = A / 'mimi105-b1f1-lossless-owner-source-rootfalse-20261127-v5'
spec = importlib.util.spec_from_file_location('startup_logged_closure_common', B / 'common.py')
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
common.limits()
binding = common.load(B / 'frozen/binding.json',
    '5eca8e07d955d8c5d4ec0f18936b8055c322344a01e728ac0ece4ae01779e4a8')
release = common.load(O / 'runtime.root-approved.json',
    '381bc7d50b2e26207c2cfbcc87d0b24a8dc3a878cc0c0d02fa84975fb37a2047')
attempt = B / 'attempt-1'
handles = common.load(attempt / 'handles.json')
cleanup = common.load(attempt / 'owned-cleanup-gate.json')
assert handles['state'] == 'closed'
assert cleanup['allOwnedGroupsEmpty'] and not cleanup['cleanupErrors']
assert cleanup['allOwnedPidsAndPortsAbsent']
output = O / 'root-independent-input-closure'
output.mkdir()
verified = common.verify(binding, output, additional=release['runtimeBindings'])
owned_pids = {handles['supervisorPid'], *(item['pid'] for item in handles['owned'])}
owned_groups = {item['pgid'] for item in handles['owned']}
table = subprocess.check_output(['ps', '-eo', 'pid,ppid,pgid,comm'], text=True)
rows = [line.split(None, 3) for line in table.splitlines()[1:]]
assert not [row for row in rows if int(row[0]) in owned_pids or int(row[2]) in owned_groups]
assert not [row for row in rows if row[3] in {'firefox', 'Xvfb', 'ffmpeg'}]

temporary = handles['temporaryState']
markers = [str(B).encode(), str(O).encode(), temporary['root'].encode(),
           b'STELLA_BROWSER_OWNER=/root/ui_browser_owner']
matches, unreadable = [], []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        comm = (proc / 'comm').read_text().strip()
    except OSError:
        continue
    try:
        environment = (proc / 'environ').read_bytes()
    except PermissionError:
        unreadable.append({'pid': int(proc.name), 'comm': comm})
        continue
    except OSError:
        continue
    if any(marker in environment for marker in markers):
        matches.append({'pid': int(proc.name), 'comm': comm, 'source': 'readable environment'})
assert not matches, matches

ports = []
port_values = [5198]
if handles.get('address'):
    port_values.append(urlparse(handles['address']).port)
for port in port_values:
    with socket.socket() as client:
        client.settimeout(1)
        code = client.connect_ex(('127.0.0.1', port))
    assert code == 111, (port, code)
    ports.append({'port': port, 'connectEx': code, 'closed': True})
display = handles['display']
assert display.startswith(':') and display[1:].isdigit()
xsocket = '/tmp/.X11-unix/X' + display[1:]
xlock = '/tmp/.X' + display[1:] + '-lock'
assert not os.path.lexists(xsocket) and not os.path.lexists(xlock)
unix_rows = Path('/proc/net/unix').read_text().splitlines()
assert not [line for line in unix_rows if line.split()[-1:] in [[xsocket], ['@' + xsocket]]]
for name in ('root', 'profile', 'authority'):
    assert not os.path.lexists(temporary[name]), temporary[name]
result = {
    'schema': 'stella.mimi105-startup-logged.root-independent-runtime-closure.v1',
    'status': 'PASS_CLOSED_ORIGINAL_EXIT_RETAINED',
    'originalSession': args.original_session, 'originalExitCode': args.original_exit_code,
    'originalTerminalChunk': args.terminal_chunk,
    'fullInputsFreshVerified': verified,
    'ownedPidAndGroupAbsence': True, 'readableEscapedMarkersAbsent': True,
    'foreignEnvironPermissionLimits': unreadable,
    'unreadableForeignEnvironmentsClaimedInspected': False,
    'ports': ports, 'actualAssignedDisplay': display,
    'actualDisplayLockFilesystemAndUnixSocketAbsent': True,
    'privateProfileAuthorityDeleted': True, 'noLiveTestFirefoxXvfbFfmpeg': True,
    'userFloorpNotSignaledOrControlled': True, 'DWriteHold': False,
    'imagesViewed': False, 'losslessOrBodyFaceAccepted': False,
}
common.write(O / 'runtime.root-closure.json', result)
print(json.dumps({'closure': str(O / 'runtime.root-closure.json'),
    'sha256': common.sha(O / 'runtime.root-closure.json'),
    'originalExitCode': args.original_exit_code, 'DWriteHold': False}))
