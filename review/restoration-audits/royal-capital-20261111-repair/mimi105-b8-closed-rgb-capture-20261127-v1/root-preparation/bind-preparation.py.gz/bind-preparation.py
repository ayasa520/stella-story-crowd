"""Bind the reviewed v5 diagnostic to the actual published ARM inventory.

Root promotes the source-only template after collector32840/cd9df3 completed.
The SHA and34780 tracked count below are observed, never inferred from a prior
runtime. This preparation keeps browser authorization false; freezing and the
unchanged API preparation remain separate gates before one original run.

This writes only a new preparation release. It does not freeze a scene, call
an API, launch a browser, or accept a motion. The prior missing system-Xvfb
path is recorded explicitly; the preserved project-local ARM executable is
validated against its archive and current dynamic dependencies instead.
"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import os
import re
import struct
import subprocess
import tarfile

ROOT = Path('/home/rikka/Projects/stella')
A = ROOT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
B = A / 'mimi105-b1f1-lossless-owner-source-rootfalse-20261127-v5'
O = Path(__file__).resolve().parent

# Root-only promotion binds the same completed collector's SHA and count.
# No published file, program transform, gameplay clock or budget is inferred.
ROOT_EXECUTION_AUTHORIZED = True
EXPECTED_INVENTORY_SHA256 = 'fbb6896abf3b0fbe347c448b746099774d8506699ed15c14cedb43010e9fecf1'
EXPECTED_DATA_TRACKED_COUNT = 34780
EXPECTED_DATA_HEAD = '4d1d5a2233a5456b8b8fcdc39e472432cffe809c'
assert ROOT_EXECUTION_AUTHORIZED is True, 'ROOTFALSE binder template; root promotion required'
assert isinstance(EXPECTED_INVENTORY_SHA256, str) and re.fullmatch('[a-f0-9]{64}', EXPECTED_INVENTORY_SHA256)
assert type(EXPECTED_DATA_TRACKED_COUNT) is int and EXPECTED_DATA_TRACKED_COUNT > 0


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


# Use the reviewed first-read implementation, including its independent
# fallback when an archive sink fails, without importing a CLI entry point.
seal_raw = (B / 'receipt.rootfalse.json').read_bytes()
assert hashlib.sha256(seal_raw).hexdigest() == 'daf0909b3b050cfb99967dc62885664a5ff5df93e647eefd2c65b758d985faff'
try:
    kit = json.loads(seal_raw)
except json.JSONDecodeError as error:
    (O / 'binding-seal-first-read.raw.gz').write_bytes(gzip.compress(seal_raw, mtime=0))
    (O / 'binding-seal-exception-doc.gz').write_bytes(gzip.compress(error.doc.encode('utf-8', 'surrogatepass'), mtime=0))
    raise
common_ref = next(item for item in kit['payloads'] if Path(item['path']) == B / 'common.py')
assert (B / 'common.py').stat().st_size == common_ref['bytes']
assert sha(B / 'common.py') == common_ref['sha256']
spec = importlib.util.spec_from_file_location('mimi_root_read_only_common', B / 'common.py')
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)

inventory_path = O / 'inventory.rootfalse.json'
inventory = common.load(inventory_path, EXPECTED_INVENTORY_SHA256)
previous = common.load(A / 'ui31-root-preparation-2b79f247-20261126-v1/inventory.rootfalse.json',
    'f23aecfd00bb5e42750c67bb7967ad7f1414c44d3117bdeb5ab4d2f23b7135ad')
assert inventory['protectedFirstThree'] == previous['protectedFirstThree']
assert len(inventory['dataInputs']) == EXPECTED_DATA_TRACKED_COUNT
assert inventory['allTrackedActualBytesMatchedHeadBlobs']
assert len(inventory['sourceFiles']) == 312 and len(inventory['distFiles']) == 234
head = EXPECTED_DATA_HEAD
source = '6630ac70f17332efa031d021af00532d42307568'
assert inventory['dataHead'] == head and inventory['sourceHead'] == source
assert subprocess.check_output(['git', '-C', str(D), 'rev-parse', 'HEAD']).decode().strip() == head
assert subprocess.check_output(['git', '-C', str(D), 'status', '--short']) == b''

for item in kit['payloads']:
    assert Path(item['path']).stat().st_size == item['bytes'] and sha(item['path']) == item['sha256']
peer = A / 'mimi105-b1f1-lossless-owner-source-independent-peer-rootfalse-20261127-v5/review.rootfalse.json'
assert sha(peer) == 'de7b1fc4d6bf5e4544ad9984ddbc3dcc27e30279bde343f4c21f68c1dc9bc388'
assert not (B / 'frozen').exists()
release = common.load(B / 'root-inputs.draft.json')
release.update(rootConfirmed=True, freezeAuthorized=True, apiPreparationAuthorized=True,
    controlledNativeCandidateAuthorized=True, fullInventoryApproved=True,
    candidateSourcePeerAccepted=True, independentRunnerAccepted=True,
    browserLaunchAuthorized=False, finalDataHead=head, finalSourceHead=source,
    inventory={'path': str(inventory_path), 'bytes': inventory_path.stat().st_size, 'sha256': sha(inventory_path)},
    independentRunnerPeer={'path': str(peer), 'bytes': peer.stat().st_size, 'sha256': sha(peer)})
tool_paths = {'python': '/usr/bin/python3', 'node': '/usr/bin/node',
    'firefox': '/usr/lib/firefox/firefox', 'ffmpeg': '/usr/bin/ffmpeg',
    'xvfb': str(ROOT / 'artifacts/stella-p30-capture-tools-20261120/usr/bin/Xvfb')}
for name, launch in tool_paths.items():
    binary = Path(launch).resolve(strict=True)
    with binary.open('rb') as stream:
        header = stream.read(20)
    assert header[:6] == b'\x7fELF\x02\x01' and struct.unpack('<H', header[18:20])[0] == 183
    assert os.access(binary, os.X_OK)
    release['tools'][name] = {'launchPath': launch, 'binaryPath': str(binary), 'sha256': sha(binary)}
    if name in inventory['tools']:
        assert release['tools'][name]['sha256'] == inventory['tools'][name]['sha256']
    release['sourceGuards'][str(binary)] = sha(binary)

capture_tools = ROOT / 'artifacts/stella-p30-capture-tools-20261120'
archive = capture_tools / 'xorg-server-xvfb-21.1.26-1-aarch64.pkg.tar.xz'
with tarfile.open(archive, 'r:xz') as package:
    held = package.extractfile('usr/bin/Xvfb').read()
assert hashlib.sha256(held).hexdigest() == release['tools']['xvfb']['sha256']
dependencies = subprocess.run(['ldd', release['tools']['xvfb']['binaryPath']], capture_output=True, check=True)
assert b'not found' not in dependencies.stdout + dependencies.stderr
# The missing system Xvfb path was an OLD root assumption, not a failure of
# this fresh binding. Record current executable/package/dependency evidence.
observation = {'historicalCorrectionReceipt': str(A / 'mimi105-four-case-root-preparation-deb3093e-20261127-v1/observed-arm-tool-path-correction.json'),
    'observedExistingArmTool': release['tools']['xvfb'],
    'existingPackageSHA256': sha(archive), 'binaryExactlyMatchesExistingPackage': True,
    'dynamicDependenciesAllResolved': True, 'newPackageOrBrowserInstalled': False}
common.write(O / 'observed-arm-tool-paths.json', observation)
with (O / 'xvfb.dependencies.stdout.log').open('xb') as stream:
    stream.write(dependencies.stdout)
# B5 preserves B4's resource bounds: the same per-PID RSS sum is capped at
# 3 GiB while every existing budget observation enforces the 512 MiB system
# MemAvailable floor. This is neither an OOM diagnosis nor a continuous floor
# guarantee. The single-case RGB/lossless/LP2 capture policy is separately
# hash-bound; program, clocks, CPU affinity and full-source acceptance stay unchanged.
# This 60-second budget is only for the local verification host to become ready.
# It is not an authored story Wait or Actor/Normal-clock control, does not skip
# or parallelize the two full verifications, and does not promise 60 seconds
# will suffice. Reject bool/non-integer/zero/negative/over-cap values explicitly.
readiness = release['budgets']['workerReadinessSeconds']
assert type(readiness) is int and 0 < readiness <= 60
assert readiness == 60, 'This root draft allocates the reviewed 60-second policy'
release['budgets'].update(nodeHeapMiB=512, maximumOwnedRssBytes=3221225472,
    maximumOutputBytes=268435456, minimumAvailableMemoryBytes=536870912, diskReserveBytes=1610612736)
for name, expected in [
    ('episode9-mimi-first50-final-publication-receipt-20261126-v1.json', '02a6aaa6ac0c795dea435618694dd75ce7cf71a90745727f9c71c9905118ee9f'),
    ('episode9-mimi-last50-final-publication-receipt-20261127-v1.json', '7fe4c6490c0bfb2b74b6d983e240b1530afbfb7d3ac84b4992f4552b0e197c25'),
    ('chapter1-ui31-directory-final-publication-receipt-20261127-v1.json', '4fd418188bc4bb19d80f283942dc1b2028d118c52bd94153111c16a2b7fc1c26')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
for name, expected in [
    ('episode9-mimi67-voice-final-publication-receipt-20261127-v1.json', '941d87e7d676cd509ccc72c823ab7c41fb754413b892d3beb8753f5c082699d2'),
    ('chapter1-flow-and-episode13-cumulative-final-publication-receipt-20261127-v1.json', 'de9d3cfbcd00d95a6bfe6c5f410648e61b0f950fb15f56f106cc81efea26e59e'),
    ('mimi105-b4-final-publication-receipt-20261127-v1.json', '289e9cf4852a58b12cc85265570c53fb237b238f9a5d834c08beed5aee80f301')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# The closed failure and requested cleanup are authoritative publications.
# Bind their exact receipts without treating either as a motion acceptance or
# reusing the historical runtime release after the data HEAD changed.
for name, expected in [
    ('mimi105-b5-failed-startup-final-publication-receipt-20261127-v1.json', '6e4c13f007f7fa51e879e1863eccb7b8a346ac2284073ba12434b663c5ec7099'),
    ('investigation-temp-cleanup-final-receipt-20261127-v6.json', '1b91aef045953d58a925b719a26564eb6890eff697fafce814b7fdb99dc80ca8')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# The v4 source allocates 64 MiB to the single RGB recording, within the
# unchanged 256 MiB total output budget. The earlier 18 MB SIGXFSZ remains a
# failed capture; neither a larger file allowance nor this release accepts
# losslessness, complete source coverage or performance identity.
assert release['budgets']['videoBytesPerCase'] == 67108864
for name, expected in [
    ('mimi105-b6-recording-bound-final-publication-receipt-20261127-v1.json', 'a223ee234f3a5026916339418050bbdde816b851dc4e7db41ac084588163fe46'),
    ('p33-three-character-final-publication-receipt-20261127-v1.json', '47dd2e9e9d69ffc6d2f959d85159336ee9cb534a14dd46f27608b629ff8af434')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# These exact publications include the closed 21741 startup failure, both P32
# resource/field publications, and the normal Mimi100 voice save. Publication
# proofs do not accept the still-unreviewed B1F1 performance or authorize a browser.
for name, expected in [
    ('mimi105-b7-startup-deadline-final-publication-receipt-20261127-v1.json', 'a5a552c6b289af06bae88ec110d9129ce23cdd2b61d3fb2d49a30f10100d6b61'),
    ('p32-cg004-resource-final-publication-receipt-20261127-v1.json', '0b45af9b28de9f1d04c62e13cbeda36b8136eaec8daafb0bd826ace6146d146c'),
    ('p32-node74-cg004-final-publication-receipt-20261127-v1.json', '43c1e7ab931753f720180149194821dad273f5d040a9890dc414407c1276ac04'),
    ('mimi100-normal-voice-final-publication-receipt-20261127-v1.json', '0456664f0bf03d4ded3746bfbd6d664c34f660b5d628d7f0e8a675a88da90a0c')]:
    assert sha(A / name) == expected
    release['publicationGuards'][str(A / name)] = expected
# Bind this fresh root decision's producer as evidence; no old release, frozen
# document or runtime output is reused as current authorization.
release['sourceGuards'][str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
assert not (B / 'prepared').exists() and not (B / 'attempt-1').exists()
disk = os.statvfs(O)
assert disk.f_bavail * disk.f_frsize > release['budgets']['diskReserveBytes'] + release['budgets']['maximumOutputBytes']
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
assert available > release['budgets']['minimumAvailableMemoryBytes'] + 536870912
target = O / 'preparation.root-approved.json'
common.write(target, release)
print(json.dumps({'release': str(target), 'sha256': sha(target), 'fiveObservedArmToolsBound': True,
    'browserAuthorized': False, 'memoryAvailableBytes': available}))
