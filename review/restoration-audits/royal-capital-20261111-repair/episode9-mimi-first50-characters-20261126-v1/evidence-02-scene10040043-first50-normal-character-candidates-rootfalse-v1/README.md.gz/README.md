50 source/peer-agreed static character candidates, scene10040043. Only character changes; root flags false and baseSha/expectedHead null. This is a normal node_fields-shaped candidate, not an execution release.

All12 string fields plus command form the13 expected keys. Complete rows, UID/index/stable, JP/ZH, branches and order are guarded. The50 original full-frame files and positive original/D resources were byte-hashed; this assembler did not open images or run the importer. Source49 keeps the peer qualification: face occluded by a phone, distinctive Felt outfit positively visible. Choice UI portraits are not the actor.

All model-local files and portraits match package metadata. Existing shared player/animation.json is present, but its package entry differs; exact actual and declared hashes remain in resource-locks/validation. No metadata fix or motion acceptance is proposed.

Root must decide that existing shared-metadata boundary, fresh-bind final HEAD/manifest/ownership/global guards and separately approve the existing normal stage/audit/apply. No D/C/old evidence/Git/browser/API/decoder/renderer/business-helper operations were performed.
