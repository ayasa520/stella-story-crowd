"""Serialize this agent's completed, direct static-image review.

This writer only creates a new evidence packet beside the data checkout.  It
does not stage, install, edit native/review data, run media, or grant approval.
The observations below were entered after viewing each of the fifty original
full-frame JPEGs and the explicitly named original texture references.  Code
only binds those human observations to current rows and opaque file hashes.
"""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


PROJECT = Path('/home/rikka/Projects/stella')
A = PROJECT / 'artifacts/stella-script-continuation-20261121'
D = A / 'data-checkout'
OUT = A / 'scene10040043-first50-static-identity-source-rootfalse-v1'
OCR = PROJECT / 'data/native_recovery/royal-capital-20261110/ocr/31'
SOURCE = PROJECT / 'data/extracted_archives/limeos'
SCAN = A / 'chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json'
NATIVE = D / 'native/scenes/10040043.json'
REVIEW = D / 'review/scenes/10040043.json'
INDEX = OCR / 'root-review/index.json'
SEED = PROJECT / 'data/story_directory/seed.json'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def obj_digest(value):
    # The guard hashes the full object, including native branches and commands;
    # root must freshly rebind it before any ordinary staging/install operation.
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             separators=(',', ':')).encode())


def info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def load(path):
    return json.loads(path.read_text())


def write(name, data):
    path = OUT / name
    assert not path.exists(), 'Evidence files are immutable; choose a new packet.'
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return info(path)


# Manual identity observations are indexed by the candidate array offset, not
# by node number and not by speaker metadata.  Each label denotes visible main
# foreground geometry/costume in the original recording frame actually viewed.
observed = [
    'subaru01', 'mimi01', 'ricardo01', 'subaru01', 'mimi01',
    'felt01', 'felt01', 'subaru01', 'felt01', 'subaru01',
    'ricardo01', 'felt01', 'subaru01', 'felt01', 'ricardo01',
    'mimi01', 'subaru01', 'mimi01', 'mimi01', 'felt01',
    'subaru01', 'mimi01', 'mimi01', 'subaru01', 'felt01',
    'subaru01', 'mimi01', 'subaru01', 'ricardo01', 'mimi01',
    'felt01', 'felt01', 'subaru01', 'felt01', 'subaru01',
    'felt01', 'felt01', 'subaru01', 'subaru01', 'ricardo01',
    'subaru01', 'ricardo01', 'felt01', 'felt01', 'felt01',
    'ricardo01', 'felt01', 'felt01', 'subaru01', 'ricardo01',
]
positives = {
    'subaru01': ['gray-white zip-front tracksuit with dark long sleeves',
                 'orange standing collar and thin orange chest/shoulder trim',
                 'dark/orange N-shaped chest emblem and short dark spiked hair'],
    'mimi01': ['orange triangular cat ears and two short bell-tied braids',
               'white cape/robe with intact orange edging and wide sleeves',
               'red neck bow, two white pom-poms, orange/cream tail'],
    'ricardo01': ['large brown canine head and tall swept mane with side braids',
                  'bare muscular torso with dark pointed chest fur',
                  'black diagonal strap and red/black decorated shoulder guard'],
    'felt01': ['short blonde hair with crown braid and large dark bow',
               'red scarf, open brown sleeveless short vest and black bandeau',
               'bare midriff and brown gloves with pale fluffy cuffs'],
}
exclusions = {
    'subaru01': {
        'subaru_tshirt01': 'The viewed variant has a plain dark short-sleeved shirt and bare arms; the source main foreground visibly wears the zip-front light tracksuit and orange standing collar.',
        'subaru_tshirt02': 'The viewed variant has a plain dark shirt instead of the source light tracksuit chest panels, zipper and N emblem.',
    },
    'mimi01': {
        'mimi_musha01': 'The viewed variant contains dark/red armor, helmet crest and patterned yellow outerwear; source sleeves and cape are smooth white with orange trim.',
        'mimi_halloween01': 'The viewed variant contains purple hood and red frilled outerwear; those are absent from the source white/orange costume.',
        'mimi_after20y01': 'The viewed variant has visibly torn/notched cloak and sleeve edges; the source visible raised sleeves, cape edges and front panels are intact. This is a costume-texture distinction only.',
    },
    'ricardo01': {
        'ricardo_prison01': 'The viewed variant contains striped prison shirt/sleeves and restraints; source has bare chest, black cross-body strap and red/black shoulder armor.',
    },
    'felt01': {
        'felt_dress01': 'The viewed variant contains yellow/pale frilled dress, corset and white gloves; source has red scarf, open brown vest, black bandeau and brown fur-cuffed gloves.',
    },
}

assert sorted(os.sched_getaffinity(0)) == [0, 1]
assert os.getpriority(os.PRIO_PROCESS, 0) == 19
scan = load(SCAN)
scene = next(x for x in scan['scenes'] if x['sceneId'] == 10040043)
targets = scene['rows'][:50]
assert len(scene['rows']) == 100 and len(targets) == len(observed) == 50
native = load(NATIVE)
review = load(REVIEW)
events = {r['id']: r for r in load(INDEX)['events']}
native_rows = {r['scenario_id']: r for r in native['scenario_list']}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=D, text=True).strip()

approvals = {
    'rootConfirmed': False, 'rootApproved': False, 'installationApproved': False,
    'runtimeApproved': False, 'browserApproved': False, 'executionApproved': False,
    'publicationApproved': False, 'freshBindCompleted': False,
}
resource_names = list(positives) + [n for v in exclusions.values() for n in v]
resources = {}
for name in resource_names:
    detail_path = D / 'assets/models' / name / 'detail.json'
    detail = load(detail_path)
    original_descriptor = SOURCE / detail['member']
    data_descriptor = D / 'assets/models' / name / 'ac/ac.model3.json'
    original_refs = load(original_descriptor)['FileReferences']
    data_refs = load(data_descriptor)['FileReferences']
    pairs = [('descriptor', original_descriptor, data_descriptor),
             ('mocOpaqueBytes', original_descriptor.parent / original_refs['Moc'],
              data_descriptor.parent / data_refs['Moc'])]
    assert len(original_refs['Textures']) == len(data_refs['Textures']) == 1
    pairs.append(('texture_00', original_descriptor.parent / original_refs['Textures'][0],
                  data_descriptor.parent / data_refs['Textures'][0]))
    components = []
    for kind, source_path, data_path in pairs:
        source_info = info(source_path)
        # Some excluded costumes have catalog descriptors in D but their MOC
        # and texture payloads are deliberately not bundled.  Log that actual
        # absence; only the four positive candidate resources require a fully
        # present and byte-equal original-to-D chain for all three components.
        data_info = info(data_path) if data_path.is_file() else {
            'path': str(data_path), 'exists': False, 'bytes': None, 'sha256': None}
        components.append({'kind': kind, 'original': source_info, 'D': data_info,
                           'sameOpaqueBytes': (source_info['sha256'] == data_info['sha256'])
                           if data_info['sha256'] else None})
    resources[name] = {'modelId': name, 'nativeFieldValue': 'live2d/AC_' + name,
                       'DDetail': info(detail_path), 'sourceMember': detail['member'],
                       'components': components, 'originalTextureDirectlyViewed': True,
                       'mocParsedOrRendered': False,
                       'positiveVisualFeatures': positives.get(name),
                       'excludedReviewedVariants': exclusions.get(name, {}),
                       'notExhaustiveAllCostumesReview': True}
    if name in positives:
        assert all(c['sameOpaqueBytes'] for c in components), name

# The phone is an observed supplementary cut-in.  It must not be transcribed
# into character_image: this packet makes no command/layer/timing installation.
cutins = {}
for num in ['002', '006', '007', '012']:
    name = 'ADV_cutin_item' + num + '.png'
    source_path = SOURCE / 'LIMEOS/assets/downloadassets/assetbundle/images/adv_cutin' / name
    data_path = D / 'assets/cutins' / name
    si, di = info(source_path), info(data_path)
    assert si['sha256'] == di['sha256']
    cutins[num] = {'original': si, 'D': di, 'sameOpaqueBytes': True,
                   'originalImageDirectlyViewed': True}

rows, candidates = [], []
for offset, (target, model) in enumerate(zip(targets, observed)):
    sid = target['scenarioId']
    current = native_rows[sid]
    current_review = review['scenarios'][str(sid)]
    assert current['uniq_id'] == target['UID']
    assert current_review['stableKey'] == target['stableKey']
    assert current_review['sourceText'] == target['sourceText']
    assert current['msg_text'] == current_review['translation']
    assert current['character'] == current['character_image'] == ''
    recording = target['recordings'][0]
    assert recording in current_review['recordings']
    event = events[recording['ocrEventId']]
    assert event['source_video'] == recording['sourceVideo']
    assert event['source_sha256'] == recording['sourceSha256']
    assert event['crop'] == recording['frame']
    full_frame = Path(event['frame'])
    assert full_frame.is_relative_to(OCR / 'root-review/frames')
    view = info(full_frame)
    view.update({'sourceFrameTimeSecondsAsRecorded': event['source_frame_time'],
                 'sourceFrameIndexAsRecorded': event['frame_index'],
                 'timestampPrecision': 'Copied verbatim from existing root-review/index.json source_frame_time; indexed recording seconds, not a newly probed PTS or frame-exact boundary.',
                 'sourceIndex': str(INDEX), 'eventId': event['id'],
                 'sourceVideo': recording['sourceVideo'],
                 'sourceVideoSha256Inherited': recording['sourceSha256'],
                 'sourceVideoRehashedHere': False, 'sourceIndexAndReviewAgree': True,
                 'imageKind': 'original recording full frame, 480x856 JPEG',
                 'directlyViewedBy': '/root/scene43_identity_first50',
                 'viewedIndividuallyWithViewImage': True,
                 'usedSubtitleCropAsModelEvidence': False,
                 'usedSpeakerAsModelEvidence': False,
                 'usedSmallChoicePortraitAsModelEvidence': False})
    caveats = []
    local_positive = positives[model]
    if sid in (40, 48):
        caveats.append('Choice UI overlaps the lower foreground. Identity is read from the large central Felt card with blonde hair/dark bow, red scarf, open brown vest and exposed midriff; small Subaru choice portraits are excluded from evidence.')
    if sid == 49:
        local_positive = ['visible red scarf below the cut-in',
                          'open brown short vest over black bandeau and bare abdomen',
                          'brown gloves with pale fluffy cuffs on both visible arms']
        caveats.append('Phone cut-in obscures the face and upper torso. Felt costume identity is supported by the lower main foreground, not the speaker label. Original ADV_cutin_item006 matches the silver open clamshell phone, antenna, purple screen and black strap. No character_image or command/layer/timing candidate is signed.')
    guard = {'fullNativeRowCanonicalSha256': obj_digest(current),
             'fullReviewScenarioCanonicalSha256': obj_digest(current_review),
             'sourceText': current_review['sourceText'],
             'sourceTextUtf8Sha256': digest(current_review['sourceText'].encode()),
             'translation': current['msg_text'],
             'translationUtf8Sha256': digest(current['msg_text'].encode()),
             'currentCharacter': '', 'currentCharacterImage': ''}
    allowed = {'field': 'character', 'before': '', 'candidate': 'live2d/AC_' + model}
    row = {'candidateArrayOffset': offset, 'sceneId': 10040043,
           'scenarioId': sid, 'UID': target['UID'], 'stableKey': target['stableKey'],
           'currentNativeRow': current, 'currentReviewScenario': current_review,
           'guard': guard, 'originalCandidateRow': target,
           'sourceFullFrame': view, 'actualViewStatement': 'I directly viewed this individual original full frame. The observation is the visible large foreground costume/identity only; I did not review the complete entry sequence.',
           'visibleForeground': 'main Live2D character',
           'positiveVisualFeaturesActuallyVisible': local_positive,
           'resourceEvidenceRef': 'resources.json#/models/' + model,
           'originalToDComponents': resources[model]['components'],
           'reviewedVariantExclusions': exclusions[model],
           'decision': 'single-field-static-identity-candidate',
           'allowedCandidate': allowed, 'identityUnknown': False,
           'originalBlankHasDirectNoCharacterEvidence': False,
           'characterImageDecision': 'no candidate; remains unknown/unchanged',
           'caveats': caveats, 'fullEntryReviewed': False,
           'motionApproved': False, 'faceApproved': False,
           'additionalLayersApproved': False, 'phaseApproved': False,
           'timingApproved': False, 'wholeSceneApproved': False, **approvals}
    rows.append(row)
    candidates.append({'candidateArrayOffset': offset, 'sceneId': 10040043,
                       'scenarioId': sid, 'UID': target['UID'],
                       'stableKey': target['stableKey'], **allowed,
                       'guards': guard, 'fullFrame': view,
                       'ledgerRowOffset': offset,
                       'resourceEvidenceRef': row['resourceEvidenceRef'],
                       'requiresRootFreshBindBeforeStaging': True, **approvals})

directory_entries = [e for e in load(SEED)['entries']
                     if e.get('id') in ('chapter:1', 'section:1004', 'scene:10040043')]
common = {'schema': 'stella.static-identity-source-review.v1',
          'reviewer': '/root/scene43_identity_first50',
          'createdAtUtc': datetime.now(timezone.utc).isoformat(),
          'scope': {'sceneId': 10040043, 'candidateArrayOffset': 0, 'count': 50,
                    'arrayOffsetIsNotScenarioNumber': True,
                    'sceneCandidateTotal': 100, 'chapterId': 1,
                    'sectionId': 1004, 'episode': '第9話 / 終わりと始まり',
                    'route': '本編：ミミVer.', 'sceneTitle': 'ミミとフェルト'},
          'observedHEAD': head, 'observedHEADIsMetadataOnly': True,
          'DcleanClaimed': False, 'DModified': False, 'CModified': False,
          'gitMutated': False, 'existingEvidenceModified': False,
          'sourceVideoDecoded': False, 'browserStarted': False,
          'runtimeStarted': False, 'newExtractionRequired': [],
          'sourceImageReviewCompleteForThisStaticScopeOnly': True,
          'fullRestorationAccepted': False, **approvals}
inputs = {'scan': info(SCAN), 'nativeScene': info(NATIVE), 'reviewScene': info(REVIEW),
          'fullFrameIndex': info(INDEX), 'directorySeed': info(SEED),
          'sceneSegments': review['sceneSegments'],
          'directoryEntrySubset': directory_entries,
          'sourceAttribution': 'Current review sourceText/stableKey/recording records match the exact merged event and its crop/fullframe link. Directory master identifies Chapter1/Episode9/Mimi route. File-number ordering is not used to infer membership.'}
OUT.mkdir(exist_ok=True)
products = []
products.append(write('resources.json', {**common, 'models': resources,
                                       'cutinReferences': cutins,
                                       'cutinIdentityObservation': {'scenarioId': 49, 'sourceImage': '006',
                                                                  'allowedFieldCandidate': None,
                                                                  'characterImageMappingAsserted': False}}))
products.append(write('ledger.json', {**common, 'inputs': inputs, 'rows': rows}))
products.append(write('candidates.json', {**common, 'count': len(candidates),
                                        'candidateStatus': 'requires-root-freshbind-and-ordinary-stage-audit',
                                        'changes': candidates}))
products.append(write('receipt.json', {**common, 'inputs': inputs,
                                      'counts': {'rowsActuallyViewed': 50,
                                                 'fullFramesActuallyViewed': 50,
                                                 'characterCandidates': 50,
                                                 'characterImageCandidates': 0,
                                                 'unknownIdentityRows': 0,
                                                 'noCharacterBlankConfirmedRows': 0,
                                                 'modelCandidates': dict(Counter(observed)),
                                                 'originalModelTexturesActuallyViewed': 11,
                                                 'originalCutinImagesActuallyViewed': 4},
                                      'runPolicy': {'nice': os.getpriority(os.PRIO_PROCESS, 0),
                                                    'cpuAffinity': sorted(os.sched_getaffinity(0)),
                                                    'noMediaOrBrowserExecution': True},
                                      'products': products,
                                      'explicitLimits': ['No body/face/motion/additional-layer/phase/timing or whole-scene acceptance.',
                                                         'No source-entry process or production playback reviewed.',
                                                         'Node49 phone is a cut-in reference, not a character_image candidate.',
                                                         'No native/review, canonical Site, Git or global configuration mutations.',
                                                         'Root must freshly guard current HEAD/rows/ownership/resources before any staging or install.']}))
print(json.dumps({'output': str(OUT), 'counts': dict(Counter(observed)),
                  'rows': len(rows), 'products': products}, ensure_ascii=False, indent=2))
