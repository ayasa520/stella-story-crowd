# scene10040043 候选数组前 50 项：静态身份原图核对

本包只覆盖 `chapter1-empty-card-foreground-candidates-e2c2b96b-v1.json`
中 scene10040043 的 **offset 0/count 50**，对应节点 4–54 中实际列出的
50 项；不包含另一个代理负责的后 50 项。

已逐项直接查看 50 张既有原录像全幅图，产生 50 个仅 `character` 的候选：
`live2d/AC_subaru01` 16 项、`live2d/AC_mimi01` 9 项、
`live2d/AC_ricardo01` 8 项、`live2d/AC_felt01` 17 项。
`character_image` 候选为 0；无角色空白确认和身份 unknown 均为 0。
这些都是等待 root freshbind 的候选，本包没有 root 或安装批准。

归属由当前 review 的 stableKey、日文原文、recording、merged event 的
crop→fullframe 链以及目录 master 对齐：第一章，第9话「終わりと始まり」，
本編：ミミVer.，场景「ミミとフェルト」。录像为
`31 9本篇「结束与开始」Ver蜜蜜.mp4`，SHA 从既有 review/index 继承，
本次未重算整段录像。没有按录像数字排序猜归属。

每项原图的路径、字节、SHA、source_frame_time 原记录值和实际查看声明在
`ledger.json`。时间值是既有 index 标注，未新探测 PTS，不能当成原生动作
或命令边界。所有图片保留完整 480×856 画面；没有用字幕 crop、speaker
名字或小选择头像作为模型证据。

对四个正向原始模型和七个排除变体的 texture_00 均实际查看。四个正向模型
的 original descriptor、MOC opaque bytes、texture_00 与 D 对应文件 SHA
全部一致，见 `resources.json`。排除服装只说明已实际看的变体，不声称看完
全部服装；MOC 只做 opaque SHA 对应，不解析/执行或据此签动作。

特殊遮挡：节点40和48有选择 UI，仍以中央大卡的菲鲁特红围巾、棕背心及
腹部等特征识别，不使用两侧小昴头像。节点49的手机 cut-in 挡住头部，
使用其下方红围巾、棕背心、黑色抹胸、腹部和毛边棕手套判静态身份。
原 `ADV_cutin_item006.png` 的银色翻盖手机、天线、紫色屏幕和黑挂绳与
该 overlay 对应；002/007/012 参考也已查看。此观察不写 character_image，
也不签命令、附加层或时间。

`candidates.json` 是小候选表；`receipt.json` 记录输入/产物摘要和范围。
`currentNativeRow`、完整 `currentReviewScenario`、日中原文及哈希 guard
均逐项保存。继承的历史 review 原件中可能出现旧 rootDecision；它们是
当前行的不可改 guard，并非本包的批准。当前包及每项全部批准字段为 false。

原图和原始纹理只读复用，没有复制大素材、运行浏览器、FFmpeg、新解码、
安装、修改 D/C、Git 或全局配置。`observedHEAD` 仅为观察 metadata，
没有声称 D clean。root 需在普通 stage/apply 前重新核对 HEAD、ownership、
完整行及资源。本包不签身体动作、表情、phase、timing、完整入场、连续播放
或整场还原。

生成日志：首次绑定排除变体 `mimi_musha01` 时，实测 D 的 MOC 不存在而
停止；只读检查确认同样的缺件见于其余四个排除服装。writer 已改为明确
记录排除变体 D 缺少 payload，正向四模型仍要求全部文件存在且 SHA 一致，
随后在 nice19/CPU0,1 下成功生成本包。没有补装缺失排除素材。
