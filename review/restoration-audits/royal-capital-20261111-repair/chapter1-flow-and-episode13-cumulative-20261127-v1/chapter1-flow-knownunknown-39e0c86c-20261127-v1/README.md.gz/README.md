# 第一章第4–13话：具体未恢复目标，只读检查

**未发现可据原版明确目标立即安装的缺线。** 本轮绑定数据 `39e0c86c2695605ed549a4560c261e57ed3d56b3`、canonical source `6630ac70f17332efa031d021af00532d42307568`。检查结束时数据已推进到 `2a3bd2861d58dcd0e84b27c0e84b89a0be8761a9`；以下保留原快照，不冒称新 HEAD 已检查。

只读核对第4–13话全部31个 section、144张目录卡、129份已导入 native：owner chart、正目标 FINISH 和合并 saved edge 后显示关系均为119对，含103条话内关系及16个跨话 portal，没有已知目标漏入图。原始 `Adv.d` 给出的范围内34条话级关系也全部已保存。目录已有线不表示分支正文已经全部可执行。

正式 UI31 审计原运行 epoch 是 `2b79f247…`，`deb3093e…` 是后续审计发布；它证明119 API/DOM line/hit pairs、144卡、16 portal。其中3个 observed-unproven **是命中采样尚未证实**，不表示3条缺线。此次没有重新运行浏览器、API、SVG或剧情验收。

实际未恢复的是15张 planned/missing-script 卡和227个空 `transition_list`：211个选项、16个 next。另6个无目标 FINISH 是合法 terminal，不能补成通向零或相邻场景的边；它们包括10030002/n42、10030006/n26、10040053/n51、10450058/n37、10040043/n110、10040036/n30。与旧静态审计的4个 terminal 保持时间边界。

## 十个具体项

以下 scene/scenario/branch ID 定位当前还原数据；正文编号多为 authored ID，不能称作已经找回的原版行号。精确 branch JSON pointer、原文、review reason、录像锚点及输入 SHA 在 `report.rootfalse.json`。

| # | 当前具体项 | 已知事实与最小缺证 |
|---|---|---|
| 1 | section1029：10290057/58/59 | 三张 Felt IF 卡缺正文、owner chart及可执行入口。现有10290008→09→10已完整供图；master 的1029→1003/1005只证明话级关系，不能接IF三卡。需要原 chart 或 transition 明确命名这些 scene 的源、目标。 |
| 2 | section1005：10050060/61/62 | 三卡全部 planned/missingScript。原 master 仅证明话1005→1006；没有任意两个 scene 的原连接。先取得精确 scene 目标及正文。 |
| 3 | section1006：10060001/02/03/04 | 四卡全部 planned/missingScript。原 master 仅证明话1006→1007；不能按位置串四卡。 |
| 4 | section1007：10070001/02/03/04/05 | 五卡全部 planned/missingScript。原 master 话级 is_end/空next不提供内部场景顺序，也不提供各个场景的结束 transition。 |
| 5 | 10100010/n7/b73，「说明状况」 | 选项 `transition_list=[]`。review明确只有右选项预览气泡，未选中、未记录后续。owner chart 两个已知出口不证明该选项具体去向；需匹配的实际选中路线或原 transition。 |
| 6 | 10020004/n19/b191 | next为空。review明确录像到CLEAR/map，但没有下一话入口；原片685–691秒锚定当前末句。需更长同路线来源或原 transition，不能从第6话目录推下一场景。 |
| 7 | 10290010/n74/b741 | next为空。原片735.9–738.5秒后终止，review明确没有CLEAR；不能补结束节点，也不能在1003/1005之间选目标。 |
| 8 | 10480028/n42/b421 | type1「完」行 next为空；既有review记录约1465秒蓝色完、1473.997秒独立CLEAR，但原生结束行身份/transition仍未知。需要原 ending transition；不能补任意scene目标。 |
| 9 | 10130005/n61/b611 | type1「完」行 next为空；既有review记录1453.997秒完及1461.997秒CLEAR，原 native ending identity未知。与上一项一样缺原 transition，不是图缺一条到相邻卡的线。 |
| 10 | 10490019/n37/b371 | 最终莱因哈鲁特对白后 next为空。既有review记录862.998–866.498秒末句，随后874.998秒CLEAR及路线奖励；原 ending identity未取得，不能制造下一scene ID。 |

这些是选出的10项，不是重新生成所有227个分支的清单。原片锚点和历史 reviewer 只保留归属，本轮没有重新识图或把旧观察升级为新验收。

## 当前供图来源与候选边界

实际代码链是 `studioGet('directory/flow')` → `readDirectoryFlow(sectionId,sha)` → `storyDirectory`：读取该话各 scene 的 owner chart，再合并 manifest 的 saved edge/删除覆盖。前端 `DirectoryFlowReader` 以 section/head 绑定结果，`directory.js.graph()` 将完整边集交给地图，包括跨话 portal。`native-directory.json` 是原 master/捕获证据的离线清点；布局及 `AdventureSection.next_section_id` 不是 scene 连线来源。`lib/preview.ts` 将空 transition 保持为 unavailable/missing，destination-free FINISH 才是 complete。

当前没有可安装 edge candidate。最小候选必须新增一条 **原版 chart/transition 已明确命名、当前119对中确实没有** 的关系；然后绑定原始 bytes、精确 source/target ID及当前 authored ID 映射，核对目标正文/入口和当前保存覆盖。新增一条猜出的线无法满足这个条件。上述末尾节点还可能需要 terminal语义恢复，但本次不据「完」、CLEAR或位置生成原版数值目标。

只在本独立目录写调查产物，未写D/C/Git、未发API/外网、未启动浏览器或查看图片。nice19、CPU0,1。原 master gzip 的摘要与旧 native-directory 来源记录相等，且其 AdventureScene 字段确实没有 next-scene 关系字段。
